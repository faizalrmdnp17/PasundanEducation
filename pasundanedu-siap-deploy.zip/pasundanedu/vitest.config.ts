import { defineConfig } from "vitest/config";
import path from "node:path";

// Isi TEST_DATABASE_URL (database KOSONG khusus uji) untuk menjalankan seluruh tes di PostgreSQL sungguhan. Tanpa itu, tes memakai PGlite di memori.
const pgUrl = process.env.TEST_DATABASE_URL ?? "";

export default defineConfig({
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
    env: {
      NODE_ENV: "test",
      DATABASE_URL: pgUrl,
      PGLITE_DIR: "memory://",
      AUTO_MIGRATE: "true",
      APP_URL: "http://localhost:3000",
      APP_SECRET: "test-secret-test-secret-test-secret-123456",
      UPLOAD_DIR: ".data/test-uploads",
      EMAIL_PROVIDER: "log",
      WHATSAPP_ACCESS_TOKEN: "test-token",
      WHATSAPP_PHONE_NUMBER_ID: "123456",
      WHATSAPP_APP_SECRET: "wa-app-secret",
      WHATSAPP_VERIFY_TOKEN: "wa-verify",
      PAYMENT_WEBHOOK_SECRET: "pay-secret",
      INLINE_WORKER: "false",
    },
    testTimeout: 60000,
    hookTimeout: 120000,
    pool: "forks",
    fileParallelism: !pgUrl, // satu database bersama: jalankan berkas tes bergantian
  },
});
