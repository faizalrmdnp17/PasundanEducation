-- PasundanEdu — skema awal (PostgreSQL 14+)
-- Semua waktu disimpan sebagai timestamptz (UTC) dan ditampilkan dalam Asia/Jakarta oleh aplikasi.
-- Harga disimpan sebagai integer rupiah (tanpa floating point).

------------------------------------------------------------------
-- Identitas dan akses
------------------------------------------------------------------
create table roles (
  id    smallint primary key,
  code  text not null unique check (code in ('mahasiswa','dosen','petugas','admin')),
  name  text not null
);
insert into roles (id, code, name) values
  (1, 'mahasiswa', 'Mahasiswa'),
  (2, 'dosen',     'Dosen'),
  (3, 'petugas',   'Petugas Administrasi'),
  (4, 'admin',     'Admin / Pengelola');

create table profiles (
  id                    uuid primary key default gen_random_uuid(),
  email                 text not null,
  full_name             text not null check (char_length(full_name) between 2 and 120),
  account_type          text not null default 'mahasiswa' check (account_type in ('mahasiswa','dosen','petugas','admin')),
  npm                   text check (npm is null or npm ~ '^[0-9A-Za-z.\-]{5,20}$'),
  nidn                  text check (nidn is null or nidn ~ '^[0-9A-Za-z.\-]{5,20}$'),
  study_program         text,
  cohort_year           smallint check (cohort_year is null or cohort_year between 1990 and 2100),
  phone                 text,
  whatsapp_number       text check (whatsapp_number is null or whatsapp_number ~ '^[1-9][0-9]{7,14}$'),
  whatsapp_verified_at  timestamptz,
  identity_verified_at  timestamptz,
  status                text not null default 'active' check (status in ('active','suspended','pending_approval','deleted')),
  email_verified_at     timestamptz,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);
create unique index profiles_email_uq on profiles (lower(email));
create unique index profiles_npm_uq   on profiles (npm)  where npm  is not null;
create unique index profiles_nidn_uq  on profiles (nidn) where nidn is not null;
create index profiles_status_idx on profiles (status);

-- Kata sandi sengaja dipisah dari tabel profil.
create table auth_credentials (
  user_id        uuid primary key references profiles(id) on delete cascade,
  password_hash  text not null,
  updated_at     timestamptz not null default now()
);

create table user_roles (
  user_id     uuid not null references profiles(id) on delete cascade,
  role_id     smallint not null references roles(id),
  granted_by  uuid references profiles(id) on delete set null,
  granted_at  timestamptz not null default now(),
  primary key (user_id, role_id)
);
create index user_roles_role_idx on user_roles (role_id);

-- Pengajuan peran dosen/petugas/admin wajib disetujui pengelola.
create table role_requests (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references profiles(id) on delete cascade,
  requested_role  text not null check (requested_role in ('dosen','petugas')),
  evidence_note   text,
  status          text not null default 'pending' check (status in ('pending','approved','rejected')),
  decided_by      uuid references profiles(id) on delete set null,
  decided_at      timestamptz,
  decision_note   text,
  created_at      timestamptz not null default now()
);
create unique index role_requests_pending_uq on role_requests (user_id, requested_role) where status = 'pending';
create index role_requests_status_idx on role_requests (status, created_at);

create table sessions (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references profiles(id) on delete cascade,
  token_hash    text not null unique,
  ip            text,
  user_agent    text,
  created_at    timestamptz not null default now(),
  last_seen_at  timestamptz not null default now(),
  expires_at    timestamptz not null,
  revoked_at    timestamptz
);
create index sessions_user_idx on sessions (user_id);
create index sessions_expires_idx on sessions (expires_at);

create table email_tokens (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references profiles(id) on delete cascade,
  purpose     text not null check (purpose in ('verify_email','reset_password')),
  token_hash  text not null unique,
  expires_at  timestamptz not null,
  used_at     timestamptz,
  created_at  timestamptz not null default now()
);
create index email_tokens_user_idx on email_tokens (user_id, purpose);

create table rate_limits (
  key            text primary key,
  count          integer not null default 0,
  window_start   timestamptz not null default now(),
  blocked_until  timestamptz
);

-- Riwayat persetujuan (append-only); persetujuan berlaku = baris terbaru per jenis.
create table consents (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references profiles(id) on delete cascade,
  consent_type  text not null check (consent_type in ('terms','privacy','whatsapp','email')),
  version       text not null default '1.0',
  granted       boolean not null,
  ip            text,
  created_at    timestamptz not null default now()
);
create index consents_user_idx on consents (user_id, consent_type, created_at desc);

------------------------------------------------------------------
-- Katalog dan layanan
------------------------------------------------------------------
create table service_categories (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique,
  name        text not null,
  icon        text not null default 'graduation-cap',
  sort_order  integer not null default 0,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table services (
  id                    uuid primary key default gen_random_uuid(),
  category_id           uuid not null references service_categories(id),
  slug                  text not null unique,
  name                  text not null,
  description           text not null,
  icon                  text not null default 'file-text',
  price_idr             integer not null default 0 check (price_idr >= 0),
  duration_minutes      integer check (duration_minutes is null or duration_minutes > 0),
  requirements          jsonb not null default '[]'::jsonb,
  estimated_process     text,
  capacity              integer check (capacity is null or capacity > 0),
  requires_appointment  boolean not null default false,
  requires_documents    boolean not null default false,
  cancellation_policy   text not null default 'Pengajuan dapat dibatalkan selama belum berstatus "Sedang diproses".',
  is_active             boolean not null default true,
  created_by            uuid references profiles(id) on delete set null,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);
create index services_category_idx on services (category_id) where is_active;
create index services_active_idx on services (is_active);

create table service_assignments (
  service_id  uuid not null references services(id) on delete cascade,
  staff_id    uuid not null references profiles(id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (service_id, staff_id)
);
create index service_assignments_staff_idx on service_assignments (staff_id);

create sequence request_number_seq start 1;

create table service_requests (
  id                uuid primary key default gen_random_uuid(),
  request_number    text not null unique,
  student_id        uuid not null references profiles(id),
  service_id        uuid not null references services(id),
  assignee_id       uuid references profiles(id) on delete set null,
  status            text not null default 'submitted' check (status in
                      ('submitted','under_review','awaiting_information','awaiting_payment','confirmed','in_progress','completed','rejected','cancelled')),
  payment_status    text not null default 'not_required' check (payment_status in
                      ('not_required','pending','awaiting_verification','paid','refunded','waived')),
  price_idr         integer not null default 0 check (price_idr >= 0),   -- harga saat pengajuan (snapshot)
  student_note      text,
  details           jsonb not null default '{}'::jsonb,
  idempotency_key   text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  completed_at      timestamptz
);
create unique index service_requests_idem_uq on service_requests (student_id, idempotency_key) where idempotency_key is not null;
create index service_requests_student_idx  on service_requests (student_id, created_at desc);
create index service_requests_assignee_idx on service_requests (assignee_id, status);
create index service_requests_service_idx  on service_requests (service_id);
create index service_requests_status_idx   on service_requests (status, created_at desc);

create table request_status_history (
  id           uuid primary key default gen_random_uuid(),
  request_id   uuid not null references service_requests(id) on delete cascade,
  from_status  text,
  to_status    text not null,
  changed_by   uuid references profiles(id) on delete set null,
  note         text,
  created_at   timestamptz not null default now()
);
create index request_status_history_req_idx on request_status_history (request_id, created_at);

-- Komunikasi pada pengajuan melalui kanal resmi (catatan staf, balasan mahasiswa).
create table request_messages (
  id          uuid primary key default gen_random_uuid(),
  request_id  uuid not null references service_requests(id) on delete cascade,
  author_id   uuid not null references profiles(id),
  body        text not null check (char_length(body) between 1 and 4000),
  visibility  text not null default 'student' check (visibility in ('student','internal')),
  created_at  timestamptz not null default now()
);
create index request_messages_req_idx on request_messages (request_id, created_at);

create table request_documents (
  id                  uuid primary key default gen_random_uuid(),
  request_id          uuid not null references service_requests(id) on delete cascade,
  uploaded_by         uuid not null references profiles(id),
  kind                text not null default 'lampiran' check (kind in ('lampiran','naskah','bukti_pembayaran','hasil')),
  original_name       text not null,
  storage_key         text not null unique,
  mime_type           text not null,
  size_bytes          integer not null check (size_bytes > 0),
  sha256              text not null,
  verification_status text not null default 'pending' check (verification_status in ('pending','verified','rejected')),
  verified_by         uuid references profiles(id) on delete set null,
  verified_at         timestamptz,
  verification_note   text,
  created_at          timestamptz not null default now()
);
create index request_documents_req_idx on request_documents (request_id);

create table availability_slots (
  id         uuid primary key default gen_random_uuid(),
  staff_id   uuid not null references profiles(id) on delete cascade,
  service_id uuid references services(id) on delete cascade,        -- null = berlaku untuk semua layanan staf tsb
  starts_at  timestamptz not null,
  ends_at    timestamptz not null,
  mode       text not null default 'online' check (mode in ('online','offline')),
  location   text,                                                  -- ruang atau tautan rapat
  capacity   integer not null default 1 check (capacity between 1 and 100),  -- 1 = bimbingan individu; >1 = kelas kecil
  status     text not null default 'open' check (status in ('open','closed')),
  created_at timestamptz not null default now(),
  check (ends_at > starts_at),
  unique (staff_id, starts_at)
);
create index availability_slots_time_idx on availability_slots (starts_at) where status = 'open';
create index availability_slots_staff_idx on availability_slots (staff_id, starts_at);

create table appointments (
  id          uuid primary key default gen_random_uuid(),
  request_id  uuid not null references service_requests(id) on delete cascade,
  slot_id     uuid not null references availability_slots(id),
  student_id  uuid not null references profiles(id),
  staff_id    uuid not null references profiles(id),
  starts_at   timestamptz not null,
  ends_at     timestamptz not null,
  status      text not null default 'booked' check (status in ('booked','cancelled','completed','no_show')),
  reminder_sent_at timestamptz,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create unique index appointments_slot_student_uq on appointments (slot_id, student_id) where status = 'booked';
create unique index appointments_request_active_uq on appointments (request_id) where status = 'booked';
create index appointments_slot_idx on appointments (slot_id) where status = 'booked';
create index appointments_student_idx on appointments (student_id, starts_at);
create index appointments_staff_idx on appointments (staff_id, starts_at);

-- Pencegah bentrok di tingkat database: jumlah janji aktif pada satu slot tidak boleh melebihi kapasitasnya.
-- Baris slot dikunci (FOR UPDATE) sehingga pemesanan serentak diserialkan.
create function enforce_slot_capacity() returns trigger language plpgsql as $$
declare cap integer; used integer;
begin
  if new.status <> 'booked' then return new; end if;
  select capacity into cap from availability_slots where id = new.slot_id for update;
  select count(*) into used from appointments where slot_id = new.slot_id and status = 'booked' and id <> new.id;
  if used >= cap then
    raise exception 'slot_full' using errcode = '23P01';
  end if;
  return new;
end $$;
create trigger appointments_capacity before insert or update of status, slot_id on appointments
  for each row execute function enforce_slot_capacity();

create table service_feedback (
  id          uuid primary key default gen_random_uuid(),
  request_id  uuid not null unique references service_requests(id) on delete cascade,
  student_id  uuid not null references profiles(id),
  rating      smallint not null check (rating between 1 and 5),
  comment     text check (comment is null or char_length(comment) <= 2000),
  created_at  timestamptz not null default now()
);

------------------------------------------------------------------
-- Pustaka dan pembelajaran
------------------------------------------------------------------
create table resource_categories (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique,
  name        text not null,
  sort_order  integer not null default 0
);

create table learning_resources (
  id            uuid primary key default gen_random_uuid(),
  category_id   uuid references resource_categories(id),
  kind          text not null check (kind in ('book','ebook','journal','video','podcast','infographic','material')),
  title         text not null,
  authors       text,
  publisher     text,
  year          smallint check (year is null or year between 1900 and 2100),
  description   text,
  access_type   text not null default 'link' check (access_type in ('link','borrow')),
  external_url  text check (external_url is null or external_url ~* '^https?://'),
  duration_minutes integer,
  license_note  text,                       -- dasar izin distribusi (wajib untuk materi yang dihosting)
  is_published  boolean not null default true,
  created_by    uuid references profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index learning_resources_kind_idx on learning_resources (kind) where is_published;
create index learning_resources_year_idx on learning_resources (year);
create index learning_resources_search_idx on learning_resources
  using gin (to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(authors,'')));

create table resource_favorites (
  user_id     uuid not null references profiles(id) on delete cascade,
  resource_id uuid not null references learning_resources(id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, resource_id)
);

create table resource_access_logs (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references profiles(id) on delete cascade,
  resource_id uuid not null references learning_resources(id) on delete cascade,
  action      text not null check (action in ('open','borrow_request')),
  created_at  timestamptz not null default now()
);
create index resource_access_logs_user_idx on resource_access_logs (user_id, created_at desc);
create index resource_access_logs_res_idx on resource_access_logs (resource_id);

create table external_integrations (
  id               uuid primary key default gen_random_uuid(),
  code             text not null unique,
  name             text not null,
  kind             text not null check (kind in ('google_classroom','moodle','google_meet','journal_repository','custom_api','lti13')),
  connection_type  text not null default 'link' check (connection_type in ('link','api','lti')),
  base_url         text check (base_url is null or base_url ~* '^https?://'),
  auth_method      text not null default 'none' check (auth_method in ('none','api_token','oauth2','oidc','lti13')),
  is_active        boolean not null default false,
  status           text not null default 'link_only' check (status in ('link_only','not_connected','connected','error')),
  instructions     text,
  config           jsonb not null default '{}'::jsonb,       -- hanya konfigurasi nonrahasia
  last_checked_at  timestamptz,
  last_error       text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create table integration_events (
  id              uuid primary key default gen_random_uuid(),
  integration_id  uuid references external_integrations(id) on delete cascade,
  level           text not null default 'info' check (level in ('info','warn','error')),
  message         text not null,
  meta            jsonb not null default '{}'::jsonb,
  created_at      timestamptz not null default now()
);
create index integration_events_idx on integration_events (integration_id, created_at desc);

create table courses (
  id              uuid primary key default gen_random_uuid(),
  code            text not null unique,
  title           text not null,
  description     text,
  kind            text not null default 'extra_class' check (kind in ('extra_class','tutoring','workshop')),
  instructor_id   uuid references profiles(id) on delete set null,
  integration_id  uuid references external_integrations(id) on delete set null,
  join_url        text check (join_url is null or join_url ~* '^https?://'),
  starts_at       timestamptz,
  capacity        integer check (capacity is null or capacity > 0),
  price_idr       integer not null default 0 check (price_idr >= 0),
  is_active       boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create table course_enrollments (
  course_id   uuid not null references courses(id) on delete cascade,
  student_id  uuid not null references profiles(id) on delete cascade,
  status      text not null default 'enrolled' check (status in ('enrolled','cancelled','completed')),
  created_at  timestamptz not null default now(),
  primary key (course_id, student_id)
);
create index course_enrollments_student_idx on course_enrollments (student_id);

create table course_resources (
  course_id   uuid not null references courses(id) on delete cascade,
  resource_id uuid not null references learning_resources(id) on delete cascade,
  primary key (course_id, resource_id)
);

------------------------------------------------------------------
-- Komunikasi
------------------------------------------------------------------
create table notifications (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references profiles(id) on delete cascade,
  type        text not null,
  title       text not null,
  body        text,
  link        text,
  read_at     timestamptz,
  created_at  timestamptz not null default now()
);
create index notifications_user_idx on notifications (user_id, created_at desc);
create index notifications_unread_idx on notifications (user_id) where read_at is null;

create table notification_preferences (
  user_id            uuid primary key references profiles(id) on delete cascade,
  email_enabled      boolean not null default true,
  whatsapp_enabled   boolean not null default false,
  reminders_enabled  boolean not null default true,
  updated_at         timestamptz not null default now()
);

create table whatsapp_templates (
  id            uuid primary key default gen_random_uuid(),
  name          text not null unique,          -- nama template di Meta Business Manager
  purpose       text not null unique check (purpose in ('request_new_staff','request_status_student','appointment_reminder')),
  language      text not null default 'id',
  body_preview  text not null,                 -- salinan teks sebagai referensi (variabel {{1}}, {{2}}, ...)
  variables     jsonb not null default '[]'::jsonb,
  status        text not null default 'draft' check (status in ('draft','submitted','approved','rejected')),
  is_active     boolean not null default false,
  updated_at    timestamptz not null default now()
);

create table notification_jobs (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid references profiles(id) on delete cascade,
  channel          text not null check (channel in ('email','whatsapp')),
  template         text not null,
  payload          jsonb not null default '{}'::jsonb,
  dedupe_key       text unique,
  status           text not null default 'pending' check (status in ('pending','processing','sent','skipped','failed','dead')),
  attempts         integer not null default 0,
  max_attempts     integer not null default 5,
  next_attempt_at  timestamptz not null default now(),
  locked_at        timestamptz,
  last_error       text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index notification_jobs_due_idx on notification_jobs (next_attempt_at) where status in ('pending','failed');
create index notification_jobs_status_idx on notification_jobs (status, created_at desc);

create table integration_message_logs (
  id                   uuid primary key default gen_random_uuid(),
  job_id               uuid references notification_jobs(id) on delete set null,
  channel              text not null check (channel in ('email','whatsapp')),
  provider             text not null,
  recipient            text not null,
  template             text not null,
  status               text not null default 'queued' check (status in ('queued','sent','delivered','read','failed','skipped')),
  provider_message_id  text,
  error                text,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);
create index integration_message_logs_pmid_idx on integration_message_logs (provider_message_id) where provider_message_id is not null;
create index integration_message_logs_created_idx on integration_message_logs (created_at desc);

create table webhook_events (
  id               uuid primary key default gen_random_uuid(),
  provider         text not null,
  event_id         text not null,
  event_type       text,
  signature_valid  boolean not null,
  payload          jsonb not null default '{}'::jsonb,
  processed_at     timestamptz,
  error            text,
  created_at       timestamptz not null default now(),
  unique (provider, event_id)
);

------------------------------------------------------------------
-- Pembayaran dan pengelolaan
------------------------------------------------------------------
create table payments (
  id              uuid primary key default gen_random_uuid(),
  request_id      uuid not null references service_requests(id) on delete cascade,
  amount_idr      integer not null check (amount_idr > 0),
  currency        text not null default 'IDR' check (currency = 'IDR'),
  provider        text not null default 'manual_transfer',
  provider_ref    text,
  status          text not null default 'pending' check (status in ('pending','awaiting_verification','paid','failed','expired','refunded')),
  proof_document_id uuid references request_documents(id) on delete set null,
  paid_at         timestamptz,
  verified_by     uuid references profiles(id) on delete set null,
  idempotency_key text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create unique index payments_provider_ref_uq on payments (provider, provider_ref) where provider_ref is not null;
create unique index payments_idem_uq on payments (request_id, idempotency_key) where idempotency_key is not null;
-- Maksimal satu pembayaran yang masih berjalan atau sudah lunas per pengajuan.
create unique index payments_active_uq on payments (request_id) where status in ('pending','awaiting_verification','paid');
create index payments_status_idx on payments (status, created_at desc);

create table payment_events (
  id                 uuid primary key default gen_random_uuid(),
  payment_id         uuid not null references payments(id) on delete cascade,
  provider           text not null,
  provider_event_id  text,
  event_type         text not null,
  payload            jsonb not null default '{}'::jsonb,
  created_at         timestamptz not null default now()
);
create unique index payment_events_provider_uq on payment_events (provider, provider_event_id) where provider_event_id is not null;
create index payment_events_payment_idx on payment_events (payment_id, created_at);

create table announcements (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  body          text,
  category      text not null default 'umum' check (category in ('akademik','beasiswa','perpustakaan','seminar','umum')),
  event_date    date,
  is_published  boolean not null default true,
  created_by    uuid references profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index announcements_pub_idx on announcements (is_published, event_date desc);

create table audit_logs (
  id           uuid primary key default gen_random_uuid(),
  actor_id     uuid references profiles(id) on delete set null,
  actor_role   text,
  action       text not null,
  entity_type  text,
  entity_id    text,
  meta         jsonb not null default '{}'::jsonb,
  ip           text,
  created_at   timestamptz not null default now()
);
create index audit_logs_created_idx on audit_logs (created_at desc);
create index audit_logs_actor_idx on audit_logs (actor_id, created_at desc);
create index audit_logs_entity_idx on audit_logs (entity_type, entity_id);

-- Hanya pengaturan nonrahasia. Kunci yang menyiratkan rahasia ditolak oleh database.
create table system_settings (
  key         text primary key check (key !~* '(secret|token|password|passwd|api_?key|private)'),
  value       jsonb not null,
  updated_by  uuid references profiles(id) on delete set null,
  updated_at  timestamptz not null default now()
);
