# Panduan deploy PasundanEdu dengan Docker

Paket ini menjalankan tiga layanan sekaligus: **aplikasi** (Next.js), **PostgreSQL 16**, dan **Caddy** (HTTPS otomatis). Berkas unggahan mahasiswa dan database disimpan di volume Docker, jadi tetap ada saat kontainer dibangun ulang.

> PasundanEdu adalah proyek mandiri, **bukan** situs resmi kampus. Jangan memakai domain, nama, atau logo institusi tanpa izin tertulis, dan jangan aktifkan `institution_verified` di Admin > Pengaturan sebelum pengelola institusi resmi mengizinkannya.

## Yang Anda butuhkan

- Server Linux (mis. Ubuntu 22.04/24.04) dengan RAM disarankan 2 GB atau lebih (proses build Next.js cukup berat).
- Docker Engine dan plugin Compose (`docker compose version` harus jalan). Panduan: https://docs.docker.com/engine/install/
- **Domain atau subdomain** yang record DNS A/AAAA-nya sudah menunjuk ke IP server. Tanpa itu HTTPS tidak bisa terbit.
- Port **80 dan 443** terbuka di firewall server.
- Akun **SMTP** (untuk email verifikasi dan reset kata sandi). Tanpa email, mahasiswa tidak bisa verifikasi akun.

## Langkah

**1. Taruh folder ini di server** (mis. `/opt/pasundanedu`) lewat `scp`, `rsync`, atau git, lalu masuk ke foldernya.

**2. Buat `.env`**

```bash
cp .env.production.example .env
openssl rand -hex 24      # untuk POSTGRES_PASSWORD
openssl rand -base64 48   # untuk APP_SECRET
nano .env                 # isi DOMAIN, POSTGRES_PASSWORD, APP_SECRET, SMTP_URL, EMAIL_FROM
chmod 600 .env
```

**3. Bangun dan jalankan**

```bash
docker compose up -d --build
```

Pertama kali butuh beberapa menit. Migrasi database berjalan otomatis saat aplikasi mulai.

**4. Buat admin pertama dan isi katalog layanan (sekali saja)**

```bash
./deploy/first-run.sh
```

Skrip menanyakan email, nama, dan kata sandi admin (tidak tampil di layar).

**5. Periksa**

```bash
curl https://DOMAIN-ANDA/api/health
# harus: {"status":"ok","database":"up","email":"ready",...}
```

Jika `"email":"not_configured"`, `SMTP_URL` belum benar. Lalu buka `https://DOMAIN-ANDA/masuk` dan masuk sebagai admin. Tinjau layanan, FAQ, Kebijakan Privasi, dan Syarat & Ketentuan sebelum dibuka untuk mahasiswa (lihat daftar periksa lengkap di `docs/DEPLOYMENT.md`, bagian 3).

## Perintah sehari-hari

```bash
docker compose ps                    # status layanan
docker compose logs -f app           # log aplikasi
docker compose restart app           # mulai ulang aplikasi
docker compose up -d --build         # terapkan versi baru setelah mengganti berkas (migrasi otomatis)
./deploy/backup.sh                   # cadangan database + unggahan ke ./backups
docker compose down                  # hentikan (data tetap aman di volume)
```

Jangan menjalankan `docker compose down -v`: opsi `-v` **menghapus semua volume**, termasuk database dan dokumen mahasiswa.

## Cadangan

`./deploy/backup.sh` menyimpan dump database dan arsip unggahan ke `./backups` (14 hari terakhir). Jadwalkan dengan cron, lalu salin hasilnya ke tempat lain di luar server. Pemulihan database:

```bash
docker compose exec -T db pg_restore -U pasundanedu -d pasundanedu --clean --if-exists --no-owner < backups/db-TANGGAL.dump
```

Latih pemulihan sekali di server uji sebelum Anda benar-benar membutuhkannya.

## Masalah umum

| Gejala | Penyebab / solusi |
|---|---|
| Browser menampilkan galat sertifikat | DNS domain belum menunjuk ke server, atau port 80/443 tertutup. Lihat `docker compose logs caddy`. |
| `POSTGRES_PASSWORD` / `DOMAIN` error saat `up` | Nilai belum diisi di `.env`. |
| Aplikasi terus restart | `docker compose logs app`. Biasanya `APP_SECRET` kurang dari 32 karakter atau `EMAIL_PROVIDER=log` (ditolak di produksi). |
| Lupa kata sandi admin | Jalankan `./deploy/first-run.sh` lagi dengan email admin yang sama; kata sandinya diganti. |
| Percobaan coba-coba di komputer sendiri | Isi `DOMAIN=localhost`; Caddy memakai sertifikat lokal, browser akan memberi peringatan yang wajar. |

## Yang sudah dan belum diuji

Sudah diuji (di lingkungan pembuatan): build produksi, migrasi dan seed pada PostgreSQL 16, server produksi dengan login admin, halaman admin, header keamanan, dan `docker compose config`.

**Belum diuji:** `docker compose up --build` itu sendiri (registry Docker tidak terjangkau dari lingkungan pembuatan), penerbitan sertifikat Caddy, pengiriman email SMTP sungguhan, dan pemulihan cadangan. Jika ada galat saat langkah 3, kirimkan keluaran `docker compose logs`-nya.
