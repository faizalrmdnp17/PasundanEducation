# Instalasi

## A. Pengembangan di komputer sendiri

Prasyarat: Node.js 20.9 atau lebih baru (diuji pada Node 22) dan npm. Tidak perlu database terpisah.

```bash
npm install
npm run dev
```

`npm run dev` menjalankan `db:setup` terlebih dahulu: menerapkan migrasi, mengisi katalog (10 layanan contoh, kategori, templat WhatsApp berstatus draf, daftar integrasi nonaktif, pengaturan awal dengan **pembayaran nonaktif**), dan, hanya bila tabel pengguna masih kosong, membuat 6 akun demo. Aplikasi berjalan di <http://localhost:3000>. Data tersimpan di `.data/pglite` (PGlite, PostgreSQL tertanam) dan berkas unggahan di `.data/uploads`. Hapus folder `.data` untuk mengulang dari awal.

Akun demo (fiktif, kata sandi sama `DemoPasundan2026`):

| Peran | Email |
|---|---|
| Admin | `admin@example.test` |
| Petugas | `petugas@example.test` |
| Dosen | `dosen@example.test`, `dosen2@example.test` |
| Mahasiswa | `mahasiswa@example.test`, `mahasiswa2@example.test` |

Email tidak benar-benar dikirim di pengembangan. Tautan verifikasi dan reset kata sandi tercetak di terminal tempat `npm run dev` berjalan (`[email:simulasi] …`). Akun demo sudah terverifikasi.

Variabel lingkungan opsional untuk pengembangan: salin `.env.example` menjadi `.env.local`. Aplikasi (Next.js) dan skrip CLI (`db:setup`, `db:migrate`, `db:seed`, `worker`) sama-sama memuatnya.

## B. Menjalankan tes

```bash
npm run typecheck
npm test                                   # 89 tes, PGlite di memori, ±20 detik
```

Tes di PostgreSQL sungguhan (gunakan database **kosong** yang khusus untuk uji, bukan database aplikasi):

```bash
createdb pasundanedu_test
TEST_DATABASE_URL=postgres://pengguna@localhost:5432/pasundanedu_test npm test
```

Tes end-to-end HTTP terhadap server yang sedang berjalan. Rahasia webhook di sisi skrip harus sama dengan yang dipakai server; bagian yang rahasianya tidak diisi akan **dilewati dan dilaporkan**, bukan dianggap lulus.

```bash
npm run build
export APP_SECRET=$(openssl rand -base64 48) COOKIE_SECURE=false EMAIL_PROVIDER=log
export WHATSAPP_APP_SECRET=uji-1 WHATSAPP_VERIFY_TOKEN=uji-2 PAYMENT_WEBHOOK_SECRET=uji-3 CRON_SECRET=uji-4
npm run db:setup && npm start -- -p 3100 &
E2E_BASE_URL=http://localhost:3100 npm run test:e2e
```

Catatan: tes e2e membuat pengguna dan pengajuan uji, jadi jalankan pada database pengembangan/uji, **bukan** produksi. `COOKIE_SECURE=false` hanya diperlukan karena `next start` berjalan sebagai produksi tetapi diakses lewat `http://localhost`.

Uji tampilan (Playwright, Python) ada di `scripts/ui/`; lihat komentar di kepala tiap berkas. Contoh audit overflow di 390 px:

```bash
pip install playwright && playwright install chromium
E2E_BASE_URL=http://localhost:3100 python3 scripts/ui/overflow.py
```

## C. Produksi (ringkas)

Panduan lengkap ada di [DEPLOYMENT.md](DEPLOYMENT.md). Urutan minimal:

1. Siapkan PostgreSQL dan buat database kosong.
2. Atur variabel lingkungan (lihat `.env.example`): minimal `DATABASE_URL`, `APP_SECRET`, `APP_URL`, dan email (`EMAIL_PROVIDER=smtp`, `SMTP_URL`). Jalankan perintah di bawah dengan `NODE_ENV=production`.
3. `npm ci && npm run build`
4. `npm run db:migrate`
5. `SEED_ADMIN_EMAIL=… SEED_ADMIN_PASSWORD=… npm run db:seed` (membuat katalog awal dan satu admin), atau `ADMIN_PASSWORD=… npm run admin:create -- email "Nama"`. Seed demo **ditolak** di produksi dan pada database berisi pengguna nyata.
6. `npm start` di belakang reverse proxy HTTPS. Jalankan `npm run worker` sebagai proses terpisah atau jadwalkan `POST /api/cron/process-jobs`.
7. Masuk sebagai admin, buka *Admin > Pengaturan*, dan baca daftar periksa di DEPLOYMENT.md sebelum membuka pendaftaran.

## Pemecahan masalah

| Gejala | Penyebab umum |
|---|---|
| Setelah masuk, halaman kembali ke `/masuk` pada produksi | Diakses lewat `http://` sementara cookie `Secure` aktif. Gunakan HTTPS, atau `COOKIE_SECURE=false` hanya untuk uji lokal. |
| `APP_SECRET wajib diatur` saat start produksi | Isi `APP_SECRET` minimal 32 karakter. |
| Email verifikasi tidak datang | `EMAIL_PROVIDER` belum `smtp`/`SMTP_URL` kosong. Periksa `GET /api/health` (`email: not_configured`) dan log server. |
| Pesan WhatsApp tidak terkirim | Lihat bagian "Uji pertama" di [WHATSAPP.md](WHATSAPP.md); biasanya templat belum `approved` dan aktif atau kredensial belum diisi. |
| `no space left on device` / unggahan gagal | Periksa ruang disk `UPLOAD_DIR`. |
| Peringatan "memakai PGlite" di log produksi | `DATABASE_URL` belum diatur. Gunakan PostgreSQL. |
