# Integrasi LMS: apa yang ada dan apa yang belum

## Ringkasan jujur

| Platform | Mode | Yang sebenarnya terjadi |
|---|---|---|
| Google Classroom | Tautan (`link_only`) | Admin mengisi URL kelas; mahasiswa membuka tautan di tab baru. **Bukan** integrasi API. |
| Google Meet | Tautan (`link_only`) | Tautan rapat dicantumkan pada slot konsultasi. **Bukan** integrasi API. |
| Repositori jurnal / perpustakaan digital | Tautan (`link_only`) | Tautan ke sumber yang aksesnya sah. Hormati lisensi masing-masing penyedia. |
| Moodle | API (`api_token`), **cek koneksi saja** | Memanggil `core_webservice_get_site_info` untuk memeriksa bahwa URL dan token valid. Tanpa token tidak mengaku terhubung. **Tidak ada** sinkronisasi kursus, nilai, atau pendaftaran. |
| LTI 1.3 | Belum diimplementasikan | Entri disediakan sebagai penanda; status tetap `not_connected`. |
| Webhook dari LMS | Tidak ada | Tidak ada endpoint penerima peristiwa LMS. |
| Halaman daftar kursus (`courses`) | Tidak ada | Belum dibuat. |

Sistem **tidak** menganggap semua situs dapat ditampilkan dalam iframe. Banyak LMS mengirim `X-Frame-Options`/`frame-ancestors` yang melarangnya, dan CSP aplikasi ini juga tidak mengizinkan sumber lain di `connect-src`. Karena itu tautan dibuka di tab baru.

## Mengatur tautan (Classroom, Meet, repositori)

1. Admin > Integrasi LMS, buka entri yang sesuai.
2. Isi **URL dasar** (`http://` atau `https://`; gunakan https), tulis petunjuk singkat untuk mahasiswa, dan centang **aktif**.
3. Tautan aktif tampil di halaman **Informasi > Platform belajar** (dibuka di tab baru, ditandai sebagai tautan eksternal). Entri nonaktif atau tanpa URL tidak tampil. Entri bawaan dibuat **nonaktif**.

## Memeriksa koneksi Moodle

1. Minta pengelola Moodle mengaktifkan *Web services*, membuat pengguna layanan dengan peran terbatas, dan menerbitkan **token**. Berikan hak minimum (cukup `core_webservice_get_site_info` untuk uji koneksi).
2. Setel `MOODLE_WS_TOKEN` di server. Token **tidak** disimpan di basis data dan tidak pernah dikirim ke browser. Di produksi, cek koneksi menolak URL `http://` dan alamat jaringan internal (localhost, 10.x, 172.16-31.x, 192.168.x, 169.254.x, `.internal`/`.local`) agar token tidak bocor atau dipakai menjajaki jaringan internal; ini pagar dasar, bukan pengganti firewall keluar (egress) di server.
3. Admin > Integrasi LMS > Moodle: isi URL situs (mis. `https://lms.contoh.ac.id`), aktifkan, lalu tekan **Cek koneksi**.
4. Hasil: `connected` (respons valid dari Moodle), `error` (galat tercatat di kolom *last_error*), atau `not_connected` (token/URL belum diisi).

Pengujian otomatis memakai `fetch` tiruan (sukses, galat, dan jaringan mati) dan memastikan Moodle tanpa token tidak mengaku terhubung. **Belum diuji terhadap instalasi Moodle sungguhan.**

## Jalur pengembangan lanjutan (belum dikerjakan)

1. **Sinkronisasi kursus Moodle:** tambahkan fungsi adapter (`core_enrol_get_users_courses`, dst.), tabel `courses`/`enrollments`, dan halaman kursus. Perlu persetujuan pengelola LMS tentang data yang boleh dibaca (nilai bersifat sensitif).
2. **LTI 1.3:** implementasi *launch* OIDC, validasi JWT dan JWKS, serta registrasi platform di LMS. Perlu akses admin LMS.
3. **Webhook LMS:** endpoint penerima peristiwa dengan tanda tangan, mengikuti pola webhook WhatsApp (verifikasi HMAC, deduplikasi `webhook_events`).
