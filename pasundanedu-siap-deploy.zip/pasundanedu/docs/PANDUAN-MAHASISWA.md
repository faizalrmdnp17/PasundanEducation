# Panduan mahasiswa

> PasundanEdu adalah aplikasi layanan pendidikan digital. Selama pengelola belum memverifikasi identitas institusi, aplikasi menyatakan hal itu di halaman masuk dan Informasi. Untuk urusan yang menyangkut keputusan akademik resmi, ikuti ketentuan dan petugas kampus.

## 1. Membuat akun dan masuk

1. Buka halaman **Daftar**. Logo PasundanEdu ada di bagian atas formulir.
2. Pilih jenis akun **Mahasiswa**, isi nama, email, kata sandi, NPM, program studi, angkatan, dan nomor WhatsApp (opsional).
3. Kata sandi minimal sesuai petunjuk di formulir dan tidak boleh memuat bagian dari email Anda.
4. Centang persetujuan Syarat dan Ketentuan serta Kebijakan Privasi. Persetujuan **email** dan **WhatsApp** terpisah dan opsional; Anda dapat mengubahnya kapan saja di **Akun**.
5. Tekan **Daftar**. Anda langsung masuk, tetapi **mengirim pengajuan baru memerlukan email yang sudah terverifikasi**. Buka tautan verifikasi yang dikirim ke email Anda (periksa folder spam). Bila email tidak tiba, buka **Akun > Verifikasi email > Kirim ulang tautan verifikasi**. Jika aplikasi menyatakan email belum dapat dikirim, hubungi pengelola.
6. Lupa kata sandi: tekan **Lupa kata sandi?** di halaman masuk, lalu ikuti tautan yang dikirim. Tautan hanya berlaku sekali.

Akun dosen dan petugas tidak dibuat dari halaman ini untuk mahasiswa; akun tersebut aktif setelah disetujui pengelola.

## 2. Mengajukan layanan

1. Buka **Layanan**, pilih layanan (mis. Konsultasi Dosen Wali, Surat Keterangan Mahasiswa), dan baca persyaratan, estimasi proses, serta kebijakan pembatalan.
2. Untuk layanan berjadwal, pilih **hari lalu slot** yang tersedia. Slot yang penuh tidak ditampilkan.
3. Isi topik/keperluan bila diminta, lalu tekan **Kirim pengajuan**. Menekan tombol dua kali tidak membuat pengajuan ganda.
4. Anda mendapat nomor pengajuan berformat `PE-TAHUN-NNNNN`.

Biaya: pada awalnya semua layanan **tanpa biaya** karena pembayaran nonaktif. Bila pengelola mengaktifkan pembayaran, tampilan layanan dan pengajuan menunjukkan nominal dan caranya.

## 3. Memantau pengajuan

Buka **Riwayat**, lalu pilih pengajuan. Halaman detail menampilkan:

- **Jejak pengajuan**: setiap perubahan status beserta waktu, petugas, dan catatan.
- **Pesan**: percakapan dengan penanggung jawab. Catatan internal staf tidak pernah terlihat oleh Anda.
- **Dokumen**: unggah lampiran (PDF, PNG, JPG, atau DOCX, maksimal 5 MB). Jenis berkas diperiksa dari isinya. Unduh berkas melalui tautan di halaman; tautan itu berlaku singkat dan hanya untuk Anda.
- **Rincian**, termasuk jadwal dan penanggung jawab.
- **Pembatalan**: tersedia selama status masih memungkinkan (mis. sebelum "Sedang diproses").
- **Penilaian**: setelah layanan selesai, beri nilai 1 sampai 5 dan komentar.

Status yang mungkin: Terkirim, Ditinjau, Menunggu informasi, Menunggu pembayaran, Terkonfirmasi, Sedang diproses, Selesai, Ditolak, Dibatalkan. Saat status berubah Anda menerima notifikasi di aplikasi, dan di email/WhatsApp bila Anda mengaktifkannya dan pengelola telah mengaturnya.

## 4. Jadwal, Pustaka, Informasi

- **Jadwal**: daftar konsultasi yang sudah dipesan.
- **Pustaka**: cari buku, jurnal, dan konten belajar; simpan sebagai favorit; buka sumber yang berupa tautan; atau **pinjam** sumber yang dipinjam melalui pengajuan layanan. Hormati lisensi sumber.
- **Informasi**: pengumuman kampus dan, bila diaktifkan pengelola, tautan eksternal "Platform belajar" (dibuka di tab baru; ini hanya tautan).

## 5. Akun, privasi, notifikasi

- **Akun > Profil**: ubah nama, program studi, angkatan, telepon, nomor WhatsApp. Mengganti nomor WhatsApp **mencabut persetujuan WhatsApp** sampai Anda menyetujui ulang.
- **Preferensi notifikasi**: pilih email, WhatsApp, pengingat jadwal.
- **WhatsApp**: balas `STOP` atau `berhenti` ke pesan WhatsApp dari PasundanEdu untuk berhenti menerima pesan.
- Jangan mengirim dokumen pribadi lewat WhatsApp; unggah di bagian Dokumen pengajuan.
- **Ganti kata sandi**: di Akun, memerlukan kata sandi saat ini.

## 6. Hal yang tidak dilakukan layanan ini

- **Cek Kemiripan Naskah** menghasilkan indikator kemiripan, **bukan jaminan bebas plagiarisme**. Penilaian akhir tetap oleh dosen/kampus.
- **Bimbingan Skripsi** adalah pendampingan. Anda tetap penulis tunggal karya Anda; layanan ini tidak membuatkan skripsi atau data.
- Tombol "Hubungi lewat WhatsApp" hanya membuka percakapan di ponsel Anda; itu bukan jaminan pesan dibalas.

## 7. Masalah umum

| Masalah | Yang dapat dilakukan |
|---|---|
| Tombol **Kirim pengajuan** tidak aktif | Verifikasi email Anda dulu; untuk layanan berjadwal pilih slot. |
| Slot yang saya pilih hilang | Slot baru saja dipesan orang lain; pilih slot lain. |
| Berkas ditolak | Gunakan PDF/PNG/JPG/DOCX asli di bawah 5 MB. Berkas yang hanya diganti ekstensinya ditolak. |
| Tidak menerima WhatsApp | Pastikan persetujuan WhatsApp aktif di Akun dan pengelola sudah mengaktifkan WhatsApp; tanpa itu pesan tidak dikirim. |
| Salah pengajuan | Batalkan dari halaman detail selama masih diperbolehkan, atau kirim pesan ke penanggung jawab. |
