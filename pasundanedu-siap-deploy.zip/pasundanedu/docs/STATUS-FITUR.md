# Status fitur: yang berfungsi, yang butuh kredensial, yang belum ada

Dokumen ini sengaja jujur. "Berfungsi" berarti sudah diimplementasikan **dan** diuji (lihat [LAPORAN-PENGUJIAN.md](LAPORAN-PENGUJIAN.md)). Tidak ada fitur di sini yang hanya berupa tombol simulasi tanpa label.

## 1. Berfungsi dan sudah diuji

| Area | Yang bekerja |
|---|---|
| Akun | Registrasi mahasiswa (aktif langsung), registrasi dosen/petugas (masuk antrean persetujuan admin, tanpa peran sampai disetujui), masuk/keluar, verifikasi email (token sekali pakai), lupa dan atur ulang kata sandi (token sekali pakai, sesi lama dicabut), ganti kata sandi. Kata sandi di-hash scrypt pada tabel terpisah. Pembatasan laju login: 5 kegagalan per 15 menit per email dan 40 per IP. Pesan galat login sama untuk email tak dikenal dan kata sandi keliru. |
| Hak akses | Peran mahasiswa/dosen/petugas/admin dicek di server pada setiap permintaan. Pengguna lain mendapat 404 (bukan 403) untuk pengajuan yang bukan miliknya. Catatan internal hanya terlihat staf. Admin tidak dapat mengubah akunnya sendiri; mengubah peran memaksa pengguna masuk ulang. Perlindungan CSRF (asal permintaan diperiksa), anti open-redirect pada `?next=`. |
| Layanan dan pengajuan | Katalog 10 layanan contoh, pengajuan dengan nomor `PE-TAHUN-NNNNN`, idempotensi (header `Idempotency-Key`; klik ganda tidak menggandakan), pemilihan slot jadwal tanpa bentrok (tes konkurensi + trigger kapasitas di database), mesin status dengan transisi sah saja, riwayat status ("jejak pengajuan"), pesan dua arah, catatan internal staf, jadwal ulang, pembatalan oleh mahasiswa pada status yang diizinkan, penilaian setelah selesai. |
| Dokumen privat | PDF/PNG/JPG/DOCX maksimal 5 MB. Jenis berkas dicek dari isi (magic bytes), bukan hanya ekstensi; berkas teks berkedok `.pdf` ditolak. Unduhan lewat URL bertanda tangan HMAC yang terikat pada pengguna dan berumur pendek, ditambah pemeriksaan hak akses. Respons `attachment` + `nosniff`. Staf dapat memverifikasi/menolak dokumen. |
| Pustaka | Buku, jurnal, konten belajar: pencarian, tab kategori, pengurutan, paginasi, favorit, catat akses, dan "pinjam" yang membuat pengajuan layanan. |
| Notifikasi | Notifikasi dalam aplikasi (lonceng, tandai dibaca). Antrean `notification_jobs` dengan klaim `SKIP LOCKED`, percobaan ulang backoff eksponensial, status `dead`, pengantrean ulang oleh admin, pengingat jadwal 24 jam sebelumnya (idempoten). Preferensi per pengguna (email, WhatsApp, pengingat). |
| Webhook WhatsApp (sisi terima) | Verifikasi tantangan GET, tanda tangan `X-Hub-Signature-256` (HMAC) wajib, deduplikasi event, pembaruan status pengiriman yang tidak mundur, dan balasan `STOP`/`berhenti` yang mencabut persetujuan penerima. Diuji dengan payload yang ditandatangani sendiri, **bukan** dengan Meta sungguhan. |
| Admin | Pengguna dan persetujuan peran, katalog layanan, pustaka, pengumuman, verifikasi pembayaran manual, status/templat/log/antrean WhatsApp, daftar integrasi, jejak audit, pengaturan sistem, laporan (status, layanan terpopuler 90 hari, rata-rata waktu penyelesaian, penilaian, grafik 14 hari). |
| Keamanan HTTP | CSP, HSTS (produksi), `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy`, tanpa `X-Powered-By`. Cookie sesi `HttpOnly`, `SameSite=Lax`, `Secure` di produksi. Rahasia API tidak ada di kode frontend dan kunci rahasia ditolak oleh constraint pada tabel pengaturan. |
| Tampilan | Responsif (0 halaman dengan overflow horizontal di lebar 390 px dari 32 halaman yang diaudit), navigasi bawah di ponsel, mode gelap mengikuti sistem, logo PasundanEdu di atas halaman Registrasi dan Masuk. |
| Pelaporan jujur | Bila email tidak dapat dikirim (mis. SMTP belum diatur), pendaftaran tetap berhasil tetapi aplikasi **tidak** mengklaim email terkirim, `/api/health` melaporkan `email: not_configured`, dan "kirim ulang verifikasi" mengembalikan galat 503. Log email provider `log` diberi label "simulasi". |

## 2. Berfungsi, tetapi butuh kredensial atau persetujuan pihak ketiga

| Fitur | Apa yang diperlukan | Perilaku tanpa itu |
|---|---|---|
| Email sungguhan | `EMAIL_PROVIDER=smtp` dan `SMTP_URL` dari penyedia email kampus/transaksional. Jalur SMTP sudah diuji end-to-end terhadap **server SMTP penampung lokal** (email verifikasi tiba, tautan berfungsi, akun terverifikasi); **belum** diuji dengan penyedia nyata, sehingga SPF/DKIM/DMARC dan masuk-tidaknya ke kotak masuk menjadi tanggung jawab pengelola domain. | Di pengembangan: tercetak di konsol (simulasi). Di produksi provider `log` ditolak; email gagal dan dilaporkan sebagai gagal. |
| WhatsApp (Cloud API resmi) | Akun WhatsApp Business Platform, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_APP_SECRET`, `WHATSAPP_VERIFY_TOKEN`, dan **templat pesan yang disetujui Meta**. Admin mengaktifkan templat setelah disetujui. Nomor kerja staf harus diverifikasi admin. Persetujuan (consent) pengguna wajib. Lihat [WHATSAPP.md](WHATSAPP.md). | Status "belum terhubung"; tidak ada pesan terkirim. Templat bawaan berstatus `draft` dan nonaktif. Pengujian pengiriman nyata **belum** dilakukan (memerlukan akun Anda). |
| Pembayaran transfer manual | Admin mengaktifkan `payments_enabled` dan mengisi info rekening di Admin > Pengaturan. | Nonaktif secara bawaan: semua pengajuan tanpa biaya, harga di-snapshot 0. Harga di katalog adalah **contoh** dan wajib ditinjau pengelola. |
| Webhook gateway pembayaran generik | `PAYMENT_WEBHOOK_SECRET` dan adapter gateway yang Anda tulis. | Tanda tangan salah ditolak 401; saat pembayaran nonaktif ditolak 409. Tidak ada adapter siap pakai. |
| Moodle | URL situs dan token layanan web (`MOODLE_WS_TOKEN`) dari pengelola LMS. | Hanya **cek konektivitas** (`core_webservice_get_site_info`). Tanpa token tidak mengaku terhubung. |
| Antrean dan pengingat | Proses `npm run worker`, atau penjadwal eksternal memanggil `POST /api/cron/process-jobs` dengan `CRON_SECRET`. Pada server Node tunggal, "inline worker" ikut memproses. | Pada hosting serverless tanpa cron, pesan menumpuk di antrean. |
| Pernyataan identitas institusi | Pengelola memverifikasi di Admin > Pengaturan (`institution_verified`). | Halaman masuk menyatakan identitas institusi belum diverifikasi. |
| Produksi | PostgreSQL (`DATABASE_URL`), `APP_SECRET`, HTTPS, folder `UPLOAD_DIR` yang dicadangkan. | PGlite hanya untuk pengembangan; aplikasi mencetak peringatan bila dipakai di produksi. |

## 3. Belum ada (tidak diklaim)

- Sinkronisasi kursus/nilai Moodle, halaman daftar kursus, LTI 1.3, dan endpoint webhook LMS. Entri "LTI 1.3" di Admin > Integrasi berstatus *belum diimplementasikan*.
- Google Classroom dan Google Meet hanya **tautan** (`link_only`), bukan integrasi API. Tidak semua situs dapat ditampilkan dalam iframe, sehingga tautan dibuka di tab baru.
- Adapter gateway pembayaran (Midtrans/Xendit), pembayaran kartu, dan penyimpanan nomor kartu (sengaja tidak pernah disimpan).
- Penyimpanan berkas S3/Supabase (saat ini disk lokal).
- Verifikasi nomor WhatsApp mahasiswa dengan OTP (nomor mahasiswa dipakai atas persetujuan, tanpa verifikasi kepemilikan).
- Autentikasi dua faktor, integrasi SSO kampus, dan impor data mahasiswa dari sistem akademik.
- CSP berbasis nonce (CSP saat ini mengizinkan `script-src 'unsafe-inline'` karena kebutuhan hidrasi Next.js).
- Mesin cek kemiripan otomatis: layanan "Cek Kemiripan Naskah" adalah **permintaan yang ditangani petugas**. Hasilnya hanya indikator, bukan jaminan bebas plagiarisme. Tidak ada layanan pembuatan skripsi atau data.

## 4. Konten yang perlu ditinjau manusia sebelum dipakai

- FAQ, Kebijakan Privasi, dan Syarat & Ketentuan adalah **draf**. Tinjau oleh pengelola dan penasihat hukum (UU PDP) sebelum rilis.
- Teks layanan, estimasi proses, kebijakan pembatalan, dan harga di katalog adalah contoh.
- Data demo (`@example.test`) hanya untuk pengembangan; `db:seed:demo` ditolak di produksi kecuali `ALLOW_DEMO_SEED=true`.
