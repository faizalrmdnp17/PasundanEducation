# Deployment produksi

Dokumen ini menjelaskan cara menjalankan PasundanEdu secara aman. Aplikasi berupa satu proses Node.js (Next.js) ditambah PostgreSQL dan folder berkas privat. Pembuat aplikasi tidak menyediakan hosting; Anda atau pengelola kampus yang memilih server.

## 1. Arsitektur minimal

```
Internet ─► reverse proxy HTTPS (nginx/Caddy/Cloudflare) ─► Next.js (npm start, port 3000) ─► PostgreSQL
                                                              │
                                                              └─► UPLOAD_DIR (disk lokal, privat)
Penjadwal (cron/systemd) atau `npm run worker` ─► antrean notifikasi ─► SMTP / WhatsApp Cloud API
```

- **Wajib di belakang reverse proxy HTTPS.** Cookie sesi `Secure` dan HSTS aktif di produksi. Proxy harus mengisi `X-Forwarded-For`, `X-Forwarded-Host`, dan `X-Forwarded-Proto`; atur `TRUSTED_PROXY_COUNT` sesuai jumlah proxy. Jangan membuka port aplikasi langsung ke internet: tanpa proxy tepercaya, pembatasan laju per IP dapat dikelabui.
- **Satu instans aplikasi untuk berkas lokal.** Berkas unggahan disimpan di disk (`UPLOAD_DIR`). Bila Anda menjalankan beberapa instans, semuanya harus berbagi volume yang sama; adapter S3/Supabase belum ada. Hosting serverless dengan disk sementara (mis. fungsi tanpa volume) **tidak cocok** untuk versi ini.
- **Gunakan PostgreSQL**, bukan PGlite. PGlite hanya untuk pengembangan: satu proses, tersimpan di berkas lokal. Aplikasi mencetak peringatan bila produksi berjalan tanpa `DATABASE_URL`.

## 2. Langkah pemasangan

```bash
# di server
git clone <repo> pasundanedu && cd pasundanedu
npm ci
cp .env.example .env.production   # lalu isi nilai asli; jangan commit. Alternatif: variabel lingkungan dari systemd/orkestrator
export NODE_ENV=production        # agar skrip CLI membaca .env.production dan pagar produksi aktif
npm run build
npm run db:migrate                # menerapkan migrasi dengan kunci advisory + checksum
SEED_ADMIN_EMAIL=admin@contoh.id SEED_ADMIN_PASSWORD='…kuat…' npm run db:seed
npm start                         # port 3000; atur lewat `-p`
```

Skrip CLI (`db:migrate`, `db:seed`, `admin:create`, `worker`) memuat `.env`, `.env.local`, dan `.env.production` dengan aturan yang sama seperti Next.js; variabel yang sudah ada di lingkungan proses tidak ditimpa. Jangan lupa `NODE_ENV=production` untuk perintah-perintah ini.

Hapus `SEED_ADMIN_*` dari lingkungan setelah akun dibuat. Seed **demo** ditolak di produksi dan juga ditolak pada database yang sudah berisi pengguna bukan-`@example.test` (kecuali `ALLOW_DEMO_SEED=true`; jangan lakukan itu pada sistem yang dipakai mahasiswa nyata).

Contoh unit systemd:

```ini
[Service]
WorkingDirectory=/opt/pasundanedu
EnvironmentFile=/etc/pasundanedu.env
ExecStart=/usr/bin/npm start -- -p 3000
Restart=on-failure
User=pasundanedu
```

Proses worker (opsional bila server Node berjalan terus; wajib bila `INLINE_WORKER=false`):

```ini
ExecStart=/usr/bin/npm run worker
```

Alternatif untuk penjadwal eksternal:

```bash
curl -fsS -X POST -H "Authorization: Bearer $CRON_SECRET" https://DOMAIN/api/cron/process-jobs   # tiap 1 menit
```

## 3. Daftar periksa sebelum dibuka untuk mahasiswa

| ✔ | Item | Mengapa |
|---|---|---|
| ☐ | `APP_SECRET` acak ≥ 32 karakter, `APP_URL` berupa `https://…` | Tanda tangan unduhan; tautan di email |
| ☐ | `DATABASE_URL` PostgreSQL, `DATABASE_SSL=true` bila database di luar mesin yang sama | Data tidak di PGlite; sertifikat server diverifikasi |
| ☐ | `EMAIL_PROVIDER=smtp` + `SMTP_URL`; kirim satu email uji dengan mendaftar akun sendiri | Tanpa ini verifikasi email/reset sandi tidak berfungsi |
| ☐ | `GET /api/health` mengembalikan `"database":"up"` dan `"email":"ready"` | Pemantauan dasar |
| ☐ | Akun admin dibuat; akun/kata sandi demo **tidak** ada | `SELECT count(*) FROM profiles WHERE email LIKE '%@example.test'` harus 0 |
| ☐ | Admin > Pengaturan: nama institusi benar; `institution_verified` diaktifkan **hanya** setelah pengelola institusi resmi memberi izin | Mencegah klaim "layanan resmi" yang tidak sah |
| ☐ | Tinjau layanan, estimasi, kebijakan pembatalan, dan harga di Admin > Katalog layanan; pembayaran tetap nonaktif sampai disetujui | Harga bawaan hanyalah contoh |
| ☐ | Tinjau FAQ, Kebijakan Privasi, Syarat & Ketentuan (`src/app/(public)`) bersama penasihat hukum | Draf, bukan nasihat hukum |
| ☐ | Tetapkan dosen/petugas pada layanan (penugasan) | Tanpa penugasan, pengajuan tidak punya penanggung jawab |
| ☐ | `CRON_SECRET` diisi dan penjadwal/worker berjalan; cek Admin > WhatsApp bagian antrean | Notifikasi tidak menumpuk |
| ☐ | Folder `UPLOAD_DIR` tidak dilayani langsung oleh web server dan izinnya hanya untuk pengguna aplikasi | Berkas privat hanya lewat URL bertanda tangan |
| ☐ | Cadangan database **dan** `UPLOAD_DIR` terjadwal; uji pemulihan sekali | Lihat bagian 4 |
| ☐ | Firewall keluar (egress) membatasi tujuan server bila memungkinkan | Pagar tambahan untuk fitur yang memanggil URL luar (cek Moodle, WhatsApp) |
| ☐ | WhatsApp: ikuti [WHATSAPP.md](WHATSAPP.md) dan lakukan "Uji pertama" dengan nomor Anda sendiri | Belum pernah diuji dengan Meta sungguhan |

## 4. Cadangan dan pemulihan

Yang harus dicadangkan: (1) database PostgreSQL, (2) folder `UPLOAD_DIR`. Keduanya harus diambil pada waktu berdekatan; metadata dokumen ada di database sedangkan isi berkas ada di disk.

```bash
# Cadangan (format custom, tanpa pemilik)
pg_dump "$DATABASE_URL" -Fc --no-owner -f pasundanedu-$(date +%F).dump
tar -czf uploads-$(date +%F).tar.gz -C "$(dirname "$UPLOAD_DIR")" "$(basename "$UPLOAD_DIR")"

# Pemulihan ke database KOSONG
createdb pasundanedu_restore
pg_restore --no-owner -d pasundanedu_restore pasundanedu-2026-10-26.dump
```

Hasil uji: cadangan `pg_dump` dari database yang berisi hasil tes e2e dipulihkan ke database baru dengan jumlah baris identik (profil, pengajuan, jejak audit, dokumen, migrasi). Pemulihan salinan folder PGlite (server berhenti) juga identik. **Pemulihan folder `UPLOAD_DIR` dan pencocokan dengan database tidak diuji otomatis**; lakukan latihan pemulihan di lingkungan Anda.

Simpan cadangan terenkripsi dan terpisah dari server. Berkas dan database berisi data pribadi mahasiswa (nama, NPM, nomor WhatsApp, dokumen).

## 5. Keamanan yang sudah ada dan yang menjadi tanggung jawab Anda

Sudah ada di aplikasi: hash scrypt kata sandi di tabel terpisah, sesi acak disimpan sebagai hash dan dapat dicabut, pembatasan laju, perlindungan CSRF, cek asal, header keamanan (CSP, HSTS, `X-Frame-Options: DENY`, `nosniff`), validasi isi berkas unggahan, unduhan bertanda tangan terikat pengguna, 404 untuk data milik orang lain, rahasia hanya di server (tabel pengaturan menolak kunci seperti `*_password`/`*_token`), jejak audit, tanda tangan HMAC pada webhook, TLS database dengan verifikasi sertifikat bila `DATABASE_SSL=true`.

Menjadi tanggung jawab penyelenggara: HTTPS dan sertifikat, pembaruan sistem operasi dan dependensi (`npm audit`), pemantauan dan rotasi log, rotasi rahasia (`APP_SECRET` diganti membuat URL unduhan lama tidak berlaku), kebijakan retensi data dan permintaan hapus data pribadi, pemberitahuan insiden sesuai UU PDP, serta pembatasan akses server.

Keterbatasan yang diketahui: CSP mengizinkan `script-src 'unsafe-inline'` (kebutuhan hidrasi Next.js; CSP berbasis nonce belum ada); tidak ada autentikasi dua faktor; berkas unggahan belum dipindai antivirus (hanya jenis dan ukuran yang divalidasi); pembatasan laju disimpan di database (cukup untuk skala kampus, bukan pengganti WAF).

## 6. Pemantauan

- `GET /api/health`: `200` dengan `database: "up"`; `503` bila database tidak terjangkau. Bidang `email` melaporkan kesiapan pengiriman email.
- Admin > Ringkasan: pengajuan tanpa penanggung jawab, pesan gagal, dan pekerjaan antrean bermasalah.
- Admin > WhatsApp: antrean `failed`/`dead` dan log pesan, dengan tombol antre ulang.
- Log server: galat API memuat `requestId` (juga dikirim ke klien) untuk pelacakan.

## 7. Pembaruan versi

1. Cadangkan database dan `UPLOAD_DIR`.
2. `git pull && npm ci && npm run build`
3. `npm run db:migrate` (migrasi berurutan, bercatatan checksum; migrasi yang sudah diterapkan tidak boleh diubah).
4. Mulai ulang proses aplikasi dan worker.
