# Referensi API

Semua endpoint berada di bawah `/api`, memakai JSON (kecuali unggahan `multipart/form-data`), dan dijalankan oleh aplikasi Next.js yang sama. Dokumen ini disusun dari kode rute (`src/app/api/**/route.ts`); total 73 kombinasi metode dan jalur.

## Konvensi

**Autentikasi.** Sesi memakai cookie `pe_session` (`HttpOnly`, `SameSite=Lax`, `Secure` di produksi). Tidak ada token API terpisah untuk klien. Kolom *Akses*: `publik` (tanpa sesi), `masuk` (sesi apa pun), daftar peran (mis. `admin`, `dosen, petugas, admin`), `khusus` (diatur oleh rute itu sendiri: webhook, cron, unduhan berkas, health). "email terverifikasi" berarti pemilik akun harus sudah memverifikasi email, bila tidak 403.

**CSRF.** Permintaan yang mengubah data (`POST`, `PUT`, `PATCH`, `DELETE`) ke rute biasa diperiksa asalnya: header `Sec-Fetch-Site` lintas situs ditolak, dan bila header `Origin` ada, hostnya harus sama dengan `Host`, `X-Forwarded-Host`, atau host `APP_URL`; selain itu 403. Webhook dan cron tidak memakai cookie sesi, melainkan tanda tangan HMAC atau bearer, sehingga tidak diperiksa asalnya. Cookie `SameSite=Lax` menjadi lapis kedua.

**Format galat.** Seluruh galat berbentuk:

```json
{ "error": { "code": "validation_error", "message": "Periksa kembali isian Anda.", "fields": { "password": "…" } }, "requestId": "a1b2c3d4" }
```

| Status | Arti |
|---|---|
| 400 | Format data tidak valid (mis. JSON rusak) |
| 401 | Belum masuk |
| 403 | Peran tidak cukup, email belum terverifikasi, asal CSRF salah, atau tanda tangan unduhan tidak valid |
| 404 | Tidak ada, **atau bukan milik/penugasan Anda** (sengaja tidak dibedakan agar keberadaan data tidak bocor) |
| 409 | Konflik: email sudah terdaftar, slot penuh, pembayaran nonaktif, dan sejenisnya |
| 413 | Muatan terlalu besar (JSON maksimal 200 KB; unggahan sesuai `MAX_UPLOAD_MB`) |
| 422 | Validasi gagal; `error.fields` memetakan kolom ke pesan |
| 429 | Dibatasi laju; ikuti header `Retry-After` |
| 503 | Layanan pendukung tidak tersedia (mis. email tidak dapat dikirim) |

Respons berisi data pengguna selalu `Cache-Control: private, no-store`.

**Idempotensi.** `POST /api/service-requests` menerima header `Idempotency-Key`. Kunci yang sama menghasilkan pengajuan yang sama (status 200 dengan `duplicate: true`), baik berurutan maupun serentak. Tanpa kunci, klik ganda identik dalam 30 detik juga tidak membuat duplikat.

**Pembatasan laju (bawaan).** Login: 5 kegagalan per 15 menit per email dan 40 per IP. Registrasi: 10 per jam per IP. Reset kata sandi: 3 per jam per email. Kirim ulang verifikasi: 3 per jam. Pengajuan baru: 30 per jam per pengguna. Pesan: 60 per 10 menit. Unggahan: 30 per jam.

**Paginasi.** Daftar memakai `page` dan `size`; respons memuat `items`, `page`, `pageSize`, `total`, `totalPages`.

**Unggahan.** `multipart/form-data` dengan bidang `file`. Jenis yang diterima: PDF, PNG, JPG, DOCX; maksimal 5 MB (`MAX_UPLOAD_MB`). Jenis ditentukan dari isi berkas, bukan hanya ekstensi. Unduhan hanya lewat URL bertanda tangan yang diberikan pada detail pengajuan (`documents[].url`), berlaku 5 menit secara bawaan (`SIGNED_URL_TTL_SECONDS`).

## Alur status pengajuan

Transisi yang sah untuk staf (sumber: `STATUS_TRANSITIONS` di `src/lib/constants.ts`). Transisi lain ditolak server dengan 409/422.

| Dari | Boleh ke |
|---|---|
| `submitted` | `under_review`, `rejected`, `cancelled` |
| `under_review` | `awaiting_information`, `awaiting_payment`, `confirmed`, `in_progress`, `rejected`, `cancelled` |
| `awaiting_information` | `under_review`, `rejected`, `cancelled` |
| `awaiting_payment` | `under_review`, `confirmed`, `in_progress`, `rejected`, `cancelled` |
| `confirmed` | `in_progress`, `completed`, `awaiting_information`, `cancelled` |
| `in_progress` | `completed`, `awaiting_information`, `cancelled` |
| `completed`, `rejected`, `cancelled` | (status akhir, tidak ada transisi) |

Aturan tambahan di server: `awaiting_payment` hanya untuk layanan berbayar; layanan berbayar tidak dapat masuk `in_progress` atau `completed` sebelum pembayaran berstatus `paid` atau `waived`. Mahasiswa dapat membatalkan sendiri (`POST …/cancel`) pada status `submitted`, `under_review`, `awaiting_information`, `awaiting_payment`, dan `confirmed`.

## Endpoint publik dan pengguna

| Metode | Jalur | Akses | Fungsi |
|---|---|---|---|
| GET | `/api/announcements` | publik | Pengumuman aktif (publik). |
| GET | `/api/appointments/availability` | publik | Slot jadwal tersedia per layanan (publik). |
| GET | `/api/appointments` | masuk | Jadwal milik pengguna. |
| POST | `/api/auth/change-password` | masuk | Ganti kata sandi (butuh kata sandi saat ini). |
| POST | `/api/auth/forgot` | publik | Minta tautan reset kata sandi. Respons sama untuk email terdaftar maupun tidak. |
| POST | `/api/auth/login` | publik | Masuk; mengatur cookie sesi. Dibatasi laju. |
| POST | `/api/auth/logout` | publik | Keluar; mencabut sesi di server. |
| GET | `/api/auth/me` | masuk | Pengguna saat ini, jumlah notifikasi belum dibaca, preferensi. |
| POST | `/api/auth/register` | publik | Daftar akun. Mahasiswa langsung aktif; dosen/petugas masuk antrean persetujuan. Respons memuat `email_sent`. |
| POST | `/api/auth/resend-verification` | masuk | Kirim ulang tautan verifikasi (3 per jam). 503 bila email tidak dapat dikirim. |
| POST | `/api/auth/reset` | publik | Atur kata sandi baru dengan token sekali pakai; sesi lama dicabut. |
| POST | `/api/auth/verify` | publik | Verifikasi email dengan token sekali pakai. |
| POST | `/api/cron/process-jobs` | khusus | Proses antrean notifikasi. Wajib `Authorization: Bearer <CRON_SECRET>`. |
| PATCH | `/api/documents/{id}/verify` | dosen, petugas, admin | Staf memverifikasi atau menolak dokumen. |
| GET | `/api/files/{id}` | khusus | Unduh berkas privat. Wajib sesi, `exp` dan `sig` yang valid dan terikat pengguna. |
| GET | `/api/health` | khusus | Cek hidup: status database dan kesiapan email (`email: ready|not_configured`). Tanpa autentikasi, tanpa data sensitif. |
| POST | `/api/integrations/payments/webhook` | khusus | Webhook gateway generik. Wajib `X-Signature` HMAC; 409 bila pembayaran nonaktif. |
| GET | `/api/integrations/whatsapp/webhook` | khusus | Tantangan verifikasi webhook Meta (`hub.verify_token`). |
| POST | `/api/integrations/whatsapp/webhook` | khusus | Webhook Meta. Wajib `X-Hub-Signature-256` valid (401 bila tidak). |
| GET | `/api/me/preferences` | masuk | Preferensi notifikasi dan status persetujuan WhatsApp. |
| PUT | `/api/me/preferences` | masuk | Ubah preferensi notifikasi (email, WhatsApp, pengingat). |
| PATCH | `/api/me` | masuk | Ubah profil (nama, prodi, angkatan, telepon, nomor WhatsApp). Mengganti nomor WhatsApp mencabut persetujuan. |
| PATCH | `/api/notifications/{id}/read` | masuk | Tandai satu notifikasi dibaca. |
| POST | `/api/notifications/read-all` | masuk | Tandai semua dibaca. |
| GET | `/api/notifications` | masuk | Daftar notifikasi dalam aplikasi. |
| POST | `/api/resources/{id}/favorites` | masuk | Tambah favorit. |
| DELETE | `/api/resources/{id}/favorites` | masuk | Hapus favorit. |
| POST | `/api/resources/{id}/open` | masuk | Catat akses dan kembalikan `{url, title}`. 409 bila sumber dipinjam lewat pengajuan, bukan tautan. |
| GET | `/api/resources` | publik | Cari pustaka (publik). Parameter: `q`, `tab`, `kind`, `year`, `sort` (`newest`|`title`|`year`), `favorites=1`, `page`, `size`. |
| PATCH | `/api/service-requests/{id}/appointment` | dosen, petugas, admin | Jadwal ulang ke slot lain. |
| POST | `/api/service-requests/{id}/cancel` | mahasiswa | Mahasiswa membatalkan pengajuan (status yang diizinkan). |
| POST | `/api/service-requests/{id}/documents` | masuk, email terverifikasi | Unggah dokumen (multipart: `file`, `kind` = lampiran|naskah|hasil). |
| POST | `/api/service-requests/{id}/feedback` | mahasiswa | Penilaian 1 sampai 5 setelah selesai. |
| POST | `/api/service-requests/{id}/messages` | masuk, email terverifikasi | Kirim pesan. `visibility: internal` hanya untuk staf. |
| POST | `/api/service-requests/{id}/payment/proof` | mahasiswa, email terverifikasi | Unggah bukti transfer manual. |
| POST | `/api/service-requests/{id}/payment` | mahasiswa, email terverifikasi | Mulai pembayaran (hanya bila pembayaran aktif dan layanan berbayar). |
| POST | `/api/service-requests/{id}/payment/verify` | petugas, admin | Petugas/admin menyetujui atau menolak bukti pembayaran. |
| GET | `/api/service-requests/{id}` | masuk | Detail pengajuan: riwayat, pesan, dokumen (dengan URL bertanda tangan), jadwal, pembayaran, kemampuan pengguna. 404 bila bukan milik/penugasan pengguna. |
| PATCH | `/api/service-requests/{id}/status` | dosen, petugas, admin | Ubah status (hanya transisi sah). |
| GET | `/api/service-requests` | masuk | Daftar pengajuan. `?scope=staff` untuk antrean staf; `status`, `q`, `unassigned=1`, `page`, `size`. |
| POST | `/api/service-requests` | masuk, email terverifikasi | Buat pengajuan. Header `Idempotency-Key` disarankan. 201 baru, 200 bila duplikat. |
| GET | `/api/services/{id}` | publik | Detail layanan. |
| GET | `/api/services` | publik | Daftar layanan aktif (publik), plus `paymentsEnabled`. |
| DELETE | `/api/staff/slots/{id}` | dosen, petugas, admin | Tutup slot (hanya yang belum dipesan). |
| GET | `/api/staff/slots` | dosen, petugas, admin | Slot jadwal milik staf. |
| POST | `/api/staff/slots` | dosen, petugas, admin, email terverifikasi | Buat slot (validasi waktu dan tumpang tindih). |

## Endpoint admin

| Metode | Jalur | Akses | Fungsi |
|---|---|---|---|
| PUT | `/api/admin/announcements/{id}` | admin, email terverifikasi | Ubah: Ubah/hapus pengumuman. |
| DELETE | `/api/admin/announcements/{id}` | admin, email terverifikasi | Hapus: Ubah/hapus pengumuman. |
| GET | `/api/admin/announcements` | admin | Baca: Pengumuman (admin). |
| POST | `/api/admin/announcements` | admin, email terverifikasi | Buat: Pengumuman (admin). |
| GET | `/api/admin/audit-logs` | admin | Baca: Jejak audit. |
| POST | `/api/admin/integrations/{id}/check` | admin | Cek konektivitas (Moodle). |
| PUT | `/api/admin/integrations/{id}` | admin, email terverifikasi | Ubah: Ubah integrasi. |
| GET | `/api/admin/integrations` | admin | Baca: Daftar/buat integrasi. |
| POST | `/api/admin/integrations` | admin, email terverifikasi | Buat: Daftar/buat integrasi. |
| POST | `/api/admin/jobs/requeue` | admin | Antre ulang pekerjaan notifikasi yang gagal/dead. |
| GET | `/api/admin/payments` | admin, petugas | Baca: Daftar pembayaran (admin, petugas). |
| GET | `/api/admin/reports` | admin | Baca: Laporan ringkas. |
| PUT | `/api/admin/resources/{id}` | admin, email terverifikasi | Ubah: Ubah sumber pustaka. |
| GET | `/api/admin/resources` | admin | Baca: Pustaka (admin). |
| POST | `/api/admin/resources` | admin, email terverifikasi | Buat: Pustaka (admin). |
| PATCH | `/api/admin/role-requests/{id}` | admin, email terverifikasi | Ubah: Setujui atau tolak permintaan peran. |
| GET | `/api/admin/role-requests` | admin | Baca: Antrean persetujuan peran dosen/petugas. |
| GET | `/api/admin/services/{id}` | admin | Baca: Detail/ubah layanan. |
| PUT | `/api/admin/services/{id}` | admin, email terverifikasi | Ubah: Detail/ubah layanan. |
| GET | `/api/admin/services` | admin | Baca: Katalog layanan. |
| POST | `/api/admin/services` | admin, email terverifikasi | Buat: Katalog layanan. |
| GET | `/api/admin/settings` | admin | Baca: Pengaturan sistem (tanpa rahasia). |
| PUT | `/api/admin/settings` | admin, email terverifikasi | Ubah: Pengaturan sistem (tanpa rahasia). |
| PATCH | `/api/admin/users/{id}` | admin, email terverifikasi | Ubah `status` (active/suspended), `roles`, `whatsapp_verified`, `identity_verified`. Admin tidak dapat mengubah akunnya sendiri. |
| GET | `/api/admin/users` | admin | Baca: Daftar pengguna. |
| GET | `/api/admin/whatsapp` | admin | Baca: Status konfigurasi (tanpa rahasia), templat, log pesan, antrean, event webhook. |
| PUT | `/api/admin/whatsapp/templates/{id}` | admin, email terverifikasi | Ubah: Ubah/aktifkan templat WhatsApp. |

## Contoh

```bash
# Masuk dan simpan cookie (pengembangan)
curl -i -c cookies.txt -H 'Content-Type: application/json' -H 'Origin: http://localhost:3000' \
  -d '{"email":"mahasiswa@example.test","password":"DemoPasundan2026"}' http://localhost:3000/api/auth/login

# Buat pengajuan dengan kunci idempotensi
curl -b cookies.txt -H 'Content-Type: application/json' -H 'Origin: http://localhost:3000' \
  -H 'Idempotency-Key: kunci-unik-1' \
  -d '{"service_id":"<UUID layanan>","student_note":"Untuk beasiswa"}' http://localhost:3000/api/service-requests
```

Uji otomatis yang memanggil endpoint-endpoint ini ada di `scripts/e2e.ts` (`npm run test:e2e`).
