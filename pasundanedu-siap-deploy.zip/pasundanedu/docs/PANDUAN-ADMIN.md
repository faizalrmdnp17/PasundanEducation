# Panduan admin (pengelola)

Menu **Kelola sistem** hanya terlihat oleh admin. Setiap perubahan penting dicatat di **Jejak audit** (siapa, kapan, apa). Admin tidak dapat mengubah peran atau status akunnya sendiri; ini disengaja agar tidak ada akun yang mengunci atau mengangkat dirinya sendiri.

## 1. Ringkasan

Menampilkan jumlah pengajuan per status, layanan terpopuler (90 hari), rata-rata waktu penyelesaian, penilaian mahasiswa, grafik pengajuan 14 hari, jadwal terdekat, aktivitas pustaka, jumlah pengguna per peran, antrean persetujuan peran, status integrasi, dan masalah: pengajuan tanpa penanggung jawab, pekerjaan notifikasi bermasalah. Angka dihitung dari database, bukan statis.

## 2. Pengguna dan peran

1. **Persetujuan peran:** pendaftar dosen/petugas muncul di antrean. Periksa NIDN/NIP dan identitas **di luar aplikasi** (mis. dengan bagian kepegawaian) sebelum **menyetujui**. Persetujuan memberi peran dan menandai akun; penolakan membiarkan akun tanpa akses staf.
2. **Daftar pengguna:** ubah status (aktif/ditangguhkan), peran, dan dua tanda verifikasi: **Identitas (NPM/NIDN) sudah saya verifikasi** dan **Nomor WhatsApp kerja sudah saya verifikasi**. Tanda WhatsApp wajib diberikan sebelum nomor dosen/petugas dipakai untuk notifikasi dan tombol hubungi.
3. Mengubah peran atau menangguhkan pengguna **memaksa pengguna itu keluar** dari semua sesi.
4. Hanya berikan peran admin kepada orang yang berwenang; admin dapat mengubah katalog, pengguna, dan pengaturan.

## 3. Katalog layanan

Buat atau ubah layanan: nama, deskripsi, harga (rupiah), durasi, persyaratan (satu per baris), perkiraan proses, apakah memakai jadwal, apakah memerlukan dokumen, kebijakan pembatalan, **Penanggung jawab** (centang dosen/petugas yang menangani), dan aktif/tidak.

- Layanan tanpa penanggung jawab tidak punya penerima pengajuan; tetapkan setidaknya satu.
- Harga yang tertulis adalah **contoh** dari penyiapan awal. Selama pembayaran nonaktif, semua pengajuan tanpa biaya. Aktifkan tarif hanya setelah disetujui pengelola institusi.
- Perubahan harga tidak mengubah pengajuan yang sudah dibuat (harga di-snapshot saat pengajuan).

## 4. Pustaka dan pengumuman

- **Pustaka:** tambah buku, jurnal, konten belajar dengan judul, penulis, tahun, penerbit, **Cara akses** (*Tautan ke penyedia* atau *Dipinjam lewat petugas*), tautan http/https, dan **catatan lisensi atau hak akses**. Hanya tautkan sumber yang aksesnya sah; jangan mengunggah ulang karya berhak cipta tanpa izin.
- **Pengumuman:** judul, isi, kategori, tanggal acara (opsional), **Publikasikan**.

## 5. Pembayaran (opsional)

Tersedia setelah diaktifkan di Pengaturan. Mode yang ada adalah **transfer manual**: mahasiswa mengunggah bukti, petugas/admin memeriksa dan menyetujui atau menolak. Daftar pembayaran menampilkan status. Tidak ada gateway otomatis, tidak ada penyimpanan nomor kartu. Pengembalian dana dilakukan manual di luar aplikasi.

## 6. WhatsApp

Menampilkan status konfigurasi (apakah setiap kredensial **terisi**, tanpa menampilkan nilainya), alamat webhook yang harus didaftarkan di Meta, tiga templat, log pesan, antrean pekerjaan, dan event webhook terakhir. Untuk mengaktifkan, ikuti [WHATSAPP.md](WHATSAPP.md): templat harus berstatus **approved** di Meta lalu Anda ubah statusnya di sini dan centang aktif. Tombol **antre ulang** mencoba lagi pekerjaan yang gagal atau berstatus dead.

## 7. Integrasi LMS

Daftar tautan dan adapter. Tautan (Classroom, Meet, repositori) hanya perlu URL dan petunjuk lalu **Aktif**; tampil di *Informasi > Platform belajar*. **Moodle** hanya mendukung **Cek koneksi** (butuh `MOODLE_WS_TOKEN` di server). LTI 1.3 belum diimplementasikan. Rincian di [LMS.md](LMS.md).

## 8. Pengaturan

- **Nama institusi**.
- **Pernyataan institusi resmi:** kotak "Saya mewakili institusi ini dan berwenang menyatakan aplikasi ini sebagai layanan resminya". **Centang hanya bila Anda benar-benar berwenang dan ada izin tertulis dari pihak institusi.** Bila tidak dicentang, aplikasi menyatakan bahwa identitas institusi belum diverifikasi.
- **Aktifkan biaya layanan (transfer manual)** dan **info rekening** untuk instruksi transfer. Aktifkan hanya setelah tarif disetujui pengelola.
- Rahasia (kata sandi, token, kunci API) **tidak** disimpan di sini; tabel pengaturan menolak kunci semacam itu. Rahasia diatur lewat variabel lingkungan server.

## 9. Jejak audit

Mencatat login/aksi penting: perubahan peran, persetujuan, perubahan status pengajuan, verifikasi dokumen dan pembayaran, perubahan pengaturan, pencabutan persetujuan WhatsApp, dan lain-lain. Gunakan untuk telaah insiden dan akuntabilitas. Retensi dan akses log adalah kebijakan Anda.

## 10. Tugas rutin yang disarankan

| Frekuensi | Tugas |
|---|---|
| Harian | Cek antrean persetujuan peran; pengajuan tanpa penanggung jawab; pekerjaan notifikasi gagal/dead. |
| Mingguan | Telaah penilaian mahasiswa dan rata-rata waktu penyelesaian; tutup/perbarui slot dan pengumuman yang kedaluwarsa. |
| Bulanan | Tinjau daftar pengguna aktif dan peran staf (cabut yang tidak lagi bertugas); cek cadangan dan uji pemulihan berkala; `npm audit` dan pembaruan dependensi. |
| Saat ada pergantian staf | Tangguhkan akun lama; tetapkan ulang penanggung jawab layanan; verifikasi ulang nomor WhatsApp kerja baru. |
