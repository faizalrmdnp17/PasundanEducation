# Panduan dosen dan petugas

## 1. Mendaftar dan persetujuan

1. Di halaman **Daftar**, pilih jenis akun **Dosen** atau **Petugas**, lalu isi NIDN/NIP.
2. Akun masuk status **menunggu persetujuan**. Sampai admin menyetujui, Anda hanya melihat halaman "Menunggu persetujuan" dan tidak dapat membuka `/dosen`, `/petugas`, atau `/admin`. Peran tidak pernah diberikan otomatis lewat registrasi.
3. Setelah disetujui, masuk kembali. Beranda Anda adalah **Beranda** (dosen atau petugas) dengan antrean pengajuan.
4. **Nomor WhatsApp kerja** baru dipakai untuk notifikasi dan tombol "Hubungi lewat WhatsApp" bila admin telah menandainya **terverifikasi**. Mintalah admin memverifikasinya.

## 2. Mengatur jadwal konsultasi (slot)

Di **Beranda** buka bagian jadwal/slot:

1. Di kartu **Buka slot baru**, isi **Tanggal**, **Mulai**, **Selesai**, **Bentuk** (Online atau Tatap muka), **Kapasitas** (jumlah mahasiswa per slot; konsultasi individu = 1), **Tautan atau keterangan** (online) atau **Lokasi** (tatap muka), dan opsional **Khusus layanan** (bila kosong, slot berlaku untuk semua layanan yang Anda tangani).
2. Tekan **Buka slot**. Server menolak waktu yang sudah lewat atau tumpang tindih dengan slot Anda sendiri.
3. Slot yang **sudah dipesan tidak dapat ditutup**; ubah jadwal pengajuannya lewat **Jadwal ulang** pada pengajuan tersebut. Slot kosong dapat ditutup dengan tombol **Tutup**.
4. Tautan Google Meet atau lokasi dicantumkan sebagai teks/tautan biasa; aplikasi tidak membuat rapat otomatis.

## 3. Memproses pengajuan

Buka **Pengajuan masuk**. Anda melihat pengajuan layanan yang ditugaskan kepada Anda, atau yang belum punya penanggung jawab pada layanan yang Anda tangani. Pengajuan layanan lain tidak muncul (dan membukanya lewat tautan memberi 404).

Pada halaman detail:

| Bagian | Fungsi |
|---|---|
| **Jejak pengajuan** | Riwayat status. |
| **Pesan** | Berkomunikasi dengan mahasiswa. Pilih penerima **Hanya staf (catatan internal)** pada kotak pilihan di formulir pesan (bawaannya **Mahasiswa**), lalu **Kirim pesan**. Mahasiswa tidak pernah melihat catatan internal. |
| **Dokumen** | Lihat lampiran lewat tautan berlaku singkat; **verifikasi atau tolak** dokumen dengan catatan verifikasi; unggah hasil layanan (jenis "Hasil layanan"). |
| **Proses pengajuan** | Pilih status berikutnya dan **Simpan status**. Hanya transisi yang sah ditawarkan (mis. Terkirim → Ditinjau → Terkonfirmasi → Sedang diproses → Selesai). Isi **Catatan untuk mahasiswa** bila status memerlukannya (mis. Menunggu informasi, Ditolak). |
| **Jadwal ulang** | Pilih slot lain yang tersedia lalu **Ubah jadwal**; alasan opsional. |
| **Pembayaran** (hanya petugas/admin, bila pembayaran aktif) | Periksa bukti transfer, setujui atau tolak dengan catatan. |

Aturan yang ditegakkan server:

- Anda tidak dapat memproses pengajuan yang bukan wewenang Anda.
- Layanan berbayar tidak dapat masuk "Sedang diproses"/"Selesai" sebelum pembayaran lunas atau dibebaskan.
- Pengajuan berstatus akhir (Selesai, Ditolak, Dibatalkan) tidak dapat diubah lagi.
- Pembatalan atau penolakan pengajuan yang sudah dibayar: pengembalian dana ditangani manual oleh petugas sesuai kebijakan; sistem hanya memberi catatan pengingat.

## 4. Etika dan privasi

- Gunakan WhatsApp hanya untuk koordinasi singkat. **Jangan** meminta atau mengirim dokumen pribadi/akademik lewat WhatsApp; minta mahasiswa mengunggah di pengajuan.
- Aplikasi tidak mengakses akun WhatsApp pribadi Anda. Notifikasi WhatsApp berasal dari nomor bisnis resmi pengelola (bila diaktifkan).
- Data mahasiswa yang Anda lihat hanya untuk melayani pengajuan tersebut. Tindakan Anda (perubahan status, verifikasi dokumen, pesan) tercatat dalam jejak audit.
- Bimbingan skripsi: dampingi, jangan menulis menggantikan mahasiswa. Hasil cek kemiripan hanyalah indikator.

## 5. Notifikasi

Pengajuan baru dan pesan mahasiswa memunculkan notifikasi di aplikasi (lonceng), email bila diaktifkan, dan WhatsApp bila diaktifkan oleh pengelola, nomor Anda terverifikasi, dan Anda menyetujuinya di **Akun > Preferensi**. Pengingat jadwal dikirim 24 jam sebelum sesi.
