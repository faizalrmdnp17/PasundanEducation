# Mengaktifkan WhatsApp (Cloud API resmi)

PasundanEdu hanya memakai **WhatsApp Business Platform (Cloud API) resmi dari Meta**. Aplikasi ini tidak memakai bot tidak resmi, tidak mengambil alih akun WhatsApp pribadi dosen, dan tidak mengirim dokumen sensitif lewat WhatsApp (pesan hanya memuat nomor pengajuan, status, dan ajakan membuka dashboard).

**Status saat ini:** sisi *terima* (webhook) dan sisi *kirim* (klien Cloud API, antrean, percobaan ulang) sudah diimplementasikan dan diuji dengan simulasi (payload bertanda tangan dan `fetch` tiruan). **Pengiriman ke Meta sungguhan belum pernah diuji** karena memerlukan akun, nomor, dan templat milik Anda. Lakukan uji tahap "Uji pertama" di bawah sebelum dipakai mahasiswa.

## Yang harus Anda siapkan

1. Akun Meta Business dan aplikasi di Meta for Developers dengan produk **WhatsApp**.
2. Nomor telepon bisnis yang terdaftar di WhatsApp Business Platform (bukan nomor pribadi yang masih dipakai di aplikasi WhatsApp biasa).
3. Dari dashboard Meta, kumpulkan: *Access Token* (disarankan token system user permanen), *Phone Number ID*, *WhatsApp Business Account ID*, *App Secret*.
4. Templat pesan yang **disetujui Meta** (lihat di bawah).

## Variabel lingkungan

```
WHATSAPP_ACCESS_TOKEN=...
WHATSAPP_PHONE_NUMBER_ID=...
WHATSAPP_BUSINESS_ACCOUNT_ID=...
WHATSAPP_BUSINESS_NUMBER=62...      # untuk tampilan di admin
WHATSAPP_APP_SECRET=...             # memeriksa X-Hub-Signature-256 webhook
WHATSAPP_VERIFY_TOKEN=...           # string acak buatan Anda sendiri
# WHATSAPP_API_VERSION=v21.0
```

Semua nilai hanya dibaca di server. Halaman *Admin > WhatsApp* hanya menampilkan **apakah** setiap nilai sudah diisi, tidak pernah nilainya.

## Webhook

Di dashboard Meta > WhatsApp > Configuration:

- **Callback URL:** `https://DOMAIN-ANDA/api/integrations/whatsapp/webhook`
- **Verify token:** sama dengan `WHATSAPP_VERIFY_TOKEN`
- Berlangganan bidang **`messages`** (status pengiriman dan pesan masuk).

Perilaku di sisi aplikasi:

| Kejadian | Hasil |
|---|---|
| GET verifikasi dengan token benar | Mengembalikan `hub.challenge`. Token salah: 403. |
| POST tanpa/dengan `X-Hub-Signature-256` salah | 401, payload diabaikan. Tanpa `WHATSAPP_APP_SECRET` semua POST ditolak. |
| POST bertanda tangan benar | Event dicatat di `webhook_events` (deduplikasi per ID event); event ulang dihitung sebagai duplikat dan tidak diproses lagi. |
| Status `sent`/`delivered`/`read`/`failed` | Memperbarui log pesan. Status tidak pernah mundur (mis. `read` tidak kembali menjadi `delivered`). Alasan gagal disimpan. |
| Pesan masuk `STOP`, `berhenti`, `unsubscribe`, atau `batal notifikasi` | Mencabut persetujuan WhatsApp pengirim (`whatsapp_enabled=false`, tercatat di `consents` dan audit). |

## Templat pesan

Pengiriman otomatis **hanya** memakai templat Meta yang disetujui. Tiga templat disiapkan sebagai **draf** (nonaktif) di Admin > WhatsApp:

| Tujuan (`purpose`) | Nama bawaan | Variabel (berurutan) |
|---|---|---|
| `request_new_staff` | `pe_pengajuan_baru_staf` | nama penerima, nomor pengajuan, layanan, jadwal |
| `request_status_student` | `pe_status_pengajuan` | nama penerima, nomor pengajuan, status |
| `appointment_reminder` | `pe_pengingat_jadwal` | nama penerima, layanan, jadwal |

Langkah:

1. Di Meta Business Manager, buat templat kategori **Utility**, bahasa **Indonesia (`id`)**, dengan isi yang sama dengan pratinjau di Admin > WhatsApp dan variabel `{{1}}`, `{{2}}`, … sesuai urutan di atas.
2. Tunggu persetujuan Meta.
3. Di Admin > WhatsApp, ubah **status** templat menjadi `approved` dan centang **aktif**. Bila nama templat di Meta berbeda, samakan kolom nama.

Selama templat belum `approved` **dan** aktif, pekerjaan pengiriman diberi status `skipped` (`template_not_approved`) dan tidak ada pesan keluar. Notifikasi pembayaran sengaja **tidak** dikirim lewat WhatsApp.

## Persetujuan dan nomor

- Pengguna memberi persetujuan saat registrasi atau di Akun > Preferensi; setiap perubahan tercatat di tabel `consents`. WhatsApp tidak dikirim tanpa persetujuan aktif.
- Mengganti nomor WhatsApp otomatis mencabut persetujuan dan mematikan notifikasi WhatsApp sampai pengguna menyetujui ulang.
- **Dosen/petugas:** pesan hanya dikirim ke nomor yang sudah ditandai *terverifikasi* oleh admin (Admin > Pengguna). Tombol "Hubungi lewat WhatsApp" di detail pengajuan juga hanya muncul untuk nomor kerja terverifikasi.
- **Mahasiswa:** nomor dipakai atas persetujuan, **tanpa** verifikasi kepemilikan (OTP belum ada). Risiko salah ketik nomor ada; pengguna dapat mematikan WhatsApp kapan saja.
- Tombol `wa.me` hanya membuka percakapan di perangkat pengguna; itu **bukan** integrasi API dan tidak menjamin pesan terkirim.

## Antrean dan pemrosesan

Notifikasi masuk tabel `notification_jobs`. Pekerjaan diproses oleh `npm run worker`, atau `POST /api/cron/process-jobs` dengan `Authorization: Bearer <CRON_SECRET>`, atau pemroses inline pada server Node tunggal. Galat sementara (HTTP 429/5xx, jaringan) dicoba ulang dengan backoff eksponensial (2, 4, 8 … maksimal 60 menit); galat permanen atau melewati batas percobaan berstatus `dead`. Admin dapat mengantre ulang dari Admin > WhatsApp.

## Uji pertama (disarankan)

1. Isi variabel lingkungan dan mulai ulang aplikasi. Admin > WhatsApp harus menampilkan semua nilai "terisi".
2. Daftarkan webhook di Meta dan pastikan Meta menerima 200 pada verifikasi.
3. Buat akun uji milik Anda sendiri, isi nomor Anda, setujui WhatsApp, lalu ajukan layanan. Pastikan pesan templat tiba, dan status di log berubah ke `delivered`/`read`.
4. Balas `STOP` dari ponsel Anda dan pastikan preferensi WhatsApp berubah mati.
5. Jangan menguji dengan nomor mahasiswa nyata tanpa persetujuan mereka.

## Biaya dan kebijakan

Percakapan berbasis templat dapat dikenai biaya oleh Meta; aplikasi ini tidak mengaktifkan biaya apa pun sendiri. Pastikan penggunaan sesuai Kebijakan WhatsApp Business dan UU Pelindungan Data Pribadi (persetujuan, tujuan terbatas, hak berhenti).
