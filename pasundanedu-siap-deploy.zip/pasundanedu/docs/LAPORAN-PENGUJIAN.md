# Laporan pengujian

Semua angka di bawah berasal dari eksekusi nyata pada 26 Oktober 2026 terhadap kode yang dikemas dalam paket ini (Node.js 22, PostgreSQL 16, Chromium via Playwright). Bagian 6 menyatakan dengan jelas apa yang **tidak** teruji.

## 1. Ringkasan

| Lapisan | Alat | Hasil |
|---|---|---|
| Tipe | `tsc --noEmit` | Bersih |
| Unit dan integrasi | Vitest, PGlite di memori | **89 lulus** dari 89 (6 berkas) |
| Unit dan integrasi | Vitest, **PostgreSQL 16 sungguhan** (`TEST_DATABASE_URL`) | **89 lulus** dari 89 |
| End-to-end HTTP | `scripts/e2e.ts` terhadap `next build` + `next start`, PGlite | **33 lulus**, 0 gagal, 0 dilewati |
| End-to-end HTTP | sama, **PostgreSQL 16** | **33 lulus**, 0 gagal, 0 dilewati |
| Kontrol negatif | e2e dengan rahasia webhook sengaja tidak cocok | 2 gagal + 1 dilewati terlapor, kode keluar 1 (skrip memang bisa gagal) |
| UI per peran | Playwright, mahasiswa/petugas/dosen/admin, desktop 1280 dan ponsel 390 | Semua halaman 200, mendarat di beranda yang benar, tanpa galat JavaScript |
| UI alur pesan dan proses | `scripts/ui/e2e_ui.py` | Lulus (pesan, notifikasi, catatan internal tidak bocor, 404 untuk mahasiswa lain/admin) |
| UI autentikasi | `scripts/ui/auth_ui.py` (mode dev) | 13 pemeriksaan lulus: registrasi, banner verifikasi, pengajuan diblokir sebelum verifikasi, verifikasi, token sekali pakai, reset sandi, open-redirect diblokir, dosen belum disetujui diblokir |
| Tata letak | `scripts/ui/overflow.py`, lebar 390 px | 0 dari 32 halaman dengan overflow horizontal |
| Build produksi | `next build` | Sukses, tanpa peringatan |
| Dependensi | `npm audit --omit=dev` | 0 kerentanan (setelah Nodemailer dinaikkan ke 10.2.1) |
| Cadangan | `pg_dump -Fc` lalu `pg_restore` ke database baru; salin folder PGlite | Jumlah baris identik (profil, pengajuan, audit, dokumen, migrasi) |
| Email | Server SMTP penampung lokal, `EMAIL_PROVIDER=smtp` | Email verifikasi tiba, tautan berfungsi, akun terverifikasi; `/api/health` `email: ready` |

## 2. Cakupan tes unit dan integrasi (89)

| Berkas | Jumlah | Yang diperiksa |
|---|---|---|
| `tests/auth.test.ts` | 17 | Registrasi (peran, persetujuan, hash di tabel terpisah, email ganda tak peka huruf besar/kecil), pelaporan jujur bila email gagal terkirim, login (galat seragam, brute force, akun ditangguhkan, sesi kedaluwarsa/dicabut), verifikasi email sekali pakai, reset sandi tanpa membocorkan email, ganti sandi |
| `tests/requests.test.ts` | 21 | Pembuatan pengajuan, nomor unik termasuk pembuatan serentak, idempotensi berurutan dan serentak, harga di sisi server, pemesanan slot serentak (tepat satu berhasil), trigger kapasitas di database, transisi status dan notifikasi, pembatasan akses lintas pengguna, catatan internal, penjadwalan ulang, pembatalan, penilaian, pencarian dan paginasi |
| `tests/payments-admin.test.ts` | 22 | Pembayaran nonaktif bawaan, webhook gateway (nominal, duplikat), admin tidak bisa mengubah dirinya, perubahan peran memaksa keluar, persetujuan peran, constraint kunci rahasia pada pengaturan, integrasi `link_only` vs API, Moodle (sukses/galat/jaringan/tanpa token) dan pagar URL, laporan dari data nyata, pustaka |
| `tests/notifications.test.ts` | 17 | Pemilihan kanal berdasarkan persetujuan/verifikasi nomor/preferensi, pencabutan persetujuan setelah antre, email simulasi tercatat di log, WhatsApp tanpa templat approved dilewati, pengiriman templat (parameter berurutan, token di header, ID pesan tersimpan, parameter dibersihkan dari baris baru), tanpa kredensial ditolak sebagai belum dikonfigurasi, retry dengan backoff lalu dead, pekerja serentak tidak mengirim ganda, deduplikasi, pengingat jadwal idempoten, verifikasi langganan dan tanda tangan webhook, status tidak mundur, STOP |
| `tests/documents.test.ts` | 10 | Jenis dari isi berkas (exe berkedok .pdf, kosong, terlalu besar ditolak), nama berkas dinormalkan tanpa path traversal, berkas tidak di direktori publik, hak unduh pemilik/staf (orang lain 404), URL bertanda tangan terikat pengguna dan dokumen, verifikasi hanya oleh staf (penolakan wajib catatan), batas 15 dokumen tanpa berkas yatim, unduhan tercatat di audit |
| `tests/env.test.ts` | 2 | Pemetaan TLS database (verifikasi sertifikat bawaan saat aktif), IP klien tidak dapat dipalsukan lewat `X-Forwarded-For` |

## 3. Cakupan end-to-end HTTP (33 pemeriksaan)

Keamanan dasar (header, redirect login, 401, CSRF asal asing 403), registrasi dan login (cookie HttpOnly/SameSite, email ganda 409, sandi lemah 422, pesan galat seragam, batas laju 429, pelaporan email jujur, kirim ulang verifikasi), pengajuan (idempotensi 201 lalu 200, validasi 422, harga 0 saat pembayaran nonaktif), RBAC (mahasiswa lain 404, mahasiswa tidak dapat ubah status/antrean staf/API admin, dosen non-penanggung jawab 404, petugas memproses, transisi tidak sah ditolak, catatan internal tidak bocor), dokumen privat (berkas palsu ditolak, PDF sah diterima, unduhan bertanda tangan, tanda tangan rusak dan pengguna lain ditolak), webhook WhatsApp (tantangan, 401 tanpa/salah tanda tangan, event valid dan duplikat, STOP mencabut persetujuan yang sebelumnya aktif), webhook pembayaran (401 dan 409), cron (401 dan 200), logout mencabut sesi di server dan token lama tidak berlaku, respons admin tidak membocorkan rahasia.

## 4. Temuan dan perbaikan selama pengujian

Pengujian bukan sekadar mengonfirmasi; berikut hal yang ditemukan lalu diperbaiki.

| Temuan | Perbaikan |
|---|---|
| Registrasi menjawab "kami mengirim tautan verifikasi" walau email gagal terkirim (mis. produksi tanpa SMTP) | Respons memuat `email_sent`; pesan, banner, halaman Akun, dan kirim ulang (503) jujur; `/api/health` melaporkan `email` |
| `DATABASE_SSL=true` memakai `rejectUnauthorized:false` (tidak memverifikasi sertifikat server) | Verifikasi sertifikat menjadi bawaan, `DATABASE_SSL_CA` untuk CA khusus, `no-verify` harus eksplisit |
| IP klien diambil dari entri **pertama** `X-Forwarded-For` yang bisa dipalsukan klien (melewati batas laju per IP) | Entri ke-N dari kanan lewat `TRUSTED_PROXY_COUNT`; diuji |
| Tautan Classroom/Meet/repositori yang diatur admin tidak pernah tampil bagi mahasiswa | Bagian "Platform belajar" di halaman Informasi (tab baru, `noopener`, hanya http/https) |
| Cek koneksi Moodle mengirim token ke URL apa pun | Di produksi hanya `https` dan bukan alamat jaringan internal; diuji bahwa `fetch` tidak dipanggil |
| Skrip CLI (`db:migrate`, `seed`, `worker`) tidak membaca `.env*` | Dimuat lewat `@next/env` (`scripts/load-env.ts`) |
| `db:seed:demo` hanya dijaga `NODE_ENV` | Juga ditolak bila database berisi pengguna bukan-`@example.test` |
| Nodemailer 7 memiliki advisori tingkat tinggi | Naik ke 10.2.1, uji SMTP ulang, audit bersih |
| Konfigurasi Vitest memaksa `DATABASE_URL=""` sehingga "tes di Postgres" sebenarnya tetap PGlite | `TEST_DATABASE_URL`; helper dibuat unik per proses agar tes dapat berbagi satu database |
| PGlite dapat dipakai diam-diam di produksi | Peringatan jelas di log dan dokumentasi |

Temuan dari tahap sebelumnya (UI): reset CSS di luar `@layer` mengalahkan utilitas Tailwind, grid tanpa `grid-cols-1` menyebabkan overflow di ponsel, cache prefetch router menyebabkan loop navigasi setelah login di produksi (kini navigasi penuh di batas sesi), toast galat ganda, halaman lupa sandi terprerender statis, dan peringatan tracing berkas pada build.

## 5. Cara mengulang

Lihat [INSTALASI.md](INSTALASI.md) bagian B. Ringkas:

```bash
npm run typecheck && npm test
TEST_DATABASE_URL=postgres://… npm test        # database kosong khusus uji
npm run build && E2E_BASE_URL=http://localhost:3100 npm run test:e2e
```

## 6. Yang tidak teruji (batasan jujur)

- **WhatsApp Cloud API sungguhan.** Hanya diuji dengan payload bertanda tangan buatan sendiri dan `fetch` tiruan. Tidak ada pesan terkirim ke Meta.
- **Penyedia email nyata.** SMTP diuji dengan penampung lokal; deliverabilitas (SPF/DKIM, kotak masuk vs spam) tidak diuji.
- **Moodle sungguhan** dan **gateway pembayaran** (tidak ada adapter). Pembayaran manual diuji di tingkat domain, tidak diuji dengan transfer bank nyata.
- **Beban dan kinerja.** Tidak ada uji beban; tes konkurensi hanya untuk nomor unik dan kapasitas slot. Hasil pada skala ribuan pengguna tidak diketahui.
- **Penyimpanan berkas.** Pemulihan `UPLOAD_DIR` dan pencocokannya dengan database tidak diuji otomatis.
- **Aksesibilitas.** Struktur semantik, fokus terlihat, dan kontras diperhatikan dan diperiksa visual, tetapi tidak ada audit otomatis (axe/Lighthouse) maupun uji pembaca layar.
- **Peramban dan perangkat.** Hanya Chromium pada viewport 390 dan 1280 piksel. Safari/Firefox dan perangkat fisik tidak diuji.
- **Keamanan.** Tidak ada uji penetrasi independen atau pemindaian dinamis. Pemeriksaan terbatas pada tes di atas dan `npm audit`.
- **Pembaruan skema pada data nyata.** Hanya satu migrasi (`001_init`); jalur migrasi bertahap dengan data produksi belum pernah berjalan.
- **Hosting serverless dan multi-instans.** Tidak diuji; berkas lokal membuatnya tidak cocok tanpa volume bersama.
