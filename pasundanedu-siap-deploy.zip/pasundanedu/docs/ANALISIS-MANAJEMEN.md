# Analisis manajemen PasundanEdu

Dokumen ini menerjemahkan aplikasi ke bahasa manajemen layanan: siapa pemangku kepentingannya, bagaimana proses bisnisnya berjalan, bagaimana kinerjanya diukur, dan apa saja risikonya. Isinya adalah **kerangka kerja berdasarkan asumsi**; proses nyata di STIE Pasundan Bandung harus dikonfirmasi dengan bagian akademik, perpustakaan, dan kemahasiswaan sebelum dipakai sebagai dasar keputusan. Tidak ada data kinerja nyata di dokumen ini karena aplikasi belum dipakai mahasiswa sungguhan.

## 1. Masalah yang dituju

Layanan akademik yang bersifat tatap muka dan manual (menemui dosen wali, meminta surat keterangan, meminjam referensi) umumnya menimbulkan antrean, jadwal bentrok, status permintaan yang tidak transparan, dan jejak yang sulit ditelusuri. PasundanEdu memindahkan permintaan tersebut ke satu antrean digital dengan nomor, status, jadwal, dan catatan yang dapat dilacak. Klaim bahwa hal ini **mengurangi** waktu tunggu perlu dibuktikan dengan data sebelum-sesudah (lihat bagian 4).

## 2. Pemangku kepentingan

| Pemangku kepentingan | Kepentingan | Peran di sistem | Kekhawatiran utama |
|---|---|---|---|
| Mahasiswa | Layanan cepat, jelas statusnya, mudah dijangkau dari ponsel | Mahasiswa | Privasi data, kepastian jadwal, biaya |
| Dosen wali / pembimbing | Jadwal konsultasi terkelola, beban terukur | Dosen | Beban tambahan, batas jam kerja, privasi nomor pribadi |
| Petugas akademik/perpustakaan | Antrean terpusat, bukti proses | Petugas | Kualitas dokumen, kepatuhan prosedur |
| Pimpinan/pengelola program | Visibilitas kinerja layanan, kepatuhan | Admin | Biaya, reputasi, risiko hukum |
| Penyedia teknologi pihak ketiga (Meta, SMTP, LMS) | Kepatuhan kebijakan platform | Integrasi | Spam/penyalahgunaan, persetujuan template |
| Regulator dan penasihat hukum | Pelindungan data pribadi (UU PDP) | Tinjauan | Dasar pemrosesan, retensi, hak subjek data |

## 3. Proses bisnis

Alur utama pengajuan (sudah diimplementasikan, lihat [API.md](API.md) untuk transisi lengkap):

```
Mahasiswa mengajukan ─► Petugas/dosen meninjau ─► (butuh info? ─► Mahasiswa melengkapi)
        │                         │
        │                         ├─► (berbayar? ─► bukti transfer ─► verifikasi petugas)
        ▼                         ▼
   Dibatalkan              Terkonfirmasi ─► Sedang diproses ─► Selesai ─► Penilaian mahasiswa
                                  └─► Ditolak (dengan alasan)
```

Pembagian tanggung jawab (RACI ringkas): **R** = melaksanakan, **A** = bertanggung jawab akhir, **C** = dikonsultasikan, **I** = diberi tahu.

| Aktivitas | Mahasiswa | Dosen | Petugas | Admin |
|---|---|---|---|---|
| Mengajukan layanan, melengkapi dokumen | R | I | I | I |
| Membuka slot konsultasi | I | R | R | A |
| Meninjau dan memproses pengajuan | I | R | R | A |
| Verifikasi dokumen | I | R | R | A |
| Verifikasi pembayaran manual | I | - | R | A |
| Menyetujui peran staf | - | - | - | R/A |
| Mengatur katalog, harga, pengaturan | C | C | C | R/A |
| Menilai layanan | R | I | I | I |

Pengendalian internal yang sudah ada di sistem: pemisahan peran (mahasiswa tidak dapat mengubah status; staf hanya melihat pengajuan di wewenangnya), persetujuan peran staf oleh admin, jejak audit atas tindakan penting, catatan internal terpisah dari komunikasi ke mahasiswa, serta harga yang dikunci server (tidak dapat dimanipulasi dari browser).

## 4. Indikator kinerja (KPI)

Sebagian indikator sudah dihitung sistem di **Admin > Ringkasan**; sisanya harus dihitung manual atau ditambahkan pelaporan.

| Indikator | Definisi | Sumber | Status |
|---|---|---|---|
| Volume pengajuan | Jumlah pengajuan per hari/layanan | Ringkasan (grafik 14 hari, layanan terpopuler 90 hari) | Tersedia |
| Waktu penyelesaian rata-rata | Selisih `completed_at` dan `created_at` untuk pengajuan selesai (jam) | Ringkasan | Tersedia |
| Tingkat penyelesaian | Selesai ÷ (Selesai + Ditolak + Dibatalkan) | Hitung dari jumlah per status | Dihitung manual dari angka status |
| Kepuasan | Rata-rata penilaian 1 sampai 5 | Ringkasan | Tersedia |
| Pengajuan tanpa penanggung jawab | Jumlah pengajuan terbuka tanpa assignee | Ringkasan | Tersedia |
| Keandalan notifikasi | Pekerjaan gagal/dead terhadap total | Admin > WhatsApp | Tersedia sebagian (angka mentah) |
| Kepatuhan estimasi proses | Pengajuan yang selesai dalam estimasi layanan (mis. 1 sampai 3 hari kerja) | Perlu kueri tambahan | Belum ada |
| Waktu tunggu sebelum-sesudah | Perbandingan dengan proses manual | Survei/pencatatan awal oleh pengelola | Belum ada; perlu garis dasar |
| Adopsi | Persentase mahasiswa aktif yang pernah mengajukan | Pengguna aktif ÷ jumlah mahasiswa terdaftar kampus | Perlu data kampus |

Saran target awal (untuk didiskusikan, **bukan** hasil pengukuran): 90% pengajuan mendapat respons pertama dalam 2 hari kerja, penilaian rata-rata di atas 4, dan nol pengajuan tanpa penanggung jawab lebih dari 1 hari.

## 5. Analisis biaya dan manfaat (kerangka)

Biaya yang perlu dihitung pengelola: hosting server dan PostgreSQL, domain dan sertifikat, penyedia email, biaya percakapan WhatsApp (bila diaktifkan; ditagih Meta, tidak ada di aplikasi), waktu pengembangan/pemeliharaan, waktu staf untuk pelatihan dan moderasi, serta cadangan. Manfaat yang dapat diukur: jam kerja staf yang hemat per pengajuan, berkurangnya kunjungan ke loket, dan kepuasan mahasiswa. **Aplikasi tidak mengaktifkan biaya apa pun kepada mahasiswa tanpa persetujuan pengelola** (pembayaran nonaktif secara bawaan).

## 6. Risiko dan mitigasi

| Risiko | Dampak | Kemungkinan | Mitigasi yang ada | Tindakan pengelola |
|---|---|---|---|---|
| Kebocoran data pribadi (dokumen, nomor WhatsApp) | Tinggi | Sedang | Berkas privat, unduhan bertanda tangan, RBAC, 404 untuk data orang lain, hash kata sandi, header keamanan | HTTPS, akses server terbatas, cadangan terenkripsi, prosedur insiden UU PDP |
| Aplikasi dianggap situs resmi tanpa izin | Tinggi (reputasi/hukum) | Sedang | Pernyataan "identitas belum diverifikasi" sampai admin mengesahkan | Dapatkan izin tertulis sebelum mengaktifkan pernyataan resmi |
| Email tidak terkirim sehingga verifikasi/reset gagal | Sedang | Sedang | Aplikasi tidak mengklaim terkirim; health menunjukkan `not_configured` | Konfigurasikan SMTP dan uji sebelum rilis |
| Pesan WhatsApp dianggap spam / akun diblokir Meta | Sedang | Sedang | Hanya templat disetujui, persetujuan eksplisit, `STOP` mencabut izin | Patuhi kebijakan Meta; jangan impor nomor tanpa persetujuan |
| Penyalahgunaan layanan akademik (plagiarisme, jasa skripsi) | Tinggi (integritas akademik) | Rendah-sedang | Teks layanan menegaskan indikator bukan jaminan, mahasiswa tetap penulis | Kebijakan integritas akademik; dosen menilai akhir |
| Akun staf palsu | Tinggi | Rendah | Peran staf hanya lewat persetujuan admin; tidak otomatis | Verifikasi identitas di luar aplikasi sebelum menyetujui |
| Ketergantungan pada satu server dan disk lokal | Sedang | Sedang | Peringatan PGlite, dokumen cadangan | Cadangan terjadwal, uji pemulihan; rencanakan penyimpanan objek |
| Beban dosen meningkat | Sedang | Sedang | Kapasitas slot, jam slot diatur sendiri | Tetapkan kebijakan jam konsultasi dan kuota |
| Adopsi rendah | Sedang | Sedang | Antarmuka ponsel, notifikasi | Sosialisasi, integrasi ke proses wajib (mis. surat keterangan hanya lewat aplikasi) |
| Harga/kebijakan contoh dianggap resmi | Sedang | Sedang | Pembayaran nonaktif, harga ditandai contoh | Tinjau seluruh katalog sebelum rilis |

## 7. Rekomendasi tahapan peluncuran

1. **Pilot terbatas** (satu program studi, 1 sampai 2 layanan: mis. Surat Keterangan dan Konsultasi Dosen Wali), 4 sampai 6 minggu, dengan garis dasar waktu tunggu yang dicatat sebelumnya.
2. **Aktifkan email** dan uji penuh; baru kemudian pertimbangkan WhatsApp setelah templat disetujui dan "Uji pertama" dilakukan.
3. **Evaluasi** dengan KPI di atas, perbaiki, lalu perluas layanan dan program studi.
4. **Putuskan** pembayaran, integrasi LMS, dan penyimpanan objek berdasarkan hasil evaluasi, bukan sebelum itu.
