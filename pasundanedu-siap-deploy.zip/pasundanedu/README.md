# PasundanEdu

Aplikasi web layanan pendidikan digital untuk mahasiswa STIE Pasundan Bandung: pengajuan layanan akademik (konsultasi dosen wali, bimbingan skripsi, surat keterangan, dan lain-lain), jadwal konsultasi, pustaka digital, notifikasi email/WhatsApp, serta panel kelola untuk dosen, petugas, dan admin.

> **Penting: ini bukan situs resmi institusi.** Aplikasi ini dibangun sebagai proyek mandiri. Selama pengelola belum memverifikasi identitas institusi di *Admin > Pengaturan* (`institution_verified`), halaman masuk menampilkan pernyataan bahwa identitas institusi belum diverifikasi. Logo PasundanEdu dipakai atas pemberian pengguna. Jangan menggunakan logo/nama institusi resmi tanpa izin tertulis dari pihak kampus.

## Status fitur secara jujur

Ringkasan di bawah. Rinciannya ada di [`docs/STATUS-FITUR.md`](docs/STATUS-FITUR.md).

| Berfungsi dan sudah diuji | Berfungsi, tetapi butuh konfigurasi/kredensial Anda | Belum ada |
|---|---|---|
| Registrasi, masuk, verifikasi email, reset kata sandi, sesi, peran (mahasiswa/dosen/petugas/admin) | Email sungguhan (butuh `SMTP_URL`; mode `log` hanya simulasi) | Sinkronisasi kursus Moodle, LTI 1.3, webhook LMS |
| Pengajuan layanan, jadwal tanpa bentrok, status, pesan, catatan internal | WhatsApp (butuh akun WhatsApp Business Platform resmi + template yang disetujui Meta) | Adapter gateway pembayaran (Midtrans/Xendit) |
| Dokumen privat (cek jenis berkas, unduhan bertanda tangan) | Pembayaran transfer manual (nonaktif; aktifkan di Admin > Pengaturan) | Penyimpanan berkas S3/Supabase (kini disk lokal) |
| Pustaka, favorit, pengumuman, laporan admin, jejak audit | Moodle: hanya cek koneksi (butuh URL + token) | Verifikasi nomor WhatsApp mahasiswa dengan OTP |
| Antrean notifikasi dengan percobaan ulang, webhook WhatsApp bertanda tangan | PostgreSQL untuk produksi (`DATABASE_URL`) | Integrasi API Google Classroom/Meet (hanya tautan) |

Pengujian: 89 tes unit/integrasi (lulus di PGlite dan di PostgreSQL 16), 33 pemeriksaan end-to-end HTTP terhadap build produksi (lulus di PGlite dan PostgreSQL 16), alur UI per peran, audit tata letak 390 px (0 halaman bermasalah), `npm audit` 0 kerentanan pada dependensi produksi. Lihat [`docs/LAPORAN-PENGUJIAN.md`](docs/LAPORAN-PENGUJIAN.md) untuk apa yang **tidak** teruji.

## Mulai cepat (pengembangan)

Prasyarat: Node.js 20.9 atau lebih baru (diuji pada Node 22). Tidak perlu memasang database; mode pengembangan memakai PGlite.

```bash
npm install
npm run dev          # menyiapkan database + data demo, lalu menjalankan http://localhost:3000
```

Akun demo (data fiktif `@example.test`, kata sandi sama: `DemoPasundan2026`): `admin@`, `petugas@`, `dosen@`, `dosen2@`, `mahasiswa@`, `mahasiswa2@example.test`.

Di mode pengembangan email tidak dikirim; tautan verifikasi/reset tercetak di konsol server (provider `log`).

## Perintah

| Perintah | Fungsi |
|---|---|
| `npm run dev` | Pengembangan (menyiapkan DB + seed demo bila kosong) |
| `npm run build` lalu `npm start` | Build dan jalankan produksi |
| `npm run typecheck` | Pemeriksaan tipe TypeScript |
| `npm test` | Tes unit/integrasi (PGlite di memori) |
| `TEST_DATABASE_URL=postgres://… npm test` | Tes yang sama di PostgreSQL (gunakan database **kosong** khusus uji) |
| `npm run test:e2e` | Tes HTTP end-to-end terhadap server yang berjalan (`E2E_BASE_URL`) |
| `npm run db:migrate` | Terapkan migrasi (produksi) |
| `npm run db:seed` | Isi katalog layanan/pengaturan awal; membuat admin bila `SEED_ADMIN_*` diisi |
| `npm run admin:create -- email "Nama"` | Buat/ubah akun admin (sandi dari `ADMIN_PASSWORD`) |
| `npm run worker` | Proses antrean notifikasi sebagai proses terpisah |

## Dokumentasi

- [`docs/INSTALASI.md`](docs/INSTALASI.md): pemasangan pengembangan dan produksi
- [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md): produksi, keamanan, cadangan, pemantauan
- [`docs/API.md`](docs/API.md): referensi endpoint
- [`docs/WHATSAPP.md`](docs/WHATSAPP.md): mengaktifkan WhatsApp resmi
- [`docs/LMS.md`](docs/LMS.md): integrasi LMS dan batasannya
- [`docs/STATUS-FITUR.md`](docs/STATUS-FITUR.md): fitur berfungsi vs butuh kredensial vs belum ada
- [`docs/LAPORAN-PENGUJIAN.md`](docs/LAPORAN-PENGUJIAN.md): hasil dan cakupan pengujian
- [`docs/ANALISIS-MANAJEMEN.md`](docs/ANALISIS-MANAJEMEN.md): pemangku kepentingan, alur proses, indikator kinerja, risiko
- Panduan pengguna: [`mahasiswa`](docs/PANDUAN-MAHASISWA.md), [`dosen dan petugas`](docs/PANDUAN-DOSEN-PETUGAS.md), [`admin`](docs/PANDUAN-ADMIN.md)

## Teknologi

Next.js 16 (App Router), React 19, TypeScript, Tailwind CSS 4, PostgreSQL (produksi) / PGlite (pengembangan), Zod, Nodemailer, Vitest. Kata sandi di-hash dengan scrypt pada tabel terpisah; sesi memakai token acak yang disimpan sebagai hash; seluruh rahasia hanya hidup di sisi server.

## Catatan

- Data contoh (`@example.test`) hanya fiktif. Jangan memasukkan data mahasiswa nyata ke seed; `db:seed:demo` menolak database yang sudah berisi pengguna nyata.
- Dokumen hukum (FAQ, Privasi, Syarat) adalah draf yang perlu ditinjau sebelum rilis.
