#!/bin/sh
# Terapkan migrasi database (aman dijalankan berulang: memakai kunci advisory dan checksum), lalu jalankan perintah.
set -e

if [ "${RUN_MIGRATIONS:-true}" = "true" ]; then
  echo "[entrypoint] Menerapkan migrasi database..."
  npm run db:migrate --silent
fi

exec "$@"
