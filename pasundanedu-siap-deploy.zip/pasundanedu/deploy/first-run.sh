#!/usr/bin/env bash
# Dijalankan SEKALI setelah "docker compose up -d --build":
# mengisi katalog layanan/pengaturan awal dan membuat akun admin pertama.
# Kata sandi dibaca tanpa tampil di layar dan tidak ditulis ke berkas atau riwayat shell.
set -euo pipefail
cd "$(dirname "$0")/.."

[ -f .env ] || { echo "Berkas .env belum ada. Salin dari .env.production.example dan isi dulu."; exit 1; }

read -rp "Email admin: " ADMIN_EMAIL
read -rp "Nama admin [Pengelola PasundanEdu]: " ADMIN_NAME
read -rsp "Kata sandi admin (min. 8 karakter, jangan memuat bagian email): " SEED_ADMIN_PASSWORD; echo
read -rsp "Ulangi kata sandi: " CONFIRM; echo
[ "$SEED_ADMIN_PASSWORD" = "$CONFIRM" ] || { echo "Kata sandi tidak sama."; exit 1; }
[ -n "$ADMIN_EMAIL" ] || { echo "Email admin wajib diisi."; exit 1; }

export SEED_ADMIN_PASSWORD
docker compose up -d db
docker compose run --rm \
  -e SEED_ADMIN_EMAIL="$ADMIN_EMAIL" \
  -e SEED_ADMIN_NAME="${ADMIN_NAME:-Pengelola PasundanEdu}" \
  -e SEED_ADMIN_PASSWORD \
  app npm run db:seed

DOMAIN_VALUE=$(grep -E '^DOMAIN=' .env | head -n1 | cut -d= -f2- | tr -d '"' || true)
echo
echo "Selesai. Masuk sebagai $ADMIN_EMAIL di https://${DOMAIN_VALUE:-DOMAIN-Anda}/masuk"
echo "Jangan jalankan skrip ini lagi kecuali ingin mengatur ulang kata sandi admin tersebut."
