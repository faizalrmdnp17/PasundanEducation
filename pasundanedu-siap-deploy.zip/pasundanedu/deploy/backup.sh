#!/usr/bin/env bash
# Cadangan database + berkas unggahan ke folder ./backups (keduanya diambil berdekatan).
# Jadwalkan lewat cron, mis. tiap hari 02:00:   0 2 * * *  /opt/pasundanedu/deploy/backup.sh
# Salin hasilnya ke tempat LAIN (terenkripsi); cadangan di server yang sama tidak melindungi dari kerusakan server.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p backups
STAMP=$(date +%F-%H%M)

docker compose exec -T db pg_dump -U pasundanedu -Fc --no-owner pasundanedu > "backups/db-$STAMP.dump"
docker run --rm -v pasundanedu_uploads:/data:ro -v "$PWD/backups":/backup alpine \
  tar -czf "/backup/uploads-$STAMP.tar.gz" -C /data .

# Simpan 14 hari terakhir
find backups -type f \( -name 'db-*.dump' -o -name 'uploads-*.tar.gz' \) -mtime +14 -delete
echo "Cadangan tersimpan: backups/db-$STAMP.dump dan backups/uploads-$STAMP.tar.gz"
