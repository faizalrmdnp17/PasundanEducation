/**
 * Normalisasi nomor telepon Indonesia ke format internasional tanpa simbol (mis. 6281234567890),
 * sesuai kebutuhan tautan wa.me dan WhatsApp Cloud API.
 */
export function normalizeWhatsapp(input: string | null | undefined): string | null {
  if (!input) return null;
  let d = input.replace(/[^\d+]/g, "");
  if (d.startsWith("+")) d = d.slice(1);
  if (d.startsWith("00")) d = d.slice(2);
  if (d.startsWith("0")) d = "62" + d.slice(1);
  else if (d.startsWith("8")) d = "62" + d;
  if (!/^[1-9][0-9]{7,14}$/.test(d)) return null;
  return d;
}

export function maskPhone(n: string | null | undefined): string {
  if (!n) return "-";
  if (n.length <= 6) return "***";
  return n.slice(0, 4) + "•".repeat(Math.max(2, n.length - 7)) + n.slice(-3);
}

/** Tautan wa.me resmi. Teks awal di-URL-encode. Hanya membuka percakapan, tidak mengirim pesan otomatis. */
export function waLink(number: string, text?: string): string {
  const base = `https://wa.me/${number}`;
  return text ? `${base}?text=${encodeURIComponent(text)}` : base;
}
