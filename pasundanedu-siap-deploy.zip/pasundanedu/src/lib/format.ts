import { LOCALE, TIMEZONE } from "./constants";

export function formatRupiah(amount: number | null | undefined): string {
  if (!amount) return "Gratis";
  return "Rp " + new Intl.NumberFormat(LOCALE).format(amount);
}

type DateInput = Date | string | number | null | undefined;
function toDate(v: DateInput): Date | null {
  if (v === null || v === undefined || v === "") return null;
  const d = v instanceof Date ? v : new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function formatDateTime(v: DateInput): string {
  const d = toDate(v);
  if (!d) return "-";
  return (
    new Intl.DateTimeFormat(LOCALE, {
      timeZone: TIMEZONE,
      weekday: "short",
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    })
      .format(d)
      .replace(/\./g, ":") + " WIB"
  );
}

export function formatDate(v: DateInput): string {
  const d = toDate(v);
  if (!d) return "-";
  return new Intl.DateTimeFormat(LOCALE, { timeZone: TIMEZONE, day: "numeric", month: "long", year: "numeric" }).format(d);
}

export function formatShortDate(v: DateInput): string {
  const d = toDate(v);
  if (!d) return "-";
  return new Intl.DateTimeFormat(LOCALE, { timeZone: TIMEZONE, day: "numeric", month: "short", year: "numeric" }).format(d);
}

export function formatTime(v: DateInput): string {
  const d = toDate(v);
  if (!d) return "-";
  return new Intl.DateTimeFormat(LOCALE, { timeZone: TIMEZONE, hour: "2-digit", minute: "2-digit", hour12: false })
    .format(d)
    .replace(/\./g, ":");
}

/** Tanggal (YYYY-MM-DD) pada zona Asia/Jakarta, dipakai untuk mengelompokkan slot per hari. */
export function jakartaDateKey(v: DateInput): string {
  const d = toDate(v);
  if (!d) return "";
  return new Intl.DateTimeFormat("en-CA", { timeZone: TIMEZONE, year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
}

export function formatDayHeading(key: string): string {
  const d = new Date(`${key}T12:00:00+07:00`);
  return new Intl.DateTimeFormat(LOCALE, { timeZone: TIMEZONE, weekday: "long", day: "numeric", month: "long" }).format(d);
}

/** Mengubah "2026-10-25" + "09:00" (waktu WIB) menjadi objek Date yang benar. */
export function fromJakarta(dateKey: string, time: string): Date {
  return new Date(`${dateKey}T${time}:00+07:00`);
}

export function timeAgo(v: DateInput, now = new Date()): string {
  const d = toDate(v);
  if (!d) return "";
  const s = Math.round((now.getTime() - d.getTime()) / 1000);
  if (s < 60) return "baru saja";
  if (s < 3600) return `${Math.floor(s / 60)} menit lalu`;
  if (s < 86400) return `${Math.floor(s / 3600)} jam lalu`;
  if (s < 86400 * 7) return `${Math.floor(s / 86400)} hari lalu`;
  return formatShortDate(d);
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join("");
}
