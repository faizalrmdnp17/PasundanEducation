// Konstanta bersama (aman dipakai di server maupun klien).

export const ROLES = ["mahasiswa", "dosen", "petugas", "admin"] as const;
export type Role = (typeof ROLES)[number];

export const ROLE_LABEL: Record<Role, string> = {
  mahasiswa: "Mahasiswa",
  dosen: "Dosen",
  petugas: "Petugas Administrasi",
  admin: "Admin / Pengelola",
};

export const REQUEST_STATUSES = [
  "submitted",
  "under_review",
  "awaiting_information",
  "awaiting_payment",
  "confirmed",
  "in_progress",
  "completed",
  "rejected",
  "cancelled",
] as const;
export type RequestStatus = (typeof REQUEST_STATUSES)[number];

export const STATUS_LABEL: Record<RequestStatus, string> = {
  submitted: "Terkirim",
  under_review: "Ditinjau",
  awaiting_information: "Menunggu informasi",
  awaiting_payment: "Menunggu pembayaran",
  confirmed: "Terkonfirmasi",
  in_progress: "Sedang diproses",
  completed: "Selesai",
  rejected: "Ditolak",
  cancelled: "Dibatalkan",
};

export const STATUS_TONE: Record<RequestStatus, "info" | "warn" | "ok" | "bad" | "mute"> = {
  submitted: "info",
  under_review: "info",
  awaiting_information: "warn",
  awaiting_payment: "warn",
  confirmed: "ok",
  in_progress: "info",
  completed: "ok",
  rejected: "bad",
  cancelled: "mute",
};

export const TERMINAL_STATUSES: RequestStatus[] = ["completed", "rejected", "cancelled"];

/** Transisi status yang sah untuk staf. Selain ini ditolak server. */
export const STATUS_TRANSITIONS: Record<RequestStatus, RequestStatus[]> = {
  submitted: ["under_review", "rejected", "cancelled"],
  under_review: ["awaiting_information", "awaiting_payment", "confirmed", "in_progress", "rejected", "cancelled"],
  awaiting_information: ["under_review", "rejected", "cancelled"],
  awaiting_payment: ["under_review", "confirmed", "in_progress", "rejected", "cancelled"],
  confirmed: ["in_progress", "completed", "awaiting_information", "cancelled"],
  in_progress: ["completed", "awaiting_information", "cancelled"],
  completed: [],
  rejected: [],
  cancelled: [],
};

export function canTransition(from: RequestStatus, to: RequestStatus): boolean {
  return STATUS_TRANSITIONS[from]?.includes(to) ?? false;
}

/** Mahasiswa hanya boleh membatalkan selama belum diproses (kebijakan bawaan). */
export const STUDENT_CANCELLABLE: RequestStatus[] = [
  "submitted",
  "under_review",
  "awaiting_information",
  "awaiting_payment",
  "confirmed",
];

export const PAYMENT_STATUS_LABEL: Record<string, string> = {
  not_required: "Gratis",
  pending: "Belum dibayar",
  awaiting_verification: "Menunggu verifikasi",
  paid: "Lunas",
  refunded: "Dikembalikan",
  waived: "Dibebaskan",
};

export const RESOURCE_KIND_LABEL: Record<string, string> = {
  book: "Buku",
  ebook: "E-book",
  journal: "Jurnal",
  video: "Video",
  podcast: "Podcast",
  infographic: "Infografis",
  material: "Materi",
};

/** Pengelompokan tab di Pustaka digital (mengikuti prototipe). */
export const LIBRARY_TABS = [
  { key: "buku", label: "Buku", kinds: ["book", "ebook"] },
  { key: "jurnal", label: "Jurnal", kinds: ["journal"] },
  { key: "konten", label: "Konten belajar", kinds: ["video", "podcast", "infographic", "material"] },
] as const;

export const ANNOUNCEMENT_CATEGORIES = ["akademik", "beasiswa", "perpustakaan", "seminar", "umum"] as const;
export const ANNOUNCEMENT_LABEL: Record<string, string> = {
  akademik: "Akademik",
  beasiswa: "Beasiswa",
  perpustakaan: "Perpustakaan",
  seminar: "Seminar",
  umum: "Umum",
};

export const INTEGRATION_KINDS = [
  { value: "google_classroom", label: "Google Classroom", type: "link" },
  { value: "moodle", label: "Moodle", type: "api" },
  { value: "google_meet", label: "Google Meet / konferensi", type: "link" },
  { value: "journal_repository", label: "Repositori jurnal / perpustakaan digital", type: "link" },
  { value: "custom_api", label: "API resmi penyedia lain", type: "api" },
  { value: "lti13", label: "LTI 1.3", type: "lti" },
] as const;

export const TIMEZONE = "Asia/Jakarta";
export const LOCALE = "id-ID";

export const UPLOAD_MIME_ALLOW = ["application/pdf", "image/png", "image/jpeg", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"] as const;

/** Peran utama (urutan prioritas) dan halaman beranda peran. Murni, aman untuk klien dan server. */
export const ROLE_PRIORITY: Role[] = ["admin", "petugas", "dosen", "mahasiswa"];
export function homeForRoles(roles: Role[]): string {
  const r = ROLE_PRIORITY.find((x) => roles.includes(x));
  return r === "admin" ? "/admin" : r === "petugas" ? "/petugas" : r === "dosen" ? "/dosen" : "/";
}
