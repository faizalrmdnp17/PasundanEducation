import { z } from "zod";
import { normalizeWhatsapp } from "./phone";

// Skema validasi dipakai bersama oleh formulir (klien) dan API (server). Server tetap menjadi sumber kebenaran.

const COMMON_PASSWORDS = new Set([
  "password", "password1", "password123", "12345678", "123456789", "1234567890", "qwerty123", "qwertyuiop",
  "11111111", "iloveyou", "admin123", "abcd1234", "pasundan123", "pasundanedu", "kataSandi1".toLowerCase(),
]);

export const passwordSchema = z
  .string({ error: "Kata sandi wajib diisi." })
  .min(8, "Kata sandi minimal 8 karakter.")
  .max(128, "Kata sandi maksimal 128 karakter.")
  .refine((v) => /[A-Za-z]/.test(v) && /\d/.test(v), "Kata sandi harus memuat huruf dan angka.")
  .refine((v) => !COMMON_PASSWORDS.has(v.toLowerCase()), "Kata sandi terlalu umum. Gunakan yang lebih unik.");

const emailSchema = z
  .string({ error: "Email wajib diisi." })
  .trim()
  .toLowerCase()
  .max(254, "Email terlalu panjang.")
  .pipe(z.email("Format email tidak valid."));

const nameSchema = z.string({ error: "Nama wajib diisi." }).trim().min(2, "Nama minimal 2 karakter.").max(120, "Nama maksimal 120 karakter.");

const idNumber = (label: string) =>
  z
    .string()
    .trim()
    .regex(/^[0-9A-Za-z.\-]{5,20}$/, `${label} tidak valid (5–20 karakter, huruf/angka).`);

const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max, `Maksimal ${max} karakter.`)
    .optional()
    .transform((v) => (v ? v : undefined));

export const whatsappSchema = z
  .string()
  .trim()
  .optional()
  .transform((v, ctx) => {
    if (!v) return undefined;
    const n = normalizeWhatsapp(v);
    if (!n) {
      ctx.addIssue({ code: "custom", message: "Nomor WhatsApp tidak valid. Contoh: 0812-3456-7890." });
      return z.NEVER;
    }
    return n;
  });

export const registerSchema = z
  .object({
    full_name: nameSchema,
    email: emailSchema,
    password: passwordSchema,
    account_type: z.enum(["mahasiswa", "dosen", "petugas"], { error: "Pilih jenis akun." }),
    npm: idNumber("NPM").optional().or(z.literal("").transform(() => undefined)),
    nidn: idNumber("NIDN/NIP").optional().or(z.literal("").transform(() => undefined)),
    study_program: optionalText(120),
    cohort_year: z.coerce.number().int().min(1990).max(2100).optional().or(z.literal("").transform(() => undefined)),
    whatsapp_number: whatsappSchema,
    accept_terms: z.literal(true, { error: "Anda harus menyetujui syarat dan ketentuan serta kebijakan privasi." }),
    consent_whatsapp: z.boolean().optional().default(false),
    consent_email: z.boolean().optional().default(true),
  })
  .superRefine((v, ctx) => {
    if (v.account_type === "mahasiswa" && !v.npm) ctx.addIssue({ code: "custom", path: ["npm"], message: "NPM wajib diisi untuk mahasiswa." });
    if (v.account_type !== "mahasiswa" && !v.nidn)
      ctx.addIssue({ code: "custom", path: ["nidn"], message: "NIDN/NIP wajib diisi untuk dosen dan petugas." });
    if (v.password.toLowerCase().includes(v.email.split("@")[0]!.toLowerCase()) && v.email.split("@")[0]!.length >= 4)
      ctx.addIssue({ code: "custom", path: ["password"], message: "Kata sandi tidak boleh memuat bagian dari email Anda." });
    if (v.consent_whatsapp && !v.whatsapp_number)
      ctx.addIssue({ code: "custom", path: ["whatsapp_number"], message: "Isi nomor WhatsApp bila ingin menerima notifikasi WhatsApp." });
  });
export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string({ error: "Kata sandi wajib diisi." }).min(1, "Kata sandi wajib diisi.").max(128),
});

export const forgotSchema = z.object({ email: emailSchema });
export const resetSchema = z.object({ token: z.string().min(20).max(200), password: passwordSchema });
export const verifySchema = z.object({ token: z.string().min(20).max(200) });

export const changePasswordSchema = z.object({
  current_password: z.string().min(1, "Kata sandi saat ini wajib diisi."),
  new_password: passwordSchema,
});

export const profileUpdateSchema = z.object({
  full_name: nameSchema.optional(),
  study_program: optionalText(120),
  cohort_year: z.coerce.number().int().min(1990).max(2100).optional().or(z.literal("").transform(() => undefined)),
  phone: optionalText(30),
  whatsapp_number: whatsappSchema,
});

export const preferencesSchema = z.object({
  email_enabled: z.boolean(),
  whatsapp_enabled: z.boolean(),
  reminders_enabled: z.boolean(),
});

export const serviceRequestSchema = z.object({
  service_id: z.uuid("Layanan tidak valid."),
  slot_id: z.uuid("Jadwal tidak valid.").optional().or(z.literal("").transform(() => undefined)),
  student_note: z.string().trim().max(2000, "Catatan maksimal 2000 karakter.").optional().transform((v) => v || undefined),
  details: z.record(z.string().max(60), z.union([z.string().max(1000), z.number(), z.boolean()])).optional().default({}),
  resource_id: z.uuid().optional(),
});

export const statusChangeSchema = z.object({
  status: z.enum([
    "submitted", "under_review", "awaiting_information", "awaiting_payment", "confirmed", "in_progress", "completed", "rejected", "cancelled",
  ]),
  note: z.string().trim().max(2000).optional().transform((v) => v || undefined),
});

export const messageSchema = z.object({
  body: z.string().trim().min(1, "Pesan tidak boleh kosong.").max(4000, "Pesan maksimal 4000 karakter."),
  visibility: z.enum(["student", "internal"]).default("student"),
});

export const feedbackSchema = z.object({
  rating: z.coerce.number().int().min(1, "Beri nilai 1–5.").max(5, "Beri nilai 1–5."),
  comment: z.string().trim().max(2000).optional().transform((v) => v || undefined),
});

export const slotCreateSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Tanggal tidak valid."),
  start: z.string().regex(/^\d{2}:\d{2}$/, "Jam mulai tidak valid."),
  end: z.string().regex(/^\d{2}:\d{2}$/, "Jam selesai tidak valid."),
  mode: z.enum(["online", "offline"]).default("online"),
  location: z.string().trim().max(300).optional().transform((v) => v || undefined),
  service_id: z.uuid().optional().or(z.literal("").transform(() => undefined)),
  capacity: z.coerce.number().int().min(1).max(100).optional().or(z.literal("").transform(() => undefined)),
});

export const serviceUpsertSchema = z.object({
  category_id: z.uuid("Kategori wajib dipilih."),
  name: z.string().trim().min(3, "Nama layanan minimal 3 karakter.").max(120),
  description: z.string().trim().min(10, "Deskripsi minimal 10 karakter.").max(2000),
  icon: z.string().trim().max(40).default("file-text"),
  price_idr: z.coerce.number().int("Harga harus bilangan bulat rupiah.").min(0, "Harga tidak boleh negatif.").max(100_000_000),
  duration_minutes: z.coerce.number().int().min(5).max(600).optional().or(z.literal("").transform(() => undefined)),
  capacity: z.coerce.number().int().min(1).max(10000).optional().or(z.literal("").transform(() => undefined)),
  requirements: z.array(z.string().trim().min(1).max(200)).max(20).default([]),
  estimated_process: z.string().trim().max(200).optional().transform((v) => v || undefined),
  requires_appointment: z.boolean().default(false),
  requires_documents: z.boolean().default(false),
  cancellation_policy: z.string().trim().min(5).max(500),
  is_active: z.boolean().default(true),
  staff_ids: z.array(z.uuid()).max(50).default([]),
});

export const announcementSchema = z.object({
  title: z.string().trim().min(3, "Judul minimal 3 karakter.").max(200),
  body: z.string().trim().max(4000).optional().transform((v) => v || undefined),
  category: z.enum(["akademik", "beasiswa", "perpustakaan", "seminar", "umum"]),
  event_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().or(z.literal("").transform(() => undefined)),
  is_published: z.boolean().default(true),
});

export const resourceUpsertSchema = z.object({
  category_id: z.uuid().optional().or(z.literal("").transform(() => undefined)),
  kind: z.enum(["book", "ebook", "journal", "video", "podcast", "infographic", "material"]),
  title: z.string().trim().min(3).max(300),
  authors: optionalText(300),
  publisher: optionalText(200),
  year: z.coerce.number().int().min(1900).max(2100).optional().or(z.literal("").transform(() => undefined)),
  description: optionalText(2000),
  access_type: z.enum(["link", "borrow"]),
  external_url: z.url("URL tidak valid.").refine((u) => /^https?:\/\//i.test(u), "URL harus diawali http:// atau https://").optional().or(z.literal("").transform(() => undefined)),
  duration_minutes: z.coerce.number().int().min(1).max(10000).optional().or(z.literal("").transform(() => undefined)),
  license_note: optionalText(500),
  is_published: z.boolean().default(true),
});

export const integrationUpsertSchema = z.object({
  code: z.string().trim().regex(/^[a-z0-9][a-z0-9_-]{1,40}$/, "Kode: huruf kecil, angka, - atau _."),
  name: z.string().trim().min(2).max(120),
  kind: z.enum(["google_classroom", "moodle", "google_meet", "journal_repository", "custom_api", "lti13"]),
  connection_type: z.enum(["link", "api", "lti"]),
  base_url: z.url("URL dasar tidak valid.").refine((u) => /^https?:\/\//i.test(u), "URL harus diawali http:// atau https://").optional().or(z.literal("").transform(() => undefined)),
  auth_method: z.enum(["none", "api_token", "oauth2", "oidc", "lti13"]).default("none"),
  is_active: z.boolean().default(false),
  instructions: optionalText(2000),
});

export const roleDecisionSchema = z.object({
  decision: z.enum(["approve", "reject"]),
  note: optionalText(500),
});

export const userAdminSchema = z.object({
  status: z.enum(["active", "suspended"]).optional(),
  roles: z.array(z.enum(["mahasiswa", "dosen", "petugas", "admin"])).optional(),
  whatsapp_verified: z.boolean().optional(),
  identity_verified: z.boolean().optional(),
});

export const settingsSchema = z.object({
  payments_enabled: z.boolean().optional(),
  bank_account_info: z.string().trim().max(500).optional(),
  institution_name: z.string().trim().max(200).optional(),
  institution_verified: z.boolean().optional(),
});

export const whatsappTemplateSchema = z.object({
  name: z.string().trim().min(2).max(100).regex(/^[a-z0-9_]+$/, "Nama template: huruf kecil, angka, garis bawah."),
  language: z.string().trim().min(2).max(10).default("id"),
  status: z.enum(["draft", "submitted", "approved", "rejected"]),
  is_active: z.boolean(),
});
