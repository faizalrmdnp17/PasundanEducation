import { NextResponse, type NextRequest } from "next/server";

/**
 * Lapis pertama: halaman aplikasi tanpa cookie sesi dialihkan ke /masuk dengan tujuan semula (?next=).
 * Ini HANYA kenyamanan. Keabsahan sesi dan peran tetap diperiksa di server (layout/halaman memanggil requireUser,
 * dan semua route API memeriksa sendiri).
 */
export function proxy(req: NextRequest) {
  const cookie = process.env.SESSION_COOKIE || "pe_session";
  if (req.cookies.has(cookie)) return NextResponse.next();
  const url = req.nextUrl.clone();
  const target = req.nextUrl.pathname + req.nextUrl.search;
  url.pathname = "/masuk";
  url.search = "";
  if (target !== "/") url.searchParams.set("next", target);
  return NextResponse.redirect(url);
}

export const config = {
  matcher: [
    "/",
    "/layanan/:path*",
    "/pustaka/:path*",
    "/jadwal/:path*",
    "/riwayat/:path*",
    "/pengajuan/:path*",
    "/notifikasi/:path*",
    "/info/:path*",
    "/akun/:path*",
    "/favorit/:path*",
    "/dosen/:path*",
    "/petugas/:path*",
    "/admin/:path*",
    "/menunggu-persetujuan",
  ],
};
