import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { listResources } from "@/server/domain/resources";
import { getService } from "@/server/domain/services";
import { Empty, PageHead, Pager } from "@/components/common";
import { ResourceActions } from "@/components/library/ResourceActions";
import { BookOpen, Bookmark, Search } from "@/components/icons";
import { LIBRARY_TABS, RESOURCE_KIND_LABEL } from "@/lib/constants";

export const metadata: Metadata = { title: "Pustaka digital" };

const SORTS = [["newest", "Terbaru"], ["title", "Judul A–Z"], ["year", "Tahun terbit"]] as const;

export default async function Page({ searchParams }: { searchParams: Promise<{ tab?: string; q?: string; urut?: string; hal?: string }> }) {
  const user = await requireUser({ next: "/pustaka" });
  const sp = await searchParams;
  const tab = LIBRARY_TABS.find((t) => t.key === sp.tab)?.key ?? LIBRARY_TABS[0].key;
  const q = (sp.q ?? "").slice(0, 80);
  const sort = SORTS.find(([k]) => k === sp.urut)?.[0] ?? "newest";
  const page = Math.max(1, Number(sp.hal) || 1);
  const [res, borrow] = await Promise.all([
    listResources({ userId: user.id, tab, q, sort, page, size: 12 }),
    getService("peminjaman-buku-referensi").catch(() => null),
  ]);
  const canBorrow = user.roles.includes("mahasiswa") ? (borrow?.id ?? null) : null;
  const href = (o: Record<string, string | undefined>) => {
    const p = new URLSearchParams();
    const m = { tab, q: q || undefined, urut: sort !== "newest" ? sort : undefined, ...o };
    for (const [k, v] of Object.entries(m)) if (v) p.set(k, v);
    return `/pustaka?${p.toString()}`;
  };

  return (
    <div>
      <PageHead title="Pustaka digital" desc="Buku, jurnal, dan konten belajar. Sumber bertanda Buka mengarah ke tautan penyedia; sumber bertanda Pinjam diajukan lewat petugas perpustakaan." action={<Link href="/favorit" className="btn btn-l btn-sm"><Bookmark size={15} aria-hidden="true" /> Favorit saya</Link>} />
      <div className="scroll-x mb-3" role="tablist" aria-label="Jenis sumber">
        {LIBRARY_TABS.map((t) => (
          <Link key={t.key} href={href({ tab: t.key, hal: undefined })} role="tab" aria-selected={tab === t.key} aria-current={tab === t.key ? "true" : undefined} className={`chip ${tab === t.key ? "on" : ""}`}>{t.label}</Link>
        ))}
      </div>
      <form action="/pustaka" method="get" role="search" className="mb-4 flex flex-wrap gap-2">
        <input type="hidden" name="tab" value={tab} />
        <label className="relative block min-w-[220px] flex-1">
          <span className="sr-only">Cari judul, penulis, kategori, atau tahun</span>
          <Search size={18} aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
          <input name="q" type="search" defaultValue={q} placeholder="Cari judul atau penulis" className="input pl-10" />
        </label>
        <label className="block">
          <span className="sr-only">Urutkan</span>
          <select name="urut" defaultValue={sort} className="input">{SORTS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
        </label>
        <button className="btn" type="submit">Terapkan</button>
      </form>

      {res.items.length === 0 ? (
        <Empty icon={<BookOpen size={22} aria-hidden="true" />} title="Sumber tidak ditemukan" hint={q ? "Coba kata kunci lain atau ganti tab." : "Belum ada sumber pada tab ini."} />
      ) : (
        <>
          <p className="mu mb-2">{res.total} sumber</p>
          <ul className="grid grid-cols-1 gap-2.5 md:grid-cols-2">
            {res.items.map((r) => (
              <li key={r.id} className="card flex h-full flex-col gap-2.5">
                <div className="min-w-0">
                  <div className="mb-1 flex flex-wrap items-center gap-1.5">
                    <span className="badge badge-info">{RESOURCE_KIND_LABEL[r.kind] ?? r.kind}</span>
                    {r.category_name && r.category_name !== RESOURCE_KIND_LABEL[r.kind] ? <span className="badge badge-mute">{r.category_name}</span> : null}
                  </div>
                  <h2 className="font-semibold leading-snug">{r.title}</h2>
                  <p className="mu mt-0.5">{[r.authors, r.publisher, r.year].filter(Boolean).join(" · ") || "Tanpa keterangan penulis"}</p>
                  {r.description ? <p className="mu mt-1 line-clamp-2">{r.description}</p> : null}
                  {r.license_note ? <p className="hint">{r.license_note}</p> : null}
                </div>
                <div className="mt-auto"><ResourceActions id={r.id} title={r.title} favorite={r.favorite} accessType={r.access_type} borrowServiceId={canBorrow} /></div>
              </li>
            ))}
          </ul>
          <Pager page={res.page} totalPages={res.totalPages} path="/pustaka" params={{ tab, q: q || undefined, urut: sort !== "newest" ? sort : undefined }} />
        </>
      )}
    </div>
  );
}
