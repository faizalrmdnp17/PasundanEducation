import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { StaffHome } from "@/components/staff/StaffHome";

export const metadata: Metadata = { title: "Beranda petugas" };

export default async function Page() {
  const user = await requireUser({ next: "/petugas", roles: ["petugas", "admin"] });
  return <StaffHome user={user} />;
}
