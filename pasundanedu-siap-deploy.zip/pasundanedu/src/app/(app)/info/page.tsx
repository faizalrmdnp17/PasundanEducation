import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { listAnnouncements } from "@/server/domain/notifications";
import { getSettings } from "@/server/domain/settings";
import { listActiveLinks } from "@/server/domain/admin";
import { Empty, PageHead } from "@/components/common";
import { CircleHelp, ExternalLink, Megaphone, ShieldCheck } from "@/components/icons";
import { ANNOUNCEMENT_CATEGORIES, ANNOUNCEMENT_LABEL } from "@/lib/constants";
import { formatShortDate } from "@/lib/format";

export const metadata: Metadata = { title: "Informasi" };

export default async function Page({ searchParams }: { searchParams: Promise<{ kategori?: string }> }) {
  await requireUser({ next: "/info" });
  const sp = await searchParams;
  const cat = (ANNOUNCEMENT_CATEGORIES as readonly string[]).includes(sp.kategori ?? "") ? sp.kategori : undefined;
  const [all, s, links] = await Promise.all([listAnnouncements({ limit: 60 }), getSettings(), listActiveLinks().catch(() => [])]);
  // Hanya http(s) yang boleh menjadi tautan keluar.
  const safeLinks = links.filter((l) => /^https?:\/\//i.test(l.base_url));
  const list = cat ? all.filter((a) => a.category === cat) : all;
  return (
    <div className="mx-auto max-w-[820px]">
      <PageHead title="Informasi kampus" desc="Pengumuman akademik, beasiswa, perpustakaan, dan seminar." />
      <div className="scroll-x mb-4" role="group" aria-label="Kategori pengumuman">
        <Link href="/info" className={`chip ${!cat ? "on" : ""}`} aria-current={!cat ? "true" : undefined}>Semua</Link>
        {ANNOUNCEMENT_CATEGORIES.map((c) => <Link key={c} href={`/info?kategori=${c}`} className={`chip ${cat === c ? "on" : ""}`} aria-current={cat === c ? "true" : undefined}>{ANNOUNCEMENT_LABEL[c]}</Link>)}
      </div>
      {list.length === 0 ? <Empty icon={<Megaphone size={22} aria-hidden="true" />} title="Belum ada pengumuman" hint="Pengumuman yang dipublikasikan pengelola akan tampil di sini." /> : (
        <ul className="space-y-2.5">
          {list.map((a) => (
            <li key={a.id} className="card">
              <div className="flex flex-wrap items-center gap-2"><span className="badge badge-info">{ANNOUNCEMENT_LABEL[a.category] ?? a.category}</span>{a.event_date ? <span className="mu">{formatShortDate(a.event_date + "T12:00:00+07:00")}</span> : null}</div>
              <h2 className="mt-1.5 font-semibold leading-snug">{a.title}</h2>
              {a.body ? <p className="mt-1 whitespace-pre-line text-[13.5px] text-muted">{a.body}</p> : null}
            </li>
          ))}
        </ul>
      )}
      {safeLinks.length ? (
        <section className="mt-8" aria-labelledby="platform">
          <h2 id="platform" className="h-sec">Platform belajar</h2>
          <p className="mu mb-2.5 mt-1 text-[13px]">Tautan eksternal yang dikelola pengelola. Dibuka di tab baru; PasundanEdu tidak terhubung ke akun Anda di sana.</p>
          <ul className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            {safeLinks.map((l) => (
              <li key={l.id}>
                <a href={l.base_url} target="_blank" rel="noopener noreferrer" className="card flex h-full items-start gap-3 hover:border-brand">
                  <span className="ic"><ExternalLink size={20} aria-hidden="true" /></span>
                  <span className="min-w-0">
                    <span className="block font-semibold">{l.name}<span className="sr-only"> (tautan eksternal, tab baru)</span></span>
                    {l.instructions ? <span className="mu block text-[13px]">{l.instructions}</span> : null}
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
      <div className="mt-8 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
        <Link href="/faq" className="card flex items-center gap-3 hover:border-brand"><span className="ic"><CircleHelp size={20} aria-hidden="true" /></span><span><span className="block font-semibold">Pertanyaan umum</span><span className="mu">Cara mengajukan layanan, jadwal, dan pembayaran.</span></span></Link>
        <Link href="/privasi" className="card flex items-center gap-3 hover:border-brand"><span className="ic"><ShieldCheck size={20} aria-hidden="true" /></span><span><span className="block font-semibold">Privasi dan keamanan data</span><span className="mu">Bagaimana data Anda dipakai dan dilindungi.</span></span></Link>
      </div>
      <p className="hint mt-6">{s.institution_verified ? `Layanan resmi ${s.institution_name}.` : "Identitas institusi pengelola belum diverifikasi. Informasi di sini dikelola oleh pengelola aplikasi."}</p>
    </div>
  );
}
