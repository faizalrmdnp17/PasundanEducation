import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { listUsers } from "@/server/domain/admin";
import { Disclosure, Empty, PageHead, Pager } from "@/components/common";
import { UserEditor } from "@/components/admin/AdminForms";
import { ROLES, ROLE_LABEL, type Role } from "@/lib/constants";
import { formatShortDate } from "@/lib/format";

export const metadata: Metadata = { title: "Pengguna dan peran" };

export default async function Page({ searchParams }: { searchParams: Promise<{ q?: string; peran?: string; status?: string; hal?: string }> }) {
  const me = await requireUser({ next: "/admin/pengguna", roles: ["admin"] });
  const sp = await searchParams;
  const q = (sp.q ?? "").slice(0, 80);
  const peran = (ROLES as readonly string[]).includes(sp.peran ?? "") ? sp.peran : undefined;
  const status = ["active", "suspended", "pending_approval"].includes(sp.status ?? "") ? sp.status : undefined;
  const page = Math.max(1, Number(sp.hal) || 1);
  const res = await listUsers({ q, role: peran, status, page, size: 15 });
  const stLabel: Record<string, [string, string]> = { active: ["Aktif", "badge-ok"], suspended: ["Ditangguhkan", "badge-bad"], pending_approval: ["Menunggu persetujuan", "badge-warn"] };
  return (
    <div>
      <PageHead title="Pengguna dan peran" desc="Cari pengguna, ubah peran, tangguhkan akun, dan verifikasi identitas atau nomor WhatsApp kerja." />
      <form action="/admin/pengguna" method="get" role="search" className="mb-4 flex flex-wrap gap-2">
        <label className="block min-w-[220px] flex-1"><span className="sr-only">Cari nama, email, NPM, atau NIDN</span><input name="q" type="search" defaultValue={q} placeholder="Cari nama, email, NPM, atau NIDN" className="input" /></label>
        <label className="block"><span className="sr-only">Peran</span><select name="peran" defaultValue={peran ?? ""} className="input"><option value="">Semua peran</option>{ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</select></label>
        <label className="block"><span className="sr-only">Status</span><select name="status" defaultValue={status ?? ""} className="input"><option value="">Semua status</option><option value="active">Aktif</option><option value="suspended">Ditangguhkan</option><option value="pending_approval">Menunggu persetujuan</option></select></label>
        <button className="btn" type="submit">Terapkan</button>
      </form>
      {res.items.length === 0 ? <Empty title="Pengguna tidak ditemukan" action={<Link href="/admin/pengguna" className="btn btn-l btn-sm">Reset filter</Link>} /> : (
        <>
          <p className="mu mb-2">{res.total} pengguna</p>
          <div className="space-y-2.5">
            {res.items.map((u) => {
              const [sl, sc] = stLabel[u.status] ?? [u.status, "badge-mute"];
              return (
                <Disclosure key={u.id} summary={
                  <>
                    <span className="flex flex-wrap items-center gap-2"><span className="font-semibold">{u.full_name}</span><span className={`badge ${sc}`}>{sl}</span>{u.id === me.id ? <span className="badge badge-info">Anda</span> : null}</span>
                    <span className="mu block truncate">{u.email} · {u.roles.map((r: Role) => ROLE_LABEL[r]).join(", ") || "tanpa peran"}{u.npm ? ` · NPM ${u.npm}` : ""}{u.nidn ? ` · NIDN ${u.nidn}` : ""} · sejak {formatShortDate(u.created_at)}</span>
                  </>
                }>
                  <UserEditor u={{ id: u.id, status: u.status, roles: u.roles, whatsapp_number: u.whatsapp_number, whatsapp_verified: u.whatsapp_verified, identity_verified: u.identity_verified }} self={u.id === me.id} />
                </Disclosure>
              );
            })}
          </div>
          <Pager page={res.page} totalPages={res.totalPages} path="/admin/pengguna" params={{ q: q || undefined, peran, status }} />
        </>
      )}
    </div>
  );
}
