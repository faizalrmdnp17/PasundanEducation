import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { listResourceCategories, listResources } from "@/server/domain/resources";
import { Disclosure, PageHead, Pager } from "@/components/common";
import { ResourceForm } from "@/components/admin/AdminForms";
import { RESOURCE_KIND_LABEL } from "@/lib/constants";

export const metadata: Metadata = { title: "Kelola pustaka" };

export default async function Page({ searchParams }: { searchParams: Promise<{ q?: string; hal?: string }> }) {
  const user = await requireUser({ next: "/admin/pustaka", roles: ["admin"] });
  const sp = await searchParams;
  const q = (sp.q ?? "").slice(0, 80);
  const page = Math.max(1, Number(sp.hal) || 1);
  const [cats, res] = await Promise.all([listResourceCategories(), listResources({ userId: user.id, q, includeUnpublished: true, page, size: 15 })]);
  const blank = { category_id: "", kind: "ebook", title: "", authors: "", publisher: "", year: "", description: "", access_type: "link" as const, external_url: "", license_note: "", is_published: true };
  return (
    <div>
      <PageHead title="Kelola pustaka" desc="Tambahkan hanya sumber yang boleh diakses atau dibagikan secara sah. Isi catatan lisensi bila ada pembatasan." />
      <Disclosure summary={<span className="font-semibold text-brand-text">Tambah sumber baru</span>}><ResourceForm init={blank} categories={cats} /></Disclosure>
      <form action="/admin/pustaka" method="get" role="search" className="my-4 flex gap-2"><label className="block flex-1"><span className="sr-only">Cari sumber</span><input name="q" type="search" defaultValue={q} placeholder="Cari judul atau penulis" className="input" /></label><button className="btn" type="submit">Cari</button></form>
      <p className="mu mb-2">{res.total} sumber</p>
      <div className="space-y-2.5">
        {res.items.map((r) => (
          <Disclosure key={r.id} summary={<><span className="flex flex-wrap items-center gap-2"><span className="font-semibold">{r.title}</span><span className="badge badge-info">{RESOURCE_KIND_LABEL[r.kind] ?? r.kind}</span>{!r.is_published ? <span className="badge badge-mute">Disembunyikan</span> : null}</span><span className="mu block truncate">{[r.authors, r.year].filter(Boolean).join(" · ")}</span></>}>
            <ResourceForm init={{ id: r.id, category_id: cats.find((c) => c.code === r.category_code)?.id ?? "", kind: r.kind, title: r.title, authors: r.authors ?? "", publisher: r.publisher ?? "", year: r.year ? String(r.year) : "", description: r.description ?? "", access_type: r.access_type, external_url: r.external_url ?? "", license_note: r.license_note ?? "", is_published: r.is_published }} categories={cats} />
          </Disclosure>
        ))}
      </div>
      <Pager page={res.page} totalPages={res.totalPages} path="/admin/pustaka" params={{ q: q || undefined }} />
    </div>
  );
}
