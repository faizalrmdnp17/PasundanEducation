import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { listAuditLogs } from "@/server/domain/admin";
import { Empty, PageHead, Pager } from "@/components/common";
import { formatDateTime } from "@/lib/format";

export const metadata: Metadata = { title: "Jejak audit" };

export default async function Page({ searchParams }: { searchParams: Promise<{ q?: string; aksi?: string; hal?: string }> }) {
  await requireUser({ next: "/admin/audit", roles: ["admin"] });
  const sp = await searchParams;
  const q = (sp.q ?? "").slice(0, 80);
  const aksi = (sp.aksi ?? "").slice(0, 40);
  const page = Math.max(1, Number(sp.hal) || 1);
  const res = await listAuditLogs({ q, action: aksi || undefined, page, size: 30 });
  return (
    <div>
      <PageHead title="Jejak audit" desc="Catatan tindakan penting: masuk, perubahan peran, status pengajuan, pembayaran, dan pengaturan. Catatan tidak dapat diubah dari aplikasi." />
      <form action="/admin/audit" method="get" role="search" className="mb-4 flex flex-wrap gap-2">
        <label className="block min-w-[200px] flex-1"><span className="sr-only">Cari pelaku, tindakan, atau ID</span><input name="q" type="search" defaultValue={q} placeholder="Cari pelaku, tindakan, atau ID" className="input" /></label>
        <label className="block"><span className="sr-only">Awalan tindakan</span><input name="aksi" defaultValue={aksi} placeholder="Awalan tindakan, mis. request" className="input" /></label>
        <button className="btn" type="submit">Terapkan</button>
      </form>
      {res.items.length === 0 ? <Empty title="Tidak ada catatan" /> : (
        <>
          <p className="mu mb-2">{res.total} catatan</p>
          <div className="table-wrap"><table className="tbl">
            <thead><tr><th>Waktu</th><th>Pelaku</th><th>Tindakan</th><th>Objek</th><th>IP</th></tr></thead>
            <tbody>
              {res.items.map((a) => (
                <tr key={a.id}>
                  <td className="whitespace-nowrap">{formatDateTime(a.created_at)}</td>
                  <td>{a.actor_name ?? "Sistem"}{a.actor_role ? <span className="mu block">{a.actor_role}</span> : null}</td>
                  <td><code className="text-[12px]">{a.action}</code>{a.meta && Object.keys(a.meta).length ? <span className="mu block max-w-[34ch] truncate" title={JSON.stringify(a.meta)}>{JSON.stringify(a.meta)}</span> : null}</td>
                  <td className="mu">{a.entity_type ?? "-"}{a.entity_id ? <span className="block max-w-[14ch] truncate" title={a.entity_id}>{a.entity_id}</span> : null}</td>
                  <td className="mu">{a.ip ?? "-"}</td>
                </tr>
              ))}
            </tbody>
          </table></div>
          <Pager page={res.page} totalPages={res.totalPages} path="/admin/audit" params={{ q: q || undefined, aksi: aksi || undefined }} />
        </>
      )}
    </div>
  );
}
