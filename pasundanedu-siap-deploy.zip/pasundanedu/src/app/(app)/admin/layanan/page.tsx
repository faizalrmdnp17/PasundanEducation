import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { listCategories, listServices } from "@/server/domain/services";
import { listStaff } from "@/server/domain/admin";
import { Disclosure, PageHead } from "@/components/common";
import { ServiceForm } from "@/components/admin/AdminForms";
import { ICONS, ServiceIcon } from "@/components/icons";
import { formatRupiah } from "@/lib/format";

export const metadata: Metadata = { title: "Katalog layanan" };

export default async function Page() {
  await requireUser({ next: "/admin/layanan", roles: ["admin"] });
  const [cats, list, staff] = await Promise.all([listCategories(), listServices({ includeInactive: true, size: 100 }), listStaff()]);
  const icons = Object.keys(ICONS);
  const blank = { category_id: "", name: "", description: "", icon: "file-text", price_idr: 0, duration_minutes: null, capacity: null, requirements: [], estimated_process: null, requires_appointment: false, requires_documents: false, cancellation_policy: "Dapat dibatalkan sebelum diproses.", is_active: true, staff_ids: [] };
  return (
    <div>
      <PageHead title="Katalog layanan" desc="Tambah layanan, atur penanggung jawab, persyaratan, dan tarif. Tarif baru berlaku hanya bila pembayaran diaktifkan di Pengaturan." />
      <Disclosure summary={<span className="font-semibold text-brand-text">Tambah layanan baru</span>}>
        <ServiceForm init={blank} categories={cats} staff={staff} icons={icons} />
      </Disclosure>
      <div className="mt-4 space-y-2.5">
        {list.items.map((s) => (
          <Disclosure key={s.id} summary={
            <span className="flex items-center gap-3">
              <span className="ic !size-10"><ServiceIcon name={s.icon} /></span>
              <span className="min-w-0"><span className="flex flex-wrap items-center gap-2"><span className="font-semibold">{s.name}</span>{!s.is_active ? <span className="badge badge-mute">Nonaktif</span> : null}</span><span className="mu block truncate">{s.category_name} · {formatRupiah(s.price_idr)} · {s.staff.map((x) => x.name).join(", ") || "belum ada penanggung jawab"}</span></span>
            </span>
          }>
            <ServiceForm init={{ id: s.id, category_id: s.category_id, name: s.name, description: s.description, icon: s.icon, price_idr: s.price_idr, duration_minutes: s.duration_minutes, capacity: s.capacity, requirements: s.requirements, estimated_process: s.estimated_process, requires_appointment: s.requires_appointment, requires_documents: s.requires_documents, cancellation_policy: s.cancellation_policy, is_active: s.is_active, staff_ids: s.staff.map((x) => x.id) }} categories={cats} staff={staff} icons={icons} />
          </Disclosure>
        ))}
      </div>
    </div>
  );
}
