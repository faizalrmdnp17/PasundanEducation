import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { getSettings } from "@/server/domain/settings";
import { PageHead } from "@/components/common";
import { SettingsForm } from "@/components/admin/AdminForms";

export const metadata: Metadata = { title: "Pengaturan" };

export default async function Page() {
  await requireUser({ next: "/admin/pengaturan", roles: ["admin"] });
  const s = await getSettings();
  return (
    <div className="mx-auto max-w-[760px]">
      <PageHead title="Pengaturan" desc="Pengaturan umum aplikasi. Kunci API, token, dan kata sandi tidak disimpan di sini; semuanya diatur lewat variabel lingkungan server." />
      <SettingsForm init={{ payments_enabled: s.payments_enabled, bank_account_info: s.bank_account_info, institution_name: s.institution_name, institution_verified: s.institution_verified }} />
    </div>
  );
}
