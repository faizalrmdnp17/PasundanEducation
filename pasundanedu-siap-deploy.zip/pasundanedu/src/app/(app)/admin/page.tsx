import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { getReports, listRoleRequests } from "@/server/domain/admin";
import { Empty, PageHead, SectionHead } from "@/components/common";
import { RoleDecision } from "@/components/admin/AdminForms";
import { REQUEST_STATUSES, STATUS_LABEL, ROLE_LABEL } from "@/lib/constants";
import { formatDateTime, formatRupiah, formatShortDate, jakartaDateKey, timeAgo } from "@/lib/format";

export const metadata: Metadata = { title: "Ringkasan admin" };
export const dynamic = "force-dynamic";

const INT_STATUS: Record<string, [string, string]> = { link_only: ["Tautan saja", "badge-mute"], not_connected: ["Belum terhubung", "badge-warn"], connected: ["Terhubung", "badge-ok"], error: ["Galat", "badge-bad"] };

function Stat({ label, value, sub, href }: { label: string; value: string | number; sub?: string; href?: string }) {
  const body = (<><span className="block text-[26px] font-bold leading-none tracking-tight">{value}</span><span className="mu mt-1.5 block">{label}</span>{sub ? <span className="hint block">{sub}</span> : null}</>);
  return href ? <Link href={href} className="card hover:border-brand">{body}</Link> : <div className="card">{body}</div>;
}

export default async function Page() {
  await requireUser({ next: "/admin", roles: ["admin"] });
  const [r, roleReqs] = await Promise.all([getReports(), listRoleRequests("pending")]);
  const total = Object.values(r.byStatus).reduce((a, b) => a + b, 0);
  // Isi hari tanpa pengajuan dengan 0 agar grafik 14 hari utuh.
  const byDay = new Map(r.daily.map((d) => [d.d, d.n]));
  const days = Array.from({ length: 14 }, (_, i) => {
    const d = jakartaDateKey(new Date(Date.now() - (13 - i) * 86400_000));
    return { d, n: byDay.get(d) ?? 0 };
  });
  const max = Math.max(1, ...days.map((d) => d.n));
  const maxPop = Math.max(1, ...r.popular.map((p) => p.n));
  return (
    <div>
      <PageHead title="Ringkasan" desc="Kondisi layanan, pengguna, dan integrasi saat ini. Semua angka berasal dari database." />
      {r.unassigned > 0 ? <div className="alert alert-warn mb-4" role="status">{r.unassigned} pengajuan aktif belum memiliki penanggung jawab. <Link href="/pengajuan?k=semua&tanpa=1" className="font-semibold underline">Tinjau</Link></div> : null}

      <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
        <Stat label="Total pengajuan" value={total} href="/pengajuan?k=semua" />
        <Stat label="Perlu ditinjau" value={r.byStatus.submitted ?? 0} href="/pengajuan?k=baru" />
        <Stat label="Selesai" value={r.byStatus.completed ?? 0} sub={r.avgCompletionHours != null ? `Rata-rata ${r.avgCompletionHours} jam` : "Belum ada data"} />
        <Stat label="Nilai layanan" value={r.feedback.n ? `${r.feedback.avg} / 5` : "-"} sub={`${r.feedback.n} penilaian`} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-x-8 lg:grid-cols-2">
        <section>
          <SectionHead title="Pengajuan per status" />
          <ul className="card space-y-2">
            {REQUEST_STATUSES.map((s) => (
              <li key={s} className="flex items-center gap-3 text-[13px]">
                <span className="w-36 shrink-0">{STATUS_LABEL[s]}</span>
                <span className="h-2.5 flex-1 overflow-hidden rounded-full bg-chip"><span className="block h-full rounded-full bg-brand" style={{ width: `${total ? ((r.byStatus[s] ?? 0) / total) * 100 : 0}%` }} /></span>
                <span className="w-8 text-right font-semibold tabular-nums">{r.byStatus[s] ?? 0}</span>
              </li>
            ))}
          </ul>
        </section>
        <section>
          <SectionHead title="Layanan terpopuler (90 hari)" />
          {r.popular.length ? (
            <ul className="card space-y-2">
              {r.popular.map((p) => (
                <li key={p.name} className="flex items-center gap-3 text-[13px]">
                  <span className="w-44 shrink-0 truncate">{p.name}</span>
                  <span className="h-2.5 flex-1 overflow-hidden rounded-full bg-chip"><span className="block h-full rounded-full bg-accent" style={{ width: `${(p.n / maxPop) * 100}%` }} /></span>
                  <span className="w-8 text-right font-semibold tabular-nums">{p.n}</span>
                </li>
              ))}
            </ul>
          ) : <Empty title="Belum ada data" />}
        </section>
      </div>

      <SectionHead title="Pengajuan 14 hari terakhir" />
      <div className="card">
        {days.some((d) => d.n > 0) ? (
          <div className="flex h-32 items-end gap-1.5" role="img" aria-label={`Pengajuan harian, ${days.reduce((a, d) => a + d.n, 0)} dalam 14 hari`}>
            {days.map((d) => (
              <div key={d.d} className="flex h-full flex-1 flex-col items-center justify-end gap-1" title={`${d.d}: ${d.n}`}>
                <span className="text-[11px] font-semibold tabular-nums">{d.n}</span>
                <span className={`w-full rounded-t-md ${d.n ? "bg-brand" : "bg-chip"}`} style={{ height: `${d.n ? Math.max(8, (d.n / max) * 80) : 4}%` }} />
                <span className="text-[10.5px] text-muted">{d.d.slice(8)}</span>
              </div>
            ))}
          </div>
        ) : <p className="mu">Belum ada pengajuan dalam 14 hari terakhir.</p>}
      </div>

      <SectionHead title="Permohonan peran dosen dan petugas" href="/admin/pengguna" linkLabel="Kelola pengguna" />
      {roleReqs.length ? (
        <ul className="space-y-2.5">
          {roleReqs.map((q) => (
            <li key={q.id} className="card">
              <p className="font-semibold">{q.full_name} <span className="badge badge-info ml-1">{ROLE_LABEL[q.requested_role as "dosen" | "petugas"]}</span></p>
              <p className="mu">{q.email} · NIDN/NIP {q.nidn ?? "-"} · diajukan {timeAgo(q.created_at)}</p>
              <RoleDecision id={q.id} />
            </li>
          ))}
        </ul>
      ) : <Empty title="Tidak ada permohonan menunggu" />}

      <div className="mt-2 grid grid-cols-1 gap-x-8 lg:grid-cols-2">
        <section>
          <SectionHead title="Jadwal terdekat" />
          {r.upcoming.length ? (
            <ul className="card !py-1">{r.upcoming.map((a) => (
              <li key={a.id} className="row text-[13px]"><span className="min-w-0 flex-1"><Link href={`/pengajuan/${a.request_id}`} className="block truncate font-semibold hover:underline">{a.service_name}</Link><span className="mu">{formatDateTime(a.starts_at)} · {a.student_name} dengan {a.staff_name}</span></span></li>
            ))}</ul>
          ) : <Empty title="Tidak ada jadwal mendatang" />}
        </section>
        <section>
          <SectionHead title="Pemakaian pustaka (30 hari)" href="/admin/pustaka" linkLabel="Kelola" />
          <div className="card text-[13.5px]">
            <dl className="grid grid-cols-2 gap-3">
              <div><dt className="mu">Sumber dibuka</dt><dd className="text-[20px] font-bold">{r.library.opens}</dd></div>
              <div><dt className="mu">Permintaan pinjam</dt><dd className="text-[20px] font-bold">{r.library.borrows}</dd></div>
              <div><dt className="mu">Pengguna aktif</dt><dd className="text-[20px] font-bold">{r.library.users}</dd></div>
              <div><dt className="mu">Total favorit</dt><dd className="text-[20px] font-bold">{r.library.favs}</dd></div>
            </dl>
            {r.library.top.length ? <><p className="mu mt-3">Paling sering dibuka</p><ol className="mt-1 list-decimal space-y-0.5 pl-5">{r.library.top.map((t) => <li key={t.title}>{t.title} ({t.n})</li>)}</ol></> : null}
          </div>
        </section>
      </div>

      <div className="mt-2 grid grid-cols-1 gap-x-8 lg:grid-cols-2">
        <section>
          <SectionHead title="Integrasi" href="/admin/integrasi" linkLabel="Kelola" />
          {r.integrations.length ? (
            <ul className="card !py-1">{r.integrations.map((i) => { const [l, c] = INT_STATUS[i.status] ?? [i.status, "badge-mute"]; return (
              <li key={i.id} className="row text-[13px]"><span className="min-w-0 flex-1 truncate font-semibold">{i.name}</span><span className={`badge ${c}`}>{l}</span></li>
            ); })}</ul>
          ) : <Empty title="Belum ada integrasi" />}
        </section>
        <section>
          <SectionHead title="Notifikasi dan pengguna" href="/admin/whatsapp" linkLabel="Kelola WhatsApp" />
          <div className="card text-[13.5px]">
            <p className="mu">Antrean pesan</p>
            <p className="mt-1 flex flex-wrap gap-1.5">{Object.entries(r.notificationJobs).length ? Object.entries(r.notificationJobs).map(([k, n]) => <span key={k} className={`badge ${k === "dead" || k === "failed" ? "badge-bad" : k === "sent" ? "badge-ok" : "badge-mute"}`}>{k} {n}</span>) : <span className="mu">Kosong</span>}</p>
            {r.failedMessages.length ? <p className="alert alert-warn mt-3">{r.failedMessages.length} pesan gagal terkirim terakhir. Lihat detail di halaman WhatsApp.</p> : null}
            <p className="mu mt-4">Pengguna aktif per peran</p>
            <p className="mt-1 flex flex-wrap gap-1.5">{(["mahasiswa", "dosen", "petugas", "admin"] as const).map((k) => <span key={k} className="badge badge-info">{ROLE_LABEL[k]} {r.usersByRole[k] ?? 0}</span>)}</p>
            <p className="mu mt-4">Pembayaran: {r.paymentsEnabled ? "aktif" : "nonaktif (semua layanan tanpa biaya)"}{r.payments ? ` · lunas ${formatRupiah(r.payments.paid_total)} (${r.payments.paid_count}), menunggu verifikasi ${r.payments.awaiting}` : ""}</p>
          </div>
        </section>
      </div>
      <p className="hint mt-6">Diperbarui {formatShortDate(new Date())}. Muat ulang halaman untuk data terbaru.</p>
    </div>
  );
}
