import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { listPayments } from "@/server/domain/payments";
import { paymentsEnabled } from "@/server/domain/settings";
import { Empty, PageHead, Pager } from "@/components/common";
import { PAYMENT_STATUS_LABEL } from "@/lib/constants";
import { formatDateTime, formatRupiah } from "@/lib/format";

export const metadata: Metadata = { title: "Pembayaran" };

const FILTERS = [["", "Semua"], ["awaiting_verification", "Menunggu verifikasi"], ["pending", "Belum dibayar"], ["paid", "Lunas"], ["refunded", "Dikembalikan"], ["rejected", "Ditolak"]] as const;

export default async function Page({ searchParams }: { searchParams: Promise<{ status?: string; hal?: string }> }) {
  await requireUser({ next: "/admin/pembayaran", roles: ["admin"] });
  const sp = await searchParams;
  const status = FILTERS.find(([k]) => k === (sp.status ?? ""))?.[0] ?? "";
  const page = Math.max(1, Number(sp.hal) || 1);
  const [res, on] = await Promise.all([listPayments({ status: status || undefined, page, size: 20 }), paymentsEnabled()]);
  return (
    <div>
      <PageHead title="Pembayaran" desc="Transfer manual dengan verifikasi petugas. Integrasi gateway pembayaran belum tersedia." />
      <div className={`alert mb-4 ${on ? "alert-ok" : "alert-warn"}`} role="status">
        {on ? "Pembayaran aktif." : "Pembayaran nonaktif: semua pengajuan diproses tanpa biaya."} <Link href="/admin/pengaturan" className="font-semibold underline">Ubah di Pengaturan</Link>
      </div>
      <div className="scroll-x mb-4" role="group" aria-label="Filter status">
        {FILTERS.map(([k, l]) => <Link key={k} href={k ? `/admin/pembayaran?status=${k}` : "/admin/pembayaran"} className={`chip ${status === k ? "on" : ""}`} aria-current={status === k ? "true" : undefined}>{l}</Link>)}
      </div>
      {res.items.length === 0 ? <Empty title="Belum ada pembayaran" /> : (
        <>
          <div className="table-wrap"><table className="tbl">
            <thead><tr><th>Pengajuan</th><th>Mahasiswa</th><th>Nominal</th><th>Status</th><th>Dibuat</th></tr></thead>
            <tbody>{res.items.map((p) => (
              <tr key={p.id}>
                <td><Link href={`/pengajuan/${p.request_id}`} className="font-semibold text-brand-text hover:underline">{p.request_number}</Link><span className="mu block">{p.service_name}</span></td>
                <td>{p.student_name}</td>
                <td className="whitespace-nowrap">{formatRupiah(p.amount_idr)}</td>
                <td><span className="badge badge-mute">{PAYMENT_STATUS_LABEL[p.status] ?? p.status}</span></td>
                <td className="mu whitespace-nowrap">{formatDateTime(p.created_at)}</td>
              </tr>
            ))}</tbody>
          </table></div>
          <Pager page={res.page} totalPages={res.totalPages} path="/admin/pembayaran" params={{ status: status || undefined }} />
        </>
      )}
    </div>
  );
}
