import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { listIntegrationEvents, listIntegrations } from "@/server/domain/admin";
import { Disclosure, Empty, PageHead, SectionHead } from "@/components/common";
import { CheckIntegration, IntegrationForm } from "@/components/admin/AdminForms";
import { INTEGRATION_KINDS } from "@/lib/constants";
import { formatDateTime } from "@/lib/format";

export const metadata: Metadata = { title: "Integrasi LMS" };

const ST: Record<string, [string, string]> = { link_only: ["Tautan saja", "badge-mute"], not_connected: ["Belum terhubung", "badge-warn"], connected: ["Terhubung", "badge-ok"], error: ["Galat", "badge-bad"] };

export default async function Page() {
  await requireUser({ next: "/admin/integrasi", roles: ["admin"] });
  const [list, events] = await Promise.all([listIntegrations(), listIntegrationEvents(15)]);
  const blank = { code: "", name: "", kind: "google_classroom", connection_type: "link", base_url: "", auth_method: "none", is_active: false, instructions: "" };
  return (
    <div>
      <PageHead title="Integrasi LMS dan platform belajar" desc="Tautan ke platform lain tampil sebagai pintasan. Status Terhubung hanya muncul setelah koneksi API benar-benar berhasil diperiksa." />
      <div className="alert alert-info mb-4" role="note">
        <strong>Yang sudah berfungsi:</strong> pintasan tautan (Google Classroom, Meet, repositori) dan pemeriksaan koneksi Moodle (hanya membaca info situs). <strong>Belum tersedia:</strong> sinkronisasi kursus dan nilai, LTI 1.3, serta endpoint webhook LMS. Banyak situs juga melarang ditampilkan di dalam bingkai (iframe), sehingga aplikasi membukanya di tab baru.
      </div>
      <Disclosure summary={<span className="font-semibold text-brand-text">Tambah integrasi</span>}><IntegrationForm init={blank} /></Disclosure>
      <div className="mt-4 space-y-2.5">
        {list.length === 0 ? <Empty title="Belum ada integrasi" /> : list.map((i) => { const [l, c] = ST[i.status] ?? [i.status, "badge-mute"]; const kind = INTEGRATION_KINDS.find((k) => k.value === i.kind)?.label ?? i.kind; return (
          <Disclosure key={i.id} summary={<><span className="flex flex-wrap items-center gap-2"><span className="font-semibold">{i.name}</span><span className={`badge ${c}`}>{l}</span>{!i.is_active ? <span className="badge badge-mute">Nonaktif</span> : null}</span><span className="mu block truncate">{kind} · {i.connection_type === "link" ? "tautan" : i.connection_type === "api" ? "API" : "LTI"}{i.base_url ? ` · ${i.base_url}` : ""}</span></>}>
            {i.kind === "lti13" ? <p className="alert alert-warn mt-3">LTI 1.3 belum diimplementasikan. Entri ini hanya catatan.</p> : null}
            {i.last_error ? <p className="alert alert-bad mt-3">Galat terakhir: {i.last_error}</p> : null}
            {i.last_checked_at ? <p className="mu mt-3">Terakhir diperiksa {formatDateTime(i.last_checked_at)}</p> : null}
            {i.connection_type === "api" ? <div className="mt-3"><CheckIntegration id={i.id} />{i.kind === "moodle" ? <p className="hint">Token Moodle dibaca dari variabel lingkungan server <code>MOODLE_WS_TOKEN</code>.</p> : null}</div> : null}
            <IntegrationForm init={{ id: i.id, code: i.code, name: i.name, kind: i.kind, connection_type: i.connection_type, base_url: i.base_url ?? "", auth_method: i.auth_method, is_active: i.is_active, instructions: i.instructions ?? "" }} />
          </Disclosure>
        ); })}
      </div>
      <SectionHead title="Peristiwa terakhir" />
      {events.length ? <ul className="card !py-1">{events.map((e) => <li key={e.id} className="row text-[13px]"><span className="min-w-0 flex-1">{e.message}<span className="mu block">{e.integration_name ?? "Sistem"} · {formatDateTime(e.created_at)}</span></span><span className={`badge ${e.level === "error" ? "badge-bad" : e.level === "warn" ? "badge-warn" : "badge-mute"}`}>{e.level}</span></li>)}</ul> : <Empty title="Belum ada peristiwa" />}
    </div>
  );
}
