import { requireUser } from "@/server/auth/guard";

export default async function Layout({ children }: { children: React.ReactNode }) {
  await requireUser({ roles: ["admin"] });
  return children;
}
