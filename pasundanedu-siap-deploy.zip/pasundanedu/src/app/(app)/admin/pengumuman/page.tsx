import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { listAnnouncements } from "@/server/domain/notifications";
import { Disclosure, PageHead } from "@/components/common";
import { AnnouncementForm } from "@/components/admin/AdminForms";
import { ANNOUNCEMENT_LABEL } from "@/lib/constants";

export const metadata: Metadata = { title: "Pengumuman" };

export default async function Page() {
  await requireUser({ next: "/admin/pengumuman", roles: ["admin"] });
  const list = await listAnnouncements({ includeUnpublished: true, limit: 100 });
  return (
    <div>
      <PageHead title="Pengumuman" desc="Pengumuman yang diterbitkan tampil di Beranda dan halaman Informasi." />
      <Disclosure summary={<span className="font-semibold text-brand-text">Buat pengumuman</span>}><AnnouncementForm init={{ title: "", body: "", category: "umum", event_date: "", is_published: true }} /></Disclosure>
      <div className="mt-4 space-y-2.5">
        {list.map((a) => (
          <Disclosure key={a.id} summary={<><span className="flex flex-wrap items-center gap-2"><span className="font-semibold">{a.title}</span><span className="badge badge-info">{ANNOUNCEMENT_LABEL[a.category] ?? a.category}</span>{!a.is_published ? <span className="badge badge-mute">Draf</span> : null}</span><span className="mu">{a.event_date ?? "Tanpa tanggal"}</span></>}>
            <AnnouncementForm init={{ id: a.id, title: a.title, body: a.body ?? "", category: a.category, event_date: a.event_date ?? "", is_published: a.is_published }} />
          </Disclosure>
        ))}
      </div>
    </div>
  );
}
