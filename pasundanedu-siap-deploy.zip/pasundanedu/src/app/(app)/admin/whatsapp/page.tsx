import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { getWhatsappAdmin } from "@/server/domain/admin";
import { Disclosure, Empty, PageHead, SectionHead } from "@/components/common";
import { RequeueButton, TemplateForm } from "@/components/admin/AdminForms";
import { formatDateTime } from "@/lib/format";

export const metadata: Metadata = { title: "WhatsApp dan email" };
export const dynamic = "force-dynamic";

const TPL: Record<string, [string, string]> = { draft: ["Draf", "badge-mute"], submitted: ["Diajukan", "badge-info"], approved: ["Disetujui", "badge-ok"], rejected: ["Ditolak", "badge-bad"] };
const MSG: Record<string, string> = { queued: "badge-mute", sent: "badge-info", delivered: "badge-ok", read: "badge-ok", failed: "badge-bad", skipped: "badge-warn" };

function Row({ label, ok, hint }: { label: string; ok: boolean; hint?: string }) {
  return (
    <li className="row text-[13.5px]">
      <span className="min-w-0 flex-1"><span className="block font-semibold">{label}</span>{hint ? <span className="mu">{hint}</span> : null}</span>
      <span className={`badge ${ok ? "badge-ok" : "badge-warn"}`}>{ok ? "Terisi" : "Belum diisi"}</span>
    </li>
  );
}

export default async function Page() {
  await requireUser({ next: "/admin/whatsapp", roles: ["admin"] });
  const w = await getWhatsappAdmin();
  const c = w.config;
  return (
    <div>
      <PageHead title="WhatsApp dan email" desc="Status koneksi, template pesan, antrean, dan log pengiriman. Nilai rahasia tidak pernah ditampilkan di halaman ini." />

      {!c.configured ? <div className="alert alert-warn mb-4" role="status"><strong>WhatsApp belum terhubung.</strong> Pesan WhatsApp tidak dikirim. Notifikasi di aplikasi dan email tetap berjalan. Isi kredensial WhatsApp Cloud API di variabel lingkungan server, lalu muat ulang halaman ini.</div> : <div className="alert alert-ok mb-4" role="status">Kredensial WhatsApp Cloud API terisi. Pesan hanya terkirim bila template berstatus Disetujui dan aktif.</div>}
      {w.email.simulated ? <div className="alert alert-warn mb-4" role="status"><strong>Email masih simulasi.</strong> {w.email.name}. Email tidak dikirim ke penerima sungguhan. Atur <code>EMAIL_PROVIDER=smtp</code> dan <code>SMTP_URL</code> di server untuk mengirim email.</div> : <div className={`alert mb-4 ${w.email.connected ? "alert-ok" : "alert-warn"}`} role="status">Email: {w.email.name} {w.email.connected ? "terhubung" : "belum dikonfigurasi"}.</div>}

      <div className="grid grid-cols-1 gap-x-8 lg:grid-cols-2">
        <section>
          <SectionHead title="Konfigurasi WhatsApp Cloud API" />
          <ul className="card !py-1">
            <Row label="Phone Number ID" ok={c.phoneNumberIdSet} />
            <Row label="Access token" ok={c.tokenSet} hint="Disimpan sebagai variabel lingkungan server, bukan di database." />
            <Row label="Business Account ID" ok={c.businessAccountIdSet} />
            <Row label="App secret (tanda tangan webhook)" ok={c.appSecretSet} hint="Tanpa ini, webhook masuk ditolak." />
            <Row label="Verify token webhook" ok={c.verifyTokenSet} />
          </ul>
          <div className="card mt-2.5 text-[13px]">
            <p className="mu">URL webhook untuk Meta</p>
            <p className="mt-1 break-all font-mono text-[12.5px]">{c.webhookUrl}</p>
            {c.businessNumber ? <p className="mu mt-2">Nomor bisnis: {c.businessNumber}</p> : null}
          </div>
        </section>
        <section>
          <SectionHead title="Antrean pesan" />
          <div className="card space-y-3">
            <p className="flex flex-wrap gap-1.5">{Object.keys(w.jobs).length ? Object.entries(w.jobs).map(([k, n]) => <span key={k} className={`badge ${k === "dead" || k === "failed" ? "badge-bad" : k === "sent" ? "badge-ok" : "badge-mute"}`}>{k} {n}</span>) : <span className="mu">Antrean kosong.</span>}</p>
            <p className="hint">Pesan gagal dicoba ulang otomatis dengan jeda bertahap; setelah 5 percobaan statusnya dead. Pesan tidak dikirim bila pengguna mencabut persetujuan, nomor tidak ada, atau template belum disetujui.</p>
            <RequeueButton />
          </div>
        </section>
      </div>

      <SectionHead title="Template pesan" />
      <p className="mu mb-2.5 max-w-[70ch]">Pesan di luar jendela 24 jam wajib memakai template yang disetujui Meta. Buat dan ajukan template di WhatsApp Business Manager, lalu catat statusnya di sini. Template tidak akan dipakai sebelum berstatus Disetujui dan aktif.</p>
      <div className="space-y-2.5">
        {w.templates.map((t) => { const [l, cls] = TPL[t.status] ?? [t.status, "badge-mute"]; return (
          <Disclosure key={t.id} summary={<><span className="flex flex-wrap items-center gap-2"><span className="font-semibold">{t.purpose}</span><span className={`badge ${cls}`}>{l}</span>{t.is_active ? <span className="badge badge-ok">Aktif</span> : <span className="badge badge-mute">Nonaktif</span>}</span><span className="mu block truncate">{t.name} · {t.language}</span></>}>
            <div className="mt-3 rounded-xl bg-soft p-3 text-[13px]"><p className="mu mb-1">Contoh isi (ajukan ke Meta persis seperti ini)</p><p className="whitespace-pre-line">{t.body_preview}</p>{t.variables.length ? <p className="mu mt-2">Variabel: {t.variables.map((v, i) => `{{${i + 1}}} ${v}`).join(", ")}</p> : null}</div>
            <TemplateForm t={{ id: t.id, name: t.name, language: t.language, status: t.status, is_active: t.is_active }} />
          </Disclosure>
        ); })}
      </div>

      <SectionHead title="Log pengiriman terakhir" />
      {w.logs.length === 0 ? <Empty title="Belum ada log pengiriman" /> : (
        <div className="table-wrap"><table className="tbl">
          <thead><tr><th>Waktu</th><th>Kanal</th><th>Penyedia</th><th>Template</th><th>Penerima</th><th>Status</th></tr></thead>
          <tbody>{w.logs.map((l) => (
            <tr key={l.id}><td className="mu whitespace-nowrap">{formatDateTime(l.created_at)}</td><td>{l.channel}</td><td>{l.provider === "log" ? <span className="badge badge-warn">simulasi (log)</span> : l.provider}</td><td>{l.template}</td><td className="mu">{l.recipient.replace(/.(?=.{4})/g, "•")}</td><td><span className={`badge ${MSG[l.status] ?? "badge-mute"}`}>{l.status}</span>{l.error ? <span className="mu block max-w-[30ch] truncate" title={l.error}>{l.error}</span> : null}</td></tr>
          ))}</tbody>
        </table></div>
      )}

      <SectionHead title="Webhook masuk terakhir" />
      {w.webhooks.length === 0 ? <Empty title="Belum ada webhook masuk" /> : (
        <ul className="card !py-1">{w.webhooks.map((e) => (
          <li key={e.id} className="row text-[13px]"><span className="min-w-0 flex-1">{e.event_type ?? "event"}<span className="mu block">{formatDateTime(e.created_at)}</span></span><span className={`badge ${e.signature_valid ? "badge-ok" : "badge-bad"}`}>{e.signature_valid ? "Tanda tangan valid" : "Tanda tangan tidak valid"}</span></li>
        ))}</ul>
      )}
    </div>
  );
}
