import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { RequestDetailView } from "@/components/request/RequestDetailView";

export const metadata: Metadata = { title: "Detail pengajuan" };

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser({ next: `/pengajuan/${id}`, roles: ["dosen", "petugas", "admin"] });
  return <RequestDetailView user={user} id={id} />;
}
