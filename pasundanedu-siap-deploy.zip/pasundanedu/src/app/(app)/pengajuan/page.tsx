import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { listRequests } from "@/server/domain/requests";
import { Empty, PageHead, Pager, RequestRow } from "@/components/common";

export const metadata: Metadata = { title: "Antrean pengajuan" };

const GROUPS = [
  { key: "baru", label: "Perlu ditinjau", status: "submitted" },
  { key: "proses", label: "Dalam proses", status: "under_review,awaiting_information,awaiting_payment,confirmed,in_progress" },
  { key: "selesai", label: "Selesai", status: "completed" },
  { key: "tutup", label: "Ditolak atau dibatalkan", status: "rejected,cancelled" },
  { key: "semua", label: "Semua", status: undefined },
] as const;

export default async function Page({ searchParams }: { searchParams: Promise<{ k?: string; q?: string; hal?: string; tanpa?: string }> }) {
  const user = await requireUser({ next: "/pengajuan", roles: ["dosen", "petugas", "admin"] });
  const sp = await searchParams;
  const g = GROUPS.find((x) => x.key === sp.k) ?? GROUPS[0];
  const q = (sp.q ?? "").slice(0, 80);
  const page = Math.max(1, Number(sp.hal) || 1);
  const unassigned = sp.tanpa === "1" && user.roles.includes("admin");
  const res = await listRequests(user, { as: "staff", status: g.status, q, page, size: 12, unassigned });
  const href = (k: string) => `/pengajuan?${new URLSearchParams({ k, ...(q ? { q } : {}) })}`;
  return (
    <div>
      <PageHead title="Antrean pengajuan" desc={user.roles.includes("admin") ? "Semua pengajuan di sistem." : "Pengajuan yang ditugaskan kepada Anda atau layanan yang Anda tangani."} />
      <div className="scroll-x mb-3" role="group" aria-label="Filter status">
        {GROUPS.map((x) => <Link key={x.key} href={href(x.key)} className={`chip ${g.key === x.key ? "on" : ""}`} aria-current={g.key === x.key ? "true" : undefined}>{x.label}</Link>)}
        {user.roles.includes("admin") ? <Link href={`/pengajuan?k=${g.key}&tanpa=${unassigned ? "0" : "1"}`} className={`chip ${unassigned ? "on" : ""}`} aria-current={unassigned ? "true" : undefined}>Belum ada penanggung jawab</Link> : null}
      </div>
      <form action="/pengajuan" method="get" role="search" className="mb-4 flex gap-2">
        <input type="hidden" name="k" value={g.key} />
        <label className="block flex-1"><span className="sr-only">Cari nomor, layanan, nama, atau NPM</span><input name="q" type="search" defaultValue={q} placeholder="Cari nomor, layanan, nama, atau NPM" className="input" /></label>
        <button className="btn" type="submit">Cari</button>
      </form>
      {res.items.length === 0 ? <Empty title="Tidak ada pengajuan" hint="Pengajuan baru akan muncul di sini dan Anda akan mendapat notifikasi." /> : (
        <>
          <p className="mu mb-2">{res.total} pengajuan</p>
          <div className="space-y-2.5">{res.items.map((r) => <RequestRow key={r.id} r={r} href={`/pengajuan/${r.id}`} showStudent />)}</div>
          <Pager page={res.page} totalPages={res.totalPages} path="/pengajuan" params={{ k: g.key, q: q || undefined, tanpa: unassigned ? "1" : undefined }} />
        </>
      )}
    </div>
  );
}
