import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { requireUser, homeFor } from "@/server/auth/guard";
import { listCategories } from "@/server/domain/services";
import { listRequests } from "@/server/domain/requests";
import { listMyAppointments } from "@/server/domain/appointments";
import { listAnnouncements } from "@/server/domain/notifications";
import { recentAccess } from "@/server/domain/resources";
import { Empty, RequestRow, SectionHead } from "@/components/common";
import { ServiceIcon, Search, CalendarDays, BookOpen } from "@/components/icons";
import { ANNOUNCEMENT_LABEL, RESOURCE_KIND_LABEL } from "@/lib/constants";
import { formatDayHeading, formatShortDate, formatTime, jakartaDateKey } from "@/lib/format";

export const metadata: Metadata = { title: "Beranda" };

export default async function Page({ searchParams }: { searchParams: Promise<{ baru?: string; email?: string }> }) {
  const user = await requireUser({ next: "/" });
  if (homeFor(user) !== "/") redirect(homeFor(user));
  const sp = await searchParams;
  const [cats, reqs, appts, news, recent] = await Promise.all([
    listCategories(),
    listRequests(user, { as: "student", size: 3 }),
    listMyAppointments(user.id, "student"),
    listAnnouncements({ limit: 3 }),
    recentAccess(user.id, 4),
  ]);
  const now = Date.now();
  const upcoming = appts.filter((a) => a.status === "booked" && new Date(a.ends_at).getTime() > now).slice(0, 2);
  const first = user.fullName.split(" ")[0];

  return (
    <div>
      {sp.baru ? (
        <div className="alert alert-ok mb-4" role="status">
          Akun Anda sudah dibuat.{" "}
          {user.emailVerified
            ? ""
            : sp.email === "gagal"
              ? "Email verifikasi belum dapat dikirim. Coba kirim ulang dari halaman Akun nanti, atau hubungi pengelola."
              : "Periksa email untuk tautan verifikasi agar dapat mengirim pengajuan."}
        </div>
      ) : null}

      <section className="rounded-2xl bg-brand-dark p-5 text-white lg:p-7">
        <p className="text-[13px] text-white/75">{user.npm ? `NPM ${user.npm}` : "Mahasiswa"}{user.studyProgram ? ` · ${user.studyProgram}` : ""}</p>
        <h1 className="mt-0.5 text-[24px] font-bold leading-tight lg:text-[28px]">Halo, {first}</h1>
        <p className="mt-1 text-[14px] text-white/85">Layanan apa yang Anda perlukan hari ini?</p>
        <form action="/layanan" method="get" role="search" className="mt-4 flex max-w-xl gap-2">
          <label className="relative block flex-1">
            <span className="sr-only">Cari layanan</span>
            <Search size={18} aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input name="q" type="search" placeholder="Cari layanan, mis. konsultasi skripsi" className="input pl-10 !border-transparent" />
          </label>
          <button className="btn btn-o" type="submit">Cari</button>
        </form>
      </section>

      <SectionHead title="Kategori layanan" href="/layanan" />
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
        {cats.map((c) => (
          <Link key={c.id} href={`/layanan?kategori=${c.code}`} className="card flex items-center gap-3 hover:border-brand">
            <span className="ic"><ServiceIcon name={c.icon} /></span>
            <span className="text-[13.5px] font-semibold leading-snug">{c.name}</span>
          </Link>
        ))}
      </div>

      <div className="mt-2 grid grid-cols-1 gap-x-8 lg:grid-cols-2">
        <section>
          <SectionHead title="Pengajuan terbaru" href="/riwayat" />
          {reqs.items.length ? (
            <div className="space-y-2.5">{reqs.items.map((r) => <RequestRow key={r.id} r={r} href={`/riwayat/${r.id}`} />)}</div>
          ) : (
            <Empty title="Belum ada pengajuan" hint="Pengajuan yang Anda buat akan muncul di sini beserta statusnya." action={<Link href="/layanan" className="btn btn-sm">Lihat layanan</Link>} />
          )}
        </section>

        <section>
          <SectionHead title="Jadwal terdekat" href="/jadwal" />
          {upcoming.length ? (
            <div className="space-y-2.5">
              {upcoming.map((a) => (
                <Link key={a.id} href={`/riwayat/${a.request_id}`} className="card flex items-center gap-3 hover:border-brand">
                  <span className="ic"><CalendarDays size={20} aria-hidden="true" /></span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold">{a.service_name}</span>
                    <span className="mu block">{formatDayHeading(jakartaDateKey(a.starts_at))}, {formatTime(a.starts_at)}–{formatTime(a.ends_at)} WIB</span>
                    <span className="mu block">{a.other_name} · {a.mode === "online" ? "Online" : a.location || "Tatap muka"}</span>
                  </span>
                </Link>
              ))}
            </div>
          ) : (
            <Empty title="Tidak ada jadwal mendatang" hint="Jadwal konsultasi yang Anda pesan akan tampil di sini." />
          )}
        </section>
      </div>

      <div className="grid grid-cols-1 gap-x-8 lg:grid-cols-2">
        <section>
          <SectionHead title="Pengumuman" href="/info" />
          {news.length ? (
            <ul className="card !py-1">
              {news.map((n) => (
                <li key={n.id} className="row">
                  <span className="min-w-0 flex-1">
                    <span className="block font-semibold">{n.title}</span>
                    <span className="mu">{ANNOUNCEMENT_LABEL[n.category] ?? n.category}{n.event_date ? ` · ${formatShortDate(n.event_date + "T12:00:00+07:00")}` : ""}</span>
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="Belum ada pengumuman" />
          )}
        </section>

        <section>
          <SectionHead title="Terakhir dibuka di pustaka" href="/pustaka" linkLabel="Buka pustaka" />
          {recent.length ? (
            <ul className="card !py-1">
              {recent.map((r) => (
                <li key={r.resource_id} className="row">
                  <span className="ic !size-9"><BookOpen size={17} aria-hidden="true" /></span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold">{r.title}</span>
                    <span className="mu">{RESOURCE_KIND_LABEL[r.kind] ?? r.kind}</span>
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="Belum ada riwayat" hint="Sumber belajar yang Anda buka akan tercatat di sini." />
          )}
        </section>
      </div>
    </div>
  );
}
