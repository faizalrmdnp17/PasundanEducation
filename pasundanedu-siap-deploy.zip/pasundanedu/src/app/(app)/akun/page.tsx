import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { getPreferences } from "@/server/domain/profile";
import { whatsappConfigured } from "@/server/integrations/whatsapp";
import { PageHead } from "@/components/common";
import { LogoutButton } from "@/components/shell/NavClient";
import { PasswordForm, PreferencesForm, ProfileForm, ResendVerification } from "@/components/account/AccountForms";
import { Bookmark, CalendarDays, History } from "@/components/icons";
import { ROLE_LABEL } from "@/lib/constants";
import { initials } from "@/lib/format";

export const metadata: Metadata = { title: "Akun" };

function Section({ id, title, children }: { id?: string; title: string; children: React.ReactNode }) {
  return <section id={id} className="card scroll-mt-20"><h2 className="h-sec mb-3">{title}</h2>{children}</section>;
}

export default async function Page() {
  const user = await requireUser({ next: "/akun" });
  const prefs = await getPreferences(user.id);
  const isStudent = user.roles.includes("mahasiswa");
  const role = user.roles[0] ? ROLE_LABEL[(["admin", "petugas", "dosen", "mahasiswa"] as const).find((r) => user.roles.includes(r))!] : "";
  return (
    <div className="mx-auto max-w-[760px]">
      <PageHead title="Akun" />
      <div className="card flex items-center gap-4">
        <span aria-hidden="true" className="grid size-14 shrink-0 place-items-center rounded-full bg-brand text-[18px] font-bold text-white">{initials(user.fullName)}</span>
        <div className="min-w-0">
          <p className="truncate text-[17px] font-bold">{user.fullName}</p>
          <p className="mu truncate">{user.email} · {role}</p>
          <p className="mu">{user.npm ? `NPM ${user.npm}` : user.nidn ? `NIDN/NIP ${user.nidn}` : ""}</p>
          <p className="mt-1">{user.emailVerified ? <span className="badge badge-ok">Email terverifikasi</span> : <span className="badge badge-warn">Email belum terverifikasi</span>}</p>
        </div>
      </div>

      {isStudent ? (
        <nav aria-label="Pintasan" className="mt-3 grid grid-cols-3 gap-2.5">
          {[["/riwayat", "Riwayat", History], ["/jadwal", "Jadwal", CalendarDays], ["/favorit", "Favorit", Bookmark]].map(([h, l, I]) => {
            const Icon = I as typeof History;
            return <Link key={h as string} href={h as string} className="card flex flex-col items-center gap-1.5 !py-3 text-[13px] font-semibold hover:border-brand"><Icon size={20} aria-hidden="true" className="text-brand-text" />{l as string}</Link>;
          })}
        </nav>
      ) : null}

      <div className="mt-4 space-y-4">
        {!user.emailVerified ? (
          <Section id="verifikasi" title="Verifikasi email">
            <p className="mb-3 text-[13.5px]">Email Anda <strong>{user.email}</strong> belum diverifikasi. Periksa folder spam bila tautan dari pendaftaran belum ditemukan, atau kirim ulang di bawah.</p>
            <ResendVerification />
          </Section>
        ) : null}
        <Section title="Profil">
          <ProfileForm isStudent={isStudent} init={{ full_name: user.fullName, study_program: user.studyProgram ?? "", cohort_year: user.cohortYear ? String(user.cohortYear) : "", phone: user.phone ?? "", whatsapp_number: user.whatsappNumber ?? "" }} />
        </Section>
        <Section title="Notifikasi">
          <PreferencesForm init={{ email_enabled: prefs.email_enabled, whatsapp_enabled: prefs.whatsapp_enabled, reminders_enabled: prefs.reminders_enabled }} hasNumber={!!user.whatsappNumber} whatsappReady={whatsappConfigured()} />
        </Section>
        <Section title="Keamanan"><PasswordForm /></Section>
        <div className="flex justify-end lg:hidden"><LogoutButton className="btn btn-line" /></div>
      </div>
    </div>
  );
}
