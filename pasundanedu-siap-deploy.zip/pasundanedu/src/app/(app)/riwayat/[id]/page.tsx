import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { RequestDetailView } from "@/components/request/RequestDetailView";

export const metadata: Metadata = { title: "Detail pengajuan" };

export default async function Page({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ baru?: string }> }) {
  const { id } = await params;
  const user = await requireUser({ next: `/riwayat/${id}` });
  const { baru } = await searchParams;
  return <RequestDetailView user={user} id={id} justCreated={baru} />;
}
