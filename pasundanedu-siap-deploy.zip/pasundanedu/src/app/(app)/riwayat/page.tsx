import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { listRequests } from "@/server/domain/requests";
import { Empty, PageHead, Pager, RequestRow } from "@/components/common";

export const metadata: Metadata = { title: "Riwayat pengajuan" };

const GROUPS = [
  { key: "", label: "Semua" },
  { key: "aktif", label: "Berjalan", status: "submitted,under_review,awaiting_information,awaiting_payment,confirmed,in_progress" },
  { key: "selesai", label: "Selesai", status: "completed" },
  { key: "tutup", label: "Ditolak atau dibatalkan", status: "rejected,cancelled" },
] as const;

export default async function Page({ searchParams }: { searchParams: Promise<{ k?: string; q?: string; hal?: string }> }) {
  const user = await requireUser({ next: "/riwayat" });
  const sp = await searchParams;
  const g = GROUPS.find((x) => x.key === (sp.k ?? "")) ?? GROUPS[0];
  const q = (sp.q ?? "").slice(0, 80);
  const page = Math.max(1, Number(sp.hal) || 1);
  const res = await listRequests(user, { as: "student", status: "status" in g ? g.status : undefined, q, page, size: 10 });
  const href = (k: string) => `/riwayat${k || q ? `?${new URLSearchParams({ ...(k ? { k } : {}), ...(q ? { q } : {}) })}` : ""}`;
  return (
    <div>
      <PageHead title="Riwayat pengajuan" desc="Semua pengajuan Anda beserta statusnya." action={<Link href="/layanan" className="btn btn-sm">Ajukan layanan</Link>} />
      <div className="scroll-x mb-3" role="group" aria-label="Filter status">
        {GROUPS.map((x) => <Link key={x.key} href={href(x.key)} className={`chip ${g.key === x.key ? "on" : ""}`} aria-current={g.key === x.key ? "true" : undefined}>{x.label}</Link>)}
      </div>
      <form action="/riwayat" method="get" role="search" className="mb-4 flex gap-2">
        {g.key ? <input type="hidden" name="k" value={g.key} /> : null}
        <label className="block flex-1"><span className="sr-only">Cari nomor atau nama layanan</span><input name="q" type="search" defaultValue={q} placeholder="Cari nomor pengajuan atau layanan" className="input" /></label>
        <button className="btn" type="submit">Cari</button>
      </form>
      {res.items.length === 0 ? (
        <Empty title={q || g.key ? "Tidak ada pengajuan yang cocok" : "Belum ada pengajuan"} hint="Pengajuan yang Anda buat akan tampil di sini." action={<Link href="/layanan" className="btn btn-sm">Lihat layanan</Link>} />
      ) : (
        <>
          <div className="space-y-2.5">{res.items.map((r) => <RequestRow key={r.id} r={r} href={`/riwayat/${r.id}`} />)}</div>
          <Pager page={res.page} totalPages={res.totalPages} path="/riwayat" params={{ k: g.key || undefined, q: q || undefined }} />
        </>
      )}
    </div>
  );
}
