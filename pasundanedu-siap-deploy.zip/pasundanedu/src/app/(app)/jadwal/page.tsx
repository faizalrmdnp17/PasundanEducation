import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { listMyAppointments } from "@/server/domain/appointments";
import { Empty, PageHead } from "@/components/common";
import { CalendarDays } from "@/components/icons";
import { formatDayHeading, formatTime, jakartaDateKey } from "@/lib/format";

export const metadata: Metadata = { title: "Jadwal" };

const STATUS: Record<string, [string, string]> = { booked: ["Terjadwal", "badge-info"], completed: ["Selesai", "badge-ok"], no_show: ["Tidak hadir", "badge-bad"] };

export default async function Page() {
  const user = await requireUser({ next: "/jadwal" });
  const staff = !user.roles.includes("mahasiswa");
  const all = await listMyAppointments(user.id, staff ? "staff" : "student");
  const now = Date.now();
  const up = all.filter((a) => a.status === "booked" && new Date(a.ends_at).getTime() > now);
  const past = all.filter((a) => !up.includes(a)).reverse();
  const base = staff ? "/pengajuan" : "/riwayat";
  const row = (a: (typeof all)[number]) => {
    const [label, cls] = STATUS[a.status] ?? [a.status, "badge-mute"];
    return (
      <li key={a.id}>
        <Link href={`${base}/${a.request_id}`} className="card flex items-center gap-3 hover:border-brand">
          <span className="ic"><CalendarDays size={20} aria-hidden="true" /></span>
          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-2"><span className="truncate font-semibold">{a.service_name}</span><span className={`badge ${cls}`}>{label}</span></span>
            <span className="mu block">{formatDayHeading(jakartaDateKey(a.starts_at))}, {formatTime(a.starts_at)}–{formatTime(a.ends_at)} WIB</span>
            <span className="mu block">{staff ? "Mahasiswa" : "Dengan"} {a.other_name} · {a.mode === "online" ? "Online" : a.location || "Tatap muka"} · {a.request_number}</span>
          </span>
        </Link>
      </li>
    );
  };
  return (
    <div>
      <PageHead title="Jadwal" desc="Konsultasi dan sesi yang sudah dipesan." />
      <h2 className="h-sec mb-2.5">Mendatang</h2>
      {up.length ? <ul className="space-y-2.5">{up.map(row)}</ul> : <Empty title="Tidak ada jadwal mendatang" hint={staff ? "Buka jadwal baru dari halaman beranda Anda." : "Pilih layanan yang memakai jadwal untuk memesan sesi."} action={staff ? undefined : <Link href="/layanan" className="btn btn-sm">Lihat layanan</Link>} />}
      {past.length ? (<><h2 className="h-sec mb-2.5 mt-7">30 hari terakhir</h2><ul className="space-y-2.5">{past.map(row)}</ul></>) : null}
    </div>
  );
}
