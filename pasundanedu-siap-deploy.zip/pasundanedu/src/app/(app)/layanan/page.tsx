import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { listCategories, listServices } from "@/server/domain/services";
import { paymentsEnabled } from "@/server/domain/settings";
import { Empty, PageHead } from "@/components/common";
import { CalendarDays, FileText, Search, ServiceIcon } from "@/components/icons";
import { formatRupiah } from "@/lib/format";

export const metadata: Metadata = { title: "Layanan" };

export default async function Page({ searchParams }: { searchParams: Promise<{ q?: string; kategori?: string }> }) {
  await requireUser({ next: "/layanan" });
  const sp = await searchParams;
  const q = (sp.q ?? "").slice(0, 80);
  const [cats, list, payOn] = await Promise.all([listCategories(), listServices({ q, category: sp.kategori }), paymentsEnabled()]);
  const chip = (href: string, label: string, on: boolean) => (
    <Link key={href} href={href} className={`chip ${on ? "on" : ""}`} aria-current={on ? "true" : undefined}>{label}</Link>
  );
  const withQ = (kategori?: string) => {
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (kategori) p.set("kategori", kategori);
    const s = p.toString();
    return s ? `/layanan?${s}` : "/layanan";
  };

  return (
    <div>
      <PageHead title="Layanan" desc="Pilih layanan, isi kebutuhan Anda, lalu pantau prosesnya sampai selesai." />
      <form action="/layanan" method="get" role="search" className="mb-3 flex gap-2">
        {sp.kategori ? <input type="hidden" name="kategori" value={sp.kategori} /> : null}
        <label className="relative block flex-1">
          <span className="sr-only">Cari layanan</span>
          <Search size={18} aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
          <input name="q" type="search" defaultValue={q} placeholder="Cari layanan" className="input pl-10" />
        </label>
        <button className="btn" type="submit">Cari</button>
      </form>
      <div className="scroll-x mb-4" role="group" aria-label="Kategori">
        {chip(withQ(), "Semua", !sp.kategori)}
        {cats.map((c) => chip(withQ(c.code), c.name, sp.kategori === c.code))}
      </div>

      {list.items.length === 0 ? (
        <Empty title="Layanan tidak ditemukan" hint="Coba kata kunci lain atau tampilkan semua kategori." action={<Link href="/layanan" className="btn btn-l btn-sm">Tampilkan semua</Link>} />
      ) : (
        <ul className="grid grid-cols-1 gap-2.5 md:grid-cols-2">
          {list.items.map((s) => (
            <li key={s.id}>
              <Link href={`/layanan/${s.slug}`} className="card flex h-full gap-3 hover:border-brand">
                <span className="ic"><ServiceIcon name={s.icon} /></span>
                <span className="min-w-0 flex-1">
                  <span className="block font-semibold leading-snug">{s.name}</span>
                  <span className="mu mt-0.5 line-clamp-2 block">{s.description}</span>
                  <span className="mt-2 flex flex-wrap items-center gap-1.5">
                    <span className="badge badge-mute">{s.category_name}</span>
                    <span className={`badge ${payOn && s.price_idr > 0 ? "badge-warn" : "badge-ok"}`}>{payOn ? formatRupiah(s.price_idr) : "Tanpa biaya"}</span>
                    {s.requires_appointment ? <span className="badge badge-info"><CalendarDays size={12} aria-hidden="true" /> Pakai jadwal</span> : null}
                    {s.requires_documents ? <span className="badge badge-info"><FileText size={12} aria-hidden="true" /> Perlu dokumen</span> : null}
                  </span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
