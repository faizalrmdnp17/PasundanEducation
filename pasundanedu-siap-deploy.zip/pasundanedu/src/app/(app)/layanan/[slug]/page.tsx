import type { Metadata } from "next";
import Link from "next/link";
import { notFound as nf } from "next/navigation";
import { requireUser } from "@/server/auth/guard";
import { getService } from "@/server/domain/services";
import { listAvailability } from "@/server/domain/appointments";
import { paymentsEnabled } from "@/server/domain/settings";
import { RequestForm } from "@/components/request/RequestForm";
import { ServiceIcon } from "@/components/icons";
import { formatRupiah } from "@/lib/format";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const s = await getService(slug).catch(() => null);
  return { title: s?.name ?? "Layanan" };
}

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const user = await requireUser({ next: `/layanan/${slug}` });
  const svc = await getService(slug).catch(() => null);
  if (!svc) nf();
  const [slots, payOn] = await Promise.all([svc.requires_appointment ? listAvailability({ serviceId: svc.id }) : Promise.resolve([]), paymentsEnabled()]);
  const isStudent = user.roles.includes("mahasiswa");

  return (
    <div className="mx-auto max-w-[760px]">
      <Link href="/layanan" className="mb-3 inline-block text-[13px] font-semibold text-brand-text hover:underline">Semua layanan</Link>
      <header className="card flex gap-3.5">
        <span className="ic !size-12"><ServiceIcon name={svc.icon} size={24} /></span>
        <div className="min-w-0">
          <h1 className="h-page !text-[22px]">{svc.name}</h1>
          <p className="mu mt-1 text-[13.5px]">{svc.category_name}</p>
        </div>
      </header>

      <section className="card mt-3">
        <p className="text-[14px] leading-relaxed">{svc.description}</p>
        <dl className="mt-4 grid grid-cols-1 gap-x-6 gap-y-3 text-[13.5px] sm:grid-cols-2">
          <div>
            <dt className="mu">Biaya</dt>
            <dd className="font-semibold">{payOn ? formatRupiah(svc.price_idr) : "Tanpa biaya"}</dd>
            {!payOn && svc.price_idr > 0 ? <dd className="hint">Tarif {formatRupiah(svc.price_idr)} belum diaktifkan oleh pengelola. Pengajuan saat ini tidak dikenai biaya.</dd> : null}
          </div>
          {svc.estimated_process ? <div><dt className="mu">Perkiraan proses</dt><dd className="font-semibold">{svc.estimated_process}</dd></div> : null}
          {svc.duration_minutes ? <div><dt className="mu">Durasi sesi</dt><dd className="font-semibold">{svc.duration_minutes} menit</dd></div> : null}
          {svc.staff.length ? <div><dt className="mu">Penanggung jawab</dt><dd className="font-semibold">{svc.staff.map((s) => s.name).join(", ")}</dd></div> : null}
        </dl>
        {svc.requirements.length ? (
          <div className="mt-4">
            <h2 className="text-[13.5px] font-bold">Persyaratan</h2>
            <ul className="mt-1.5 list-disc space-y-1 pl-5 text-[13.5px]">{svc.requirements.map((r) => <li key={r}>{r}</li>)}</ul>
          </div>
        ) : null}
        <div className="mt-4">
          <h2 className="text-[13.5px] font-bold">Kebijakan pembatalan</h2>
          <p className="mu mt-1 text-[13.5px]">{svc.cancellation_policy}</p>
        </div>
      </section>

      <section className="card mt-3" aria-labelledby="form-ajukan">
        <h2 id="form-ajukan" className="h-sec mb-3">Ajukan layanan ini</h2>
        {!isStudent ? (
          <div className="alert alert-info">Hanya akun mahasiswa yang dapat mengajukan layanan.</div>
        ) : svc.requires_appointment && slots.length === 0 ? (
          <div className="alert alert-warn">Belum ada jadwal tersedia untuk layanan ini. Silakan cek kembali nanti, pengelola akan membuka jadwal baru.</div>
        ) : (
          <RequestForm
            serviceId={svc.id}
            emailVerified={user.emailVerified}
            requiresAppointment={svc.requires_appointment}
            requiresDocuments={svc.requires_documents}
            slots={slots.map((s) => ({ id: s.id, staff: s.staff_name, starts_at: new Date(s.starts_at).toISOString(), ends_at: new Date(s.ends_at).toISOString(), mode: s.mode, location: s.location, left: s.capacity - s.booked }))}
          />
        )}
      </section>
    </div>
  );
}
