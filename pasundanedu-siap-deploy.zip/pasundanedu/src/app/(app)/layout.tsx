import { AppShell } from "@/components/shell/AppShell";
import { requireUser } from "@/server/auth/guard";

// Semua halaman di grup ini membutuhkan sesi aktif. Halaman khusus peran menambah pemeriksaan sendiri (requireUser({ roles })).
export const dynamic = "force-dynamic";

export default async function Layout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  return <AppShell user={user}>{children}</AppShell>;
}
