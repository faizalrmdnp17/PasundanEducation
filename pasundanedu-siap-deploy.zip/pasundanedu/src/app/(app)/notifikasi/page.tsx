import type { Metadata } from "next";
import { requireUser } from "@/server/auth/guard";
import { listNotifications } from "@/server/domain/notifications";
import { NotificationList } from "@/components/account/NotificationList";
import { Empty, PageHead, Pager } from "@/components/common";
import { Bell } from "@/components/icons";

export const metadata: Metadata = { title: "Notifikasi" };

export default async function Page({ searchParams }: { searchParams: Promise<{ hal?: string }> }) {
  const user = await requireUser({ next: "/notifikasi" });
  const page = Math.max(1, Number((await searchParams).hal) || 1);
  const res = await listNotifications(user.id, { page, size: 20 });
  const unread = res.items.filter((n) => !n.read_at).length;
  return (
    <div className="mx-auto max-w-[760px]">
      <PageHead title="Notifikasi" desc="Kabar terbaru tentang pengajuan dan jadwal Anda." />
      {res.items.length === 0 ? (
        <Empty icon={<Bell size={22} aria-hidden="true" />} title="Belum ada notifikasi" hint="Saat status pengajuan berubah atau ada pengingat jadwal, kabarnya muncul di sini." />
      ) : (
        <>
          <NotificationList
            unread={unread}
            items={res.items.map((n) => ({ id: n.id, title: n.title, body: n.body, link: n.link, read_at: n.read_at ? new Date(n.read_at).toISOString() : null, created_at: new Date(n.created_at).toISOString() }))}
          />
          <Pager page={res.page} totalPages={res.totalPages} path="/notifikasi" />
        </>
      )}
    </div>
  );
}
