import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/server/auth/guard";
import { listResources } from "@/server/domain/resources";
import { getService } from "@/server/domain/services";
import { Empty, PageHead, Pager } from "@/components/common";
import { ResourceActions } from "@/components/library/ResourceActions";
import { RESOURCE_KIND_LABEL } from "@/lib/constants";

export const metadata: Metadata = { title: "Favorit" };

export default async function Page({ searchParams }: { searchParams: Promise<{ hal?: string }> }) {
  const user = await requireUser({ next: "/favorit" });
  const page = Math.max(1, Number((await searchParams).hal) || 1);
  const [res, borrow] = await Promise.all([listResources({ userId: user.id, onlyFavorites: true, page, size: 12 }), getService("peminjaman-buku-referensi").catch(() => null)]);
  const canBorrow = user.roles.includes("mahasiswa") ? (borrow?.id ?? null) : null;
  return (
    <div>
      <PageHead title="Favorit saya" desc="Sumber belajar yang Anda simpan." />
      {res.items.length === 0 ? (
        <Empty title="Belum ada favorit" hint="Tekan Simpan pada sumber di pustaka agar mudah ditemukan lagi." action={<Link href="/pustaka" className="btn btn-sm">Buka pustaka</Link>} />
      ) : (
        <>
          <ul className="grid grid-cols-1 gap-2.5 md:grid-cols-2">
            {res.items.map((r) => (
              <li key={r.id} className="card flex flex-col gap-2.5">
                <div>
                  <span className="badge badge-info mb-1">{RESOURCE_KIND_LABEL[r.kind] ?? r.kind}</span>
                  <h2 className="font-semibold leading-snug">{r.title}</h2>
                  <p className="mu mt-0.5">{[r.authors, r.year].filter(Boolean).join(" · ")}</p>
                </div>
                <ResourceActions id={r.id} title={r.title} favorite accessType={r.access_type} borrowServiceId={canBorrow} />
              </li>
            ))}
          </ul>
          <Pager page={res.page} totalPages={res.totalPages} path="/favorit" />
        </>
      )}
    </div>
  );
}
