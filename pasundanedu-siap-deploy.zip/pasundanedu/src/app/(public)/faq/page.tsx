import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "Pertanyaan umum" };

const QA: [string, React.ReactNode][] = [
  ["Bagaimana cara mengajukan layanan?", <>Masuk, buka menu Layanan, pilih layanan, lalu isi formulir. Bila layanan memakai jadwal, pilih slot yang tersedia. Setelah terkirim, pantau statusnya di Riwayat. Email Anda harus sudah terverifikasi.</>],
  ["Mengapa saya tidak melihat jadwal untuk sebuah layanan?", <>Jadwal dibuka oleh dosen atau petugas yang menangani layanan itu. Bila belum ada slot, cek lagi nanti. Anda juga akan menerima notifikasi bila pengajuan dijadwalkan ulang.</>],
  ["Berapa biaya layanan?", <>Saat ini pembayaran hanya berlaku bila diaktifkan oleh pengelola. Selama belum aktif, semua pengajuan diproses tanpa biaya. Bila diaktifkan, pembayaran dilakukan lewat transfer manual dan bukti transfer diperiksa petugas. Aplikasi tidak meminta nomor kartu atau CVV.</>],
  ["Bagaimana membatalkan pengajuan?", <>Buka detail pengajuan lalu pilih Batalkan pengajuan. Pembatalan hanya dapat dilakukan pada tahap tertentu dan tidak lebih dekat dari 2 jam sebelum jadwal. Kebijakan setiap layanan tertera di halaman layanan.</>],
  ["Dokumen apa yang boleh diunggah?", <>PDF, PNG, JPG, atau DOCX, maksimal 5 MB per berkas. Dokumen bersifat privat dan hanya dapat dibuka oleh Anda dan staf yang menangani pengajuan itu. Jangan kirim dokumen pribadi lewat WhatsApp; unggah lewat halaman pengajuan.</>],
  ["Apakah layanan cek kemiripan menjamin bebas plagiarisme?", <>Tidak. Cek kemiripan hanya membantu Anda menemukan bagian yang mirip. Keputusan akhir ada pada dosen pembimbing dan ketentuan kampus.</>],
  ["Bagaimana notifikasi WhatsApp bekerja?", <>Hanya bila Anda mengaktifkannya di menu Akun dan pengelola sudah menghubungkan WhatsApp. Anda dapat berhenti kapan saja dengan membalas STOP. Pesan memakai template yang disetujui dan tidak berisi dokumen.</>],
  ["Saya lupa kata sandi.", <>Buka <Link href="/lupa-sandi" className="font-semibold text-brand-text underline">halaman lupa kata sandi</Link>. Tautan atur ulang berlaku singkat dan hanya dapat dipakai sekali.</>],
  ["Saya dosen atau petugas. Mengapa akun saya belum aktif?", <>Akun dosen dan petugas diaktifkan setelah pengelola memeriksa identitas Anda. Anda akan diberi tahu lewat email setelah ada keputusan.</>],
];

export default function Page() {
  return (
    <article>
      <h1 className="h-page mb-1">Pertanyaan umum</h1>
      <p className="mu mb-5 text-[13.5px]">Jawaban singkat tentang cara memakai PasundanEdu.</p>
      <div className="space-y-2">
        {QA.map(([q, a]) => (
          <details key={q} className="card group">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-3 font-semibold [&::-webkit-details-marker]:hidden">{q}<span aria-hidden="true" className="text-muted transition-transform group-open:rotate-45">+</span></summary>
            <p className="mt-2.5 text-[14px] leading-relaxed text-muted">{a}</p>
          </details>
        ))}
      </div>
    </article>
  );
}
