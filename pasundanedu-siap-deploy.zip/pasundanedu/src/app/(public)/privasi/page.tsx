import type { Metadata } from "next";

export const metadata: Metadata = { title: "Kebijakan privasi" };

const S: [string, string[]][] = [
  ["Data yang kami simpan", [
    "Profil: nama, email, NPM atau NIDN/NIP, program studi, angkatan, nomor telepon dan WhatsApp (bila Anda isi).",
    "Pengajuan layanan: layanan yang dipilih, catatan, pesan, status, jadwal, dan dokumen yang Anda unggah.",
    "Preferensi dan persetujuan notifikasi (email dan WhatsApp), beserta waktu persetujuan atau pencabutannya.",
    "Catatan keamanan: waktu masuk, alamat IP, dan tindakan penting untuk jejak audit.",
  ]],
  ["Untuk apa data dipakai", [
    "Memproses pengajuan Anda dan menghubungi Anda tentang statusnya.",
    "Mengirim pengingat jadwal dan notifikasi sesuai pilihan Anda.",
    "Menjaga keamanan akun dan menelusuri penyalahgunaan.",
  ]],
  ["Siapa yang dapat melihat", [
    "Dokumen dan pesan pengajuan hanya dapat dibuka oleh Anda, staf yang ditugaskan pada pengajuan itu, dan admin untuk keperluan pengelolaan.",
    "Catatan internal staf tidak terlihat oleh mahasiswa.",
    "Kami tidak menjual data Anda.",
  ]],
  ["Penyimpanan dan keamanan", [
    "Kata sandi disimpan sebagai hash terpisah dari profil, tidak dapat dibaca kembali.",
    "Dokumen disimpan privat dan diunduh lewat tautan bertanda tangan berumur pendek.",
    "Kunci API dan token layanan pihak ketiga disimpan di server, tidak di aplikasi peramban.",
  ]],
  ["WhatsApp dan email", [
    "Pesan WhatsApp hanya dikirim bila Anda menyetujuinya, memakai template yang disetujui, dan tidak memuat dokumen sensitif.",
    "Anda dapat berhenti kapan saja lewat menu Akun atau dengan membalas STOP.",
    "Nomor WhatsApp mahasiswa tidak diverifikasi dengan kode OTP pada versi ini.",
  ]],
  ["Hak Anda", [
    "Memperbarui profil dan preferensi notifikasi di menu Akun.",
    "Mencabut persetujuan notifikasi kapan saja.",
    "Meminta salinan atau penghapusan data lewat pengelola aplikasi.",
  ]],
];

export default function Page() {
  return (
    <article>
      <h1 className="h-page mb-1">Kebijakan privasi</h1>
      <p className="alert alert-warn my-4" role="note">Dokumen ini adalah draf kerja. Pengelola institusi perlu meninjau dan menyesuaikannya dengan ketentuan hukum yang berlaku (termasuk UU Pelindungan Data Pribadi) sebelum aplikasi dipakai secara resmi.</p>
      {S.map(([h, items]) => (
        <section key={h} className="mt-6">
          <h2 className="h-sec mb-2">{h}</h2>
          <ul className="list-disc space-y-1.5 pl-5 text-[14px] leading-relaxed">{items.map((i) => <li key={i}>{i}</li>)}</ul>
        </section>
      ))}
    </article>
  );
}
