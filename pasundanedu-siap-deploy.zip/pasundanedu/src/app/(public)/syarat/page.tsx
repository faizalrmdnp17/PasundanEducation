import type { Metadata } from "next";

export const metadata: Metadata = { title: "Syarat dan ketentuan" };

const S: [string, string[]][] = [
  ["Penggunaan akun", [
    "Gunakan data yang benar dan jaga kerahasiaan kata sandi. Aktivitas dari akun Anda menjadi tanggung jawab Anda.",
    "Akun dosen dan petugas diaktifkan setelah verifikasi oleh pengelola.",
  ]],
  ["Layanan", [
    "Layanan, jadwal, dan persyaratan ditetapkan pengelola dan dapat berubah.",
    "Pengajuan diproses oleh dosen atau petugas yang ditugaskan; waktu proses adalah perkiraan.",
    "Aplikasi tidak menyediakan jasa pembuatan skripsi atau data penelitian palsu, dan tidak menerima permintaan semacam itu.",
    "Hasil cek kemiripan adalah alat bantu, bukan jaminan bebas plagiarisme.",
  ]],
  ["Pembayaran", [
    "Biaya hanya berlaku setelah diaktifkan pengelola. Selama belum aktif, layanan diproses tanpa biaya.",
    "Pembayaran dilakukan lewat transfer manual dan baru sah setelah diverifikasi petugas. Jangan membagikan nomor kartu, CVV, atau kata sandi perbankan.",
  ]],
  ["Dokumen dan konten", [
    "Unggah hanya berkas yang Anda berhak bagikan. Berkas yang melanggar hukum atau membahayakan akan ditolak.",
    "Sumber pustaka diakses sesuai lisensi penyedia. Jangan menyebarkan ulang konten berhak cipta.",
  ]],
  ["Pembatasan", [
    "Pengelola dapat menangguhkan akun yang menyalahgunakan layanan.",
    "Aplikasi disediakan sebagaimana adanya; kami berupaya menjaga ketersediaan tetapi tidak menjamin bebas gangguan.",
  ]],
];

export default function Page() {
  return (
    <article>
      <h1 className="h-page mb-1">Syarat dan ketentuan</h1>
      <p className="alert alert-warn my-4" role="note">Dokumen ini adalah draf kerja. Pengelola institusi perlu meninjau dan mengesahkannya sebelum aplikasi dipakai secara resmi.</p>
      {S.map(([h, items]) => (
        <section key={h} className="mt-6">
          <h2 className="h-sec mb-2">{h}</h2>
          <ul className="list-disc space-y-1.5 pl-5 text-[14px] leading-relaxed">{items.map((i) => <li key={i}>{i}</li>)}</ul>
        </section>
      ))}
    </article>
  );
}
