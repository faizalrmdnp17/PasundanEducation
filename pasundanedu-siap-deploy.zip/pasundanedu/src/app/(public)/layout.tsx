import Link from "next/link";
import { Emblem } from "@/components/logo";
import { getCurrentUser } from "@/server/auth/session";

export const dynamic = "force-dynamic";

/** Halaman informasi publik (FAQ, privasi, syarat) yang dapat dibuka tanpa masuk. */
export default async function Layout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  return (
    <div className="min-h-dvh">
      <header className="flex h-14 items-center justify-between gap-3 bg-brand px-4 text-white lg:px-8">
        <Link href="/" className="flex items-center gap-2.5" aria-label="PasundanEdu, ke beranda"><Emblem size={32} /><span className="text-[16px] font-bold">PasundanEdu</span></Link>
        <Link href={user ? "/" : "/masuk"} className="rounded-lg px-3 py-1.5 text-[13px] font-semibold hover:bg-white/15">{user ? "Ke aplikasi" : "Masuk"}</Link>
      </header>
      <main id="isi" className="mx-auto w-full max-w-[760px] px-4 pb-16 pt-6 lg:px-0">{children}</main>
    </div>
  );
}
