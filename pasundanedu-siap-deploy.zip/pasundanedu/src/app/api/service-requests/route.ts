import { NextResponse } from "next/server";
import { route, pageParams } from "@/server/http";
import { serviceRequestSchema } from "@/lib/validation";
import { createServiceRequest, listRequests } from "@/server/domain/requests";

// Daftar pengajuan. ?scope=mine (default, milik mahasiswa) atau ?scope=staff (antrean staf/admin).
export const GET = route({ auth: "user" }, async ({ user, search }) => {
  const { page, size } = pageParams(search);
  const scope = search.get("scope") === "staff" ? "staff" : "student";
  return listRequests(user!, {
    as: scope, page, size, status: search.get("status") ?? undefined, q: search.get("q") ?? undefined,
    unassigned: search.get("unassigned") === "1",
  });
});

// Header `Idempotency-Key` (disarankan) mencegah pengajuan ganda saat tombol ditekan berulang atau koneksi terputus.
export const POST = route({ auth: "user", verified: true, schema: serviceRequestSchema }, async ({ user, body, req, ip }) => {
  const r = await createServiceRequest(user!, body, req.headers.get("idempotency-key"), { ip });
  return NextResponse.json({ id: r.id, request_number: r.request_number, duplicate: r.duplicate }, { status: r.duplicate ? 200 : 201 });
});
