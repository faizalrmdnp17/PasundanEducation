import { NextResponse } from "next/server";
import { route } from "@/server/http";
import { feedbackSchema } from "@/lib/validation";
import { submitFeedback } from "@/server/domain/requests";

export const POST = route({ auth: ["mahasiswa"], schema: feedbackSchema }, async ({ user, params, body }) => {
  await submitFeedback(user!, params.id!, body.rating, body.comment);
  return NextResponse.json({ ok: true }, { status: 201 });
});
