import { NextResponse } from "next/server";
import { route } from "@/server/http";
import { messageSchema } from "@/lib/validation";
import { addMessage } from "@/server/domain/requests";

export const POST = route({ auth: "user", verified: true, schema: messageSchema }, async ({ user, params, body, ip }) => {
  const id = await addMessage(user!, params.id!, body.body, body.visibility, { ip });
  return NextResponse.json({ id }, { status: 201 });
});
