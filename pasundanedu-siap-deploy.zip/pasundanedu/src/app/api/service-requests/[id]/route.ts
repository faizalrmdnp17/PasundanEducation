import { route } from "@/server/http";
import { getRequestDetail } from "@/server/domain/requests";

export const GET = route({ auth: "user" }, async ({ user, params }) => getRequestDetail(user!, params.id!));
