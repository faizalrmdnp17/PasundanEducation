import { route } from "@/server/http";
import { statusChangeSchema } from "@/lib/validation";
import { changeStatus } from "@/server/domain/requests";

// Hanya dosen/petugas/admin. Mahasiswa tidak dapat mengubah status secara langsung (gunakan /cancel).
export const PATCH = route({ auth: ["dosen", "petugas", "admin"], schema: statusChangeSchema }, async ({ user, params, body, ip }) =>
  changeStatus(user!, params.id!, body.status, body.note, { ip }),
);
