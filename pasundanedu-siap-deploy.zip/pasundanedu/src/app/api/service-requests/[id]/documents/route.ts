import { NextResponse } from "next/server";
import { route, readUpload } from "@/server/http";
import { addDocument } from "@/server/domain/requests";

// multipart/form-data: file (wajib), kind = lampiran | naskah | hasil (bukti pembayaran lewat /payment/proof)
export const POST = route({ auth: "user", verified: true, multipart: true }, async ({ user, req, params, ip }) => {
  const { file, fields } = await readUpload(req);
  const kind = fields.kind === "naskah" || fields.kind === "hasil" ? fields.kind : "lampiran";
  const id = await addDocument(user!, params.id!, file, kind, { ip });
  return NextResponse.json({ id }, { status: 201 });
});
