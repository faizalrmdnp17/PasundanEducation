import { z } from "zod";
import { route } from "@/server/http";
import { cancelByStudent } from "@/server/domain/requests";

const schema = z.object({ reason: z.string().trim().max(500).optional().transform((v) => v || undefined) });

export const POST = route({ auth: ["mahasiswa"], schema }, async ({ user, params, body, ip }) => cancelByStudent(user!, params.id!, body.reason, { ip }));
