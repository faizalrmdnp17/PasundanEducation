import { z } from "zod";
import { route } from "@/server/http";
import { rescheduleAppointment } from "@/server/domain/requests";

const schema = z.object({ slot_id: z.uuid("Jadwal tidak valid."), note: z.string().trim().max(500).optional().transform((v) => v || undefined) });

// Menjadwalkan ulang oleh dosen/petugas/admin.
export const PATCH = route({ auth: ["dosen", "petugas", "admin"], schema }, async ({ user, params, body, ip }) =>
  rescheduleAppointment(user!, params.id!, body.slot_id, body.note, { ip }),
);
