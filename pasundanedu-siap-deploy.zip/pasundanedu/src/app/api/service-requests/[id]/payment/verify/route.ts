import { z } from "zod";
import { route } from "@/server/http";
import { refundPayment, verifyPayment } from "@/server/domain/payments";

const schema = z.object({ decision: z.enum(["approve", "reject", "refund"]) });

export const POST = route({ auth: ["petugas", "admin"], schema }, async ({ user, params, body, ip }) =>
  body.decision === "refund" ? refundPayment(user!, params.id!, ip) : verifyPayment(user!, params.id!, body.decision, ip),
);
