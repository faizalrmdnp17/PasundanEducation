import { NextResponse } from "next/server";
import { route } from "@/server/http";
import { startPayment } from "@/server/domain/payments";

export const POST = route({ auth: ["mahasiswa"], verified: true }, async ({ user, params, req, ip }) => {
  const r = await startPayment(user!, params.id!, req.headers.get("idempotency-key"), ip);
  return NextResponse.json(r, { status: r.duplicate ? 200 : 201 });
});
