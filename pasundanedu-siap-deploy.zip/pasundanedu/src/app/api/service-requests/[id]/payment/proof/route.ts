import { NextResponse } from "next/server";
import { route, readUpload } from "@/server/http";
import { submitPaymentProof } from "@/server/domain/payments";

export const POST = route({ auth: ["mahasiswa"], verified: true, multipart: true }, async ({ user, req, params, ip }) => {
  const { file } = await readUpload(req);
  const r = await submitPaymentProof(user!, params.id!, file, ip);
  return NextResponse.json(r, { status: 201 });
});
