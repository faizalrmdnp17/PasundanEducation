import { z } from "zod";
import { route } from "@/server/http";
import { verifyDocument } from "@/server/domain/requests";

const schema = z.object({ status: z.enum(["verified", "rejected"]), note: z.string().trim().max(500).optional().transform((v) => v || undefined) });

export const PATCH = route({ auth: ["dosen", "petugas", "admin"], schema }, async ({ user, params, body, ip }) => {
  await verifyDocument(user!, params.id!, body.status, body.note, { ip });
  return { ok: true };
});
