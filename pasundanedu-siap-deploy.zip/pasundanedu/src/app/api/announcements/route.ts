import { route } from "@/server/http";
import { listAnnouncements } from "@/server/domain/notifications";

export const GET = route({ auth: "public" }, async () => ({ items: await listAnnouncements() }));
