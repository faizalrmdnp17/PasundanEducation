import { route } from "@/server/http";
import { profileUpdateSchema } from "@/lib/validation";
import { updateProfile } from "@/server/domain/profile";

export const PATCH = route({ auth: "user", schema: profileUpdateSchema }, async ({ user, body, ip }) => {
  await updateProfile(user!, body, ip);
  return { ok: true };
});
