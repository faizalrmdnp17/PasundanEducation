import { route } from "@/server/http";
import { preferencesSchema } from "@/lib/validation";
import { getPreferences, updatePreferences } from "@/server/domain/profile";

export const GET = route({ auth: "user" }, async ({ user }) => getPreferences(user!.id));

export const PUT = route({ auth: "user", schema: preferencesSchema }, async ({ user, body, ip }) => {
  await updatePreferences(user!, body, ip);
  return { ok: true };
});
