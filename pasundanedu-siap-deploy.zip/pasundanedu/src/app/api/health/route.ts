import { NextResponse } from "next/server";
import { query } from "@/server/db";
import { emailConfigured } from "@/server/integrations/email";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await query("select 1");
    // `email` menandakan apakah pengiriman email benar-benar dapat bekerja (provider "log" tidak dihitung pada produksi).
    return NextResponse.json({ status: "ok", database: "up", email: emailConfigured() ? "ready" : "not_configured", time: new Date().toISOString() });
  } catch {
    return NextResponse.json({ status: "degraded", database: "down" }, { status: 503 });
  }
}
