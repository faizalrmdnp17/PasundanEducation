import { route } from "@/server/http";
import { listAvailability } from "@/server/domain/appointments";
import { getService } from "@/server/domain/services";
import { badRequest } from "@/server/errors";

export const GET = route({ auth: "public" }, async ({ search }) => {
  const serviceId = search.get("service_id");
  if (!serviceId) throw badRequest("Parameter service_id wajib diisi.");
  const service = await getService(serviceId);
  const days = Number(search.get("days") ?? 30) || 30;
  return { service_id: service.id, slots: await listAvailability({ serviceId: service.id, days }) };
});
