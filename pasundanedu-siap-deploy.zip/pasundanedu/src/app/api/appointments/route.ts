import { route } from "@/server/http";
import { hasRole } from "@/server/auth/types";
import { listMyAppointments } from "@/server/domain/appointments";

// Janji temu milik pengguna (mahasiswa) atau yang ditangani pengguna (staf). Pemesanan slot dilakukan saat membuat pengajuan.
export const GET = route({ auth: "user" }, async ({ user, search }) => {
  const role = search.get("as") === "staff" && hasRole(user!, "dosen", "petugas", "admin") ? "staff" : "student";
  return { items: await listMyAppointments(user!.id, role) };
});
