import { route } from "@/server/http";
import { getService } from "@/server/domain/services";
import { listAvailability } from "@/server/domain/appointments";
import { paymentsEnabled } from "@/server/domain/settings";

export const GET = route({ auth: "public" }, async ({ params }) => {
  const service = await getService(params.id!);
  const slots = service.requires_appointment ? await listAvailability({ serviceId: service.id }) : [];
  return { service, slots, paymentsEnabled: await paymentsEnabled() };
});
