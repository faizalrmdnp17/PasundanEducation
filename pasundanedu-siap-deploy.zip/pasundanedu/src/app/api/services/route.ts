import { route, pageParams, paged } from "@/server/http";
import { listServices } from "@/server/domain/services";
import { paymentsEnabled } from "@/server/domain/settings";

export const GET = route({ auth: "public" }, async ({ search }) => {
  const { page, size } = pageParams(search, 50);
  const r = await listServices({ q: search.get("q") ?? undefined, category: search.get("category") ?? undefined, page, size });
  return { ...paged(r.items, r.total, page, size), paymentsEnabled: await paymentsEnabled() };
});
