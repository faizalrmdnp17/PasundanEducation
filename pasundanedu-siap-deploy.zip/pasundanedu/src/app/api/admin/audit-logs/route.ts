import { route, pageParams } from "@/server/http";
import { listAuditLogs } from "@/server/domain/admin";

export const GET = route({ auth: ["admin"] }, async ({ search }) => {
  const { page, size } = pageParams(search, 30);
  return listAuditLogs({ q: search.get("q") ?? undefined, action: search.get("action") ?? undefined, page, size });
});
