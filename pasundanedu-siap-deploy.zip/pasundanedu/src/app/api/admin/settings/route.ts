import { route } from "@/server/http";
import { settingsSchema } from "@/lib/validation";
import { getSettings, updateSettings } from "@/server/domain/settings";

export const GET = route({ auth: ["admin"] }, async () => getSettings());

// Pengaturan nonrahasia saja. Token/kunci API hanya lewat variabel lingkungan server (secret manager).
export const PUT = route({ auth: ["admin"], verified: true, schema: settingsSchema }, async ({ user, body, ip }) => updateSettings(user!, body, ip));
