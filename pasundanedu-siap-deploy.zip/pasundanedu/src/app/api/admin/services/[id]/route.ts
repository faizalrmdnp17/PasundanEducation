import { route } from "@/server/http";
import { serviceUpsertSchema } from "@/lib/validation";
import { getService, upsertService } from "@/server/domain/services";

export const GET = route({ auth: ["admin"] }, async ({ params }) => getService(params.id!, true));

export const PUT = route({ auth: ["admin"], verified: true, schema: serviceUpsertSchema }, async ({ user, params, body, ip }) => ({
  id: await upsertService(user!, body, params.id!, ip),
}));
