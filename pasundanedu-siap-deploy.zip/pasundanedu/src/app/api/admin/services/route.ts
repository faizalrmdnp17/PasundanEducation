import { NextResponse } from "next/server";
import { route, pageParams } from "@/server/http";
import { serviceUpsertSchema } from "@/lib/validation";
import { listServices, upsertService } from "@/server/domain/services";

export const GET = route({ auth: ["admin"] }, async ({ search }) => {
  const { page, size } = pageParams(search, 100);
  return listServices({ includeInactive: true, q: search.get("q") ?? undefined, page, size });
});

export const POST = route({ auth: ["admin"], verified: true, schema: serviceUpsertSchema }, async ({ user, body, ip }) =>
  NextResponse.json({ id: await upsertService(user!, body, undefined, ip) }, { status: 201 }),
);
