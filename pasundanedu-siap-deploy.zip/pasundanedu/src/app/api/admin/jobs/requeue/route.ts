import { route } from "@/server/http";
import { requeueFailedJobs } from "@/server/domain/admin";

export const POST = route({ auth: ["admin"] }, async ({ user, ip }) => ({ requeued: await requeueFailedJobs(user!, ip) }));
