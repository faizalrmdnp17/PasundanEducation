import { route } from "@/server/http";
import { resourceUpsertSchema } from "@/lib/validation";
import { upsertResource } from "@/server/domain/resources";

export const PUT = route({ auth: ["admin"], verified: true, schema: resourceUpsertSchema }, async ({ user, params, body, ip }) => ({
  id: await upsertResource(user!, body, params.id!, ip),
}));
