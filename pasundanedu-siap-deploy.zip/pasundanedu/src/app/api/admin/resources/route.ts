import { NextResponse } from "next/server";
import { route, pageParams } from "@/server/http";
import { resourceUpsertSchema } from "@/lib/validation";
import { listResources, upsertResource } from "@/server/domain/resources";

export const GET = route({ auth: ["admin"] }, async ({ user, search }) => {
  const { page, size } = pageParams(search);
  return listResources({ userId: user!.id, q: search.get("q") ?? undefined, includeUnpublished: true, page, size });
});

export const POST = route({ auth: ["admin"], verified: true, schema: resourceUpsertSchema }, async ({ user, body, ip }) =>
  NextResponse.json({ id: await upsertResource(user!, body, undefined, ip) }, { status: 201 }),
);
