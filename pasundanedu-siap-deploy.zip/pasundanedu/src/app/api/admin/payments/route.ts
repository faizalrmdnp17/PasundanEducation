import { route, pageParams } from "@/server/http";
import { listPayments } from "@/server/domain/payments";

export const GET = route({ auth: ["admin", "petugas"] }, async ({ search }) => {
  const { page, size } = pageParams(search);
  return listPayments({ status: search.get("status") ?? undefined, page, size });
});
