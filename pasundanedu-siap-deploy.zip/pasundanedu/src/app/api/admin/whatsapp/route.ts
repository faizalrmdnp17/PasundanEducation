import { route } from "@/server/http";
import { getWhatsappAdmin } from "@/server/domain/admin";

export const GET = route({ auth: ["admin"] }, async () => getWhatsappAdmin());
