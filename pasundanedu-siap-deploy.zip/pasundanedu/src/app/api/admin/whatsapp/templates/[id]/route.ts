import { route } from "@/server/http";
import { whatsappTemplateSchema } from "@/lib/validation";
import { updateWhatsappTemplate } from "@/server/domain/admin";

export const PUT = route({ auth: ["admin"], verified: true, schema: whatsappTemplateSchema }, async ({ user, params, body, ip }) => {
  await updateWhatsappTemplate(user!, params.id!, body, ip);
  return { ok: true };
});
