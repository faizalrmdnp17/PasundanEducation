import { NextResponse } from "next/server";
import { route } from "@/server/http";
import { announcementSchema } from "@/lib/validation";
import { upsertAnnouncement } from "@/server/domain/admin";
import { listAnnouncements } from "@/server/domain/notifications";

export const GET = route({ auth: ["admin"] }, async () => ({ items: await listAnnouncements({ includeUnpublished: true }) }));

export const POST = route({ auth: ["admin"], verified: true, schema: announcementSchema }, async ({ user, body, ip }) =>
  NextResponse.json({ id: await upsertAnnouncement(user!, body, undefined, ip) }, { status: 201 }),
);
