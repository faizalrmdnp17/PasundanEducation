import { route } from "@/server/http";
import { announcementSchema } from "@/lib/validation";
import { deleteAnnouncement, upsertAnnouncement } from "@/server/domain/admin";

export const PUT = route({ auth: ["admin"], verified: true, schema: announcementSchema }, async ({ user, params, body, ip }) => ({
  id: await upsertAnnouncement(user!, body, params.id!, ip),
}));

export const DELETE = route({ auth: ["admin"], verified: true }, async ({ user, params, ip }) => {
  await deleteAnnouncement(user!, params.id!, ip);
  return { ok: true };
});
