import { route } from "@/server/http";
import { getReports } from "@/server/domain/admin";

export const GET = route({ auth: ["admin"] }, async () => getReports());
