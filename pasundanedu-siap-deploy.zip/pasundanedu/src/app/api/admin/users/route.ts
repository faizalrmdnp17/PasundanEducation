import { route, pageParams } from "@/server/http";
import { listUsers } from "@/server/domain/admin";

export const GET = route({ auth: ["admin"] }, async ({ search }) => {
  const { page, size } = pageParams(search);
  return listUsers({ q: search.get("q") ?? undefined, role: search.get("role") ?? undefined, status: search.get("status") ?? undefined, page, size });
});
