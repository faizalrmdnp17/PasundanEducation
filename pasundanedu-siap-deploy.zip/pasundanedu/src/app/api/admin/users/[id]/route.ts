import { route } from "@/server/http";
import { userAdminSchema } from "@/lib/validation";
import { updateUserAdmin } from "@/server/domain/admin";

export const PATCH = route({ auth: ["admin"], verified: true, schema: userAdminSchema }, async ({ user, params, body, ip }) => {
  await updateUserAdmin(user!, params.id!, body, ip);
  return { ok: true };
});
