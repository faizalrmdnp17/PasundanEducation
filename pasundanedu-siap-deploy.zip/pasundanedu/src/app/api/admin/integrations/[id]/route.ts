import { route } from "@/server/http";
import { integrationUpsertSchema } from "@/lib/validation";
import { upsertIntegration } from "@/server/domain/admin";

export const PUT = route({ auth: ["admin"], verified: true, schema: integrationUpsertSchema }, async ({ user, params, body, ip }) => ({
  id: await upsertIntegration(user!, body, params.id!, ip),
}));
