import { route } from "@/server/http";
import { checkIntegration } from "@/server/integrations/moodle";
import { audit } from "@/server/audit";
import { rateLimit } from "@/server/rate-limit";

export const POST = route({ auth: ["admin"] }, async ({ user, params, ip }) => {
  await rateLimit(`integ-check:${user!.id}`, { limit: 20, windowSec: 600 });
  const r = await checkIntegration(params.id!);
  await audit(null, { actor: user, action: "integration.check", entityType: "external_integration", entityId: params.id, meta: { status: r.status }, ip });
  return r;
});
