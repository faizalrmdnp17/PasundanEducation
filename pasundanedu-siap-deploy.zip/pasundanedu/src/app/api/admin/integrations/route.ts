import { NextResponse } from "next/server";
import { route } from "@/server/http";
import { integrationUpsertSchema } from "@/lib/validation";
import { listIntegrationEvents, listIntegrations, upsertIntegration } from "@/server/domain/admin";

export const GET = route({ auth: ["admin"] }, async () => ({ items: await listIntegrations(), events: await listIntegrationEvents() }));

export const POST = route({ auth: ["admin"], verified: true, schema: integrationUpsertSchema }, async ({ user, body, ip }) =>
  NextResponse.json({ id: await upsertIntegration(user!, body, undefined, ip) }, { status: 201 }),
);
