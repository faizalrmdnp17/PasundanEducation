import { route } from "@/server/http";
import { listRoleRequests } from "@/server/domain/admin";

export const GET = route({ auth: ["admin"] }, async ({ search }) => ({ items: await listRoleRequests(search.get("status") ?? "pending") }));
