import { route } from "@/server/http";
import { roleDecisionSchema } from "@/lib/validation";
import { decideRoleRequest } from "@/server/domain/admin";

export const PATCH = route({ auth: ["admin"], verified: true, schema: roleDecisionSchema }, async ({ user, params, body, ip }) => {
  await decideRoleRequest(user!, params.id!, body.decision, body.note, ip);
  return { ok: true };
});
