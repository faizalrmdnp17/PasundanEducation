import { route, pageParams } from "@/server/http";
import { listResources } from "@/server/domain/resources";

// Pencarian judul/penulis/kategori/tahun + filter tab/jenis/tahun + pagination + urutan.
export const GET = route({ auth: "public" }, async ({ user, search }) => {
  const { page, size } = pageParams(search);
  const sort = search.get("sort");
  return listResources({
    userId: user?.id, q: search.get("q") ?? undefined, tab: search.get("tab") ?? undefined, kind: search.get("kind") ?? undefined,
    year: Number(search.get("year")) || undefined, sort: sort === "title" || sort === "year" ? sort : "newest",
    onlyFavorites: search.get("favorites") === "1" && !!user, page, size,
  });
});
