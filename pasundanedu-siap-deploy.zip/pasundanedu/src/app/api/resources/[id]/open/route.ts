import { route } from "@/server/http";
import { openResource } from "@/server/domain/resources";

export const POST = route({ auth: "user" }, async ({ user, params }) => openResource(user!.id, params.id!));
