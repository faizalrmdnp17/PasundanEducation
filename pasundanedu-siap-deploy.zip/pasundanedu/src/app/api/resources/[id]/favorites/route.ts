import { route } from "@/server/http";
import { setFavorite } from "@/server/domain/resources";

export const POST = route({ auth: "user" }, async ({ user, params }) => setFavorite(user!.id, params.id!, true));
export const DELETE = route({ auth: "user" }, async ({ user, params }) => setFavorite(user!.id, params.id!, false));
