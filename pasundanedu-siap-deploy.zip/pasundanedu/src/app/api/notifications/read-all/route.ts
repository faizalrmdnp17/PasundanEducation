import { route } from "@/server/http";
import { markAllRead } from "@/server/domain/notifications";

export const POST = route({ auth: "user" }, async ({ user }) => {
  await markAllRead(user!.id);
  return { ok: true };
});
