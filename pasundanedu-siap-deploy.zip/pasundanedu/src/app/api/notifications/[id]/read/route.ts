import { route } from "@/server/http";
import { markRead } from "@/server/domain/notifications";

export const PATCH = route({ auth: "user" }, async ({ user, params }) => {
  await markRead(user!.id, params.id!);
  return { ok: true };
});
