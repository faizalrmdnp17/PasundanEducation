import { route, pageParams } from "@/server/http";
import { listNotifications, unreadCount } from "@/server/domain/notifications";

export const GET = route({ auth: "user" }, async ({ user, search }) => {
  const { page, size } = pageParams(search);
  const r = await listNotifications(user!.id, { page, size, unreadOnly: search.get("unread") === "1" });
  return { ...r, unread: await unreadCount(user!.id) };
});
