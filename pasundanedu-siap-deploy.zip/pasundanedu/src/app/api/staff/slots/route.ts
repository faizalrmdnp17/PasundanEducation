import { NextResponse } from "next/server";
import { route } from "@/server/http";
import { slotCreateSchema } from "@/lib/validation";
import { createSlot, listStaffSlots } from "@/server/domain/appointments";

export const GET = route({ auth: ["dosen", "petugas", "admin"] }, async ({ user }) => ({ items: await listStaffSlots(user!.id) }));

export const POST = route({ auth: ["dosen", "petugas", "admin"], verified: true, schema: slotCreateSchema }, async ({ user, body, ip }) => {
  const id = await createSlot(user!, body, ip);
  return NextResponse.json({ id }, { status: 201 });
});
