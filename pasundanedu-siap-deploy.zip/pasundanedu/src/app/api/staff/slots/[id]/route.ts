import { route } from "@/server/http";
import { closeSlot } from "@/server/domain/appointments";

export const DELETE = route({ auth: ["dosen", "petugas", "admin"] }, async ({ user, params, ip }) => {
  await closeSlot(user!, params.id!, ip);
  return { ok: true };
});
