import { NextRequest, NextResponse } from "next/server";
import { env } from "@/server/env";
import { userFromToken } from "@/server/auth/session";
import { getDocumentForDownload } from "@/server/domain/requests";
import { verifyDownloadSignature } from "@/server/storage";
import { errorResponse } from "@/server/http";
import { forbidden, unauthorized } from "@/server/errors";

export const dynamic = "force-dynamic";

/**
 * Unduhan berkas privat. Dua lapis: (1) URL bertanda tangan berumur pendek yang terikat pada pengguna,
 * (2) pemeriksaan hak akses ke pengajuan pada setiap permintaan.
 */
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const user = await userFromToken(req.cookies.get(env.sessionCookie)?.value);
    if (!user) throw unauthorized();
    const sp = req.nextUrl.searchParams;
    if (!verifyDownloadSignature(id, user.id, sp.get("exp"), sp.get("sig"))) throw forbidden("Tautan unduhan tidak valid atau sudah kedaluwarsa.");
    const doc = await getDocumentForDownload(user, id);
    const safe = doc.original_name.replace(/[^\w.\- ]+/g, "_");
    return new NextResponse(new Uint8Array(doc.data), {
      headers: {
        "Content-Type": doc.mime_type,
        "Content-Disposition": `attachment; filename="${safe}"`,
        "Content-Length": String(doc.data.length),
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "private, no-store",
      },
    });
  } catch (e) {
    return errorResponse(e, "file");
  }
}
