import { NextRequest, NextResponse } from "next/server";
import { clientIp, errorResponse } from "@/server/http";
import { processWhatsappWebhook, verifyWebhookChallenge, verifyWebhookSignature } from "@/server/integrations/whatsapp";
import { rateLimit } from "@/server/rate-limit";
import { forbidden } from "@/server/errors";

export const dynamic = "force-dynamic";

/** Verifikasi langganan webhook oleh Meta (hub.challenge). */
export async function GET(req: NextRequest) {
  const challenge = verifyWebhookChallenge(req.nextUrl.searchParams);
  if (challenge === null) return new NextResponse("Forbidden", { status: 403 });
  return new NextResponse(challenge, { status: 200, headers: { "Content-Type": "text/plain" } });
}

/**
 * Event masuk (status pesan, balasan). Tanda tangan X-Hub-Signature-256 WAJIB valid; jika tidak, ditolak 401
 * dan payload tidak diproses. Event diduplikasi lewat webhook_events.
 */
export async function POST(req: NextRequest) {
  try {
    await rateLimit(`wa-webhook:${clientIp(req)}`, { limit: 600, windowSec: 60 });
    const raw = await req.text();
    if (raw.length > 1_000_000) throw forbidden("Payload terlalu besar.");
    if (!verifyWebhookSignature(raw, req.headers.get("x-hub-signature-256"))) {
      return NextResponse.json({ error: { code: "invalid_signature", message: "Tanda tangan webhook tidak valid." } }, { status: 401 });
    }
    let payload: unknown;
    try {
      payload = JSON.parse(raw);
    } catch {
      return NextResponse.json({ error: { code: "bad_json", message: "JSON tidak valid." } }, { status: 400 });
    }
    const r = await processWhatsappWebhook(payload as never, true);
    return NextResponse.json({ ok: true, ...r });
  } catch (e) {
    return errorResponse(e, "wa-webhook");
  }
}
