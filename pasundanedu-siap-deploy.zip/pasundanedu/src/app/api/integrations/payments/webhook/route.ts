import { NextRequest, NextResponse } from "next/server";
import { clientIp, errorResponse } from "@/server/http";
import { processPaymentWebhook, verifyPaymentSignature } from "@/server/domain/payments";
import { paymentsEnabled } from "@/server/domain/settings";
import { rateLimit } from "@/server/rate-limit";

export const dynamic = "force-dynamic";

/** Callback payment gateway generik: header X-Signature = HMAC-SHA256(body, PAYMENT_WEBHOOK_SECRET). */
export async function POST(req: NextRequest) {
  try {
    await rateLimit(`pay-webhook:${clientIp(req)}`, { limit: 300, windowSec: 60 });
    const raw = await req.text();
    if (!verifyPaymentSignature(raw, req.headers.get("x-signature"))) {
      return NextResponse.json({ error: { code: "invalid_signature", message: "Tanda tangan tidak valid." } }, { status: 401 });
    }
    if (!(await paymentsEnabled())) {
      return NextResponse.json({ error: { code: "payments_disabled", message: "Pembayaran belum diaktifkan." } }, { status: 409 });
    }
    let payload: unknown;
    try {
      payload = JSON.parse(raw);
    } catch {
      return NextResponse.json({ error: { code: "bad_json", message: "JSON tidak valid." } }, { status: 400 });
    }
    return NextResponse.json({ ok: true, ...(await processPaymentWebhook(payload as never)) });
  } catch (e) {
    return errorResponse(e, "pay-webhook");
  }
}
