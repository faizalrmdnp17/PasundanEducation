import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { env } from "@/server/env";
import { enqueueAppointmentReminders, processDueJobs } from "@/server/jobs";
import { purgeRateLimits } from "@/server/rate-limit";
import { errorResponse } from "@/server/http";

export const dynamic = "force-dynamic";

/**
 * Pemicu untuk penjadwal eksternal (cron/Vercel Cron/GitHub Actions): memproses antrean notifikasi,
 * membuat pengingat jadwal, dan membersihkan data kedaluwarsa. Wajib `Authorization: Bearer <CRON_SECRET>`.
 */
export async function POST(req: NextRequest) {
  try {
    const given = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
    const a = Buffer.from(given);
    const b = Buffer.from(env.cronSecret);
    if (!env.cronSecret || a.length !== b.length || !timingSafeEqual(a, b)) {
      return NextResponse.json({ error: { code: "unauthorized", message: "Tidak diizinkan." } }, { status: 401 });
    }
    const reminders = await enqueueAppointmentReminders();
    const jobs = await processDueJobs({ limit: 50 });
    const purged = await purgeRateLimits();
    return NextResponse.json({ ok: true, reminders, jobs, purged });
  } catch (e) {
    return errorResponse(e, "cron");
  }
}
