import { route } from "@/server/http";
import { resetSchema } from "@/lib/validation";
import { resetPassword } from "@/server/auth/service";
import { badRequest } from "@/server/errors";
import { rateLimit } from "@/server/rate-limit";

export const POST = route({ auth: "public", schema: resetSchema }, async ({ body, ip, userAgent }) => {
  await rateLimit(`reset-submit:ip:${ip}`, { limit: 20, windowSec: 900 });
  const ok = await resetPassword(body.token, body.password, { ip, userAgent });
  if (!ok) throw badRequest("Tautan tidak valid atau sudah kedaluwarsa. Minta tautan baru.");
  return { ok: true, message: "Kata sandi diperbarui. Silakan masuk dengan kata sandi baru." };
});
