import { route } from "@/server/http";
import { unreadCount } from "@/server/domain/notifications";
import { getPreferences } from "@/server/domain/profile";

export const GET = route({ auth: "user" }, async ({ user }) => {
  const u = user!;
  const { sessionId: _s, ...safe } = u;
  return { user: safe, unread: await unreadCount(u.id), preferences: await getPreferences(u.id) };
});
