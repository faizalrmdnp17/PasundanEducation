import { route } from "@/server/http";
import { verifySchema } from "@/lib/validation";
import { verifyEmail } from "@/server/auth/service";
import { badRequest } from "@/server/errors";
import { rateLimit } from "@/server/rate-limit";

export const POST = route({ auth: "public", schema: verifySchema }, async ({ body, ip }) => {
  await rateLimit(`verify:ip:${ip}`, { limit: 30, windowSec: 900 });
  const ok = await verifyEmail(body.token);
  if (!ok) throw badRequest("Tautan verifikasi tidak valid atau sudah kedaluwarsa. Kirim ulang dari halaman akun.");
  return { ok: true };
});
