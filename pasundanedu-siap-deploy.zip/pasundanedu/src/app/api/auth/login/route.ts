import { route } from "@/server/http";
import { env } from "@/server/env";
import { loginSchema } from "@/lib/validation";
import { login } from "@/server/auth/service";

export const POST = route({ auth: "public", schema: loginSchema }, async ({ body, ip, userAgent, setCookie }) => {
  const r = await login(body.email, body.password, { ip, userAgent });
  setCookie(env.sessionCookie, r.sessionToken, r.sessionExpires);
  return { ok: true };
});
