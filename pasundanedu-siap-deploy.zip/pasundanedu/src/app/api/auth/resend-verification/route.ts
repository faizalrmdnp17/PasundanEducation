import { route } from "@/server/http";
import { resendVerification } from "@/server/auth/service";

export const POST = route({ auth: "user" }, async ({ user, ip, userAgent }) => {
  await resendVerification(user!.id, { ip, userAgent });
  return { ok: true, message: "Jika email Anda belum terverifikasi, tautan baru telah dikirim." };
});
