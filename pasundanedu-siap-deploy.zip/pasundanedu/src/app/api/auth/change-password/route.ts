import { route } from "@/server/http";
import { changePasswordSchema } from "@/lib/validation";
import { changePassword } from "@/server/auth/service";

export const POST = route({ auth: "user", schema: changePasswordSchema }, async ({ user, body, ip, userAgent }) => {
  await changePassword(user!, body.current_password, body.new_password, { ip, userAgent });
  return { ok: true, message: "Kata sandi diperbarui. Perangkat lain telah dikeluarkan." };
});
