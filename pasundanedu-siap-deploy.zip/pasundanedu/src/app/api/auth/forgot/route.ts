import { route } from "@/server/http";
import { forgotSchema } from "@/lib/validation";
import { requestPasswordReset } from "@/server/auth/service";

// Respons selalu sama agar tidak membocorkan apakah email terdaftar.
export const POST = route({ auth: "public", schema: forgotSchema }, async ({ body, ip, userAgent }) => {
  await requestPasswordReset(body.email, { ip, userAgent });
  return { ok: true, message: "Jika email terdaftar, tautan untuk mengatur ulang kata sandi telah dikirim." };
});
