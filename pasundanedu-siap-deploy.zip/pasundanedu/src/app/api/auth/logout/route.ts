import { route } from "@/server/http";
import { env } from "@/server/env";
import { revokeSession } from "@/server/auth/session";
import { audit } from "@/server/audit";

export const POST = route({ auth: "public" }, async ({ user, clearCookie, ip }) => {
  if (user) {
    await revokeSession(user.sessionId);
    await audit(null, { actor: user, action: "auth.logout", ip });
  }
  clearCookie(env.sessionCookie);
  return { ok: true };
});
