import { route } from "@/server/http";
import { env } from "@/server/env";
import { registerSchema } from "@/lib/validation";
import { register } from "@/server/auth/service";

export const POST = route({ auth: "public", schema: registerSchema }, async ({ body, ip, userAgent, setCookie }) => {
  const r = await register(body, { ip, userAgent });
  setCookie(env.sessionCookie, r.sessionToken, r.sessionExpires);
  const base = r.status === "pending_approval"
    ? "Pendaftaran diterima. Akun dosen/petugas aktif setelah disetujui pengelola."
    : "Pendaftaran berhasil.";
  return {
    ok: true,
    status: r.status,
    email_sent: r.emailSent,
    message: r.emailSent
      ? `${base} Tautan verifikasi dikirim ke email Anda.`
      : `${base} Email verifikasi belum dapat dikirim. Coba kirim ulang dari halaman Akun nanti, atau hubungi pengelola.`,
  };
});
