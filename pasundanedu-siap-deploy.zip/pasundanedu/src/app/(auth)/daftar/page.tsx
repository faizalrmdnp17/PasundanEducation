import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthShell } from "@/components/auth/AuthShell";
import { RegisterForm } from "@/components/auth/AuthForms";
import { getCurrentUser } from "@/server/auth/session";
import { homeFor } from "@/server/auth/guard";

export const metadata: Metadata = { title: "Daftar" };

export default async function Page() {
  const user = await getCurrentUser();
  if (user) redirect(homeFor(user));
  return (
    <AuthShell
      title="Buat akun PasundanEdu"
      subtitle="Satu akun untuk semua layanan pendidikan kampus."
      footer={<>Sudah punya akun? <Link href="/masuk" className="font-semibold text-brand-text hover:underline">Masuk</Link></>}
    >
      <RegisterForm />
    </AuthShell>
  );
}
