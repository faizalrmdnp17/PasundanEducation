import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthShell } from "@/components/auth/AuthShell";
import { LoginForm } from "@/components/auth/AuthForms";
import { getCurrentUser } from "@/server/auth/session";
import { homeFor, safeNext } from "@/server/auth/guard";

export const metadata: Metadata = { title: "Masuk" };

export default async function Page({ searchParams }: { searchParams: Promise<{ next?: string; diatur?: string }> }) {
  const sp = await searchParams;
  const user = await getCurrentUser();
  if (user) redirect(safeNext(sp.next) ?? homeFor(user));
  return (
    <AuthShell
      title="Masuk ke PasundanEdu"
      subtitle="Gunakan email dan kata sandi akun Anda."
      footer={<>Belum punya akun? <Link href="/daftar" className="font-semibold text-brand-text hover:underline">Daftar sekarang</Link></>}
    >
      <LoginForm next={safeNext(sp.next) ?? undefined} notice={sp.diatur ? "Kata sandi diperbarui. Silakan masuk dengan kata sandi baru." : undefined} />
    </AuthShell>
  );
}
