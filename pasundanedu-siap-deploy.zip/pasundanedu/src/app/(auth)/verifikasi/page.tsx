import type { Metadata } from "next";
import Link from "next/link";
import { AuthShell } from "@/components/auth/AuthShell";
import { VerifyClient } from "@/components/auth/AuthForms";

export const metadata: Metadata = { title: "Verifikasi email" };

export default async function Page({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  return (
    <AuthShell title="Verifikasi email">
      {token ? <VerifyClient token={token} /> : (
        <div className="space-y-4">
          <div className="alert alert-bad" role="alert">Tautan verifikasi tidak lengkap. Buka tautan langsung dari email Anda.</div>
          <Link href="/akun" className="btn btn-l btn-block">Kirim ulang dari halaman akun</Link>
        </div>
      )}
    </AuthShell>
  );
}
