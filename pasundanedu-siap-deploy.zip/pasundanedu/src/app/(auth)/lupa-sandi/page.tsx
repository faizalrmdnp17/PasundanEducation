import type { Metadata } from "next";
import Link from "next/link";
import { AuthShell } from "@/components/auth/AuthShell";
import { ForgotForm } from "@/components/auth/AuthForms";

export const metadata: Metadata = { title: "Lupa kata sandi" };

export default function Page() {
  return (
    <AuthShell
      title="Atur ulang kata sandi"
      subtitle="Masukkan email akun Anda. Kami akan mengirim tautan untuk membuat kata sandi baru."
      footer={<Link href="/masuk" className="font-semibold text-brand-text hover:underline">Kembali ke halaman masuk</Link>}
    >
      <ForgotForm />
    </AuthShell>
  );
}
