import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthShell } from "@/components/auth/AuthShell";
import { LogoutButton } from "@/components/shell/NavClient";
import { requireUser, homeFor } from "@/server/auth/guard";
import { one } from "@/server/db";
import { ROLE_LABEL, type Role } from "@/lib/constants";
import { formatDateTime } from "@/lib/format";

export const metadata: Metadata = { title: "Menunggu persetujuan" };
export const dynamic = "force-dynamic";

export default async function Page() {
  const user = await requireUser({ next: "/menunggu-persetujuan", allowPending: true });
  if (user.status !== "pending_approval") redirect(homeFor(user));
  const req = await one<{ requested_role: Role; status: string; created_at: Date }>(
    "select requested_role, status, created_at from role_requests where user_id = $1 order by created_at desc limit 1",
    [user.id],
  );
  return (
    <AuthShell title="Pendaftaran Anda sedang ditinjau" subtitle="Akun dosen dan petugas diaktifkan setelah pengelola memeriksa identitas Anda.">
      <div className="space-y-4">
        <dl className="space-y-2 rounded-xl bg-soft p-3.5 text-[13.5px]">
          <div className="flex justify-between gap-3"><dt className="text-muted">Nama</dt><dd className="text-right font-semibold">{user.fullName}</dd></div>
          <div className="flex justify-between gap-3"><dt className="text-muted">Email</dt><dd className="break-all text-right font-semibold">{user.email}</dd></div>
          {req ? <div className="flex justify-between gap-3"><dt className="text-muted">Peran diajukan</dt><dd className="text-right font-semibold">{ROLE_LABEL[req.requested_role]}</dd></div> : null}
          {req ? <div className="flex justify-between gap-3"><dt className="text-muted">Diajukan</dt><dd className="text-right font-semibold">{formatDateTime(req.created_at)}</dd></div> : null}
        </dl>
        <p className="mu text-[13.5px]">Kami akan memberi tahu Anda lewat email setelah ada keputusan. Sementara itu Anda belum dapat membuka layanan dosen atau petugas.</p>
        <LogoutButton className="btn btn-l btn-block" />
      </div>
    </AuthShell>
  );
}
