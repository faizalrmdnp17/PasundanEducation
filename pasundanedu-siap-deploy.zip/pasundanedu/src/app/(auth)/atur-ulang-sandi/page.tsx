import type { Metadata } from "next";
import Link from "next/link";
import { AuthShell } from "@/components/auth/AuthShell";
import { ResetForm } from "@/components/auth/AuthForms";

export const metadata: Metadata = { title: "Kata sandi baru" };

export default async function Page({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  return (
    <AuthShell title="Buat kata sandi baru" subtitle="Setelah disimpan, semua perangkat akan keluar dan Anda perlu masuk lagi.">
      {token ? (
        <ResetForm token={token} />
      ) : (
        <div className="space-y-4">
          <div className="alert alert-bad" role="alert">Tautan tidak lengkap. Minta tautan baru dari halaman lupa kata sandi.</div>
          <Link href="/lupa-sandi" className="btn btn-l btn-block">Minta tautan baru</Link>
        </div>
      )}
    </AuthShell>
  );
}
