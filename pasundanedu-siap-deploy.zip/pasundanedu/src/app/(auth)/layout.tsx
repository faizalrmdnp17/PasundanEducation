// Halaman auth membaca pengaturan institusi dari database, jadi tidak boleh diprerender saat build.
export const dynamic = "force-dynamic";

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
