import type { Metadata, Viewport } from "next";
import "@fontsource-variable/dm-sans";
import "./globals.css";
import { ToastProvider } from "@/components/client/toast";

export const metadata: Metadata = {
  title: { default: "PasundanEdu", template: "%s · PasundanEdu" },
  description: "Layanan pendidikan digital untuk mahasiswa STIE Pasundan Bandung: konsultasi, bimbingan, administrasi akademik, dan pustaka.",
  applicationName: "PasundanEdu",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#137a6b" },
    { media: "(prefers-color-scheme: dark)", color: "#0a1412" },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>
        <a href="#isi" className="skip-link">Lewati ke konten utama</a>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
