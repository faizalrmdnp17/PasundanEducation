"use client";
import { useState } from "react";
import { api, useSubmit } from "@/components/client/toast";
import { Check, Field, FormError, SubmitButton } from "@/components/client/ui";
import { ROLES, ROLE_LABEL, ANNOUNCEMENT_CATEGORIES, ANNOUNCEMENT_LABEL, INTEGRATION_KINDS, RESOURCE_KIND_LABEL, type Role } from "@/lib/constants";

/* ------------------------- Permohonan peran ------------------------- */
export function RoleDecision({ id }: { id: string }) {
  const { busy, error, run } = useSubmit();
  const [note, setNote] = useState("");
  const go = (decision: "approve" | "reject", ok: string) => run(() => api(`/api/admin/role-requests/${id}`, { method: "PATCH", body: { decision, note } }), { success: ok });
  return (
    <div className="mt-2 space-y-2">
      <FormError message={error} />
      <input className="input !min-h-9" placeholder="Catatan keputusan (opsional)" maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} aria-label="Catatan keputusan" />
      <div className="flex gap-2">
        <button type="button" disabled={busy} className="btn btn-sm" onClick={() => go("approve", "Permohonan disetujui.")}>Setujui</button>
        <button type="button" disabled={busy} className="btn btn-bad btn-sm" onClick={() => go("reject", "Permohonan ditolak.")}>Tolak</button>
      </div>
    </div>
  );
}

/* ------------------------------ Pengguna ------------------------------ */
export function UserEditor({ u, self }: { u: { id: string; status: string; roles: Role[]; whatsapp_number: string | null; whatsapp_verified: boolean; identity_verified: boolean }; self: boolean }) {
  const { busy, error, run } = useSubmit();
  const [status, setStatus] = useState(u.status === "suspended" ? "suspended" : "active");
  const [roles, setRoles] = useState<Role[]>(u.roles);
  const [wa, setWa] = useState(u.whatsapp_verified);
  const [idv, setIdv] = useState(u.identity_verified);
  const toggle = (r: Role) => setRoles((s) => (s.includes(r) ? s.filter((x) => x !== r) : [...s, r]));
  return (
    <form className="space-y-3 pt-3" onSubmit={(e) => { e.preventDefault(); run(() => api(`/api/admin/users/${u.id}`, { method: "PATCH", body: self ? { whatsapp_verified: wa, identity_verified: idv } : { status, roles, whatsapp_verified: wa, identity_verified: idv } }), { success: "Perubahan disimpan." }); }}>
      <FormError message={error} />
      {self ? <p className="hint">Anda tidak dapat mengubah peran atau status akun Anda sendiri.</p> : (
        <>
          <fieldset>
            <legend className="label">Peran</legend>
            <div className="flex flex-wrap gap-x-5 gap-y-2">{ROLES.map((r) => <Check key={r} checked={roles.includes(r)} onChange={() => toggle(r)} label={ROLE_LABEL[r]} />)}</div>
            <p className="hint">Mengubah peran mengeluarkan pengguna dari semua perangkat.</p>
          </fieldset>
          <label className="block max-w-xs"><span className="label">Status akun</span>
            <select className="input" value={status} onChange={(e) => setStatus(e.target.value)}><option value="active">Aktif</option><option value="suspended">Ditangguhkan</option></select>
          </label>
        </>
      )}
      {u.whatsapp_number ? <Check checked={wa} onChange={setWa} label="Nomor WhatsApp kerja sudah saya verifikasi" hint="Menampilkan tombol WhatsApp kepada mahasiswa. Centang hanya setelah Anda memastikan nomor ini milik yang bersangkutan." /> : null}
      <Check checked={idv} onChange={setIdv} label="Identitas (NPM/NIDN) sudah saya verifikasi" />
      <SubmitButton busy={busy} className="btn btn-sm">Simpan</SubmitButton>
    </form>
  );
}

/* ------------------------------- Layanan ------------------------------- */
export type ServiceInit = {
  id?: string; category_id: string; name: string; description: string; icon: string; price_idr: number; duration_minutes: number | null; capacity: number | null;
  requirements: string[]; estimated_process: string | null; requires_appointment: boolean; requires_documents: boolean; cancellation_policy: string; is_active: boolean; staff_ids: string[];
};
export function ServiceForm({ init, categories, staff, icons }: { init: ServiceInit; categories: { id: string; name: string }[]; staff: { id: string; full_name: string }[]; icons: string[] }) {
  const { busy, error, fields, run } = useSubmit();
  const [v, setV] = useState({ ...init, requirements: init.requirements.join("\n"), estimated_process: init.estimated_process ?? "", duration_minutes: init.duration_minutes ? String(init.duration_minutes) : "", capacity: init.capacity ? String(init.capacity) : "", price_idr: String(init.price_idr) });
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setV((s) => ({ ...s, [k]: e.target.value }));
  const toggleStaff = (id: string) => setV((s) => ({ ...s, staff_ids: s.staff_ids.includes(id) ? s.staff_ids.filter((x) => x !== id) : [...s.staff_ids, id] }));
  return (
    <form className="space-y-3.5 pt-3" noValidate onSubmit={(e) => {
      e.preventDefault();
      const body = { ...v, price_idr: Number(v.price_idr || 0), requirements: v.requirements.split("\n").map((x) => x.trim()).filter(Boolean) };
      delete (body as { id?: string }).id;
      run(() => api(init.id ? `/api/admin/services/${init.id}` : "/api/admin/services", { method: init.id ? "PUT" : "POST", body }), { success: init.id ? "Layanan diperbarui." : "Layanan dibuat." });
    }}>
      <FormError message={error} />
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
        <Field label="Nama layanan" error={fields.name}><input className="input" value={v.name} onChange={set("name")} /></Field>
        <label className="block"><span className="label">Kategori</span><select className="input" value={v.category_id} onChange={set("category_id")}><option value="">Pilih kategori</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>{fields.category_id ? <span role="alert" className="err block">{fields.category_id}</span> : null}</label>
      </div>
      <Field label="Deskripsi" error={fields.description}><textarea className="input" rows={3} value={v.description} onChange={set("description")} /></Field>
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-3">
        <Field label="Harga (rupiah)" error={fields.price_idr} hint="Hanya berlaku bila pembayaran diaktifkan."><input className="input" inputMode="numeric" value={v.price_idr} onChange={set("price_idr")} /></Field>
        <Field label="Durasi sesi (menit)" error={fields.duration_minutes}><input className="input" inputMode="numeric" value={v.duration_minutes} onChange={set("duration_minutes")} /></Field>
        <label className="block"><span className="label">Ikon</span><select className="input" value={v.icon} onChange={set("icon")}>{icons.map((i) => <option key={i} value={i}>{i}</option>)}</select></label>
      </div>
      <Field label="Persyaratan (satu per baris)" error={fields.requirements}><textarea className="input" rows={3} value={v.requirements} onChange={set("requirements")} /></Field>
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
        <Field label="Perkiraan proses" error={fields.estimated_process}><input className="input" value={v.estimated_process} onChange={set("estimated_process")} placeholder="1–3 hari kerja" /></Field>
        <Field label="Kebijakan pembatalan" error={fields.cancellation_policy}><input className="input" value={v.cancellation_policy} onChange={set("cancellation_policy")} /></Field>
      </div>
      <div className="flex flex-wrap gap-x-6 gap-y-2">
        <Check checked={v.requires_appointment} onChange={(x) => setV((s) => ({ ...s, requires_appointment: x }))} label="Memakai jadwal konsultasi" />
        <Check checked={v.requires_documents} onChange={(x) => setV((s) => ({ ...s, requires_documents: x }))} label="Memerlukan dokumen" />
        <Check checked={v.is_active} onChange={(x) => setV((s) => ({ ...s, is_active: x }))} label="Aktif (tampil untuk mahasiswa)" />
      </div>
      <fieldset>
        <legend className="label">Penanggung jawab</legend>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">{staff.map((s) => <Check key={s.id} checked={v.staff_ids.includes(s.id)} onChange={() => toggleStaff(s.id)} label={s.full_name} />)}</div>
        {fields.staff_ids ? <span role="alert" className="err block">{fields.staff_ids}</span> : null}
      </fieldset>
      <SubmitButton busy={busy} className="btn btn-sm">{init.id ? "Simpan perubahan" : "Buat layanan"}</SubmitButton>
    </form>
  );
}

/* ------------------------------- Pustaka ------------------------------- */
export type ResourceInit = { id?: string; category_id: string; kind: string; title: string; authors: string; publisher: string; year: string; description: string; access_type: "link" | "borrow"; external_url: string; license_note: string; is_published: boolean };
export function ResourceForm({ init, categories }: { init: ResourceInit; categories: { id: string; name: string }[] }) {
  const { busy, error, fields, run } = useSubmit();
  const [v, setV] = useState(init);
  const set = (k: keyof ResourceInit) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setV((s) => ({ ...s, [k]: e.target.value }));
  return (
    <form className="space-y-3.5 pt-3" noValidate onSubmit={(e) => { e.preventDefault(); const { id: _i, ...body } = v; run(() => api(init.id ? `/api/admin/resources/${init.id}` : "/api/admin/resources", { method: init.id ? "PUT" : "POST", body }), { success: "Sumber disimpan." }); }}>
      <FormError message={error} />
      <Field label="Judul" error={fields.title}><input className="input" value={v.title} onChange={set("title")} /></Field>
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-3">
        <label className="block"><span className="label">Jenis</span><select className="input" value={v.kind} onChange={set("kind")}>{Object.entries(RESOURCE_KIND_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></label>
        <label className="block"><span className="label">Kategori</span><select className="input" value={v.category_id} onChange={set("category_id")}><option value="">Tanpa kategori</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
        <label className="block"><span className="label">Cara akses</span><select className="input" value={v.access_type} onChange={set("access_type")}><option value="link">Tautan ke penyedia</option><option value="borrow">Dipinjam lewat petugas</option></select></label>
      </div>
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-3">
        <Field label="Penulis" error={fields.authors}><input className="input" value={v.authors} onChange={set("authors")} /></Field>
        <Field label="Penerbit" error={fields.publisher}><input className="input" value={v.publisher} onChange={set("publisher")} /></Field>
        <Field label="Tahun" error={fields.year}><input className="input" inputMode="numeric" maxLength={4} value={v.year} onChange={set("year")} /></Field>
      </div>
      {v.access_type === "link" ? <Field label="Tautan (http/https)" error={fields.external_url} hint="Gunakan hanya sumber yang boleh diakses secara sah."><input className="input" type="url" value={v.external_url} onChange={set("external_url")} /></Field> : null}
      <Field label="Deskripsi" error={fields.description}><textarea className="input" rows={2} value={v.description} onChange={set("description")} /></Field>
      <Field label="Catatan lisensi atau hak akses" error={fields.license_note}><input className="input" value={v.license_note} onChange={set("license_note")} /></Field>
      <Check checked={v.is_published} onChange={(x) => setV((s) => ({ ...s, is_published: x }))} label="Tampil di pustaka" />
      <SubmitButton busy={busy} className="btn btn-sm">{init.id ? "Simpan perubahan" : "Tambah sumber"}</SubmitButton>
    </form>
  );
}

/* ------------------------------ Pengumuman ------------------------------ */
export type AnnInit = { id?: string; title: string; body: string; category: string; event_date: string; is_published: boolean };
export function AnnouncementForm({ init }: { init: AnnInit }) {
  const { busy, error, fields, run } = useSubmit();
  const del = useSubmit();
  const [v, setV] = useState(init);
  const set = (k: keyof AnnInit) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setV((s) => ({ ...s, [k]: e.target.value }));
  return (
    <form className="space-y-3.5 pt-3" noValidate onSubmit={(e) => { e.preventDefault(); const { id: _i, ...body } = v; run(() => api(init.id ? `/api/admin/announcements/${init.id}` : "/api/admin/announcements", { method: init.id ? "PUT" : "POST", body }), { success: "Pengumuman disimpan.", onDone: () => { if (!init.id) setV(init); } }); }}>
      <FormError message={error || del.error} />
      <Field label="Judul" error={fields.title}><input className="input" value={v.title} onChange={set("title")} /></Field>
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
        <label className="block"><span className="label">Kategori</span><select className="input" value={v.category} onChange={set("category")}>{ANNOUNCEMENT_CATEGORIES.map((c) => <option key={c} value={c}>{ANNOUNCEMENT_LABEL[c]}</option>)}</select></label>
        <Field label="Tanggal acara (opsional)" error={fields.event_date}><input className="input" type="date" value={v.event_date} onChange={set("event_date")} /></Field>
      </div>
      <Field label="Isi" error={fields.body}><textarea className="input" rows={4} value={v.body} onChange={set("body")} /></Field>
      <Check checked={v.is_published} onChange={(x) => setV((s) => ({ ...s, is_published: x }))} label="Publikasikan" />
      <div className="flex gap-2">
        <SubmitButton busy={busy} className="btn btn-sm">{init.id ? "Simpan" : "Terbitkan pengumuman"}</SubmitButton>
        {init.id ? <button type="button" disabled={del.busy} className="btn btn-bad btn-sm" onClick={() => { if (confirm("Hapus pengumuman ini?")) del.run(() => api(`/api/admin/announcements/${init.id}`, { method: "DELETE" }), { success: "Pengumuman dihapus." }); }}>Hapus</button> : null}
      </div>
    </form>
  );
}

/* ------------------------------ Integrasi ------------------------------ */
export type IntInit = { id?: string; code: string; name: string; kind: string; connection_type: string; base_url: string; auth_method: string; is_active: boolean; instructions: string };
export function IntegrationForm({ init }: { init: IntInit }) {
  const { busy, error, fields, run } = useSubmit();
  const [v, setV] = useState(init);
  const set = (k: keyof IntInit) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setV((s) => ({ ...s, [k]: e.target.value }));
  const pickKind = (e: React.ChangeEvent<HTMLSelectElement>) => { const k = INTEGRATION_KINDS.find((x) => x.value === e.target.value); setV((s) => ({ ...s, kind: e.target.value, connection_type: k?.type ?? s.connection_type })); };
  return (
    <form className="space-y-3.5 pt-3" noValidate onSubmit={(e) => { e.preventDefault(); const { id: _i, ...body } = v; run(() => api(init.id ? `/api/admin/integrations/${init.id}` : "/api/admin/integrations", { method: init.id ? "PUT" : "POST", body }), { success: "Integrasi disimpan." }); }}>
      <FormError message={error} />
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
        <Field label="Nama" error={fields.name}><input className="input" value={v.name} onChange={set("name")} /></Field>
        <Field label="Kode" error={fields.code} hint="Huruf kecil, angka, - atau _."><input className="input" value={v.code} onChange={set("code")} disabled={!!init.id} /></Field>
      </div>
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-3">
        <label className="block"><span className="label">Jenis</span><select className="input" value={v.kind} onChange={pickKind}>{INTEGRATION_KINDS.map((k) => <option key={k.value} value={k.value}>{k.label}</option>)}</select></label>
        <label className="block"><span className="label">Cara terhubung</span><select className="input" value={v.connection_type} onChange={set("connection_type")}><option value="link">Tautan saja</option><option value="api">API</option><option value="lti">LTI</option></select></label>
        <label className="block"><span className="label">Autentikasi</span><select className="input" value={v.auth_method} onChange={set("auth_method")}><option value="none">Tanpa</option><option value="api_token">Token API (di server)</option><option value="oauth2">OAuth 2</option><option value="oidc">OIDC</option><option value="lti13">LTI 1.3</option></select></label>
      </div>
      <Field label="URL dasar" error={fields.base_url}><input className="input" type="url" value={v.base_url} onChange={set("base_url")} placeholder="https://" /></Field>
      <Field label="Petunjuk untuk pengguna (opsional)" error={fields.instructions}><textarea className="input" rows={2} value={v.instructions} onChange={set("instructions")} /></Field>
      <p className="hint">Token atau kunci rahasia tidak disimpan di sini. Isi lewat variabel lingkungan server (lihat dokumentasi LMS).</p>
      <Check checked={v.is_active} onChange={(x) => setV((s) => ({ ...s, is_active: x }))} label="Aktif" />
      <SubmitButton busy={busy} className="btn btn-sm">{init.id ? "Simpan" : "Tambah integrasi"}</SubmitButton>
    </form>
  );
}

export function CheckIntegration({ id }: { id: string }) {
  const { busy, error, run } = useSubmit();
  return (
    <div className="space-y-1.5">
      <FormError message={error} />
      <button type="button" disabled={busy} className="btn btn-l btn-sm" onClick={() => run(() => api(`/api/admin/integrations/${id}/check`, { method: "POST" }), { success: "Pemeriksaan selesai." })}>Periksa koneksi</button>
    </div>
  );
}

/* ------------------------------- WhatsApp ------------------------------- */
export function TemplateForm({ t }: { t: { id: string; name: string; language: string; status: string; is_active: boolean } }) {
  const { busy, error, run } = useSubmit();
  const [v, setV] = useState(t);
  return (
    <form className="space-y-3 pt-3" onSubmit={(e) => { e.preventDefault(); run(() => api(`/api/admin/whatsapp/templates/${t.id}`, { method: "PUT", body: { name: v.name, language: v.language, status: v.status, is_active: v.is_active } }), { success: "Template disimpan." }); }}>
      <FormError message={error} />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <label className="block sm:col-span-2"><span className="label">Nama template di WhatsApp Business Manager</span><input className="input" value={v.name} onChange={(e) => setV((s) => ({ ...s, name: e.target.value }))} /></label>
        <label className="block"><span className="label">Bahasa</span><input className="input" value={v.language} onChange={(e) => setV((s) => ({ ...s, language: e.target.value }))} /></label>
      </div>
      <label className="block max-w-xs"><span className="label">Status persetujuan Meta</span>
        <select className="input" value={v.status} onChange={(e) => setV((s) => ({ ...s, status: e.target.value }))}><option value="draft">Draf</option><option value="submitted">Diajukan</option><option value="approved">Disetujui</option><option value="rejected">Ditolak</option></select>
      </label>
      <Check checked={v.is_active} onChange={(x) => setV((s) => ({ ...s, is_active: x }))} label="Aktifkan pengiriman memakai template ini" hint="Hanya dapat diaktifkan setelah berstatus Disetujui di WhatsApp Business Manager." />
      <SubmitButton busy={busy} className="btn btn-sm">Simpan template</SubmitButton>
    </form>
  );
}

export function RequeueButton() {
  const { busy, error, run } = useSubmit();
  return (
    <div className="space-y-1.5">
      <FormError message={error} />
      <button type="button" disabled={busy} className="btn btn-l btn-sm" onClick={() => run(() => api<{ requeued: number }>("/api/admin/jobs/requeue", { method: "POST" }), { success: "Pesan gagal dijadwalkan ulang." })}>Coba kirim ulang pesan gagal</button>
    </div>
  );
}

/* ------------------------------ Pengaturan ------------------------------ */
export function SettingsForm({ init }: { init: { payments_enabled: boolean; bank_account_info: string; institution_name: string; institution_verified: boolean } }) {
  const { busy, error, fields, run } = useSubmit();
  const [v, setV] = useState(init);
  return (
    <form className="space-y-4" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api("/api/admin/settings", { method: "PUT", body: v }), { success: "Pengaturan disimpan." }); }}>
      <FormError message={error} />
      <div className="card space-y-3">
        <h2 className="h-sec">Identitas institusi</h2>
        <Field label="Nama institusi" error={fields.institution_name}><input className="input" value={v.institution_name} onChange={(e) => setV((s) => ({ ...s, institution_name: e.target.value }))} /></Field>
        <Check checked={v.institution_verified} onChange={(x) => setV((s) => ({ ...s, institution_verified: x }))} label="Saya mewakili institusi ini dan berwenang menyatakan aplikasi ini sebagai layanan resminya" hint="Bila tidak dicentang, aplikasi menampilkan bahwa identitas institusi belum diverifikasi. Centang hanya dengan izin tertulis pimpinan institusi, termasuk untuk pemakaian logo." />
      </div>
      <div className="card space-y-3">
        <h2 className="h-sec">Pembayaran</h2>
        <Check checked={v.payments_enabled} onChange={(x) => setV((s) => ({ ...s, payments_enabled: x }))} label="Aktifkan biaya layanan (transfer manual)" hint="Bila nonaktif, semua pengajuan diproses tanpa biaya. Aktifkan hanya setelah tarif disetujui pengelola." />
        <label className="block"><span className="label">Informasi rekening tujuan transfer</span><textarea className="input" rows={3} maxLength={500} value={v.bank_account_info} onChange={(e) => setV((s) => ({ ...s, bank_account_info: e.target.value }))} placeholder="Nama bank, nomor rekening, atas nama" /></label>
        <p className="hint">Hanya data rekening penerima. Jangan memasukkan nomor kartu, CVV, atau kata sandi.</p>
      </div>
      <SubmitButton busy={busy} className="btn btn-sm">Simpan pengaturan</SubmitButton>
    </form>
  );
}
