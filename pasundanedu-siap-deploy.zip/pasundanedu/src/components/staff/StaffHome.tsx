import Link from "next/link";
import type { SessionUser } from "@/server/auth/types";
import { listRequests } from "@/server/domain/requests";
import { listMyAppointments, listStaffSlots } from "@/server/domain/appointments";
import { query } from "@/server/db";
import { Empty, RequestRow, SectionHead } from "@/components/common";
import { SlotManager } from "@/components/staff/SlotManager";
import { CalendarDays } from "@/components/icons";
import { ROLE_LABEL } from "@/lib/constants";
import { formatDayHeading, formatTime, jakartaDateKey } from "@/lib/format";

function Stat({ label, value, href }: { label: string; value: number; href: string }) {
  return (
    <Link href={href} className="card hover:border-brand">
      <span className="block text-[28px] font-bold leading-none tracking-tight">{value}</span>
      <span className="mu mt-1.5 block">{label}</span>
    </Link>
  );
}

/** Beranda dosen/petugas: ringkasan antrean, jadwal terdekat, dan pengelola slot. */
export async function StaffHome({ user }: { user: SessionUser }) {
  const [newReq, working, waiting, recent, appts, slots, svcs] = await Promise.all([
    listRequests(user, { as: "staff", status: "submitted", size: 1 }),
    listRequests(user, { as: "staff", status: "under_review,confirmed,in_progress", size: 1 }),
    listRequests(user, { as: "staff", status: "awaiting_information,awaiting_payment", size: 1 }),
    listRequests(user, { as: "staff", status: "submitted,under_review,awaiting_information,awaiting_payment,confirmed,in_progress", size: 5 }),
    listMyAppointments(user.id, "staff"),
    listStaffSlots(user.id),
    query<{ id: string; name: string }>("select s.id, s.name from services s join service_assignments sa on sa.service_id = s.id where sa.staff_id = $1 and s.is_active and s.requires_appointment order by s.name", [user.id]),
  ]);
  const now = Date.now();
  const upcoming = appts.filter((a) => a.status === "booked" && new Date(a.ends_at).getTime() > now).slice(0, 5);
  const role = user.roles.includes("petugas") ? ROLE_LABEL.petugas : ROLE_LABEL.dosen;
  return (
    <div>
      <header className="mb-4">
        <h1 className="h-page">Halo, {user.fullName.split(" ")[0]}</h1>
        <p className="mu mt-1 text-[13.5px]">{role}. Berikut ringkasan pengajuan yang menjadi tanggung jawab Anda.</p>
      </header>
      <div className="grid grid-cols-3 gap-2.5">
        <Stat label="Perlu ditinjau" value={newReq.total} href="/pengajuan?k=baru" />
        <Stat label="Dalam proses" value={working.total} href="/pengajuan?k=proses" />
        <Stat label="Menunggu mahasiswa" value={waiting.total} href="/pengajuan?k=proses" />
      </div>

      <div className="grid grid-cols-1 gap-x-8 lg:grid-cols-2">
        <section>
          <SectionHead title="Pengajuan aktif" href="/pengajuan?k=semua" />
          {recent.items.length ? <div className="space-y-2.5">{recent.items.map((r) => <RequestRow key={r.id} r={r} href={`/pengajuan/${r.id}`} showStudent />)}</div> : <Empty title="Tidak ada pengajuan aktif" hint="Pengajuan baru akan muncul di sini dan Anda akan mendapat notifikasi." />}
        </section>
        <section>
          <SectionHead title="Jadwal terdekat" href="/jadwal" />
          {upcoming.length ? (
            <div className="space-y-2.5">
              {upcoming.map((a) => (
                <Link key={a.id} href={`/pengajuan/${a.request_id}`} className="card flex items-center gap-3 hover:border-brand">
                  <span className="ic"><CalendarDays size={20} aria-hidden="true" /></span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold">{a.service_name}</span>
                    <span className="mu block">{formatDayHeading(jakartaDateKey(a.starts_at))}, {formatTime(a.starts_at)}–{formatTime(a.ends_at)} WIB</span>
                    <span className="mu block">Mahasiswa {a.other_name} · {a.mode === "online" ? "Online" : a.location || "Tatap muka"}</span>
                  </span>
                </Link>
              ))}
            </div>
          ) : <Empty title="Tidak ada jadwal mendatang" />}
        </section>
      </div>

      <SectionHead title="Kelola ketersediaan" />
      <SlotManager
        services={svcs.rows}
        slots={slots.map((s) => ({ id: s.id, starts_at: new Date(s.starts_at).toISOString(), ends_at: new Date(s.ends_at).toISOString(), mode: s.mode, location: s.location, capacity: s.capacity, booked: s.booked, status: s.status, service_id: s.service_id }))}
      />
    </div>
  );
}
