"use client";
import { useState } from "react";
import { api, useSubmit } from "@/components/client/toast";
import { Field, FormError, SubmitButton } from "@/components/client/ui";
import { formatDayHeading, formatTime, jakartaDateKey } from "@/lib/format";

export type SlotRow = { id: string; starts_at: string; ends_at: string; mode: "online" | "offline"; location: string | null; capacity: number; booked: number; status: string; service_id: string | null };
export type ServiceOpt = { id: string; name: string };

export function SlotManager({ slots, services }: { slots: SlotRow[]; services: ServiceOpt[] }) {
  const { busy, error, fields, run } = useSubmit();
  const closing = useSubmit();
  const today = jakartaDateKey(new Date());
  const [v, setV] = useState({ date: today, start: "09:00", end: "10:00", mode: "online", location: "", service_id: "", capacity: "1" });
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setV((s) => ({ ...s, [k]: e.target.value }));
  const byDay = new Map<string, SlotRow[]>();
  for (const s of slots) { const k = jakartaDateKey(s.starts_at); byDay.set(k, [...(byDay.get(k) ?? []), s]); }

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
      <form className="card space-y-3" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api("/api/staff/slots", { body: v }), { success: "Slot dibuka." }); }}>
        <h3 className="h-sec">Buka slot baru</h3>
        <FormError message={error} />
        <Field label="Tanggal" error={fields.date}><input className="input" type="date" min={today} value={v.date} onChange={set("date")} required /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Mulai" error={fields.start}><input className="input" type="time" value={v.start} onChange={set("start")} required /></Field>
          <Field label="Selesai" error={fields.end}><input className="input" type="time" value={v.end} onChange={set("end")} required /></Field>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label className="block"><span className="label">Bentuk</span><select className="input" value={v.mode} onChange={set("mode")}><option value="online">Online</option><option value="offline">Tatap muka</option></select></label>
          <Field label="Kapasitas" error={fields.capacity} hint="Jumlah mahasiswa per slot."><input className="input" type="number" min={1} max={100} value={v.capacity} onChange={set("capacity")} /></Field>
        </div>
        <Field label={v.mode === "online" ? "Tautan atau keterangan (opsional)" : "Lokasi"} error={fields.location}><input className="input" maxLength={300} value={v.location} onChange={set("location")} /></Field>
        <label className="block"><span className="label">Khusus layanan (opsional)</span>
          <select className="input" value={v.service_id} onChange={set("service_id")}><option value="">Semua layanan yang saya tangani</option>{services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
        </label>
        <SubmitButton busy={busy} className="btn btn-sm">Buka slot</SubmitButton>
      </form>

      <div>
        <h3 className="h-sec mb-2.5">Slot saya yang akan datang</h3>
        <FormError message={closing.error} />
        {slots.length === 0 ? <p className="card mu text-[13px]">Belum ada slot. Buka slot agar mahasiswa dapat memesan jadwal.</p> : (
          <div className="space-y-3">
            {[...byDay.entries()].map(([day, list]) => (
              <div key={day}>
                <p className="mb-1 text-[12.5px] font-semibold text-muted">{formatDayHeading(day)}</p>
                <ul className="card !py-1">
                  {list.map((s) => (
                    <li key={s.id} className="row text-[13.5px]">
                      <span className="min-w-0 flex-1">
                        <span className="block font-semibold">{formatTime(s.starts_at)}–{formatTime(s.ends_at)} WIB</span>
                        <span className="mu block">{s.mode === "online" ? "Online" : s.location || "Tatap muka"} · terisi {s.booked}/{s.capacity}{s.status !== "open" ? " · ditutup" : ""}</span>
                      </span>
                      {s.status === "open" && s.booked === 0 ? (
                        <button type="button" disabled={closing.busy} className="btn btn-bad btn-sm" onClick={() => closing.run(() => api(`/api/staff/slots/${s.id}`, { method: "DELETE" }), { success: "Slot ditutup." })}>Tutup</button>
                      ) : s.status === "open" ? (
                        <span className="mu max-w-[16ch] text-right !text-[12px]">Sudah dipesan. Jadwalkan ulang dari pengajuannya.</span>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
