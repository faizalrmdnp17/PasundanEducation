import Link from "next/link";
import type { ReactNode } from "react";
import { ChevronRight } from "@/components/icons";
import { ServiceIcon } from "@/components/icons";
import { PAYMENT_STATUS_LABEL, STATUS_LABEL, STATUS_TONE, type RequestStatus } from "@/lib/constants";
import { formatRupiah, formatShortDate } from "@/lib/format";

export function StatusBadge({ status }: { status: RequestStatus }) {
  return <span className={`badge badge-${STATUS_TONE[status]}`}>{STATUS_LABEL[status]}</span>;
}

export function PaymentBadge({ status, price }: { status: string; price: number }) {
  if (price <= 0) return <span className="badge badge-mute">Gratis</span>;
  const tone = status === "paid" ? "ok" : status === "awaiting_verification" ? "info" : status === "refunded" ? "mute" : "warn";
  return <span className={`badge badge-${tone}`}>{PAYMENT_STATUS_LABEL[status] ?? status}</span>;
}

export function PageHead({ title, desc, action }: { title: string; desc?: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        <h1 className="h-page">{title}</h1>
        {desc ? <p className="mu mt-1 max-w-[62ch] text-[13.5px]">{desc}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function SectionHead({ title, href, linkLabel }: { title: string; href?: string; linkLabel?: string }) {
  return (
    <div className="mb-2.5 mt-6 flex items-baseline justify-between gap-3">
      <h2 className="h-sec">{title}</h2>
      {href ? <Link href={href} className="text-[13px] font-semibold text-brand-text hover:underline">{linkLabel ?? "Lihat semua"}</Link> : null}
    </div>
  );
}

export function Empty({ title, hint, action, icon }: { title: string; hint?: ReactNode; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="card-flat flex flex-col items-center gap-1.5 px-5 py-9 text-center">
      {icon ? <span className="ic mb-1">{icon}</span> : null}
      <p className="font-semibold">{title}</p>
      {hint ? <p className="mu max-w-[46ch] text-[13px]">{hint}</p> : null}
      {action ? <div className="mt-3">{action}</div> : null}
    </div>
  );
}

/** Pagination berbasis tautan (server-rendered, aman untuk dibagikan/refresh). */
export function Pager({ page, totalPages, path, params = {} }: { page: number; totalPages: number; path: string; params?: Record<string, string | undefined> }) {
  if (totalPages <= 1) return null;
  const href = (p: number) => {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) sp.set(k, v);
    if (p > 1) sp.set("hal", String(p));
    const s = sp.toString();
    return s ? `${path}?${s}` : path;
  };
  return (
    <nav aria-label="Halaman" className="mt-5 flex items-center justify-center gap-3 text-[13px]">
      {page > 1 ? <Link href={href(page - 1)} className="btn btn-line btn-sm" rel="prev">Sebelumnya</Link> : <span className="btn btn-line btn-sm" aria-disabled="true">Sebelumnya</span>}
      <span className="text-muted">Halaman {page} dari {totalPages}</span>
      {page < totalPages ? <Link href={href(page + 1)} className="btn btn-line btn-sm" rel="next">Berikutnya</Link> : <span className="btn btn-line btn-sm" aria-disabled="true">Berikutnya</span>}
    </nav>
  );
}

export type RequestRowData = {
  id: string; request_number: string; status: RequestStatus; payment_status: string; price_idr: number; created_at: Date;
  service_name: string; service_icon: string; student_name?: string; student_npm?: string | null; assignee_name?: string | null; appointment_at?: Date | null;
};

/** Baris pengajuan. `href` menentukan tujuan (riwayat mahasiswa atau antrean staf). */
export function RequestRow({ r, href, showStudent = false }: { r: RequestRowData; href: string; showStudent?: boolean }) {
  return (
    <Link href={href} className="card flex items-center gap-3 hover:border-brand">
      <span className="ic"><ServiceIcon name={r.service_icon} /></span>
      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="truncate font-semibold">{r.service_name}</span>
          <StatusBadge status={r.status} />
        </span>
        <span className="mu mt-0.5 block truncate">
          {r.request_number}
          {showStudent && r.student_name ? ` · ${r.student_name}${r.student_npm ? ` (${r.student_npm})` : ""}` : ""}
          {` · ${formatShortDate(r.created_at)}`}
        </span>
        {r.price_idr > 0 ? <span className="mu block">{formatRupiah(r.price_idr)} · {PAYMENT_STATUS_LABEL[r.payment_status] ?? r.payment_status}</span> : null}
        {r.appointment_at ? <span className="mu block">Jadwal: {formatShortDate(r.appointment_at)}</span> : null}
      </span>
      <ChevronRight size={18} className="shrink-0 text-muted" aria-hidden="true" />
    </Link>
  );
}

/** Baris yang dapat dibuka untuk menampilkan formulir ubah (tanpa JavaScript tambahan). */
export function Disclosure({ summary, children, open = false }: { summary: ReactNode; children: ReactNode; open?: boolean }) {
  return (
    <details className="card group" open={open}>
      <summary className="flex cursor-pointer list-none items-center gap-3 [&::-webkit-details-marker]:hidden">
        <span className="min-w-0 flex-1">{summary}</span>
        <ChevronRight size={18} className="shrink-0 text-muted transition-transform group-open:rotate-90" aria-hidden="true" />
      </summary>
      {children}
    </details>
  );
}
