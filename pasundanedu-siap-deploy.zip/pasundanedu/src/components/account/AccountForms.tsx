"use client";
import { useState } from "react";
import { api, useSubmit } from "@/components/client/toast";
import { Check, Field, FormError, SubmitButton } from "@/components/client/ui";

export function ProfileForm({ init, isStudent }: { init: { full_name: string; study_program: string; cohort_year: string; phone: string; whatsapp_number: string }; isStudent: boolean }) {
  const { busy, error, fields, run } = useSubmit();
  const [v, setV] = useState(init);
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) => setV((s) => ({ ...s, [k]: e.target.value }));
  return (
    <form className="space-y-3.5" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api("/api/me", { method: "PATCH", body: { ...v, cohort_year: v.cohort_year || "" } }), { success: "Profil disimpan." }); }}>
      <FormError message={error} />
      <Field label="Nama lengkap" error={fields.full_name}><input className="input" autoComplete="name" value={v.full_name} onChange={set("full_name")} /></Field>
      {isStudent ? (
        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          <Field label="Program studi" error={fields.study_program}><input className="input" value={v.study_program} onChange={set("study_program")} /></Field>
          <Field label="Angkatan" error={fields.cohort_year}><input className="input" inputMode="numeric" maxLength={4} value={v.cohort_year} onChange={set("cohort_year")} /></Field>
        </div>
      ) : null}
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
        <Field label="Telepon" error={fields.phone}><input className="input" type="tel" autoComplete="tel" value={v.phone} onChange={set("phone")} /></Field>
        <Field label="Nomor WhatsApp" error={fields.whatsapp_number} hint="Mengubah nomor menonaktifkan notifikasi WhatsApp sampai Anda mengaktifkannya lagi."><input className="input" type="tel" inputMode="tel" value={v.whatsapp_number} onChange={set("whatsapp_number")} /></Field>
      </div>
      <SubmitButton busy={busy} className="btn btn-sm">Simpan profil</SubmitButton>
    </form>
  );
}

export function PreferencesForm({ init, hasNumber, whatsappReady }: { init: { email_enabled: boolean; whatsapp_enabled: boolean; reminders_enabled: boolean }; hasNumber: boolean; whatsappReady: boolean }) {
  const { busy, error, fields, run } = useSubmit();
  const [p, setP] = useState(init);
  return (
    <form className="space-y-3" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api("/api/me/preferences", { method: "PUT", body: p }), { success: "Preferensi disimpan." }); }}>
      <FormError message={error} />
      <Check checked={p.email_enabled} onChange={(v) => setP((s) => ({ ...s, email_enabled: v }))} label="Pembaruan layanan lewat email" />
      <Check checked={p.reminders_enabled} onChange={(v) => setP((s) => ({ ...s, reminders_enabled: v }))} label="Pengingat jadwal (sehari sebelumnya)" />
      <div>
        <Check
          checked={p.whatsapp_enabled} onChange={(v) => setP((s) => ({ ...s, whatsapp_enabled: v }))}
          label="Pembaruan layanan lewat WhatsApp"
          hint={!hasNumber ? "Isi nomor WhatsApp di profil terlebih dahulu." : whatsappReady ? "Anda dapat berhenti kapan saja, juga dengan membalas STOP. Dokumen tidak pernah dikirim lewat WhatsApp." : "Pengelola belum menghubungkan WhatsApp. Pilihan Anda disimpan, tetapi pesan belum dikirim."}
        />
        {fields.whatsapp_enabled ? <span role="alert" className="err block">{fields.whatsapp_enabled}</span> : null}
      </div>
      <SubmitButton busy={busy} className="btn btn-sm">Simpan preferensi</SubmitButton>
    </form>
  );
}

export function PasswordForm() {
  const { busy, error, fields, run } = useSubmit();
  const [cur, setCur] = useState("");
  const [nw, setNw] = useState("");
  return (
    <form className="space-y-3.5" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api("/api/auth/change-password", { body: { current_password: cur, new_password: nw } }), { success: "Kata sandi diperbarui.", onDone: () => { setCur(""); setNw(""); } }); }}>
      <FormError message={error} />
      <Field label="Kata sandi saat ini" error={fields.current_password}><input className="input" type="password" autoComplete="current-password" value={cur} onChange={(e) => setCur(e.target.value)} /></Field>
      <Field label="Kata sandi baru" error={fields.new_password} hint="Minimal 8 karakter, memuat huruf dan angka. Perangkat lain akan keluar."><input className="input" type="password" autoComplete="new-password" value={nw} onChange={(e) => setNw(e.target.value)} /></Field>
      <SubmitButton busy={busy} className="btn btn-sm">Ganti kata sandi</SubmitButton>
    </form>
  );
}

export function ResendVerification() {
  const { busy, error, run } = useSubmit();
  return (
    <div className="space-y-2">
      <FormError message={error} />
      <button type="button" disabled={busy} className="btn btn-sm" onClick={() => run(() => api<{ message: string }>("/api/auth/resend-verification", { method: "POST" }), { success: "Tautan verifikasi dikirim bila email Anda belum terverifikasi.", refresh: false })}>Kirim ulang tautan verifikasi</button>
    </div>
  );
}
