"use client";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api, useSubmit } from "@/components/client/toast";
import { timeAgo } from "@/lib/format";

type N = { id: string; title: string; body: string | null; link: string | null; read_at: string | null; created_at: string };

export function NotificationList({ items, unread }: { items: N[]; unread: number }) {
  const router = useRouter();
  const { busy, run } = useSubmit();
  async function open(n: N) {
    if (!n.read_at) { try { await api(`/api/notifications/${n.id}/read`, { method: "PATCH" }); } catch { /* abaikan */ } }
    if (n.link && n.link.startsWith("/") && !n.link.startsWith("//")) router.push(n.link);
    else router.refresh();
  }
  return (
    <div>
      {unread > 0 ? (
        <div className="mb-3 flex justify-end">
          <button type="button" disabled={busy} className="btn btn-l btn-sm" onClick={() => run(() => api("/api/notifications/read-all", { method: "POST" }), { success: "Semua notifikasi ditandai dibaca.", toastError: true })}>Tandai semua dibaca</button>
        </div>
      ) : null}
      <ul className="space-y-2">
        {items.map((n) => (
          <li key={n.id}>
            <button type="button" onClick={() => open(n)} className={`card flex w-full items-start gap-3 text-left hover:border-brand ${n.read_at ? "" : "!border-brand/50 !bg-chip/60"}`}>
              <span aria-hidden="true" className={`mt-1.5 size-2.5 shrink-0 rounded-full ${n.read_at ? "bg-transparent" : "bg-accent"}`} />
              <span className="min-w-0 flex-1">
                <span className="block font-semibold leading-snug">{n.title}{n.read_at ? "" : <span className="sr-only"> (belum dibaca)</span>}</span>
                {n.body ? <span className="mu mt-0.5 block text-[13px]">{n.body}</span> : null}
                <span className="mu mt-1 block !text-[12px]">{timeAgo(n.created_at)}</span>
              </span>
            </button>
          </li>
        ))}
      </ul>
      <noscript><Link href="/riwayat">Riwayat</Link></noscript>
    </div>
  );
}
