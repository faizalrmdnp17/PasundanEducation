"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Bookmark } from "@/components/icons";
import { api, useToast } from "@/components/client/toast";
import { ApiError, newIdempotencyKey } from "@/lib/client";

/** Aksi pada satu sumber belajar: simpan ke favorit, buka tautan, atau ajukan peminjaman. */
export function ResourceActions({ id, title, favorite, accessType, borrowServiceId }: { id: string; title: string; favorite: boolean; accessType: "link" | "borrow"; borrowServiceId: string | null }) {
  const router = useRouter();
  const { push } = useToast();
  const [fav, setFav] = useState(favorite);
  const [busy, setBusy] = useState<null | "fav" | "act">(null);

  async function toggle() {
    if (busy) return;
    setBusy("fav");
    const next = !fav;
    setFav(next);
    try {
      await api(`/api/resources/${id}/favorites`, { method: next ? "POST" : "DELETE" });
      push("ok", next ? "Disimpan ke favorit." : "Dihapus dari favorit.");
      router.refresh();
    } catch (e) {
      setFav(!next);
      push("bad", e instanceof ApiError ? e.message : "Gagal menyimpan favorit.");
    } finally { setBusy(null); }
  }

  async function act() {
    if (busy) return;
    setBusy("act");
    try {
      if (accessType === "link") {
        const r = await api<{ url: string }>(`/api/resources/${id}/open`, { method: "POST" });
        if (/^https?:\/\//i.test(r.url)) window.open(r.url, "_blank", "noopener,noreferrer");
        else push("bad", "Tautan tidak valid.");
      } else if (borrowServiceId) {
        const r = await api<{ id: string }>("/api/service-requests", {
          headers: { "Idempotency-Key": newIdempotencyKey() },
          body: { service_id: borrowServiceId, resource_id: id, student_note: `Peminjaman: ${title}` },
        });
        push("ok", "Permintaan peminjaman terkirim.");
        router.push(`/riwayat/${r.id}`);
      }
    } catch (e) {
      push("bad", e instanceof ApiError ? e.message : "Terjadi kesalahan.");
    } finally { setBusy(null); }
  }

  return (
    <div className="flex items-center gap-2">
      <button type="button" onClick={toggle} aria-pressed={fav} aria-label={fav ? `Hapus ${title} dari favorit` : `Simpan ${title} ke favorit`} className={`btn btn-sm ${fav ? "btn-l" : "btn-line"}`}>
        <Bookmark size={15} aria-hidden="true" fill={fav ? "currentColor" : "none"} />
        {fav ? "Tersimpan" : "Simpan"}
      </button>
      {accessType === "link" || borrowServiceId ? (
        <button type="button" onClick={act} disabled={busy === "act"} className="btn btn-sm">
          {accessType === "link" ? "Buka" : "Pinjam"}
        </button>
      ) : null}
    </div>
  );
}
