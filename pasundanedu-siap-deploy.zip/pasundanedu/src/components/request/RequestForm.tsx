"use client";
import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, useSubmit } from "@/components/client/toast";
import { Field, FormError, SubmitButton } from "@/components/client/ui";
import { newIdempotencyKey } from "@/lib/client";
import { formatDayHeading, formatTime, jakartaDateKey } from "@/lib/format";

export type SlotOption = { id: string; staff: string; starts_at: string; ends_at: string; mode: "online" | "offline"; location: string | null; left: number };

export function RequestForm({
  serviceId, emailVerified, requiresAppointment, requiresDocuments, slots,
}: { serviceId: string; emailVerified: boolean; requiresAppointment: boolean; requiresDocuments: boolean; slots: SlotOption[] }) {
  const router = useRouter();
  const { busy, error, fields, run } = useSubmit();
  const key = useRef(newIdempotencyKey());
  const [slot, setSlot] = useState("");
  const [topik, setTopik] = useState("");
  const [note, setNote] = useState("");

  const days = useMemo(() => {
    const m = new Map<string, SlotOption[]>();
    for (const s of slots) {
      const k = jakartaDateKey(s.starts_at);
      m.set(k, [...(m.get(k) ?? []), s]);
    }
    return [...m.entries()];
  }, [slots]);

  return (
    <form
      noValidate
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        run(
          () =>
            api<{ id: string; request_number: string; duplicate: boolean }>("/api/service-requests", {
              headers: { "Idempotency-Key": key.current },
              body: { service_id: serviceId, slot_id: requiresAppointment ? slot : undefined, student_note: note, details: topik.trim() ? { topik: topik.trim() } : {} },
            }),
          { refresh: false, onDone: (r) => router.push(`/riwayat/${r.id}?baru=${encodeURIComponent(r.request_number)}`) },
        );
      }}
    >
      {!emailVerified ? (
        <div className="alert alert-warn" role="status">
          Verifikasi email Anda dulu sebelum mengirim pengajuan. <Link href="/akun#verifikasi" className="font-semibold underline">Kirim ulang tautan verifikasi</Link>.
        </div>
      ) : null}
      <FormError message={error} />

      {requiresAppointment ? (
        <fieldset>
          <legend className="label">Pilih jadwal</legend>
          <div className="space-y-3">
            {days.map(([day, list]) => (
              <div key={day}>
                <p className="mb-1.5 text-[12.5px] font-semibold text-muted">{formatDayHeading(day)}</p>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {list.map((s) => (
                    <label key={s.id} className={`flex cursor-pointer items-start gap-2.5 rounded-xl border p-3 text-[13px] has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-accent ${slot === s.id ? "border-brand bg-chip" : "border-line"}`}>
                      <input type="radio" name="slot" value={s.id} checked={slot === s.id} onChange={() => setSlot(s.id)} className="mt-0.5 size-4 accent-[var(--g)]" />
                      <span>
                        <span className="block font-semibold">{formatTime(s.starts_at)}–{formatTime(s.ends_at)} WIB</span>
                        <span className="mu block">{s.staff}</span>
                        <span className="mu block">{s.mode === "online" ? "Online" : s.location || "Tatap muka"}{s.left <= 2 ? ` · sisa ${s.left} tempat` : ""}</span>
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>
          {fields.slot_id ? <span role="alert" className="err block">{fields.slot_id}</span> : null}
        </fieldset>
      ) : null}

      <Field label="Topik atau keperluan (opsional)" error={fields.topik} hint="Contoh: judul skripsi, mata kuliah, atau jenis surat yang dibutuhkan.">
        <input className="input" value={topik} maxLength={200} onChange={(e) => setTopik(e.target.value)} />
      </Field>
      <Field label="Catatan untuk penanggung jawab (opsional)" error={fields.student_note}>
        <textarea className="input" rows={4} maxLength={2000} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      {requiresDocuments ? <p className="mu text-[13px]">Layanan ini memerlukan dokumen. Anda dapat mengunggahnya di halaman pengajuan setelah pengajuan terkirim (PDF, PNG, JPG, atau DOCX, maksimal 5 MB per berkas).</p> : null}

      <SubmitButton busy={busy} disabled={!emailVerified || (requiresAppointment && !slot)} className="btn btn-block sm:w-auto sm:min-w-[200px]">Kirim pengajuan</SubmitButton>
    </form>
  );
}
