"use client";
import { useRef, useState } from "react";
import { api, useSubmit } from "@/components/client/toast";
import { Field, FormError, SubmitButton } from "@/components/client/ui";
import { newIdempotencyKey } from "@/lib/client";
import { STATUS_LABEL, type RequestStatus } from "@/lib/constants";
import { formatDayHeading, formatTime, jakartaDateKey } from "@/lib/format";

/* ---------------------------- Mahasiswa ---------------------------- */

export function CancelPanel({ id, policy }: { id: string; policy: string }) {
  const { busy, error, run } = useSubmit();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  if (!open) return <button type="button" className="btn btn-bad btn-sm" onClick={() => setOpen(true)}>Batalkan pengajuan</button>;
  return (
    <form className="space-y-3 rounded-xl border border-line p-3.5" onSubmit={(e) => { e.preventDefault(); run(() => api(`/api/service-requests/${id}/cancel`, { body: { reason } }), { success: "Pengajuan dibatalkan.", onDone: () => setOpen(false) }); }}>
      <p className="mu text-[13px]">{policy}</p>
      <FormError message={error} />
      <Field label="Alasan pembatalan (opsional)"><textarea className="input" rows={2} maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      <div className="flex gap-2">
        <SubmitButton busy={busy} className="btn btn-bad btn-sm">Ya, batalkan</SubmitButton>
        <button type="button" className="btn btn-line btn-sm" onClick={() => setOpen(false)}>Tidak jadi</button>
      </div>
    </form>
  );
}

export function FeedbackForm({ id }: { id: string }) {
  const { busy, error, fields, run } = useSubmit();
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  return (
    <form className="space-y-3" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api(`/api/service-requests/${id}/feedback`, { body: { rating, comment } }), { success: "Terima kasih atas penilaian Anda." }); }}>
      <FormError message={error} />
      <fieldset>
        <legend className="label">Bagaimana layanan ini?</legend>
        <div className="flex gap-1.5" role="radiogroup">
          {[1, 2, 3, 4, 5].map((n) => (
            <label key={n} className={`grid size-11 cursor-pointer place-items-center rounded-xl border text-[15px] font-bold has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-accent ${rating === n ? "border-brand bg-brand text-white" : "border-line"}`}>
              <input type="radio" name="rating" value={n} checked={rating === n} onChange={() => setRating(n)} className="sr-only" />
              <span aria-hidden="true">{n}</span><span className="sr-only">{n} dari 5</span>
            </label>
          ))}
        </div>
        <p className="hint">1 = kurang, 5 = sangat baik</p>
        {fields.rating ? <span role="alert" className="err block">{fields.rating}</span> : null}
      </fieldset>
      <Field label="Komentar (opsional)"><textarea className="input" rows={3} maxLength={2000} value={comment} onChange={(e) => setComment(e.target.value)} /></Field>
      <SubmitButton busy={busy} disabled={rating === 0} className="btn btn-sm">Kirim penilaian</SubmitButton>
    </form>
  );
}

/** Unggah berkas (lampiran/naskah/hasil). Validasi tipe dan ukuran dilakukan ulang di server. */
export function UploadForm({ id, kinds = [["lampiran", "Lampiran"]], url, label = "Unggah dokumen" }: { id: string; kinds?: [string, string][]; url?: string; label?: string }) {
  const { busy, error, run } = useSubmit();
  const ref = useRef<HTMLInputElement>(null);
  const [kind, setKind] = useState(kinds[0]![0]);
  const [name, setName] = useState("");
  return (
    <form
      className="space-y-2.5" noValidate
      onSubmit={(e) => {
        e.preventDefault();
        const f = ref.current?.files?.[0];
        if (!f) return;
        const fd = new FormData();
        fd.set("file", f);
        fd.set("kind", kind);
        run(() => api(url ?? `/api/service-requests/${id}/documents`, { form: fd }), { success: "Berkas terunggah.", onDone: () => { if (ref.current) ref.current.value = ""; setName(""); } });
      }}
    >
      <FormError message={error} />
      <div className="flex flex-wrap items-end gap-2">
        {kinds.length > 1 ? (
          <label className="block"><span className="label">Jenis</span>
            <select className="input" value={kind} onChange={(e) => setKind(e.target.value)}>{kinds.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
          </label>
        ) : null}
        <label className="block min-w-[200px] flex-1"><span className="label">{label}</span>
          <input ref={ref} type="file" accept=".pdf,.png,.jpg,.jpeg,.docx" onChange={(e) => setName(e.target.files?.[0]?.name ?? "")} className="input !py-1.5 file:mr-3 file:rounded-lg file:border-0 file:bg-chip file:px-3 file:py-1.5 file:font-semibold file:text-brand-text" />
        </label>
        <SubmitButton busy={busy} disabled={!name} className="btn btn-sm">Unggah</SubmitButton>
      </div>
      <p className="hint">PDF, PNG, JPG, atau DOCX. Maksimal 5 MB per berkas.</p>
    </form>
  );
}

export function MessageForm({ id, staff }: { id: string; staff: boolean }) {
  const { busy, error, fields, run } = useSubmit();
  const [body, setBody] = useState("");
  const [vis, setVis] = useState<"student" | "internal">("student");
  return (
    <form className="space-y-2.5" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api(`/api/service-requests/${id}/messages`, { body: { body, visibility: staff ? vis : "student" } }), { onDone: () => setBody("") }); }}>
      <FormError message={error} />
      <Field label="Tulis pesan" error={fields.body}><textarea className="input" rows={3} maxLength={4000} value={body} onChange={(e) => setBody(e.target.value)} /></Field>
      <div className="flex flex-wrap items-center gap-3">
        {staff ? (
          <label className="flex items-center gap-2 text-[13px]">
            <span className="font-semibold">Terlihat oleh</span>
            <select className="input !min-h-9 !w-auto !py-1" value={vis} onChange={(e) => setVis(e.target.value as "student" | "internal")}>
              <option value="student">Mahasiswa</option><option value="internal">Hanya staf (catatan internal)</option>
            </select>
          </label>
        ) : null}
        <SubmitButton busy={busy} disabled={!body.trim()} className="btn btn-sm">Kirim pesan</SubmitButton>
      </div>
    </form>
  );
}

export function PaymentPanel({ id, status, amountLabel, bankInfo, hasPayment }: { id: string; status: string; amountLabel: string; bankInfo: string; hasPayment: boolean }) {
  const { busy, error, run } = useSubmit();
  const key = useRef(newIdempotencyKey());
  return (
    <div className="space-y-3">
      <FormError message={error} />
      {!hasPayment ? (
        <>
          <p className="text-[13.5px]">Total yang harus dibayar: <strong>{amountLabel}</strong>. Pembayaran dilakukan lewat transfer manual dan diverifikasi petugas.</p>
          <button type="button" disabled={busy} className="btn btn-sm" onClick={() => run(() => api(`/api/service-requests/${id}/payment`, { method: "POST", headers: { "Idempotency-Key": key.current } }), { success: "Pembayaran dibuat. Silakan transfer lalu unggah bukti." })}>Mulai pembayaran</button>
        </>
      ) : status === "pending" ? (
        <>
          <div className="rounded-xl bg-soft p-3.5 text-[13.5px]">
            <p>Transfer <strong>{amountLabel}</strong> ke:</p>
            <p className="mt-1 whitespace-pre-line font-semibold">{bankInfo || "Informasi rekening belum diisi pengelola. Hubungi petugas."}</p>
          </div>
          <UploadForm id={id} url={`/api/service-requests/${id}/payment/proof`} label="Bukti transfer" />
        </>
      ) : null}
    </div>
  );
}

/* ------------------------------ Staf ------------------------------ */

export function StatusForm({ id, next }: { id: string; next: RequestStatus[] }) {
  const { busy, error, run } = useSubmit();
  const [to, setTo] = useState<string>("");
  const [note, setNote] = useState("");
  if (!next.length) return <p className="mu text-[13px]">Tidak ada perubahan status yang tersedia.</p>;
  return (
    <form className="space-y-2.5" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api(`/api/service-requests/${id}/status`, { method: "PATCH", body: { status: to, note } }), { success: "Status diperbarui.", onDone: () => { setTo(""); setNote(""); } }); }}>
      <FormError message={error} />
      <label className="block"><span className="label">Ubah status menjadi</span>
        <select className="input" value={to} onChange={(e) => setTo(e.target.value)} required>
          <option value="">Pilih status</option>
          {next.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
        </select>
      </label>
      <Field label="Catatan untuk mahasiswa (opsional)" hint="Catatan ini tercatat di jejak pengajuan dan dikirim sebagai notifikasi."><textarea className="input" rows={2} maxLength={2000} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
      <SubmitButton busy={busy} disabled={!to} className="btn btn-sm">Simpan status</SubmitButton>
    </form>
  );
}

export type StaffSlot = { id: string; staff: string; starts_at: string; ends_at: string; mode: string; location: string | null };

export function RescheduleForm({ id, slots }: { id: string; slots: StaffSlot[] }) {
  const { busy, error, run } = useSubmit();
  const [slot, setSlot] = useState("");
  const [note, setNote] = useState("");
  if (!slots.length) return <p className="mu text-[13px]">Belum ada slot lain yang tersedia. Buka slot baru dari halaman beranda Anda.</p>;
  return (
    <form className="space-y-2.5" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api(`/api/service-requests/${id}/appointment`, { method: "PATCH", body: { slot_id: slot, note } }), { success: "Jadwal diubah.", onDone: () => setSlot("") }); }}>
      <FormError message={error} />
      <label className="block"><span className="label">Jadwal baru</span>
        <select className="input" value={slot} onChange={(e) => setSlot(e.target.value)}>
          <option value="">Pilih slot</option>
          {slots.map((s) => <option key={s.id} value={s.id}>{formatDayHeading(jakartaDateKey(s.starts_at))}, {formatTime(s.starts_at)}–{formatTime(s.ends_at)} · {s.staff} · {s.mode === "online" ? "Online" : s.location || "Tatap muka"}</option>)}
        </select>
      </label>
      <Field label="Alasan (opsional)"><input className="input" maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
      <SubmitButton busy={busy} disabled={!slot} className="btn btn-sm">Ubah jadwal</SubmitButton>
    </form>
  );
}

export function DocVerify({ docId }: { docId: string }) {
  const { busy, error, run } = useSubmit();
  const [note, setNote] = useState("");
  return (
    <div className="mt-2 space-y-2">
      <FormError message={error} />
      <input className="input !min-h-9" placeholder="Catatan verifikasi (opsional)" maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} aria-label="Catatan verifikasi" />
      <div className="flex gap-2">
        <button type="button" disabled={busy} className="btn btn-sm" onClick={() => run(() => api(`/api/documents/${docId}/verify`, { method: "PATCH", body: { status: "verified", note } }), { success: "Dokumen diverifikasi." })}>Verifikasi</button>
        <button type="button" disabled={busy} className="btn btn-bad btn-sm" onClick={() => run(() => api(`/api/documents/${docId}/verify`, { method: "PATCH", body: { status: "rejected", note } }), { success: "Dokumen ditolak." })}>Tolak</button>
      </div>
    </div>
  );
}

export function PaymentVerify({ id, status }: { id: string; status: string }) {
  const { busy, error, run } = useSubmit();
  const go = (decision: "approve" | "reject" | "refund", ok: string) => run(() => api(`/api/service-requests/${id}/payment/verify`, { body: { decision } }), { success: ok });
  return (
    <div className="space-y-2">
      <FormError message={error} />
      <div className="flex flex-wrap gap-2">
        {status === "awaiting_verification" ? (
          <>
            <button type="button" disabled={busy} className="btn btn-sm" onClick={() => go("approve", "Pembayaran disetujui.")}>Setujui pembayaran</button>
            <button type="button" disabled={busy} className="btn btn-bad btn-sm" onClick={() => go("reject", "Pembayaran ditolak.")}>Tolak bukti</button>
          </>
        ) : null}
        {status === "paid" ? <button type="button" disabled={busy} className="btn btn-bad btn-sm" onClick={() => { if (confirm("Tandai pembayaran ini sebagai dikembalikan? Pengembalian dana dilakukan manual di luar aplikasi.")) go("refund", "Pembayaran ditandai dikembalikan."); }}>Tandai dikembalikan</button> : null}
      </div>
    </div>
  );
}
