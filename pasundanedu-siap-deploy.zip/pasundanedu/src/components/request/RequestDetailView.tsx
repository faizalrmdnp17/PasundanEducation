import Link from "next/link";
import { notFound as nf } from "next/navigation";
import { MessageCircle } from "@/components/icons";
import { PaymentBadge, StatusBadge } from "@/components/common";
import {
  CancelPanel, DocVerify, FeedbackForm, MessageForm, PaymentPanel, PaymentVerify, RescheduleForm, StatusForm, UploadForm,
} from "@/components/request/RequestPanels";
import { PAYMENT_STATUS_LABEL, STATUS_LABEL, STATUS_TONE, TERMINAL_STATUSES, type RequestStatus } from "@/lib/constants";
import { formatDateTime, formatRupiah, formatTime, timeAgo, formatDayHeading, jakartaDateKey } from "@/lib/format";
import { AppError } from "@/server/errors";
import { getRequestDetail } from "@/server/domain/requests";
import { listAvailability } from "@/server/domain/appointments";
import { getSettings } from "@/server/domain/settings";
import type { SessionUser } from "@/server/auth/types";

const DOC_STATUS: Record<string, [string, string]> = { pending: ["Menunggu verifikasi", "badge-warn"], verified: ["Terverifikasi", "badge-ok"], rejected: ["Ditolak", "badge-bad"] };

function Card({ title, children, id }: { title: string; children: React.ReactNode; id?: string }) {
  return (
    <section className="card" aria-labelledby={id}>
      <h2 id={id} className="h-sec mb-3">{title}</h2>
      {children}
    </section>
  );
}

export async function RequestDetailView({ user, id, justCreated }: { user: SessionUser; id: string; justCreated?: string }) {
  let d;
  try {
    d = await getRequestDetail(user, id);
  } catch (e) {
    if (e instanceof AppError && (e.status === 404 || e.status === 403)) nf();
    throw e;
  }
  const { request: r, history, messages, documents, appointment, payment, feedback, abilities: ab, contact } = d;
  const staff = d.viewAs === "staff";
  const settings = await getSettings();
  const terminal = TERMINAL_STATUSES.includes(r.status);
  const slots = staff && ab.manage && r.requires_appointment && !terminal
    ? (await listAvailability({ serviceId: r.service_id, days: 30, limit: 60 })).map((s) => ({ id: s.id, staff: s.staff_name, starts_at: new Date(s.starts_at).toISOString(), ends_at: new Date(s.ends_at).toISOString(), mode: s.mode, location: s.location }))
    : [];
  const back = staff ? "/pengajuan" : "/riwayat";
  const detailRows = Object.entries(r.details ?? {}).filter(([k]) => !["resource_id"].includes(k));
  const labelOf = (k: string) => (k === "topik" ? "Topik" : k === "resource_title" ? "Sumber yang dipinjam" : k.replace(/_/g, " "));

  return (
    <div>
      <Link href={back} className="mb-3 inline-block text-[13px] font-semibold text-brand-text hover:underline">{staff ? "Antrean pengajuan" : "Riwayat pengajuan"}</Link>
      {justCreated ? <div className="alert alert-ok mb-3" role="status">Pengajuan {justCreated} terkirim. Anda akan menerima kabar saat statusnya berubah.</div> : null}

      <header className="mb-4">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="h-page">{r.service_name}</h1>
          <StatusBadge status={r.status} />
          <PaymentBadge status={r.payment_status} price={r.price_idr} />
        </div>
        <p className="mu mt-1 text-[13px]">{r.request_number} · dibuat {formatDateTime(r.created_at)}</p>
      </header>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <div className="space-y-4">
          <Card title="Jejak pengajuan" id="jejak">
            <ol className="trail">
              {history.map((h, i) => {
                const last = i === history.length - 1;
                const tone = STATUS_TONE[h.to_status as RequestStatus];
                return (
                  <li key={h.id} data-now={last && !terminal ? "true" : undefined} data-tone={tone === "bad" ? "bad" : tone === "mute" ? "mute" : undefined}>
                    <p className="font-semibold leading-snug">{STATUS_LABEL[h.to_status as RequestStatus] ?? h.to_status}</p>
                    <p className="mu">{formatDateTime(h.created_at)}{h.by_name ? ` · ${h.by_name}` : ""}</p>
                    {h.note ? <p className="mt-0.5 text-[13px]">{h.note}</p> : null}
                  </li>
                );
              })}
            </ol>
          </Card>

          <Card title="Pesan" id="pesan">
            {messages.length === 0 ? <p className="mu mb-3 text-[13px]">Belum ada pesan.</p> : (
              <ul className="mb-4 space-y-2.5">
                {messages.map((m) => {
                  const mine = m.author_id === user.id;
                  return (
                    <li key={m.id} className={`max-w-[92%] rounded-2xl px-3.5 py-2.5 text-[13.5px] ${mine ? "ml-auto bg-chip" : "bg-soft"} ${m.visibility === "internal" ? "border border-dashed border-line" : ""}`}>
                      <p className="mu !text-[12px]">{mine ? "Anda" : m.author_name}{m.author_staff && !mine ? " (staf)" : ""} · {timeAgo(m.created_at)}{m.visibility === "internal" ? " · catatan internal" : ""}</p>
                      <p className="mt-0.5 whitespace-pre-wrap break-words">{m.body}</p>
                    </li>
                  );
                })}
              </ul>
            )}
            {!terminal || staff ? <MessageForm id={r.id} staff={staff} /> : <p className="mu text-[13px]">Pengajuan sudah ditutup.</p>}
          </Card>

          <Card title="Dokumen" id="dokumen">
            {documents.length === 0 ? <p className="mu mb-3 text-[13px]">{r.requires_documents ? "Belum ada dokumen. Layanan ini memerlukan dokumen yang diunggah." : "Belum ada dokumen."}</p> : (
              <ul className="mb-4 divide-y divide-line">
                {documents.map((x) => {
                  const [lab, cls] = DOC_STATUS[x.verification_status] ?? [x.verification_status, "badge-mute"];
                  return (
                    <li key={x.id} className="py-2.5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <a href={x.url} className="min-w-0 truncate font-semibold text-brand-text hover:underline" download>{x.original_name}</a>
                        <span className={`badge ${cls}`}>{lab}</span>
                      </div>
                      <p className="mu">{x.kind.replace(/_/g, " ")} · {(x.size_bytes / 1024).toFixed(0)} KB · {x.uploader_name} · {formatDateTime(x.created_at)}</p>
                      {x.verification_note ? <p className="mt-0.5 text-[13px]">Catatan: {x.verification_note}</p> : null}
                      {staff && ab.manage && x.verification_status === "pending" && x.kind !== "bukti_pembayaran" ? <DocVerify docId={x.id} /> : null}
                    </li>
                  );
                })}
              </ul>
            )}
            {ab.canUpload ? (
              <UploadForm id={r.id} kinds={staff ? [["hasil", "Hasil layanan"], ["lampiran", "Lampiran"]] : [["lampiran", "Lampiran"], ["naskah", "Naskah"]]} />
            ) : null}
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Rincian" id="rincian">
            <dl className="space-y-3 text-[13.5px]">
              {staff ? (
                <div><dt className="mu">Mahasiswa</dt><dd className="font-semibold">{r.student_name}{r.student_npm ? ` (${r.student_npm})` : ""}</dd>{r.student_prodi ? <dd className="mu">{r.student_prodi}{r.student_year ? ` · angkatan ${r.student_year}` : ""}</dd> : null}</div>
              ) : null}
              <div><dt className="mu">Penanggung jawab</dt><dd className="font-semibold">{r.assignee_name ?? "Belum ditentukan"}</dd></div>
              {appointment ? (
                <div>
                  <dt className="mu">Jadwal</dt>
                  <dd className="font-semibold">{formatDayHeading(jakartaDateKey(appointment.starts_at))}, {formatTime(appointment.starts_at)}–{formatTime(appointment.ends_at)} WIB</dd>
                  <dd className="mu">{appointment.mode === "online" ? "Online" : appointment.location || "Tatap muka"}{appointment.status !== "booked" ? ` · ${appointment.status === "cancelled" ? "dibatalkan" : appointment.status}` : ""}</dd>
                </div>
              ) : null}
              {detailRows.map(([k, v]) => <div key={k}><dt className="mu capitalize">{labelOf(k)}</dt><dd className="font-semibold">{String(v)}</dd></div>)}
              {r.student_note ? <div><dt className="mu">Catatan mahasiswa</dt><dd className="whitespace-pre-wrap">{r.student_note}</dd></div> : null}
              <div><dt className="mu">Biaya</dt><dd className="font-semibold">{r.price_idr > 0 ? formatRupiah(r.price_idr) : "Tanpa biaya"}</dd></div>
            </dl>
            {contact ? (
              <div className="mt-4 border-t border-line pt-3">
                <a href={contact.wa} target="_blank" rel="noopener noreferrer" className="btn btn-l btn-sm w-full"><MessageCircle size={16} aria-hidden="true" /> Hubungi {contact.name} lewat WhatsApp</a>
                <p className="hint">Jangan kirim dokumen pribadi lewat WhatsApp. Unggah di bagian Dokumen.</p>
              </div>
            ) : null}
          </Card>

          {r.price_idr > 0 ? (
            <Card title="Pembayaran" id="bayar">
              <p className="text-[13.5px]">Status: <strong>{PAYMENT_STATUS_LABEL[r.payment_status] ?? r.payment_status}</strong>{payment?.paid_at ? ` · dibayar ${formatDateTime(payment.paid_at)}` : ""}</p>
              {ab.canPay ? <div className="mt-3"><PaymentPanel id={r.id} status={payment?.status ?? "none"} hasPayment={!!payment} amountLabel={formatRupiah(r.price_idr)} bankInfo={settings.bank_account_info} /></div> : null}
              {r.payment_status === "awaiting_verification" && !ab.canVerifyPayment ? <p className="mu mt-2 text-[13px]">Bukti pembayaran sedang diperiksa petugas.</p> : null}
              {ab.canVerifyPayment ? <div className="mt-3"><PaymentVerify id={r.id} status={r.payment_status} /></div> : null}
            </Card>
          ) : null}

          {ab.manage ? (
            <>
              <Card title="Proses pengajuan" id="status"><StatusForm id={r.id} next={ab.nextStatuses as RequestStatus[]} /></Card>
              {r.requires_appointment && !terminal ? <Card title="Jadwal ulang" id="jadwal-ulang"><RescheduleForm id={r.id} slots={slots} /></Card> : null}
            </>
          ) : null}

          {ab.owner && ab.canCancel ? <Card title="Pembatalan" id="batal"><CancelPanel id={r.id} policy={r.cancellation_policy} /></Card> : null}

          {ab.owner && r.status === "completed" ? (
            <Card title="Penilaian" id="nilai">
              {feedback ? <p className="text-[13.5px]">Penilaian Anda: <strong>{feedback.rating} dari 5</strong>{feedback.comment ? ` · ${feedback.comment}` : ""}</p> : ab.canFeedback ? <FeedbackForm id={r.id} /> : null}
            </Card>
          ) : null}
        </div>
      </div>
    </div>
  );
}
