"use client";
import Link from "next/link";
import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import { api, useSubmit } from "@/components/client/toast";
import { Check, Field, FormError, SubmitButton } from "@/components/client/ui";
import { homeForRoles } from "@/lib/constants";

function safeNext(n?: string | null) {
  return n && n.startsWith("/") && !n.startsWith("//") && !n.includes("\\") ? n : null;
}

function PasswordField({ label, autoComplete, value, onChange, error, hint, aside, name = "password" }: { label: string; autoComplete: string; value: string; onChange: (v: string) => void; error?: string; hint?: string; aside?: ReactNode; name?: string }) {
  const [show, setShow] = useState(false);
  const id = useId();
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between gap-3">
        <label htmlFor={id} className="label !mb-0">{label}</label>
        {aside}
      </div>
      <span className="relative block">
        <input
          id={id} className="input pr-[92px]" type={show ? "text" : "password"} name={name} autoComplete={autoComplete} value={value}
          onChange={(e) => onChange(e.target.value)} aria-invalid={!!error || undefined} aria-describedby={error ? `${id}-e` : hint ? `${id}-h` : undefined} required
        />
        <button type="button" onClick={() => setShow((x) => !x)} aria-pressed={show} className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-lg px-2.5 py-1.5 text-[12px] font-semibold text-brand-text hover:bg-chip">
          {show ? "Sembunyikan" : "Tampilkan"}
        </button>
      </span>
      {error ? <span id={`${id}-e`} role="alert" className="err block">{error}</span> : hint ? <span id={`${id}-h`} className="hint block">{hint}</span> : null}
    </div>
  );
}

export function LoginForm({ next, notice }: { next?: string; notice?: string }) {
  const { busy, error, fields, run } = useSubmit();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <form
      className="space-y-4"
      noValidate
      onSubmit={(e) => {
        e.preventDefault();
        run(
          async () => {
            await api("/api/auth/login", { body: { email, password } });
            const me = await api<{ user: { roles: any[]; status: string } }>("/api/auth/me");
            return me.user;
          },
          {
            refresh: false,
            onDone: (u) => {
              const target = u.status === "pending_approval" ? "/menunggu-persetujuan" : (safeNext(next) ?? homeForRoles(u.roles));
              // Navigasi penuh (bukan router.replace): membuang cache router klien yang dibuat saat belum masuk.
              window.location.assign(target);
            },
          },
        );
      }}
    >
      {notice ? <div className="alert alert-ok" role="status">{notice}</div> : null}
      <FormError message={error} />
      <Field label="Email" error={fields.email}>
        <input className="input" type="email" name="email" autoComplete="username" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} aria-invalid={!!fields.email || undefined} required />
      </Field>
      <PasswordField
        label="Kata sandi" autoComplete="current-password" value={password} onChange={setPassword} error={fields.password}
        aside={<Link href="/lupa-sandi" className="text-[12.5px] font-medium text-brand-text hover:underline">Lupa kata sandi?</Link>}
      />
      <SubmitButton busy={busy} className="btn btn-block">Masuk</SubmitButton>
    </form>
  );
}

type AccountType = "mahasiswa" | "dosen" | "petugas";

export function RegisterForm() {
  const { busy, error, fields, run } = useSubmit();
  const [type, setType] = useState<AccountType>("mahasiswa");
  const [v, setV] = useState({ full_name: "", email: "", password: "", npm: "", nidn: "", study_program: "", cohort_year: "", whatsapp_number: "" });
  const [terms, setTerms] = useState(false);
  const [emailPref, setEmailPref] = useState(true);
  const [waPref, setWaPref] = useState(false);
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) => setV((s) => ({ ...s, [k]: e.target.value }));
  const inv = (k: string) => (fields[k] ? true : undefined);

  return (
    <form
      className="space-y-4"
      noValidate
      onSubmit={(e) => {
        e.preventDefault();
        run(
          () =>
            api<{ status: "active" | "pending_approval"; message: string; email_sent: boolean }>("/api/auth/register", {
              body: {
                account_type: type, full_name: v.full_name, email: v.email, password: v.password,
                npm: type === "mahasiswa" ? v.npm : "", nidn: type !== "mahasiswa" ? v.nidn : "",
                study_program: type === "mahasiswa" ? v.study_program : "", cohort_year: type === "mahasiswa" ? v.cohort_year : "",
                whatsapp_number: v.whatsapp_number, accept_terms: terms, consent_email: emailPref, consent_whatsapp: waPref,
              },
            }),
          {
            refresh: false,
            success: "Pendaftaran berhasil.",
            onDone: (r) => {
              window.location.assign(r.status === "pending_approval" ? "/menunggu-persetujuan" : r.email_sent ? "/?baru=1" : "/?baru=1&email=gagal");
            },
          },
        );
      }}
    >
      <FormError message={error} />

      <fieldset>
        <legend className="label">Saya mendaftar sebagai</legend>
        <div className="grid grid-cols-3 gap-1.5 rounded-xl bg-chip p-1" role="radiogroup">
          {([["mahasiswa", "Mahasiswa"], ["dosen", "Dosen"], ["petugas", "Petugas"]] as const).map(([k, l]) => (
            <label key={k} className={`cursor-pointer rounded-lg py-2 text-center text-[13px] font-semibold transition-colors has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-accent ${type === k ? "bg-card text-brand-text shadow-sm" : "text-muted"}`}>
              <input type="radio" name="account_type" value={k} checked={type === k} onChange={() => setType(k)} className="sr-only" />
              {l}
            </label>
          ))}
        </div>
        {type !== "mahasiswa" ? <p className="hint">Akun dosen dan petugas diaktifkan setelah disetujui pengelola. Anda tetap dapat masuk untuk memantau statusnya.</p> : null}
      </fieldset>

      <Field label="Nama lengkap" error={fields.full_name}>
        <input className="input" name="full_name" autoComplete="name" value={v.full_name} onChange={set("full_name")} aria-invalid={inv("full_name")} required />
      </Field>
      <Field label="Email" error={fields.email} hint="Dipakai untuk masuk dan verifikasi akun.">
        <input className="input" type="email" name="email" autoComplete="email" inputMode="email" value={v.email} onChange={set("email")} aria-invalid={inv("email")} required />
      </Field>

      {type === "mahasiswa" ? (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="NPM" error={fields.npm}>
              <input className="input" name="npm" inputMode="numeric" autoComplete="off" value={v.npm} onChange={set("npm")} aria-invalid={inv("npm")} required />
            </Field>
            <Field label="Angkatan" error={fields.cohort_year}>
              <input className="input" name="cohort_year" inputMode="numeric" placeholder="2023" maxLength={4} value={v.cohort_year} onChange={set("cohort_year")} aria-invalid={inv("cohort_year")} />
            </Field>
          </div>
          <Field label="Program studi" error={fields.study_program}>
            <input className="input" name="study_program" list="prodi" value={v.study_program} onChange={set("study_program")} placeholder="Mis. Manajemen" />
            <datalist id="prodi"><option value="Manajemen" /><option value="Akuntansi" /></datalist>
          </Field>
        </>
      ) : (
        <Field label="NIDN / NIP" error={fields.nidn} hint="Dipakai pengelola untuk memverifikasi identitas Anda.">
          <input className="input" name="nidn" autoComplete="off" value={v.nidn} onChange={set("nidn")} aria-invalid={inv("nidn")} required />
        </Field>
      )}

      <Field label="Nomor WhatsApp (opsional)" error={fields.whatsapp_number} hint="Contoh: 0812-3456-7890. Hanya dipakai untuk notifikasi layanan.">
        <input className="input" type="tel" name="whatsapp_number" autoComplete="tel" inputMode="tel" value={v.whatsapp_number} onChange={set("whatsapp_number")} aria-invalid={inv("whatsapp_number")} />
      </Field>

      <PasswordField
        label="Kata sandi" autoComplete="new-password" value={v.password} onChange={(x) => setV((st) => ({ ...st, password: x }))}
        error={fields.password} hint="Minimal 8 karakter, memuat huruf dan angka."
      />

      <div className="space-y-2.5 rounded-xl border border-line p-3.5">
        <Check checked={emailPref} onChange={setEmailPref} label="Kirim pembaruan layanan lewat email" />
        <Check checked={waPref} onChange={setWaPref} label="Kirim pembaruan layanan lewat WhatsApp" hint="Anda dapat berhenti kapan saja dengan membalas STOP atau lewat menu Akun." />
      </div>

      <div>
        <Check
          checked={terms} onChange={setTerms}
          label={<>Saya menyetujui <Link href="/syarat" target="_blank" className="font-semibold text-brand-text underline">syarat dan ketentuan</Link> serta <Link href="/privasi" target="_blank" className="font-semibold text-brand-text underline">kebijakan privasi</Link>.</>}
        />
        {fields.accept_terms ? <span role="alert" className="err block">{fields.accept_terms}</span> : null}
      </div>

      <SubmitButton busy={busy} className="btn btn-block">Daftar</SubmitButton>
    </form>
  );
}

export function ForgotForm() {
  const { busy, error, fields, run } = useSubmit();
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState<string | null>(null);
  if (sent) return <div className="alert alert-ok" role="status">{sent}</div>;
  return (
    <form className="space-y-4" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api<{ message: string }>("/api/auth/forgot", { body: { email } }), { refresh: false, onDone: (r) => setSent(r.message) }); }}>
      <FormError message={error} />
      <Field label="Email terdaftar" error={fields.email}>
        <input className="input" type="email" autoComplete="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoFocus />
      </Field>
      <SubmitButton busy={busy} className="btn btn-block">Kirim tautan atur ulang</SubmitButton>
    </form>
  );
}

export function ResetForm({ token }: { token: string }) {
  const { busy, error, fields, run } = useSubmit();
  const [password, setPassword] = useState("");
  return (
    <form className="space-y-4" noValidate onSubmit={(e) => { e.preventDefault(); run(() => api("/api/auth/reset", { body: { token, password } }), { refresh: false, onDone: () => window.location.assign("/masuk?diatur=1") }); }}>
      <FormError message={error} />
      <PasswordField label="Kata sandi baru" autoComplete="new-password" value={password} onChange={setPassword} error={fields.password} hint="Minimal 8 karakter, memuat huruf dan angka." />
      <SubmitButton busy={busy} className="btn btn-block">Simpan kata sandi baru</SubmitButton>
    </form>
  );
}

/** Memverifikasi email otomatis saat halaman dibuka dari tautan di email. */
export function VerifyClient({ token }: { token: string }) {
  const [state, setState] = useState<"loading" | "ok" | "bad">("loading");
  const [msg, setMsg] = useState("");
  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    api("/api/auth/verify", { body: { token } })
      .then(() => setState("ok"))
      .catch((e) => { setMsg(e.message); setState("bad"); });
  }, [token]);
  if (state === "loading") return <p role="status" className="mu">Memverifikasi email Anda…</p>;
  if (state === "ok")
    return (
      <div className="space-y-4">
        <div className="alert alert-ok" role="status">Email Anda sudah terverifikasi. Semua layanan kini dapat Anda gunakan.</div>
        <Link href="/" className="btn btn-block">Lanjut ke beranda</Link>
      </div>
    );
  return (
    <div className="space-y-4">
      <div className="alert alert-bad" role="alert">{msg}</div>
      <Link href="/masuk?next=/akun" className="btn btn-l btn-block">Masuk untuk mengirim ulang tautan</Link>
    </div>
  );
}
