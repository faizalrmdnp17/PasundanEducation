import Link from "next/link";
import type { ReactNode } from "react";
import { Logo } from "@/components/logo";
import { getSettings } from "@/server/domain/settings";
import { BookOpen, CalendarDays, GraduationCap } from "@/components/icons";

/**
 * Kerangka halaman registrasi & login. Logo penuh PasundanEdu berada di bagian paling atas formulir.
 * Panel hijau di kiri hanya tampil pada layar lebar.
 */
export async function AuthShell({ title, subtitle, children, footer }: { title: string; subtitle?: string; children: ReactNode; footer?: ReactNode }) {
  const s = await getSettings().catch(() => null);
  const official = !!s?.institution_verified;
  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
      <aside className="hidden bg-brand-dark p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="max-w-md">
          <p className="text-[28px] font-bold leading-tight tracking-tight">Layanan kuliah Anda, dalam satu aplikasi.</p>
          <p className="mt-3 text-[15px] leading-relaxed text-white/80">Ajukan konsultasi, pantau status, dan temukan bahan belajar tanpa antre di loket.</p>
          <ul className="mt-10 space-y-6">
            {[
              [GraduationCap, "Konsultasi dosen wali dan bimbingan skripsi", "Pilih jadwal yang tersedia, lalu pantau prosesnya sampai selesai."],
              [BookOpen, "Pustaka digital", "Cari buku, jurnal, dan konten belajar, lalu simpan yang Anda perlukan."],
              [CalendarDays, "Administrasi akademik", "Ajukan surat keterangan dan terima kabar saat statusnya berubah."],
            ].map(([Icon, t, d]) => {
              const I = Icon as typeof GraduationCap;
              return (
                <li key={t as string} className="flex gap-3.5">
                  <span className="mt-0.5 grid size-9 shrink-0 place-items-center rounded-xl bg-white/12"><I size={18} aria-hidden="true" /></span>
                  <span>
                    <span className="block font-semibold">{t as string}</span>
                    <span className="block text-[13.5px] leading-relaxed text-white/75">{d as string}</span>
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
        <p className="max-w-md text-[12.5px] leading-relaxed text-white/65">
          {official ? `Layanan resmi ${s?.institution_name}.` : "PasundanEdu adalah platform layanan pendidikan untuk mahasiswa STIE Pasundan Bandung. Identitas institusi belum diverifikasi oleh pengelola."}
        </p>
      </aside>

      <main id="isi" className="flex min-h-dvh flex-col items-center justify-center px-5 py-8 sm:px-8">
        <div className="w-full max-w-[440px]">
          <Link href="/" prefetch={false} aria-label="PasundanEdu, ke beranda" className="mx-auto mb-6 block w-fit">
            <Logo width={300} priority />
          </Link>
          <div className="card-flat p-6 sm:p-7">
            <h1 className="text-[22px] font-bold leading-tight tracking-tight">{title}</h1>
            {subtitle ? <p className="mu mt-1.5 text-[13.5px]">{subtitle}</p> : null}
            <div className="mt-5">{children}</div>
          </div>
          {footer ? <div className="mt-4 text-center text-[13px] text-muted">{footer}</div> : null}
          <p className="mt-6 text-center text-[12px] text-muted">
            <Link href="/syarat" className="underline-offset-2 hover:underline">Syarat dan ketentuan</Link>
            <span aria-hidden="true"> &nbsp;|&nbsp; </span>
            <Link href="/privasi" className="underline-offset-2 hover:underline">Kebijakan privasi</Link>
          </p>
        </div>
      </main>
    </div>
  );
}
