import Image from "next/image";

/** Logo penuh PasundanEdu (lambang + tulisan). Berlatar putih bawaan: dibungkus pelat putih agar tetap terbaca di mode gelap. */
export function Logo({ width = 280, priority = false, className = "" }: { width?: number; priority?: boolean; className?: string }) {
  const src = width > 400 ? "/brand/logo-720.png" : "/brand/logo-400.png";
  return (
    <span className={`logo-plate inline-block p-2.5 ${className}`}>
      <Image
        src={src}
        alt="PasundanEdu – STIE Pasundan Bandung"
        width={width}
        height={Math.round((width * 649) / 1730)}
        priority={priority}
        unoptimized
        className="block h-auto"
        style={{ width, maxWidth: "100%" }}
      />
    </span>
  );
}

export function Emblem({ size = 36 }: { size?: number }) {
  return (
    <span className="logo-plate inline-grid shrink-0 place-items-center" style={{ width: size, height: size, borderRadius: size / 3 }}>
      <Image src="/brand/emblem-72.png" alt="" width={size} height={size} unoptimized className="block object-contain" style={{ width: size - 4, height: size - 4 }} />
    </span>
  );
}
