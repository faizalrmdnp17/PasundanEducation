"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  Bell, BookOpen, CalendarDays, FileText, GraduationCap, History, Home, Inbox, LayoutDashboard, LogOut, Megaphone, MessageCircle,
  Plug, ScrollText, ShieldCheck, User, Users, Wallet, Settings, Library,
} from "@/components/icons";
import { Emblem } from "@/components/logo";
import { api } from "@/lib/client";
import type { Role } from "@/lib/constants";
import { ROLE_LABEL } from "@/lib/constants";

type Item = { href: string; label: string; icon: keyof typeof I; exact?: boolean };
const I = { home: Home, layanan: GraduationCap, pustaka: Library, info: Megaphone, akun: User, jadwal: CalendarDays, riwayat: History, notif: Bell, inbox: Inbox, dash: LayoutDashboard, users: Users, wallet: Wallet, plug: Plug, wa: MessageCircle, audit: ScrollText, shield: ShieldCheck, settings: Settings, file: FileText, book: BookOpen } as const;

function navFor(roles: Role[]): { main: Item[]; manage: Item[]; tabs: Item[] } {
  const admin = roles.includes("admin");
  const petugas = roles.includes("petugas");
  const dosen = roles.includes("dosen");
  const staff = admin || petugas || dosen;
  const home: Item = admin ? { href: "/admin", label: "Ringkasan", icon: "dash", exact: true } : petugas ? { href: "/petugas", label: "Beranda", icon: "home", exact: true } : dosen ? { href: "/dosen", label: "Beranda", icon: "home", exact: true } : { href: "/", label: "Beranda", icon: "home", exact: true };
  const common: Item[] = [
    { href: "/pustaka", label: "Pustaka", icon: "pustaka" },
    { href: "/info", label: "Informasi", icon: "info" },
  ];
  const main: Item[] = staff
    ? [home, { href: "/pengajuan", label: "Pengajuan masuk", icon: "inbox" }, ...common, { href: "/notifikasi", label: "Notifikasi", icon: "notif" }, { href: "/akun", label: "Akun", icon: "akun" }]
    : [home, { href: "/layanan", label: "Layanan", icon: "layanan" }, ...common, { href: "/jadwal", label: "Jadwal", icon: "jadwal" }, { href: "/riwayat", label: "Riwayat", icon: "riwayat" }, { href: "/notifikasi", label: "Notifikasi", icon: "notif" }, { href: "/akun", label: "Akun", icon: "akun" }];
  const manage: Item[] = admin
    ? [
        { href: "/admin/pengguna", label: "Pengguna dan peran", icon: "users" },
        { href: "/admin/layanan", label: "Katalog layanan", icon: "layanan" },
        { href: "/admin/pustaka", label: "Pustaka", icon: "pustaka" },
        { href: "/admin/pengumuman", label: "Pengumuman", icon: "info" },
        { href: "/admin/pembayaran", label: "Pembayaran", icon: "wallet" },
        { href: "/admin/whatsapp", label: "WhatsApp", icon: "wa" },
        { href: "/admin/integrasi", label: "Integrasi LMS", icon: "plug" },
        { href: "/admin/audit", label: "Jejak audit", icon: "audit" },
        { href: "/admin/pengaturan", label: "Pengaturan", icon: "settings" },
      ]
    : [];
  // Bottom nav mobile: 5 tab (mengikuti prototipe).
  const tabs: Item[] = staff
    ? [home, { href: "/pengajuan", label: "Pengajuan", icon: "inbox" }, { href: "/pustaka", label: "Pustaka", icon: "pustaka" }, { href: "/info", label: "Info", icon: "info" }, { href: "/akun", label: "Akun", icon: "akun" }]
    : [{ href: "/", label: "Beranda", icon: "home", exact: true }, { href: "/layanan", label: "Layanan", icon: "layanan" }, { href: "/pustaka", label: "Pustaka", icon: "pustaka" }, { href: "/info", label: "Info", icon: "info" }, { href: "/akun", label: "Akun", icon: "akun" }];
  return { main, manage, tabs };
}

function active(path: string, it: Item) {
  return it.exact ? path === it.href : path === it.href || path.startsWith(it.href + "/");
}

export function Sidebar({ roles, name, unread }: { roles: Role[]; name: string; unread: number }) {
  const path = usePathname();
  const { main, manage } = navFor(roles);
  const top = (["admin", "petugas", "dosen", "mahasiswa"] as Role[]).find((r) => roles.includes(r))!;
  const link = (it: Item) => {
    const Icon = I[it.icon];
    const on = active(path, it);
    return (
      <li key={it.href}>
        <Link href={it.href} aria-current={on ? "page" : undefined} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] font-medium transition-colors ${on ? "bg-white/16 text-white" : "text-white/80 hover:bg-white/10 hover:text-white"}`}>
          <Icon size={18} aria-hidden="true" />
          <span className="flex-1">{it.label}</span>
          {it.icon === "notif" && unread > 0 ? <span className="rounded-full bg-accent px-1.5 text-[11px] font-bold text-[#2b1a00]" aria-label={`${unread} belum dibaca`}>{unread > 99 ? "99+" : unread}</span> : null}
        </Link>
      </li>
    );
  };
  return (
    <aside className="sticky top-0 hidden h-dvh w-[252px] shrink-0 flex-col bg-brand-dark px-3.5 py-5 text-white lg:flex">
      <Link href="/" className="mb-6 flex items-center gap-2.5 px-2" aria-label="PasundanEdu, ke beranda">
        <Emblem size={38} />
        <span className="leading-tight"><span className="block text-[16px] font-bold">PasundanEdu</span><span className="block text-[11.5px] text-white/70">STIE Pasundan Bandung</span></span>
      </Link>
      <nav aria-label="Menu utama" className="min-h-0 flex-1 overflow-y-auto">
        <ul className="space-y-0.5">{main.map(link)}</ul>
        {manage.length ? (
          <>
            <p className="mb-1.5 mt-6 px-3 text-[12px] font-semibold text-white/60">Kelola sistem</p>
            <ul className="space-y-0.5">{manage.map(link)}</ul>
          </>
        ) : null}
      </nav>
      <div className="mt-4 border-t border-white/15 pt-4">
        <div className="mb-2 px-2">
          <p className="truncate text-[13.5px] font-semibold">{name}</p>
          <p className="text-[12px] text-white/65">{ROLE_LABEL[top]}</p>
        </div>
        <LogoutButton className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] font-medium text-white/80 hover:bg-white/10 hover:text-white" />
      </div>
    </aside>
  );
}

export function BottomNav({ roles }: { roles: Role[] }) {
  const path = usePathname();
  const { tabs } = navFor(roles);
  return (
    <nav aria-label="Menu utama" className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-card pb-[env(safe-area-inset-bottom)] lg:hidden">
      <ul className="mx-auto grid max-w-xl grid-cols-5">
        {tabs.map((it) => {
          const Icon = I[it.icon];
          const on = active(path, it);
          return (
            <li key={it.href}>
              <Link href={it.href} aria-current={on ? "page" : undefined} className={`flex min-h-[58px] flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${on ? "text-brand-text" : "text-muted"}`}>
                <span className={`grid h-7 w-12 place-items-center rounded-full ${on ? "bg-chip" : ""}`}><Icon size={20} aria-hidden="true" /></span>
                {it.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export function LogoutButton({ className = "btn btn-line" }: { className?: string }) {
  const [busy, setBusy] = useState(false);
  return (
    <button
      type="button" className={className} disabled={busy}
      onClick={async () => {
        setBusy(true);
        try { await api("/api/auth/logout", { method: "POST" }); } catch { /* sesi mungkin sudah berakhir */ }
        // Navigasi penuh agar cache halaman berautentikasi di router klien ikut dibuang.
        window.location.assign("/masuk");
      }}
    >
      <LogOut size={18} aria-hidden="true" />
      {busy ? "Keluar…" : "Keluar"}
    </button>
  );
}
