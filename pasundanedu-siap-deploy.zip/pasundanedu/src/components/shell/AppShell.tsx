import Link from "next/link";
import type { ReactNode } from "react";
import { Bell } from "@/components/icons";
import { Emblem } from "@/components/logo";
import { Sidebar, BottomNav } from "@/components/shell/NavClient";
import { unreadCount } from "@/server/domain/notifications";
import type { SessionUser } from "@/server/auth/types";

/** Kerangka halaman setelah masuk: sidebar (desktop), bilah atas, dan navigasi bawah 5 tab (mobile). */
export async function AppShell({ user, children }: { user: SessionUser; children: ReactNode }) {
  const unread = await unreadCount(user.id);
  const first = user.fullName.split(" ")[0] ?? user.fullName;
  return (
    <div className="min-h-dvh lg:flex">
      <Sidebar roles={user.roles} name={user.fullName} unread={unread} />
      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 bg-brand px-4 text-white lg:h-16 lg:justify-end lg:bg-page lg:px-8 lg:text-ink">
          <Link href="/" className="flex items-center gap-2.5 lg:hidden" aria-label="PasundanEdu, ke beranda">
            <Emblem size={32} />
            <span className="text-[16px] font-bold">PasundanEdu</span>
          </Link>
          <span className="flex-1 lg:hidden" />
          <span className="hidden text-[13px] text-muted lg:block">Halo, <span className="font-semibold text-ink">{first}</span></span>
          <Link
            href="/notifikasi" aria-label={unread ? `Notifikasi, ${unread} belum dibaca` : "Notifikasi"}
            className="relative grid size-10 place-items-center rounded-full hover:bg-white/15 lg:border lg:border-line lg:bg-card lg:hover:bg-chip"
          >
            <Bell size={20} aria-hidden="true" />
            {unread > 0 ? (
              <span className="absolute -right-0.5 -top-0.5 grid min-w-[18px] place-items-center rounded-full bg-accent px-1 text-[10.5px] font-bold leading-[18px] text-[#2b1a00]">{unread > 99 ? "99+" : unread}</span>
            ) : null}
          </Link>
        </header>

        <main id="isi" className="mx-auto w-full max-w-[1080px] px-4 pb-28 pt-5 lg:px-8 lg:pb-12 lg:pt-4">
          {!user.emailVerified ? (
            <div className="alert alert-warn mb-4 flex flex-wrap items-center justify-between gap-2" role="status">
              <span>Email Anda belum diverifikasi. Beberapa layanan memerlukan email terverifikasi.</span>
              <Link href="/akun#verifikasi" className="font-semibold underline">Kirim ulang tautan</Link>
            </div>
          ) : null}
          {children}
        </main>
      </div>
      <BottomNav roles={user.roles} />
    </div>
  );
}
