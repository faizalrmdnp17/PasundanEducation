import {
  Bell, BookOpen, Bookmark, Briefcase, CalendarDays, Check, CheckCheck, ChevronRight, CircleHelp, Clock, Download, FileText, FlaskConical,
  GraduationCap, History, Home, Inbox, Library, LayoutDashboard, LogIn, LogOut, Megaphone, MessageCircle, Microscope, Palette, PenLine, Plug,
  ExternalLink, ScanSearch, ScrollText, Search, Settings, ShieldCheck, Star, Upload, User, Users, Wallet, X, AlertTriangle, Info, Mail, Smartphone, Lock,
  type LucideIcon,
} from "lucide-react";

/** Peta nama ikon (disimpan di database) → komponen. Nama tidak dikenal memakai FileText. */
export const ICONS: Record<string, LucideIcon> = {
  "graduation-cap": GraduationCap, "pen-line": PenLine, "flask-conical": FlaskConical, "file-text": FileText, library: Library,
  microscope: Microscope, "search-check": ScanSearch, users: Users, palette: Palette, briefcase: Briefcase, "book-open": BookOpen,
};

export function ServiceIcon({ name, size = 20 }: { name?: string | null; size?: number }) {
  const I = (name && ICONS[name]) || FileText;
  return <I size={size} aria-hidden="true" />;
}

export {
  Bell, BookOpen, Bookmark, Briefcase, CalendarDays, Check, CheckCheck, ChevronRight, CircleHelp, Clock, Download, FileText, GraduationCap,
  History, Home, Inbox, Library, LayoutDashboard, LogIn, LogOut, Megaphone, MessageCircle, Plug, ScrollText, Search, Settings, ShieldCheck,
  Star, Upload, User, Users, Wallet, X, AlertTriangle, Info, Mail, Smartphone, Lock, ExternalLink,
};
