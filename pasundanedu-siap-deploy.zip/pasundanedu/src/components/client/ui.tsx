"use client";
import type { ReactNode } from "react";

/** Label + kontrol + galat kolom. Label membungkus kontrol sehingga terhubung otomatis (aksesibel). */
export function Field({ label, error, hint, children, className = "" }: { label: string; error?: string; hint?: string; children: ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="label">{label}</span>
      {children}
      {hint && !error ? <span className="hint block">{hint}</span> : null}
      {error ? <span role="alert" className="err block">{error}</span> : null}
    </label>
  );
}

export function FormError({ message }: { message: string | null }) {
  if (!message) return null;
  return <div role="alert" className="alert alert-bad">{message}</div>;
}

export function Spinner() {
  return <span aria-hidden="true" className="inline-block size-4 animate-spin rounded-full border-2 border-current border-r-transparent" />;
}

export function SubmitButton({ busy, children, className = "btn", ...rest }: { busy: boolean; children: ReactNode; className?: string } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button type="submit" className={className} disabled={busy || rest.disabled} {...rest}>
      {busy ? <Spinner /> : null}
      {children}
    </button>
  );
}

export function Check({ label, checked, onChange, hint, name }: { label: ReactNode; checked: boolean; onChange: (v: boolean) => void; hint?: string; name?: string }) {
  return (
    <label className="flex items-start gap-2.5 text-[13px]">
      <input type="checkbox" name={name} checked={checked} onChange={(e) => onChange(e.target.checked)} className="mt-0.5 size-[18px] shrink-0 accent-[var(--g)]" />
      <span>
        {label}
        {hint ? <span className="hint block">{hint}</span> : null}
      </span>
    </label>
  );
}
