"use client";
import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/client";

type Toast = { id: number; kind: "ok" | "bad"; text: string };
const Ctx = createContext<{ push: (kind: Toast["kind"], text: string) => void }>({ push: () => {} });

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const n = useRef(0);
  const push = useCallback((kind: Toast["kind"], text: string) => {
    const id = ++n.current;
    setItems((s) => [...s.slice(-2), { id, kind, text }]);
    setTimeout(() => setItems((s) => s.filter((t) => t.id !== id)), 4500);
  }, []);
  return (
    <Ctx.Provider value={{ push }}>
      {children}
      <div aria-live="polite" role="status" className="pointer-events-none fixed inset-x-3 bottom-[76px] z-50 flex flex-col items-center gap-2 lg:bottom-6 lg:items-end lg:right-6 lg:left-auto">
        {items.map((t) => (
          <div key={t.id} className={`pointer-events-auto max-w-sm rounded-xl px-3.5 py-2.5 text-[13px] font-medium shadow-lg ${t.kind === "ok" ? "bg-[#17302c] text-white" : "bg-[#a3231b] text-white"}`}>
            {t.text}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export const useToast = () => useContext(Ctx);

/** Pola umum submit: status sibuk, pesan galat, galat per kolom, toast sukses, dan refresh data server. */
export function useSubmit() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});
  const router = useRouter();
  const { push } = useToast();

  async function run<T>(fn: () => Promise<T>, o: { success?: string; onDone?: (r: T) => void; refresh?: boolean; toastError?: boolean } = {}): Promise<T | undefined> {
    if (busy) return;
    setBusy(true);
    setError(null);
    setFields({});
    try {
      const r = await fn();
      if (o.success) push("ok", o.success);
      o.onDone?.(r);
      if (o.refresh !== false) router.refresh();
      return r;
    } catch (e) {
      if (e instanceof ApiError) {
        setError(e.message);
        setFields(e.fields ?? {});
        // Galat tampil inline lewat <FormError>; toast hanya bila pemanggil tidak punya tempat inline.
        if (o.toastError) push("bad", e.message);
      } else {
        setError("Terjadi kesalahan tak terduga.");
        if (o.toastError) push("bad", "Terjadi kesalahan tak terduga.");
      }
    } finally {
      setBusy(false);
    }
  }
  return { busy, error, fields, run, setError };
}

export { api };
