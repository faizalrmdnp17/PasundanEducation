import { env } from "./env";
import type { Queryable } from "./db";
import type { JobVars } from "./integrations/templates";

export type NotifyInput = {
  userId: string;
  type: string;
  title: string;
  body?: string;
  link?: string; // path relatif, mis. /riwayat/xxx
  /** Bila diisi, pesan juga diantrekan ke email/WhatsApp sesuai preferensi & persetujuan. */
  template?: "request_new_staff" | "request_status_student" | "appointment_reminder" | "payment_update";
  vars?: JobVars;
  dedupe?: string;
};

type Recipient = {
  email: string; full_name: string; email_verified_at: Date | null; whatsapp_number: string | null;
  whatsapp_verified_at: Date | null; account_type: string; email_enabled: boolean; whatsapp_enabled: boolean;
  reminders_enabled: boolean; wa_consent: boolean | null; status: string;
};

/**
 * Membuat notifikasi dalam aplikasi dan (opsional) mengantrekan pesan email/WhatsApp.
 * WhatsApp hanya diantrekan bila: preferensi aktif + persetujuan terbaru "granted" + nomor tersedia
 * (untuk dosen/petugas nomor juga harus sudah diverifikasi pengelola).
 */
export async function notify(q: Queryable, n: NotifyInput): Promise<void> {
  await q.query(
    `insert into notifications (user_id, type, title, body, link) values ($1,$2,$3,$4,$5)`,
    [n.userId, n.type, n.title, n.body ?? null, n.link ?? null],
  );
  if (!n.template) return;

  const { rows } = await q.query<Recipient>(
    `select p.email, p.full_name, p.email_verified_at, p.whatsapp_number, p.whatsapp_verified_at, p.account_type, p.status,
            coalesce(np.email_enabled, true) as email_enabled,
            coalesce(np.whatsapp_enabled, false) as whatsapp_enabled,
            coalesce(np.reminders_enabled, true) as reminders_enabled,
            (select granted from consents c where c.user_id = p.id and c.consent_type = 'whatsapp' order by c.created_at desc limit 1) as wa_consent
     from profiles p left join notification_preferences np on np.user_id = p.id where p.id = $1`,
    [n.userId],
  );
  const r = rows[0];
  if (!r || r.status === "deleted" || r.status === "suspended") return;
  if (n.template === "appointment_reminder" && !r.reminders_enabled) return;

  const vars: JobVars = {
    nama_penerima: r.full_name,
    link: n.link ? `${env.appUrl}${n.link}` : env.appUrl,
    ...(n.vars ?? {}),
  };
  const enqueue = async (channel: "email" | "whatsapp") => {
    await q.query(
      `insert into notification_jobs (user_id, channel, template, payload, dedupe_key) values ($1,$2,$3,$4::jsonb,$5)
       on conflict (dedupe_key) do nothing`,
      [n.userId, channel, n.template, JSON.stringify(vars), n.dedupe ? `${n.dedupe}:${channel}` : null],
    );
  };

  if (r.email_enabled && r.email_verified_at) await enqueue("email");

  const isStaffAccount = r.account_type !== "mahasiswa";
  const numberOk = !!r.whatsapp_number && (!isStaffAccount || !!r.whatsapp_verified_at);
  if (r.whatsapp_enabled && r.wa_consent === true && numberOk && n.template !== "payment_update") await enqueue("whatsapp");

  scheduleJobKick();
}

let kickTimer: ReturnType<typeof setTimeout> | null = null;
/**
 * Memicu pemrosesan antrean tak lama setelah transaksi selesai (best effort, untuk server Node yang berjalan terus).
 * Pada lingkungan serverless, jadwalkan /api/cron/process-jobs atau jalankan `npm run worker`.
 */
export function scheduleJobKick() {
  if (env.isTest || process.env.INLINE_WORKER === "false" || kickTimer) return;
  kickTimer = setTimeout(async () => {
    kickTimer = null;
    try {
      const { processDueJobs } = await import("./jobs");
      await processDueJobs({ limit: 20 });
    } catch (e) {
      console.error("[jobs] pemrosesan antrean gagal:", (e as Error).message);
    }
  }, 1500);
  kickTimer.unref?.();
}
