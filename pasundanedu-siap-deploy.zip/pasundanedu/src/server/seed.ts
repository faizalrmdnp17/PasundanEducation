import type { Db, Queryable } from "./db";
import { hashPassword } from "./auth/password";

/**
 * Seed katalog: aman untuk produksi dan idempoten (bisa dijalankan berulang).
 * Mengikuti struktur layanan pada prototipe HTML PasundanEdu.
 *
 * Catatan harga: tarif di bawah adalah USULAN AWAL. Penagihan baru berlaku setelah pengelola
 * mengaktifkan pembayaran (pengaturan `payments_enabled`).
 */

const CATEGORIES = [
  { code: "akademik", name: "Akademik", icon: "graduation-cap", sort: 1 },
  { code: "pustaka", name: "Pustaka", icon: "book-open", sort: 2 },
  { code: "kreatif", name: "Kreatif", icon: "palette", sort: 3 },
  { code: "karier", name: "Karier", icon: "briefcase", sort: 4 },
];

type SvcSeed = {
  slug: string; cat: string; name: string; desc: string; icon: string; price: number; minutes?: number;
  req: string[]; est: string; appt: boolean; docs: boolean; cap?: number; cancel?: string;
};

const SERVICES: SvcSeed[] = [
  { slug: "konsultasi-dosen-wali", cat: "akademik", name: "Konsultasi Dosen Wali", icon: "graduation-cap", price: 0, minutes: 30,
    desc: "Jadwalkan sesi bimbingan studi daring atau tatap muka dengan dosen wali.",
    req: ["Mahasiswa aktif", "Topik konsultasi singkat"], est: "Dikonfirmasi maksimal 2 hari kerja", appt: true, docs: false },
  { slug: "bimbingan-skripsi", cat: "akademik", name: "Bimbingan Skripsi", icon: "pen-line", price: 50000, minutes: 60,
    desc: "Pendampingan judul, metodologi, dan penulisan Bab I–V. Mahasiswa tetap penulis tunggal karyanya.",
    req: ["Mahasiswa aktif tingkat akhir", "Draf/naskah terakhir (PDF/DOCX)", "Pertanyaan atau bagian yang ingin dibahas"],
    est: "Dikonfirmasi maksimal 3 hari kerja", appt: true, docs: true },
  { slug: "konsultasi-metodologi", cat: "akademik", name: "Konsultasi Metodologi Penelitian", icon: "flask-conical", price: 0, minutes: 45,
    desc: "Diskusi desain penelitian, instrumen, populasi-sampel, dan teknik analisis data.",
    req: ["Ringkasan rencana penelitian"], est: "Dikonfirmasi maksimal 3 hari kerja", appt: true, docs: false },
  { slug: "surat-keterangan-mahasiswa", cat: "akademik", name: "Surat Keterangan Mahasiswa", icon: "file-text", price: 0,
    desc: "Ajukan surat keterangan aktif kuliah dan keperluan administrasi lainnya.",
    req: ["Mahasiswa aktif", "Keperluan surat", "Unggah KTM/KRS terbaru"], est: "1–3 hari kerja", appt: false, docs: true },
  { slug: "peminjaman-buku-referensi", cat: "pustaka", name: "Peminjaman Buku & Request Referensi", icon: "library", price: 0,
    desc: "Pinjam buku kampus atau minta pengadaan referensi baru.",
    req: ["Mahasiswa aktif", "Judul/penulis referensi"], est: "1–2 hari kerja", appt: false, docs: false },
  { slug: "akses-jurnal-ilmiah", cat: "pustaka", name: "Akses Jurnal Ilmiah", icon: "microscope", price: 0,
    desc: "Minta artikel jurnal teks lengkap yang aksesnya sah melalui langganan kampus.",
    req: ["Judul artikel / DOI"], est: "1–2 hari kerja", appt: false, docs: false },
  { slug: "cek-kemiripan-naskah", cat: "pustaka", name: "Cek Kemiripan Naskah", icon: "search-check", price: 25000,
    desc: "Periksa tingkat kemiripan naskah sebelum diajukan ke dosen. Hasil hanya indikator, bukan jaminan bebas plagiarisme.",
    req: ["Naskah (PDF/DOCX)", "Pernyataan naskah adalah karya sendiri"], est: "1–2 hari kerja", appt: false, docs: true },
  { slug: "kelas-tutor-sebaya", cat: "kreatif", name: "Kelas Tutor Sebaya", icon: "users", price: 20000, minutes: 90,
    desc: "Belajar bersama kakak tingkat: Akuntansi, Statistik, Manajemen.",
    req: ["Mata kuliah/topik yang ingin dipelajari"], est: "Dikonfirmasi maksimal 3 hari kerja", appt: true, docs: false, cap: 8,
    cancel: 'Dapat dibatalkan maksimal 24 jam sebelum jadwal.' },
  { slug: "workshop-konten-belajar", cat: "kreatif", name: "Workshop Konten Belajar Kreatif", icon: "palette", price: 35000, minutes: 120,
    desc: "Latihan membuat infografis, video singkat, dan podcast belajar.",
    req: ["Topik atau mata kuliah yang akan dijadikan konten"], est: "Dikonfirmasi maksimal 5 hari kerja", appt: true, docs: false, cap: 20 },
  { slug: "konsultasi-karier-magang", cat: "karier", name: "Konsultasi Karier & Magang", icon: "briefcase", price: 0, minutes: 45,
    desc: "Tinjau CV, simulasi wawancara, dan informasi lowongan magang.",
    req: ["CV terbaru (PDF/DOCX)", "Posisi/bidang yang dituju"], est: "Dikonfirmasi maksimal 3 hari kerja", appt: true, docs: true },
];

const RES_CATS = [
  { code: "buku", name: "Buku", sort: 1 },
  { code: "jurnal", name: "Jurnal", sort: 2 },
  { code: "konten", name: "Konten belajar", sort: 3 },
];

const WA_TEMPLATES = [
  { purpose: "request_new_staff", name: "pe_pengajuan_baru_staf", variables: ["nama_penerima", "nomor_pengajuan", "layanan", "jadwal"],
    body: "Halo, Bapak/Ibu {{1}}. Terdapat pengajuan konsultasi baru di PasundanEdu.\n\nNomor pengajuan: {{2}}\nLayanan: {{3}}\nJadwal yang diajukan: {{4}}\n\nSilakan buka dashboard PasundanEdu untuk melihat detail dan memproses pengajuan." },
  { purpose: "request_status_student", name: "pe_status_pengajuan", variables: ["nama_penerima", "nomor_pengajuan", "status"],
    body: "Halo, {{1}}. Status pengajuan {{2}} di PasundanEdu kini: {{3}}. Buka aplikasi PasundanEdu untuk detailnya." },
  { purpose: "appointment_reminder", name: "pe_pengingat_jadwal", variables: ["nama_penerima", "layanan", "jadwal"],
    body: "Halo, {{1}}. Pengingat jadwal {{2}} Anda: {{3}}. Buka PasundanEdu untuk detail dan tautan pertemuan." },
];

const INTEGRATIONS = [
  { code: "google-classroom", name: "Google Classroom", kind: "google_classroom", type: "link", auth: "none", status: "link_only",
    instructions: "Tautan eksternal. Isi URL kelas lalu aktifkan. Ini hanya tautan, bukan integrasi API." },
  { code: "moodle", name: "Moodle LMS", kind: "moodle", type: "api", auth: "api_token", status: "not_connected",
    instructions: "Adapter Moodle Web Services tersedia, tetapi belum terhubung: butuh URL situs Moodle dan token layanan web (MOODLE_WS_TOKEN) dari pengelola LMS." },
  { code: "google-meet", name: "Google Meet", kind: "google_meet", type: "link", auth: "none", status: "link_only",
    instructions: "Tautan rapat dicantumkan pada slot konsultasi dosen. Hanya tautan, bukan integrasi API." },
  { code: "repositori-jurnal", name: "Repositori Jurnal & Perpustakaan Digital", kind: "journal_repository", type: "link", auth: "none", status: "link_only",
    instructions: "Tautan ke repositori yang aksesnya sah. Hormati lisensi masing-masing penyedia." },
  { code: "lti13", name: "LTI 1.3", kind: "lti13", type: "lti", auth: "lti13", status: "not_connected",
    instructions: "Belum diimplementasikan. Dicadangkan untuk platform LMS yang mendukung LTI 1.3 setelah akses disetujui." },
];

export async function seedCatalog(q: Queryable) {
  for (const c of CATEGORIES) {
    await q.query(
      `insert into service_categories (code, name, icon, sort_order) values ($1,$2,$3,$4)
       on conflict (code) do update set name = excluded.name, icon = excluded.icon, sort_order = excluded.sort_order`,
      [c.code, c.name, c.icon, c.sort],
    );
  }
  for (const s of SERVICES) {
    // Tidak menimpa perubahan harga/teks yang sudah dibuat pengelola: hanya menyisipkan bila belum ada.
    await q.query(
      `insert into services (category_id, slug, name, description, icon, price_idr, duration_minutes, requirements,
                             estimated_process, capacity, requires_appointment, requires_documents, cancellation_policy)
       select c.id, $2, $3, $4, $5, $6, $7, $8::jsonb, $9, $10, $11, $12, coalesce($13, 'Pengajuan dapat dibatalkan selama belum berstatus "Sedang diproses".')
       from service_categories c where c.code = $1
       on conflict (slug) do nothing`,
      [s.cat, s.slug, s.name, s.desc, s.icon, s.price, s.minutes ?? null, JSON.stringify(s.req), s.est, s.cap ?? null, s.appt, s.docs, s.cancel ?? null],
    );
  }
  for (const c of RES_CATS) {
    await q.query(
      `insert into resource_categories (code, name, sort_order) values ($1,$2,$3)
       on conflict (code) do update set name = excluded.name, sort_order = excluded.sort_order`,
      [c.code, c.name, c.sort],
    );
  }
  for (const t of WA_TEMPLATES) {
    await q.query(
      `insert into whatsapp_templates (name, purpose, language, body_preview, variables, status, is_active)
       values ($1,$2,'id',$3,$4::jsonb,'draft',false) on conflict (purpose) do nothing`,
      [t.name, t.purpose, t.body, JSON.stringify(t.variables)],
    );
  }
  for (const i of INTEGRATIONS) {
    await q.query(
      `insert into external_integrations (code, name, kind, connection_type, auth_method, status, is_active, instructions)
       values ($1,$2,$3,$4,$5,$6,false,$7) on conflict (code) do nothing`,
      [i.code, i.name, i.kind, i.type, i.auth, i.status, i.instructions],
    );
  }
  // Pengaturan awal: pembayaran NONAKTIF sampai pengelola menyetujui.
  const settings: Array<[string, unknown]> = [
    ["payments_enabled", false],
    ["institution_name", "STIE Pasundan Bandung"],
    ["institution_verified", false],
    ["bank_account_info", ""],
  ];
  for (const [k, v] of settings) {
    await q.query(`insert into system_settings (key, value) values ($1,$2::jsonb) on conflict (key) do nothing`, [k, JSON.stringify(v)]);
  }
}

/* ------------------------------------------------------------------ */
/* Seed DEMO: hanya untuk pengembangan/uji. Seluruh data fiktif (@example.test). */
/* ------------------------------------------------------------------ */

export const DEMO_PASSWORD = "DemoPasundan2026";

export const DEMO_USERS = [
  { email: "admin@example.test", name: "Admin Demo", type: "admin", role: "admin" },
  { email: "petugas@example.test", name: "Petugas Demo", type: "petugas", role: "petugas", nidn: "PTG-0001", wa: "628111000001" },
  { email: "dosen@example.test", name: "Dr. Dosen Demo, M.M.", type: "dosen", role: "dosen", nidn: "0412345601", wa: "628111000002" },
  { email: "dosen2@example.test", name: "Dosen Kedua Demo, S.E., M.Ak.", type: "dosen", role: "dosen", nidn: "0412345602", wa: "628111000003" },
  { email: "mahasiswa@example.test", name: "Mahasiswa Demo", type: "mahasiswa", role: "mahasiswa", npm: "2025000001", prodi: "Manajemen", year: 2022 },
  { email: "mahasiswa2@example.test", name: "Mahasiswi Demo Dua", type: "mahasiswa", role: "mahasiswa", npm: "2025000002", prodi: "Akuntansi", year: 2023 },
] as const;

export async function seedDemo(db: Db) {
  const hash = await hashPassword(DEMO_PASSWORD);
  await db.tx(async (q) => {
    for (const u of DEMO_USERS) {
      const npm = "npm" in u ? u.npm : null;
      const nidn = "nidn" in u ? u.nidn : null;
      const wa = "wa" in u ? u.wa : null;
      const prodi = "prodi" in u ? u.prodi : null;
      const year = "year" in u ? u.year : null;
      const r = await q.query<{ id: string }>(
        `insert into profiles (email, full_name, account_type, npm, nidn, study_program, cohort_year, whatsapp_number, whatsapp_verified_at,
                               identity_verified_at, status, email_verified_at)
         values ($1,$2,$3,$4,$5,$6,$7,$8, case when $8::text is null then null else now() end, now(), 'active', now())
         on conflict (lower(email)) do update set full_name = excluded.full_name returning id`,
        [u.email, u.name, u.type, npm, nidn, prodi, year, wa],
      );
      const id = r.rows[0]!.id;
      await q.query(
        `insert into auth_credentials (user_id, password_hash) values ($1,$2) on conflict (user_id) do nothing`,
        [id, hash],
      );
      await q.query(`insert into user_roles (user_id, role_id) select $1, id from roles where code = $2 on conflict do nothing`, [id, u.role]);
      await q.query(`insert into notification_preferences (user_id) values ($1) on conflict do nothing`, [id]);
      await q.query(
        `insert into consents (user_id, consent_type, version, granted) select $1, t, '1.0', true from unnest(array['terms','privacy']) t
         where not exists (select 1 from consents where user_id = $1)`,
        [id],
      );
    }

    // Penugasan layanan: dosen untuk layanan konsultasi, petugas untuk layanan administrasi.
    const assign = async (email: string, slugs: string[]) => {
      await q.query(
        `insert into service_assignments (service_id, staff_id)
         select s.id, p.id from services s, profiles p where p.email = $1 and s.slug = any($2::text[]) on conflict do nothing`,
        [email, slugs],
      );
    };
    await assign("dosen@example.test", ["konsultasi-dosen-wali", "bimbingan-skripsi", "konsultasi-metodologi", "konsultasi-karier-magang"]);
    await assign("dosen2@example.test", ["bimbingan-skripsi", "konsultasi-metodologi", "kelas-tutor-sebaya", "workshop-konten-belajar"]);
    await assign("petugas@example.test", ["surat-keterangan-mahasiswa", "peminjaman-buku-referensi", "akses-jurnal-ilmiah", "cek-kemiripan-naskah"]);

    // Slot ketersediaan 14 hari ke depan (Senin–Jumat 09:00 / 13:00, WIB).
    const day = 86400_000;
    const base = new Date();
    for (let i = 1; i <= 14; i++) {
      const d = new Date(base.getTime() + i * day);
      const key = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta", year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
      const wd = new Date(`${key}T12:00:00+07:00`).getUTCDay();
      if (wd === 0 || wd === 6) continue;
      for (const [email, hours] of [["dosen@example.test", ["09:00", "13:00"]], ["dosen2@example.test", ["10:00", "14:00"]]] as const) {
        for (const h of hours) {
          const start = new Date(`${key}T${h}:00+07:00`);
          const end = new Date(start.getTime() + 60 * 60_000);
          await q.query(
            `insert into availability_slots (staff_id, starts_at, ends_at, mode, location)
             select id, $2, $3, 'online', 'Tautan rapat dikirim setelah dikonfirmasi' from profiles where email = $1
             on conflict (staff_id, starts_at) do nothing`,
            [email, start.toISOString(), end.toISOString()],
          );
        }
      }
    }

    // Sumber belajar & pengumuman contoh (fiktif/placeholder, ditandai jelas pada deskripsi).
    const rc = async (code: string) => (await q.query<{ id: string }>("select id from resource_categories where code=$1", [code])).rows[0]!.id;
    const [cBuku, cJurnal, cKonten] = [await rc("buku"), await rc("jurnal"), await rc("konten")];
    const res: Array<[string, string, string, string, number, string, string | null, string]> = [
      [cBuku, "book", "Pengantar Akuntansi", "Penulis Contoh", 2022, "borrow", null, "Contoh data pengembangan."],
      [cBuku, "ebook", "Manajemen Keuangan", "Penulis Contoh", 2021, "link", "https://example.com/ebook/manajemen-keuangan", "Contoh data pengembangan."],
      [cBuku, "ebook", "Metodologi Penelitian Bisnis", "Penulis Contoh", 2020, "link", "https://example.com/ebook/metodologi", "Contoh data pengembangan."],
      [cBuku, "book", "Perilaku Organisasi", "Penulis Contoh", 2019, "borrow", null, "Contoh data pengembangan."],
      [cJurnal, "journal", "Jurnal Manajemen dan Bisnis", "Redaksi Contoh", 2025, "link", "https://example.com/jurnal/manajemen-bisnis", "Contoh data pengembangan."],
      [cJurnal, "journal", "Jurnal Akuntansi dan Keuangan", "Redaksi Contoh", 2025, "link", "https://example.com/jurnal/akuntansi-keuangan", "Contoh data pengembangan."],
      [cKonten, "infographic", "Infografis: Memahami Laporan Keuangan", "Tim Konten Contoh", 2026, "link", "https://example.com/konten/laporan-keuangan", "Contoh data pengembangan."],
      [cKonten, "video", "Video: Menyusun Kerangka Skripsi", "Tim Konten Contoh", 2026, "link", "https://example.com/konten/kerangka-skripsi", "Contoh data pengembangan."],
      [cKonten, "podcast", "Podcast: Kewirausahaan Anak Muda", "Tim Konten Contoh", 2026, "link", "https://example.com/konten/kewirausahaan", "Contoh data pengembangan."],
    ];
    for (const [cat, kind, title, authors, year, access, url, lic] of res) {
      await q.query(
        `insert into learning_resources (category_id, kind, title, authors, year, access_type, external_url, license_note, description)
         select $1,$2,$3,$4,$5,$6,$7,$8,'Entri contoh untuk pengembangan; ganti dengan koleksi sebenarnya melalui dashboard admin.'
         where not exists (select 1 from learning_resources where title = $3)`,
        [cat, kind, title, authors, year, access, url, lic],
      );
    }
    const ann: Array<[string, string, string]> = [
      ["Jadwal Ujian Tengah Semester Ganjil", "akademik", "Contoh pengumuman pengembangan."],
      ["Pendaftaran Beasiswa Prestasi Dibuka", "beasiswa", "Contoh pengumuman pengembangan."],
      ["Jam Layanan Perpustakaan Diperpanjang", "perpustakaan", "Contoh pengumuman pengembangan."],
      ["Seminar Kewirausahaan Digital", "seminar", "Contoh pengumuman pengembangan."],
    ];
    let n = 0;
    for (const [title, cat, body] of ann) {
      await q.query(
        `insert into announcements (title, body, category, event_date)
         select $1,$2,$3, (current_date + $4::int) where not exists (select 1 from announcements where title = $1)`,
        [title, body, cat, 3 + n * 5],
      );
      n++;
    }
  });
}

/** Membuat/memperbarui akun admin awal dari argumen (dipakai skrip admin:create dan seed produksi). */
export async function createAdmin(db: Db, email: string, password: string, name: string) {
  const hash = await hashPassword(password);
  await db.tx(async (q) => {
    const r = await q.query<{ id: string }>(
      `insert into profiles (email, full_name, account_type, status, email_verified_at, identity_verified_at)
       values ($1,$2,'admin','active', now(), now())
       on conflict (lower(email)) do update set account_type = 'admin', status = 'active' returning id`,
      [email.toLowerCase(), name],
    );
    const id = r.rows[0]!.id;
    await q.query(
      `insert into auth_credentials (user_id, password_hash) values ($1,$2)
       on conflict (user_id) do update set password_hash = excluded.password_hash, updated_at = now()`,
      [id, hash],
    );
    await q.query(`insert into user_roles (user_id, role_id) select $1, id from roles where code = 'admin' on conflict do nothing`, [id]);
    await q.query(`insert into notification_preferences (user_id) values ($1) on conflict do nothing`, [id]);
    await q.query(
      `insert into audit_logs (actor_id, action, entity_type, entity_id, meta) values (null, 'admin.bootstrap', 'profile', $1, $2::jsonb)`,
      [id, JSON.stringify({ email })],
    );
  });
}
