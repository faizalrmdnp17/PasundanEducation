import { query } from "./db";
import { tooMany } from "./errors";

type Opts = { limit: number; windowSec: number; blockSec?: number };

/** Apakah kunci sedang diblokir? (tanpa menambah hitungan) */
export async function assertNotBlocked(key: string): Promise<void> {
  const { rows } = await query<{ wait: number | null }>(
    `select ceil(extract(epoch from (blocked_until - now())))::int as wait from rate_limits where key = $1 and blocked_until > now()`,
    [key],
  );
  if (rows[0]?.wait) throw tooMany("Terlalu banyak percobaan. Coba lagi beberapa saat lagi.", rows[0].wait);
}

/** Menambah hitungan; bila melewati batas, kunci diblokir selama blockSec. Mengembalikan true bila terblokir. */
export async function registerHit(key: string, { limit, windowSec, blockSec }: Opts): Promise<boolean> {
  const { rows } = await query<{ count: number }>(
    `insert into rate_limits (key, count, window_start) values ($1, 1, now())
     on conflict (key) do update set
       count = case when rate_limits.window_start < now() - make_interval(secs => $2::double precision) then 1 else rate_limits.count + 1 end,
       window_start = case when rate_limits.window_start < now() - make_interval(secs => $2::double precision) then now() else rate_limits.window_start end,
       blocked_until = case when rate_limits.window_start < now() - make_interval(secs => $2::double precision) then null else rate_limits.blocked_until end
     returning count`,
    [key, windowSec],
  );
  const count = rows[0]!.count;
  if (count > limit) {
    await query(`update rate_limits set blocked_until = now() + make_interval(secs => $2::double precision) where key = $1`, [key, blockSec ?? windowSec]);
    return true;
  }
  return false;
}

export async function resetKey(key: string): Promise<void> {
  await query("delete from rate_limits where key = $1", [key]);
}

/** Pembatas umum: hitung lalu tolak bila melewati batas. */
export async function rateLimit(key: string, opts: Opts): Promise<void> {
  await assertNotBlocked(key);
  const blocked = await registerHit(key, opts);
  if (blocked) throw tooMany("Terlalu banyak permintaan. Coba lagi beberapa saat lagi.", opts.blockSec ?? opts.windowSec);
}

/** Bersihkan entri kedaluwarsa (dipanggil worker). */
export async function purgeRateLimits(): Promise<number> {
  const r = await query(`delete from rate_limits where window_start < now() - interval '1 day' and (blocked_until is null or blocked_until < now())`);
  return r.rowCount;
}
