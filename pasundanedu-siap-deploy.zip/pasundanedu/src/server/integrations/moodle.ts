import { env } from "../env";
import { query } from "../db";

/**
 * Adapter Moodle (Web Services REST). Saat ini hanya memverifikasi konektivitas dan kredensial
 * lewat core_webservice_get_site_info. Sinkronisasi mata kuliah/peserta BELUM diimplementasikan.
 * Token dibaca dari MOODLE_WS_TOKEN (server saja), dikirim lewat badan POST (tidak masuk URL/log).
 */
export type IntegrationCheck = { ok: boolean; status: "connected" | "not_connected" | "error" | "link_only"; message: string; details?: Record<string, string> };

/**
 * Pagar dasar untuk URL yang menerima token: di produksi wajib https dan bukan alamat jaringan internal.
 * Ini bukan pengganti firewall egress (nama domain yang diarahkan ke IP internal tidak terdeteksi di sini).
 */
export function unsafeApiUrl(raw: string): string | null {
  let u: URL;
  try { u = new URL(raw); } catch { return "URL dasar tidak valid."; }
  if (!env.isProd) return null;
  if (u.protocol !== "https:") return "Gunakan URL https:// agar token tidak dikirim tanpa enkripsi.";
  const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (h === "localhost" || h.endsWith(".local") || h.endsWith(".internal") || h === "::1" || /^(0|10|127)\./.test(h) || /^192\.168\./.test(h) || /^169\.254\./.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h))
    return "Alamat jaringan internal tidak diizinkan.";
  return null;
}

export async function checkMoodle(baseUrl: string | null, fetchImpl: typeof fetch = fetch): Promise<IntegrationCheck> {
  if (!baseUrl) return { ok: false, status: "not_connected", message: "URL dasar Moodle belum diisi." };
  if (!env.moodleToken) return { ok: false, status: "not_connected", message: "MOODLE_WS_TOKEN belum diatur di server." };
  const unsafe = unsafeApiUrl(baseUrl);
  if (unsafe) return { ok: false, status: "error", message: unsafe };
  const url = `${baseUrl.replace(/\/$/, "")}/webservice/rest/server.php`;
  try {
    const res = await fetchImpl(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ wstoken: env.moodleToken, wsfunction: "core_webservice_get_site_info", moodlewsrestformat: "json" }),
      signal: AbortSignal.timeout(10_000),
      redirect: "error",
    });
    if (!res.ok) return { ok: false, status: "error", message: `Moodle merespons HTTP ${res.status}.` };
    const json = (await res.json()) as { exception?: string; message?: string; sitename?: string; release?: string; username?: string };
    if (json.exception) return { ok: false, status: "error", message: `Moodle menolak permintaan: ${json.message ?? json.exception}` };
    return { ok: true, status: "connected", message: "Terhubung ke Moodle.", details: { sitename: json.sitename ?? "-", release: json.release ?? "-", user: json.username ?? "-" } };
  } catch (e) {
    return { ok: false, status: "error", message: `Gagal menghubungi Moodle: ${(e as Error).message}` };
  }
}

export async function checkIntegration(id: string, fetchImpl: typeof fetch = fetch): Promise<IntegrationCheck> {
  const i = (await query<{ id: string; kind: string; connection_type: string; base_url: string | null }>(
    "select id, kind, connection_type, base_url from external_integrations where id = $1", [id],
  )).rows[0];
  if (!i) return { ok: false, status: "error", message: "Integrasi tidak ditemukan." };
  let result: IntegrationCheck;
  if (i.connection_type === "link") {
    result = { ok: !!i.base_url, status: "link_only", message: i.base_url ? "Hanya tautan eksternal (bukan integrasi API)." : "URL belum diisi." };
  } else if (i.kind === "moodle") {
    result = await checkMoodle(i.base_url, fetchImpl);
  } else if (i.kind === "lti13") {
    result = { ok: false, status: "not_connected", message: "LTI 1.3 belum diimplementasikan." };
  } else {
    result = { ok: false, status: "not_connected", message: "Adapter untuk jenis integrasi ini belum tersedia." };
  }
  await query(
    `update external_integrations set status = $2, last_checked_at = now(), last_error = $3, updated_at = now() where id = $1`,
    [id, result.status, result.ok ? null : result.message],
  );
  await query(`insert into integration_events (integration_id, level, message, meta) values ($1,$2,$3,$4::jsonb)`, [
    id, result.ok ? "info" : "warn", result.message, JSON.stringify(result.details ?? {}),
  ]);
  return result;
}
