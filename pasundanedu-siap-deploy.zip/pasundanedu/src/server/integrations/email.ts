import { env } from "../env";

export type EmailMessage = { to: string; subject: string; text: string };
export type EmailResult = { provider: string; messageId: string | null; simulated: boolean };

type OutboxItem = EmailMessage & { at: string };
const g = globalThis as unknown as { __pe_outbox?: OutboxItem[] };

/** Kotak keluar khusus pengembangan (provider "log"). Tidak pernah dipakai pada produksi. */
export function getOutbox(): OutboxItem[] {
  return (g.__pe_outbox ??= []);
}
export function clearOutbox() {
  g.__pe_outbox = [];
}

export function emailConfigured(): boolean {
  return env.emailProvider === "smtp" ? !!env.smtpUrl : env.emailProvider === "log" && !env.isProd;
}

export function emailProviderLabel(): { name: string; connected: boolean; simulated: boolean } {
  if (env.emailProvider === "smtp") return { name: "SMTP", connected: !!env.smtpUrl, simulated: false };
  return { name: "Log pengembangan (tidak mengirim email sungguhan)", connected: false, simulated: true };
}

export async function sendEmail(msg: EmailMessage): Promise<EmailResult> {
  if (env.emailProvider === "smtp") {
    if (!env.smtpUrl) throw Object.assign(new Error("SMTP_URL belum diatur."), { permanent: true, notConfigured: true });
    const nodemailer = await import("nodemailer");
    const transport = nodemailer.createTransport(env.smtpUrl);
    const info = await transport.sendMail({ from: env.emailFrom, to: msg.to, subject: msg.subject, text: msg.text });
    return { provider: "smtp", messageId: info.messageId ?? null, simulated: false };
  }
  // Provider "log": tidak ada email yang benar-benar dikirim.
  if (env.isProd) throw Object.assign(new Error("EMAIL_PROVIDER=log tidak boleh dipakai pada produksi."), { permanent: true, notConfigured: true });
  const box = getOutbox();
  box.push({ ...msg, at: new Date().toISOString() });
  if (box.length > 100) box.shift();
  if (!env.isTest) console.log(`[email:simulasi] kepada=${msg.to} subjek="${msg.subject}"\n${msg.text}\n`);
  return { provider: "log", messageId: null, simulated: true };
}
