import { createHmac, timingSafeEqual } from "node:crypto";
import { env } from "../env";
import { query, tx } from "../db";
import type { Queryable } from "../db";

/**
 * Integrasi WhatsApp Business Platform (Cloud API).
 * - Pengiriman otomatis hanya memakai template yang disetujui Meta; kredensial hanya di sisi server.
 * - Tombol wa.me (lib/phone.ts) hanya membuka percakapan dan tidak menjamin pesan terkirim.
 */

export class WhatsappError extends Error {
  constructor(message: string, public status: number | null, public retryable: boolean, public notConfigured = false) {
    super(message);
  }
}

export function whatsappConfigured(): boolean {
  return !!(env.whatsappToken && env.whatsappPhoneNumberId);
}

export type WhatsappConfigStatus = {
  configured: boolean;
  provider: string;
  phoneNumberIdSet: boolean;
  tokenSet: boolean;
  businessAccountIdSet: boolean;
  businessNumber: string;
  verifyTokenSet: boolean;
  appSecretSet: boolean;
  webhookUrl: string;
};

/** Status konfigurasi untuk halaman admin. Tidak pernah mengembalikan nilai rahasia. */
export function whatsappConfigStatus(): WhatsappConfigStatus {
  return {
    configured: whatsappConfigured(),
    provider: env.whatsappProvider,
    phoneNumberIdSet: !!env.whatsappPhoneNumberId,
    tokenSet: !!env.whatsappToken,
    businessAccountIdSet: !!env.whatsappBusinessAccountId,
    businessNumber: env.whatsappBusinessNumber,
    verifyTokenSet: !!env.whatsappVerifyToken,
    appSecretSet: !!env.whatsappAppSecret,
    webhookUrl: `${env.appUrl}/api/integrations/whatsapp/webhook`,
  };
}

/** Teks parameter template tidak boleh berisi baris baru/tab atau spasi berderet. */
export function sanitizeParam(v: string): string {
  return String(v ?? "").replace(/[\r\n\t]+/g, " ").replace(/ {2,}/g, " ").trim().slice(0, 500) || "-";
}

export type SendTemplateInput = {
  to: string; // format internasional tanpa simbol
  templateName: string;
  language: string;
  params: string[];
};

export async function sendWhatsappTemplate(
  input: SendTemplateInput,
  fetchImpl: typeof fetch = fetch,
): Promise<{ messageId: string }> {
  if (!whatsappConfigured()) throw new WhatsappError("WhatsApp belum dikonfigurasi (token/ID nomor telepon belum diatur).", null, false, true);
  const url = `${env.whatsappApiBase}/${env.whatsappApiVersion}/${env.whatsappPhoneNumberId}/messages`;
  const body = {
    messaging_product: "whatsapp",
    to: input.to,
    type: "template",
    template: {
      name: input.templateName,
      language: { code: input.language },
      components: input.params.length
        ? [{ type: "body", parameters: input.params.map((p) => ({ type: "text", text: sanitizeParam(p) })) }]
        : [],
    },
  };
  let res: Response;
  try {
    res = await fetchImpl(url, {
      method: "POST",
      headers: { Authorization: `Bearer ${env.whatsappToken}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15_000),
    });
  } catch (e) {
    throw new WhatsappError(`Gagal menghubungi WhatsApp API: ${(e as Error).message}`, null, true);
  }
  const json = (await res.json().catch(() => ({}))) as { messages?: Array<{ id: string }>; error?: { message?: string; code?: number } };
  if (!res.ok) {
    const retryable = res.status === 429 || res.status >= 500;
    throw new WhatsappError(`WhatsApp API ${res.status}: ${json.error?.message ?? "galat tidak diketahui"}`, res.status, retryable);
  }
  const id = json.messages?.[0]?.id;
  if (!id) throw new WhatsappError("Respons WhatsApp API tidak memuat ID pesan.", res.status, true);
  return { messageId: id };
}

/** Verifikasi tanda tangan webhook Meta: header X-Hub-Signature-256 = "sha256=" + HMAC-SHA256(rawBody, appSecret). */
export function verifyWebhookSignature(rawBody: string, header: string | null, appSecret = env.whatsappAppSecret): boolean {
  if (!appSecret || !header || !header.startsWith("sha256=")) return false;
  const expected = createHmac("sha256", appSecret).update(rawBody, "utf8").digest();
  let given: Buffer;
  try {
    given = Buffer.from(header.slice(7), "hex");
  } catch {
    return false;
  }
  return given.length === expected.length && timingSafeEqual(given, expected);
}

/** Verifikasi langganan webhook (GET hub.challenge). Mengembalikan challenge bila token cocok. */
export function verifyWebhookChallenge(params: URLSearchParams): string | null {
  const mode = params.get("hub.mode");
  const token = params.get("hub.verify_token");
  const challenge = params.get("hub.challenge");
  if (mode !== "subscribe" || !challenge || !env.whatsappVerifyToken || !token) return null;
  const a = Buffer.from(token);
  const b = Buffer.from(env.whatsappVerifyToken);
  return a.length === b.length && timingSafeEqual(a, b) ? challenge : null;
}

type WaStatus = { id: string; status: string; timestamp?: string; recipient_id?: string; errors?: Array<{ title?: string; message?: string }> };
type WaMessage = { id: string; from: string; type?: string; text?: { body?: string } };
type WaPayload = { entry?: Array<{ changes?: Array<{ value?: { statuses?: WaStatus[]; messages?: WaMessage[] } }> }> };

const STATUS_MAP: Record<string, string> = { sent: "sent", delivered: "delivered", read: "read", failed: "failed" };
const STOP_WORDS = new Set(["stop", "berhenti", "unsubscribe", "batal notifikasi"]);

/**
 * Memproses payload webhook yang tanda tangannya SUDAH diverifikasi.
 * Deduplikasi lewat webhook_events(provider, event_id). Mengembalikan jumlah event yang diproses.
 */
export async function processWhatsappWebhook(
  payload: WaPayload,
  signatureValid: boolean,
): Promise<{ processed: number; duplicates: number }> {
  let processed = 0;
  let duplicates = 0;
  for (const entry of payload.entry ?? []) {
    for (const change of entry.changes ?? []) {
      const v = change.value ?? {};
      for (const s of v.statuses ?? []) {
        const eventId = `status:${s.id}:${s.status}`;
        const fresh = await recordEvent(eventId, "status", payload, signatureValid);
        if (!fresh) { duplicates++; continue; }
        const mapped = STATUS_MAP[s.status];
        if (mapped) {
          await query(
            `update integration_message_logs set status = $2, error = $3, updated_at = now()
             where provider_message_id = $1 and channel = 'whatsapp'
               and (case status when 'queued' then 0 when 'sent' then 1 when 'delivered' then 2 when 'read' then 3 else 4 end)
                 < (case $2::text when 'sent' then 1 when 'delivered' then 2 when 'read' then 3 else 4 end)`,
            [s.id, mapped, mapped === "failed" ? (s.errors?.[0]?.message ?? s.errors?.[0]?.title ?? "Gagal terkirim") : null],
          );
        }
        await markProcessed(eventId);
        processed++;
      }
      for (const m of v.messages ?? []) {
        const eventId = `message:${m.id}`;
        const fresh = await recordEvent(eventId, "message", payload, signatureValid);
        if (!fresh) { duplicates++; continue; }
        // Permintaan berhenti berlangganan dari penerima = pencabutan persetujuan notifikasi WhatsApp.
        const text = (m.text?.body ?? "").trim().toLowerCase();
        if (m.type === "text" && STOP_WORDS.has(text)) {
          // Di dalam transaksi hanya boleh memakai `q` (kueri di luar transaksi akan menunggu koneksi yang sama → deadlock).
          await tx(async (q) => {
            const users = await q.query<{ id: string }>("select id from profiles where whatsapp_number = $1", [m.from]);
            for (const u of users.rows) await optOutWhatsapp(q, u.id, "Penerima membalas pesan berhenti");
          });
        }
        await markProcessed(eventId);
        processed++;
      }
    }
  }
  return { processed, duplicates };
}

export async function optOutWhatsapp(q: Queryable, userId: string, reason: string) {
  await q.query(
    `insert into notification_preferences (user_id, whatsapp_enabled) values ($1,false)
     on conflict (user_id) do update set whatsapp_enabled = false, updated_at = now()`,
    [userId],
  );
  await q.query(`insert into consents (user_id, consent_type, version, granted) values ($1,'whatsapp','1.0',false)`, [userId]);
  await q.query(
    `insert into audit_logs (actor_id, action, entity_type, entity_id, meta) values (null,'consent.whatsapp.revoked','profile',$1,$2::jsonb)`,
    [userId, JSON.stringify({ reason })],
  );
}

async function recordEvent(eventId: string, type: string, payload: unknown, valid: boolean): Promise<boolean> {
  const r = await query(
    `insert into webhook_events (provider, event_id, event_type, signature_valid, payload) values ('whatsapp',$1,$2,$3,$4::jsonb)
     on conflict (provider, event_id) do nothing`,
    [eventId, type, valid, JSON.stringify(payload)],
  );
  return r.rowCount > 0;
}
async function markProcessed(eventId: string) {
  await query("update webhook_events set processed_at = now() where provider = 'whatsapp' and event_id = $1", [eventId]);
}
