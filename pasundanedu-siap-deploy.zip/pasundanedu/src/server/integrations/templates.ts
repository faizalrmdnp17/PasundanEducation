import { env } from "../env";

/** Template email (teks polos). Template WhatsApp didefinisikan di tabel whatsapp_templates (disetujui Meta). */

export type JobVars = Record<string, string>;

const footer = `\n\n—\nPasundanEdu · ${env.appUrl}\nEmail ini dikirim otomatis. Anda dapat mengatur preferensi notifikasi di menu Profil.`;

export const EMAIL_TEMPLATES: Record<string, (v: JobVars) => { subject: string; text: string }> = {
  request_new_staff: (v) => ({
    subject: `Pengajuan baru ${v.nomor_pengajuan} — ${v.layanan}`,
    text: `Halo, Bapak/Ibu ${v.nama_penerima}.\n\nTerdapat pengajuan baru di PasundanEdu.\n\nNomor pengajuan: ${v.nomor_pengajuan}\nLayanan: ${v.layanan}\nJadwal yang diajukan: ${v.jadwal}\n\nSilakan buka dashboard untuk melihat detail dan memproses pengajuan:\n${v.link}${footer}`,
  }),
  request_status_student: (v) => ({
    subject: `Status pengajuan ${v.nomor_pengajuan}: ${v.status}`,
    text: `Halo, ${v.nama_penerima}.\n\nStatus pengajuan ${v.nomor_pengajuan} (${v.layanan}) kini: ${v.status}.\n${v.catatan ? `Catatan: ${v.catatan}\n` : ""}\nLihat detailnya di:\n${v.link}${footer}`,
  }),
  appointment_reminder: (v) => ({
    subject: `Pengingat jadwal: ${v.layanan}`,
    text: `Halo, ${v.nama_penerima}.\n\nPengingat jadwal ${v.layanan} Anda:\n${v.jadwal}\n\nDetail: ${v.link}${footer}`,
  }),
  payment_update: (v) => ({
    subject: `Pembayaran ${v.nomor_pengajuan}: ${v.status}`,
    text: `Halo, ${v.nama_penerima}.\n\nStatus pembayaran untuk pengajuan ${v.nomor_pengajuan} kini: ${v.status}.\n\nDetail: ${v.link}${footer}`,
  }),
};

/** Urutan variabel template WhatsApp per tujuan. Harus sama dengan whatsapp_templates.variables. */
export const WA_VARIABLE_ORDER: Record<string, string[]> = {
  request_new_staff: ["nama_penerima", "nomor_pengajuan", "layanan", "jadwal"],
  request_status_student: ["nama_penerima", "nomor_pengajuan", "status"],
  appointment_reminder: ["nama_penerima", "layanan", "jadwal"],
};

export const verifyEmailMessage = (name: string, link: string) => ({
  subject: "Verifikasi email PasundanEdu",
  text: `Halo, ${name}.\n\nKlik tautan berikut untuk memverifikasi email Anda (berlaku 48 jam):\n${link}\n\nJika Anda tidak mendaftar di PasundanEdu, abaikan email ini.${footer}`,
});

export const resetPasswordMessage = (name: string, link: string) => ({
  subject: "Atur ulang kata sandi PasundanEdu",
  text: `Halo, ${name}.\n\nKami menerima permintaan untuk mengatur ulang kata sandi Anda. Klik tautan berikut (berlaku 1 jam, sekali pakai):\n${link}\n\nJika Anda tidak memintanya, abaikan email ini; kata sandi Anda tidak berubah.${footer}`,
});
