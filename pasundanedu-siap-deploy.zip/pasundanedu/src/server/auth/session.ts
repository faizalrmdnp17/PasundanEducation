import { cache } from "react";
import { env } from "../env";
import { one, query } from "../db";
import type { Role } from "@/lib/constants";
import type { SessionUser } from "./types";
import { randomToken, sha256 } from "./password";

const USER_SQL = `
  select p.id, p.email, p.full_name, p.account_type, p.status, p.email_verified_at, p.npm, p.nidn, p.study_program,
         p.cohort_year, p.phone, p.whatsapp_number, p.whatsapp_verified_at, p.identity_verified_at,
         s.id as session_id, s.last_seen_at,
         coalesce((select array_agg(r.code order by r.id) from user_roles ur join roles r on r.id = ur.role_id where ur.user_id = p.id), '{}') as roles
  from sessions s join profiles p on p.id = s.user_id`;

type UserRow = {
  id: string; email: string; full_name: string; account_type: Role; status: SessionUser["status"];
  email_verified_at: Date | null; npm: string | null; nidn: string | null; study_program: string | null;
  cohort_year: number | null; phone: string | null; whatsapp_number: string | null;
  whatsapp_verified_at: Date | null; identity_verified_at: Date | null; session_id: string; last_seen_at: Date; roles: Role[];
};

export function toSessionUser(r: UserRow): SessionUser {
  return {
    id: r.id,
    email: r.email,
    fullName: r.full_name,
    accountType: r.account_type,
    status: r.status,
    roles: r.roles,
    emailVerified: !!r.email_verified_at,
    npm: r.npm,
    nidn: r.nidn,
    studyProgram: r.study_program,
    cohortYear: r.cohort_year,
    phone: r.phone,
    whatsappNumber: r.whatsapp_number,
    whatsappVerified: !!r.whatsapp_verified_at,
    identityVerified: !!r.identity_verified_at,
    sessionId: r.session_id,
  };
}

/** Membuat sesi baru. Token mentah hanya dikirim ke klien; basis data menyimpan hash-nya. */
export async function createSession(userId: string, meta: { ip?: string | null; userAgent?: string | null }) {
  const token = randomToken(32);
  const expires = new Date(Date.now() + env.sessionDays * 86400_000);
  await query(
    `insert into sessions (user_id, token_hash, ip, user_agent, expires_at) values ($1,$2,$3,$4,$5)`,
    [userId, sha256(token), meta.ip ?? null, (meta.userAgent ?? "").slice(0, 300) || null, expires.toISOString()],
  );
  return { token, expires };
}

export async function userFromToken(token: string | undefined | null): Promise<SessionUser | null> {
  if (!token || token.length < 20 || token.length > 200) return null;
  const row = await one<UserRow>(
    `${USER_SQL} where s.token_hash = $1 and s.revoked_at is null and s.expires_at > now() and p.status <> 'deleted' and p.status <> 'suspended'`,
    [sha256(token)],
  );
  if (!row) return null;
  // Perbarui last_seen paling sering sekali per 10 menit.
  if (Date.now() - new Date(row.last_seen_at).getTime() > 10 * 60_000) {
    await query("update sessions set last_seen_at = now() where id = $1", [row.session_id]);
  }
  return toSessionUser(row);
}

export async function revokeSession(sessionId: string) {
  await query("update sessions set revoked_at = now() where id = $1 and revoked_at is null", [sessionId]);
}

export async function revokeAllSessions(userId: string, exceptSessionId?: string) {
  await query(
    "update sessions set revoked_at = now() where user_id = $1 and revoked_at is null and ($2::uuid is null or id <> $2::uuid)",
    [userId, exceptSessionId ?? null],
  );
}

/** Untuk Server Components: pengguna saat ini (di-cache per request). */
export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const { cookies } = await import("next/headers");
  const token = (await cookies()).get(env.sessionCookie)?.value;
  return userFromToken(token);
});

export function sessionCookieOptions(expires?: Date) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: env.cookieSecure,
    path: "/",
    ...(expires ? { expires } : {}),
  };
}
