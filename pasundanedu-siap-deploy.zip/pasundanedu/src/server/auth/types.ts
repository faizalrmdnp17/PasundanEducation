import type { Role } from "@/lib/constants";

export type SessionUser = {
  id: string;
  email: string;
  fullName: string;
  accountType: Role;
  status: "active" | "suspended" | "pending_approval" | "deleted";
  roles: Role[];
  emailVerified: boolean;
  npm: string | null;
  nidn: string | null;
  studyProgram: string | null;
  cohortYear: number | null;
  phone: string | null;
  whatsappNumber: string | null;
  whatsappVerified: boolean;
  identityVerified: boolean;
  sessionId: string;
};

/** Pelaku tindakan (subset SessionUser yang dibutuhkan service layer). */
export type Actor = Pick<SessionUser, "id" | "roles"> & Partial<Pick<SessionUser, "email" | "fullName" | "emailVerified">>;

export const ROLE_ORDER: Role[] = ["admin", "petugas", "dosen", "mahasiswa"];

export function primaryRole(roles: Role[]): Role | null {
  return ROLE_ORDER.find((r) => roles.includes(r)) ?? null;
}
export const hasRole = (u: Pick<Actor, "roles">, ...roles: Role[]) => roles.some((r) => u.roles.includes(r));
export const isStaff = (u: Pick<Actor, "roles">) => hasRole(u, "dosen", "petugas", "admin");
