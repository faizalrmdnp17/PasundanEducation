import { notFound, redirect } from "next/navigation";
import { getCurrentUser } from "./session";
import type { SessionUser } from "./types";
import { homeForRoles, type Role } from "@/lib/constants";

/**
 * Pelindung halaman (Server Component). Belum masuk → /masuk?next=…; akun menunggu persetujuan → halaman info;
 * peran tidak sesuai → 404 (tidak membocorkan keberadaan halaman admin).
 */
export async function requireUser(opts: { next?: string; roles?: Role[]; allowPending?: boolean } = {}): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) redirect(`/masuk${opts.next ? `?next=${encodeURIComponent(opts.next)}` : ""}`);
  if (user.status === "pending_approval" && !opts.allowPending) redirect("/menunggu-persetujuan");
  if (opts.roles && !opts.roles.some((r) => user.roles.includes(r))) notFound();
  return user;
}

/** Halaman beranda peran: tujuan setelah masuk bila tidak ada `next`. */
export function homeFor(user: Pick<SessionUser, "roles">): string {
  return homeForRoles(user.roles);
}

/** Hanya izinkan tujuan internal (hindari open redirect). */
export function safeNext(next: string | undefined | null): string | null {
  if (!next || !next.startsWith("/") || next.startsWith("//") || next.includes("\\")) return null;
  return next;
}
