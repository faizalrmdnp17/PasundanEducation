import { env } from "../env";
import { one, query, tx } from "../db";
import { AppError, conflict, forbidden, isUniqueViolation, unprocessable } from "../errors";
import { audit } from "../audit";
import { assertNotBlocked, rateLimit, registerHit, resetKey } from "../rate-limit";
import { hashPassword, randomToken, sha256, verifyPassword } from "./password";
import { createSession, revokeAllSessions } from "./session";
import { sendEmail } from "../integrations/email";
import { resetPasswordMessage, verifyEmailMessage } from "../integrations/templates";
import type { RegisterInput } from "@/lib/validation";
import type { SessionUser } from "./types";

type Meta = { ip?: string | null; userAgent?: string | null };

// Hash tetap untuk menyamakan waktu respons ketika email tidak ditemukan (mengurangi enumerasi akun lewat timing).
let dummyHash: Promise<string> | null = null;
const getDummyHash = () => (dummyHash ??= hashPassword("tidak-dipakai-" + randomToken(8)));

const VERIFY_TTL_H = 48;
const RESET_TTL_MIN = 60;

async function issueToken(userId: string, purpose: "verify_email" | "reset_password", ttlMs: number): Promise<string> {
  const token = randomToken(32);
  await query(
    `insert into email_tokens (user_id, purpose, token_hash, expires_at) values ($1,$2,$3,$4)`,
    [userId, purpose, sha256(token), new Date(Date.now() + ttlMs).toISOString()],
  );
  return token;
}

export async function sendVerificationEmail(user: { id: string; email: string; full_name: string }) {
  // Tandai token verifikasi lama sebagai terpakai agar hanya tautan terbaru yang berlaku.
  await query(`update email_tokens set used_at = now() where user_id = $1 and purpose = 'verify_email' and used_at is null`, [user.id]);
  const token = await issueToken(user.id, "verify_email", VERIFY_TTL_H * 3600_000);
  const link = `${env.appUrl}/verifikasi?token=${token}`;
  const msg = verifyEmailMessage(user.full_name, link);
  await sendEmail({ to: user.email, ...msg });
}

export async function register(input: RegisterInput, meta: Meta): Promise<{ user: SessionUser | null; sessionToken: string; sessionExpires: Date; status: "active" | "pending_approval"; emailSent: boolean }> {
  await rateLimit(`register:ip:${meta.ip ?? "unknown"}`, { limit: 10, windowSec: 3600 });
  const hash = await hashPassword(input.password);
  const isStudent = input.account_type === "mahasiswa";
  const status = isStudent ? "active" : "pending_approval";

  let userId: string;
  try {
    userId = await tx(async (q) => {
      const p = await q.query<{ id: string }>(
        `insert into profiles (email, full_name, account_type, npm, nidn, study_program, cohort_year, whatsapp_number, status)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9) returning id`,
        [input.email, input.full_name, input.account_type, input.npm ?? null, input.nidn ?? null, input.study_program ?? null,
         input.cohort_year ?? null, input.whatsapp_number ?? null, status],
      );
      const id = p.rows[0]!.id;
      await q.query(`insert into auth_credentials (user_id, password_hash) values ($1,$2)`, [id, hash]);
      if (isStudent) {
        // Peran mahasiswa diberikan otomatis. Peran dosen/petugas TIDAK pernah diberikan lewat registrasi.
        await q.query(`insert into user_roles (user_id, role_id) select $1, id from roles where code = 'mahasiswa'`, [id]);
      } else {
        await q.query(`insert into role_requests (user_id, requested_role, evidence_note) values ($1,$2,$3)`, [id, input.account_type, `NIDN/NIP: ${input.nidn}`]);
      }
      await q.query(
        `insert into notification_preferences (user_id, email_enabled, whatsapp_enabled) values ($1,$2,$3)`,
        [id, input.consent_email, input.consent_whatsapp && !!input.whatsapp_number],
      );
      const consent = (type: string, granted: boolean) =>
        q.query(`insert into consents (user_id, consent_type, version, granted, ip) values ($1,$2,'1.0',$3,$4)`, [id, type, granted, meta.ip ?? null]);
      await consent("terms", true);
      await consent("privacy", true);
      await consent("email", input.consent_email);
      await consent("whatsapp", input.consent_whatsapp && !!input.whatsapp_number);
      await audit(q, { actor: { id, roles: [] }, action: "auth.register", entityType: "profile", entityId: id, meta: { account_type: input.account_type }, ip: meta.ip });
      return id;
    });
  } catch (e) {
    if (isUniqueViolation(e)) {
      const hint = String((e as { constraint?: string; message?: string }).constraint ?? (e as Error).message);
      if (hint.includes("email")) throw conflict("Email sudah terdaftar. Silakan masuk atau atur ulang kata sandi.", "email_taken");
      if (hint.includes("npm")) throw unprocessable("NPM sudah terdaftar.", { npm: "NPM sudah terdaftar. Hubungi pengelola bila ini keliru." });
      if (hint.includes("nidn")) throw unprocessable("NIDN/NIP sudah terdaftar.", { nidn: "NIDN/NIP sudah terdaftar. Hubungi pengelola bila ini keliru." });
      throw conflict("Data sudah terdaftar.");
    }
    throw e;
  }

  // Kirim email verifikasi di luar transaksi; kegagalan kirim tidak membatalkan pendaftaran (ada tombol kirim ulang).
  let emailSent = true;
  try {
    await sendVerificationEmail({ id: userId, email: input.email, full_name: input.full_name });
  } catch (e) {
    emailSent = false;
    console.error("[auth] gagal mengirim email verifikasi:", (e as Error).message);
  }
  const session = await createSession(userId, meta);
  return { user: null, sessionToken: session.token, sessionExpires: session.expires, status, emailSent };
}

export async function login(email: string, password: string, meta: Meta) {
  const emailKey = `login:email:${email}`;
  const ipKey = `login:ip:${meta.ip ?? "unknown"}`;
  await assertNotBlocked(emailKey);
  await assertNotBlocked(ipKey);

  const row = await one<{ id: string; status: string; password_hash: string }>(
    `select p.id, p.status, c.password_hash from profiles p join auth_credentials c on c.user_id = p.id where lower(p.email) = $1`,
    [email],
  );
  const ok = await verifyPassword(password, row?.password_hash ?? (await getDummyHash()));
  if (!row || !ok) {
    await registerHit(emailKey, { limit: 5, windowSec: 900, blockSec: 900 });
    await registerHit(ipKey, { limit: 40, windowSec: 900, blockSec: 900 });
    await audit(null, { action: "auth.login_failed", entityType: "profile", entityId: row?.id, meta: { email }, ip: meta.ip });
    throw new AppError(401, "invalid_credentials", "Email atau kata sandi salah.");
  }
  if (row.status === "suspended" || row.status === "deleted") {
    await audit(null, { action: "auth.login_blocked", entityType: "profile", entityId: row.id, meta: { status: row.status }, ip: meta.ip });
    throw forbidden("Akun Anda dinonaktifkan. Hubungi pengelola PasundanEdu.");
  }
  await resetKey(emailKey);
  const session = await createSession(row.id, meta);
  await audit(null, { actor: { id: row.id, roles: [] }, action: "auth.login", entityType: "profile", entityId: row.id, ip: meta.ip });
  return { userId: row.id, sessionToken: session.token, sessionExpires: session.expires };
}

export async function verifyEmail(token: string): Promise<boolean> {
  return tx(async (q) => {
    const r = await q.query<{ id: string; user_id: string }>(
      `select id, user_id from email_tokens where token_hash = $1 and purpose = 'verify_email' and used_at is null and expires_at > now() for update`,
      [sha256(token)],
    );
    const t = r.rows[0];
    if (!t) return false;
    await q.query(`update email_tokens set used_at = now() where id = $1`, [t.id]);
    await q.query(`update profiles set email_verified_at = coalesce(email_verified_at, now()), updated_at = now() where id = $1`, [t.user_id]);
    await audit(q, { actor: { id: t.user_id, roles: [] }, action: "auth.email_verified", entityType: "profile", entityId: t.user_id });
    return true;
  });
}

export async function resendVerification(userId: string, meta: Meta) {
  await rateLimit(`verify-resend:${userId}`, { limit: 3, windowSec: 3600 });
  const u = await one<{ id: string; email: string; full_name: string; email_verified_at: Date | null }>(
    "select id, email, full_name, email_verified_at from profiles where id = $1", [userId],
  );
  if (!u) return;
  if (u.email_verified_at) return;
  try {
    await sendVerificationEmail(u);
  } catch (e) {
    console.error("[auth] gagal mengirim ulang email verifikasi:", (e as Error).message);
    throw new AppError(503, "email_unavailable", "Email belum dapat dikirim saat ini. Coba lagi nanti atau hubungi pengelola.");
  }
  await audit(null, { actor: { id: userId, roles: [] }, action: "auth.verification_resent", ip: meta.ip });
}

/** Selalu berhasil secara kasat mata agar tidak membocorkan apakah email terdaftar. */
export async function requestPasswordReset(email: string, meta: Meta): Promise<void> {
  await rateLimit(`reset:ip:${meta.ip ?? "unknown"}`, { limit: 10, windowSec: 3600 });
  await rateLimit(`reset:email:${email}`, { limit: 3, windowSec: 3600 });
  const u = await one<{ id: string; email: string; full_name: string; status: string }>(
    "select id, email, full_name, status from profiles where lower(email) = $1", [email],
  );
  if (!u || u.status === "deleted" || u.status === "suspended") return;
  const token = await issueToken(u.id, "reset_password", RESET_TTL_MIN * 60_000);
  const link = `${env.appUrl}/atur-ulang-sandi?token=${token}`;
  try {
    await sendEmail({ to: u.email, ...resetPasswordMessage(u.full_name, link) });
  } catch (e) {
    console.error("[auth] gagal mengirim email reset:", (e as Error).message);
  }
  await audit(null, { actor: { id: u.id, roles: [] }, action: "auth.reset_requested", ip: meta.ip });
}

export async function resetPassword(token: string, newPassword: string, meta: Meta): Promise<boolean> {
  const hash = await hashPassword(newPassword);
  const userId = await tx(async (q) => {
    const r = await q.query<{ id: string; user_id: string }>(
      `select id, user_id from email_tokens where token_hash = $1 and purpose = 'reset_password' and used_at is null and expires_at > now() for update`,
      [sha256(token)],
    );
    const t = r.rows[0];
    if (!t) return null;
    await q.query(`update email_tokens set used_at = now() where id = $1`, [t.id]);
    await q.query(`update auth_credentials set password_hash = $2, updated_at = now() where user_id = $1`, [t.user_id, hash]);
    // Menyelesaikan reset juga membuktikan kepemilikan email.
    await q.query(`update profiles set email_verified_at = coalesce(email_verified_at, now()) where id = $1`, [t.user_id]);
    await audit(q, { actor: { id: t.user_id, roles: [] }, action: "auth.password_reset", entityType: "profile", entityId: t.user_id, ip: meta.ip });
    return t.user_id;
  });
  if (!userId) return false;
  await revokeAllSessions(userId); // paksa masuk ulang di semua perangkat
  await resetKey(`login:email:${(await one<{ email: string }>("select lower(email) as email from profiles where id=$1", [userId]))?.email}`);
  return true;
}

export async function changePassword(user: SessionUser, current: string, next: string, meta: Meta) {
  await rateLimit(`chpw:${user.id}`, { limit: 5, windowSec: 900 });
  const row = await one<{ password_hash: string }>("select password_hash from auth_credentials where user_id = $1", [user.id]);
  if (!row || !(await verifyPassword(current, row.password_hash))) {
    throw unprocessable("Kata sandi saat ini salah.", { current_password: "Kata sandi saat ini salah." });
  }
  if (next.toLowerCase().includes(user.email.split("@")[0]!.toLowerCase()) && user.email.split("@")[0]!.length >= 4) {
    throw unprocessable("Kata sandi tidak boleh memuat bagian dari email Anda.", { new_password: "Kata sandi tidak boleh memuat bagian dari email Anda." });
  }
  const hash = await hashPassword(next);
  await query("update auth_credentials set password_hash = $2, updated_at = now() where user_id = $1", [user.id, hash]);
  await revokeAllSessions(user.id, user.sessionId);
  await audit(null, { actor: user, action: "auth.password_changed", entityType: "profile", entityId: user.id, ip: meta.ip });
}
