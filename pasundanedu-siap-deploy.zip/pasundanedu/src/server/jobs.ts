import { env } from "./env";
import { query, tx } from "./db";
import type { Row } from "./db";
import { EMAIL_TEMPLATES, WA_VARIABLE_ORDER, type JobVars } from "./integrations/templates";
import { sendEmail } from "./integrations/email";
import { sendWhatsappTemplate, whatsappConfigured, WhatsappError } from "./integrations/whatsapp";
import { notify } from "./notify";
import { formatDateTime } from "@/lib/format";

type Job = {
  id: string; user_id: string | null; channel: "email" | "whatsapp"; template: string; payload: JobVars;
  attempts: number; max_attempts: number;
};

export type ProcessResult = { claimed: number; sent: number; skipped: number; retried: number; dead: number };

type Deps = { fetchImpl?: typeof fetch };

/**
 * Memproses antrean notifikasi yang jatuh tempo.
 * - Klaim baris dengan FOR UPDATE SKIP LOCKED (aman untuk beberapa worker).
 * - Gagal sementara → retry dengan backoff eksponensial (2, 4, 8, … maks 60 menit); setelah max_attempts → "dead".
 * - Tidak dikonfigurasi / tidak disetujui / persetujuan dicabut → "skipped" (bukan gagal) dan dicatat di log.
 */
export async function processDueJobs(opts: { limit?: number } & Deps = {}): Promise<ProcessResult> {
  const limit = opts.limit ?? 20;
  const claimed = await query<Job & Row>(
    `update notification_jobs set status = 'processing', locked_at = now(), attempts = attempts + 1, updated_at = now()
     where id in (
       select id from notification_jobs
       where (status in ('pending','failed') and next_attempt_at <= now())
          or (status = 'processing' and locked_at < now() - interval '10 minutes')
       order by next_attempt_at limit $1 for update skip locked)
     returning id, user_id, channel, template, payload, attempts, max_attempts`,
    [limit],
  );
  const res: ProcessResult = { claimed: claimed.rows.length, sent: 0, skipped: 0, retried: 0, dead: 0 };
  for (const job of claimed.rows) {
    const out = await runJob(job, opts);
    res[out]++;
  }
  return res;
}

async function runJob(job: Job, deps: Deps): Promise<"sent" | "skipped" | "retried" | "dead"> {
  const logBase = { jobId: job.id, channel: job.channel, template: job.template };
  const finish = async (status: "sent" | "skipped" | "failed" | "dead", error: string | null, delayMin = 0) => {
    await query(
      `update notification_jobs set status = $2, last_error = $3, locked_at = null, updated_at = now(),
              next_attempt_at = now() + make_interval(mins => $4::int) where id = $1`,
      [job.id, status, error, delayMin],
    );
  };
  const log = (provider: string, recipient: string, status: string, error: string | null, messageId: string | null = null) =>
    query(
      `insert into integration_message_logs (job_id, channel, provider, recipient, template, status, provider_message_id, error)
       values ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [logBase.jobId, logBase.channel, provider, recipient, logBase.template, status, messageId, error],
    );

  const user = job.user_id
    ? (await query<{ email: string; whatsapp_number: string | null; status: string; wa_enabled: boolean; wa_consent: boolean | null }>(
        `select p.email, p.whatsapp_number, p.status,
                coalesce(np.whatsapp_enabled,false) as wa_enabled,
                (select granted from consents c where c.user_id = p.id and c.consent_type='whatsapp' order by c.created_at desc limit 1) as wa_consent
         from profiles p left join notification_preferences np on np.user_id = p.id where p.id = $1`,
        [job.user_id],
      )).rows[0]
    : undefined;

  if (!user || user.status === "deleted" || user.status === "suspended") {
    await log(job.channel, "-", "skipped", "Penerima tidak aktif");
    await finish("skipped", "Penerima tidak aktif");
    return "skipped";
  }

  try {
    if (job.channel === "email") {
      const tpl = EMAIL_TEMPLATES[job.template];
      if (!tpl) throw Object.assign(new Error(`Template email "${job.template}" tidak dikenal`), { permanent: true });
      const { subject, text } = tpl(job.payload);
      const r = await sendEmail({ to: user.email, subject, text });
      await log(r.provider, user.email, "sent", null, r.messageId);
      await finish("sent", r.simulated ? "Disimulasikan (provider log), tidak dikirim sungguhan" : null);
      return "sent";
    }

    // WhatsApp
    if (!whatsappConfigured()) {
      await log("whatsapp", user.whatsapp_number ?? "-", "skipped", "WhatsApp belum dikonfigurasi");
      await finish("skipped", "whatsapp_not_configured");
      return "skipped";
    }
    if (!user.whatsapp_number || !user.wa_enabled || user.wa_consent !== true) {
      await log("whatsapp", user.whatsapp_number ?? "-", "skipped", "Persetujuan/preferensi WhatsApp tidak aktif");
      await finish("skipped", "consent_revoked");
      return "skipped";
    }
    const tpl = (await query<{ name: string; language: string }>(
      `select name, language from whatsapp_templates where purpose = $1 and is_active and status = 'approved'`, [job.template],
    )).rows[0];
    if (!tpl) {
      await log("whatsapp", user.whatsapp_number, "skipped", "Template WhatsApp belum disetujui/diaktifkan");
      await finish("skipped", "template_not_approved");
      return "skipped";
    }
    const order = WA_VARIABLE_ORDER[job.template] ?? [];
    const r = await sendWhatsappTemplate(
      { to: user.whatsapp_number, templateName: tpl.name, language: tpl.language, params: order.map((k) => job.payload[k] ?? "-") },
      deps.fetchImpl,
    );
    await log("whatsapp_cloud_api", user.whatsapp_number, "sent", null, r.messageId);
    await finish("sent", null);
    return "sent";
  } catch (e) {
    const err = e as Error & { permanent?: boolean; notConfigured?: boolean };
    const retryable = e instanceof WhatsappError ? e.retryable : !err.permanent;
    const msg = err.message.slice(0, 500);
    await log(job.channel === "whatsapp" ? "whatsapp_cloud_api" : env.emailProvider, job.channel === "email" ? user.email : (user.whatsapp_number ?? "-"), "failed", msg);
    if (err.notConfigured) {
      await finish("skipped", msg);
      return "skipped";
    }
    if (!retryable || job.attempts >= job.max_attempts) {
      await finish("dead", msg);
      return "dead";
    }
    await finish("failed", msg, Math.min(60, 2 ** job.attempts));
    return "retried";
  }
}

/** Antrekan pengingat untuk janji temu yang mulai dalam 24 jam. Idempoten (reminder_sent_at + dedupe key). */
export async function enqueueAppointmentReminders(): Promise<number> {
  const due = await query<{
    id: string; student_id: string; staff_id: string; starts_at: Date; service_name: string; request_number: string; request_id: string;
  }>(
    `select a.id, a.student_id, a.staff_id, a.starts_at, s.name as service_name, r.request_number, r.id as request_id
     from appointments a join service_requests r on r.id = a.request_id join services s on s.id = r.service_id
     where a.status = 'booked' and a.reminder_sent_at is null and a.starts_at > now() and a.starts_at <= now() + interval '24 hours'
     limit 200`,
  );
  let n = 0;
  for (const a of due.rows) {
    await tx(async (q) => {
      const claim = await q.query("update appointments set reminder_sent_at = now() where id = $1 and reminder_sent_at is null", [a.id]);
      if (!claim.rowCount) return;
      for (const [uid, path] of [[a.student_id, `/riwayat/${a.request_id}`], [a.staff_id, `/pengajuan/${a.request_id}`]] as const) {
        await notify(q, {
          userId: uid, type: "appointment_reminder", title: `Pengingat: ${a.service_name}`,
          body: formatDateTime(a.starts_at), link: path, template: "appointment_reminder",
          vars: { layanan: a.service_name, jadwal: formatDateTime(a.starts_at), nomor_pengajuan: a.request_number },
          dedupe: `rem:${a.id}:${uid}`,
        });
      }
      n++;
    });
  }
  return n;
}

export async function jobStats() {
  const { rows } = await query<{ status: string; n: number }>(`select status, count(*)::int as n from notification_jobs group by status`);
  return Object.fromEntries(rows.map((r) => [r.status, r.n])) as Record<string, number>;
}
