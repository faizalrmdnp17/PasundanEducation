import { NextRequest, NextResponse } from "next/server";
import { ZodError, type ZodType } from "zod";
import { randomUUID } from "node:crypto";
import { env } from "./env";
import { AppError, forbidden, unauthorized } from "./errors";
import { userFromToken, sessionCookieOptions } from "./auth/session";
import type { SessionUser } from "./auth/types";
import type { Role } from "@/lib/constants";

export function clientIp(req: NextRequest): string {
  // Entri paling kiri X-Forwarded-For dikendalikan klien. Proxy tepercaya menambahkan IP yang dilihatnya di sisi kanan,
  // sehingga IP klien yang sebenarnya adalah entri ke-N dari kanan (N = TRUSTED_PROXY_COUNT).
  const xff = req.headers.get("x-forwarded-for");
  if (xff) {
    const parts = xff.split(",").map((s) => s.trim()).filter(Boolean);
    const ip = parts[Math.max(0, parts.length - env.trustedProxyCount)];
    if (ip) return ip;
  }
  return req.headers.get("x-real-ip") ?? "unknown";
}

/** Perlindungan CSRF untuk permintaan yang mengubah data: tolak asal lintas-situs. */
export function assertSameOrigin(req: NextRequest) {
  const site = req.headers.get("sec-fetch-site");
  if (site && site !== "same-origin" && site !== "none") throw forbidden("Permintaan lintas situs ditolak.");
  const origin = req.headers.get("origin");
  if (origin) {
    let host: string;
    try {
      host = new URL(origin).host;
    } catch {
      throw forbidden("Asal permintaan tidak valid.");
    }
    const allowed = new Set([req.headers.get("host"), req.headers.get("x-forwarded-host"), new URL(env.appUrl).host]);
    if (!allowed.has(host)) throw forbidden("Permintaan lintas situs ditolak.");
  }
}

export type Ctx<B = undefined> = {
  req: NextRequest;
  user: SessionUser | null;
  body: B;
  params: Record<string, string>;
  search: URLSearchParams;
  ip: string;
  userAgent: string | null;
  setCookie: (name: string, value: string, expires?: Date) => void;
  clearCookie: (name: string) => void;
};

type Auth = "public" | "user" | Role[];
type Opts<S extends ZodType | undefined> = {
  auth?: Auth;
  schema?: S;
  /** Wajib email terverifikasi (untuk tindakan yang membuat/mengubah data layanan). */
  verified?: boolean;
  /** Webhook dari pihak ketiga memakai tanda tangan, bukan cookie/CSRF. */
  csrf?: boolean;
  /** Baca badan sebagai multipart/form-data alih-alih JSON. */
  multipart?: boolean;
};

type Handler<B> = (ctx: Ctx<B>) => Promise<Response | Record<string, unknown> | unknown[] | null>;

export function errorResponse(e: unknown, requestId: string): NextResponse {
  if (e instanceof ZodError) {
    const fields: Record<string, string> = {};
    for (const i of e.issues) {
      const k = i.path.join(".") || "_";
      fields[k] ??= i.message;
    }
    return NextResponse.json({ error: { code: "validation_error", message: "Periksa kembali isian Anda.", fields }, requestId }, { status: 422 });
  }
  if (e instanceof AppError) {
    const headers: Record<string, string> = {};
    const retry = (e as AppError & { retryAfterSec?: number }).retryAfterSec;
    if (retry) headers["Retry-After"] = String(retry);
    return NextResponse.json({ error: { code: e.code, message: e.message, fields: e.fields }, requestId }, { status: e.status, headers });
  }
  console.error(`[api ${requestId}]`, e);
  return NextResponse.json(
    { error: { code: "internal_error", message: "Terjadi kesalahan pada server. Coba lagi nanti.", requestId } },
    { status: 500 },
  );
}

/**
 * Pembungkus route handler: CSRF, autentikasi sesi, otorisasi peran, validasi Zod, dan penanganan galat seragam.
 */
export function route<S extends ZodType | undefined = undefined>(opts: Opts<S>, handler: Handler<S extends ZodType ? import("zod").infer<S> : undefined>) {
  return async (req: NextRequest, routeCtx: { params: Promise<Record<string, string>> }): Promise<Response> => {
    const requestId = randomUUID().slice(0, 8);
    const cookiesToSet: Array<{ name: string; value: string; expires?: Date; clear?: boolean }> = [];
    try {
      const mutating = !["GET", "HEAD", "OPTIONS"].includes(req.method);
      if (mutating && opts.csrf !== false) assertSameOrigin(req);

      const token = req.cookies.get(env.sessionCookie)?.value;
      const user = await userFromToken(token);
      const auth = opts.auth ?? "user";
      if (auth !== "public") {
        if (!user) throw unauthorized();
        if (Array.isArray(auth) && !auth.some((r) => user.roles.includes(r))) throw forbidden();
        if (opts.verified && !user.emailVerified) throw forbidden("Verifikasi email Anda terlebih dahulu untuk melakukan tindakan ini.");
      }

      let body: unknown = undefined;
      if (opts.schema && !opts.multipart) {
        const raw = await req.text();
        if (raw.length > 200_000) throw new AppError(413, "payload_too_large", "Data terlalu besar.");
        let json: unknown = {};
        if (raw) {
          try {
            json = JSON.parse(raw);
          } catch {
            throw new AppError(400, "bad_json", "Format data tidak valid.");
          }
        }
        body = opts.schema.parse(json);
      }

      const out = await handler({
        req,
        user,
        body: body as never,
        params: await routeCtx.params,
        search: req.nextUrl.searchParams,
        ip: clientIp(req),
        userAgent: req.headers.get("user-agent"),
        setCookie: (name, value, expires) => cookiesToSet.push({ name, value, expires }),
        clearCookie: (name) => cookiesToSet.push({ name, value: "", clear: true }),
      });

      const res = out instanceof Response ? out : NextResponse.json(out ?? { ok: true });
      const nres = res as NextResponse;
      for (const c of cookiesToSet) {
        const o = sessionCookieOptions(c.expires);
        if (c.clear) nres.cookies?.set(c.name, "", { ...o, maxAge: 0 });
        else nres.cookies?.set(c.name, c.value, o);
      }
      res.headers.set("Cache-Control", "private, no-store");
      return res;
    } catch (e) {
      return errorResponse(e, requestId);
    }
  };
}

/** Membaca unggahan multipart (satu berkas bernama "file" + kolom teks), dengan batas ukuran sebelum dibaca ke memori. */
export async function readUpload(req: NextRequest): Promise<{ file: { name: string; data: Buffer }; fields: Record<string, string> }> {
  const len = Number(req.headers.get("content-length") ?? 0);
  if (len > env.maxUploadBytes + 512 * 1024) throw new AppError(413, "payload_too_large", `Ukuran berkas maksimal ${Math.round(env.maxUploadBytes / 1024 / 1024)} MB.`);
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    throw new AppError(400, "bad_form", "Data unggahan tidak valid.");
  }
  const f = form.get("file");
  if (!(f instanceof File) || !f.name) throw new AppError(400, "no_file", "Pilih berkas yang akan diunggah.");
  if (f.size > env.maxUploadBytes) throw new AppError(413, "payload_too_large", `Ukuran berkas maksimal ${Math.round(env.maxUploadBytes / 1024 / 1024)} MB.`);
  const fields: Record<string, string> = {};
  for (const [k, v] of form.entries()) if (typeof v === "string") fields[k] = v;
  return { file: { name: f.name, data: Buffer.from(await f.arrayBuffer()) }, fields };
}

/** Pagination standar: ?page=1&pageSize=20 (maks 100). */
export function pageParams(search: URLSearchParams, defaultSize = 20) {
  const page = Math.max(1, Number.parseInt(search.get("page") ?? "1", 10) || 1);
  const size = Math.min(100, Math.max(1, Number.parseInt(search.get("pageSize") ?? String(defaultSize), 10) || defaultSize));
  return { page, size, offset: (page - 1) * size };
}

export function paged<T>(items: T[], total: number, page: number, size: number) {
  return { items, page, pageSize: size, total, totalPages: Math.max(1, Math.ceil(total / size)) };
}
