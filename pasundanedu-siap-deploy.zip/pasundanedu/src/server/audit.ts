import type { Queryable } from "./db";
import { query } from "./db";
import type { Actor } from "./auth/types";

type AuditInput = {
  actor?: Pick<Actor, "id" | "roles"> | null;
  action: string;
  entityType?: string;
  entityId?: string;
  meta?: Record<string, unknown>;
  ip?: string | null;
};

/** Mencatat tindakan penting. Gunakan `q` agar tercatat dalam transaksi yang sama dengan perubahannya. */
export async function audit(q: Queryable | null, a: AuditInput): Promise<void> {
  const run = q ? q.query.bind(q) : query;
  await run(
    `insert into audit_logs (actor_id, actor_role, action, entity_type, entity_id, meta, ip)
     values ($1,$2,$3,$4,$5,$6::jsonb,$7)`,
    [a.actor?.id ?? null, a.actor?.roles?.join(",") ?? null, a.action, a.entityType ?? null, a.entityId ?? null, JSON.stringify(a.meta ?? {}), a.ip ?? null],
  );
}
