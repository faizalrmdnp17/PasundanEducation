/**
 * Akses variabel lingkungan secara terpusat. Menggunakan getter agar nilai dibaca saat dipakai
 * (memudahkan pengujian) dan seluruh rahasia hanya hidup di sisi server.
 */
const DEV_SECRET = "dev-only-secret-change-me-dev-only-secret-change-me";

function str(name: string, fallback = ""): string {
  const v = process.env[name];
  return v === undefined || v === "" ? fallback : v;
}
function bool(name: string, fallback: boolean): boolean {
  const v = process.env[name];
  if (v === undefined || v === "") return fallback;
  return ["1", "true", "yes", "on"].includes(v.toLowerCase());
}
function int(name: string, fallback: number): number {
  const n = Number.parseInt(process.env[name] ?? "", 10);
  return Number.isFinite(n) ? n : fallback;
}

export const env = {
  get nodeEnv() { return str("NODE_ENV", "development"); },
  get isProd() { return this.nodeEnv === "production"; },
  get isTest() { return this.nodeEnv === "test"; },
  /** Label lingkungan yang tampil di UI ("development" menampilkan penanda data contoh). */
  get appEnv() { return str("APP_ENV", this.isProd ? "production" : "development"); },
  get appUrl() { return str("APP_URL", "http://localhost:3000").replace(/\/$/, ""); },
  get appName() { return "PasundanEdu"; },

  get databaseUrl() { return str("DATABASE_URL"); },
  /**
   * TLS ke PostgreSQL. "off" (bawaan), "verify" (DATABASE_SSL=true: sertifikat server DIVERIFIKASI; CA khusus lewat DATABASE_SSL_CA),
   * atau "no-verify" (DATABASE_SSL=no-verify: terenkripsi tetapi sertifikat tidak diperiksa, tidak disarankan).
   */
  get databaseSsl(): "off" | "verify" | "no-verify" {
    const v = (process.env.DATABASE_SSL ?? "").trim().toLowerCase();
    if (v === "no-verify") return "no-verify";
    return ["1", "true", "yes", "on", "require", "verify"].includes(v) ? "verify" : "off";
  },
  get databaseSslCa() { return str("DATABASE_SSL_CA"); },
  get pgliteDir() { return str("PGLITE_DIR", ".data/pglite"); },
  get autoMigrate() { return bool("AUTO_MIGRATE", !this.databaseUrl); },
  get migrationsDir() { return str("MIGRATIONS_DIR", "db/migrations"); },

  /** Rahasia penandatangan URL berkas & token internal. Wajib diatur di produksi. */
  get appSecret(): string {
    const s = str("APP_SECRET");
    if (s.length >= 32) return s;
    if (this.isProd) throw new Error("APP_SECRET wajib diatur (minimal 32 karakter) pada produksi.");
    return DEV_SECRET;
  },
  get cronSecret() { return str("CRON_SECRET"); },

  get sessionCookie() { return str("SESSION_COOKIE", "pe_session"); },
  get sessionDays() { return int("SESSION_DAYS", 14); },
  /** Jumlah reverse proxy tepercaya di depan aplikasi (pengisi X-Forwarded-For). IP klien = entri ke-N dari KANAN, bukan entri pertama yang bisa dipalsukan klien. */
  get trustedProxyCount() { return Math.max(1, int("TRUSTED_PROXY_COUNT", 1)); },
  get cookieSecure() { return bool("COOKIE_SECURE", this.isProd); },

  get uploadDir() { return str("UPLOAD_DIR", ".data/uploads"); },
  get maxUploadBytes() { return int("MAX_UPLOAD_MB", 5) * 1024 * 1024; },
  get signedUrlTtlSeconds() { return int("SIGNED_URL_TTL_SECONDS", 300); },

  // Email
  get emailProvider() { return str("EMAIL_PROVIDER", this.isProd ? "smtp" : "log"); },
  get smtpUrl() { return str("SMTP_URL"); },
  get emailFrom() { return str("EMAIL_FROM", "PasundanEdu <no-reply@localhost>"); },

  // WhatsApp Business Platform / Cloud API
  get whatsappProvider() { return str("WHATSAPP_PROVIDER", "cloud_api"); },
  get whatsappToken() { return str("WHATSAPP_ACCESS_TOKEN"); },
  get whatsappPhoneNumberId() { return str("WHATSAPP_PHONE_NUMBER_ID"); },
  get whatsappBusinessAccountId() { return str("WHATSAPP_BUSINESS_ACCOUNT_ID"); },
  get whatsappBusinessNumber() { return str("WHATSAPP_BUSINESS_NUMBER"); },
  get whatsappVerifyToken() { return str("WHATSAPP_VERIFY_TOKEN"); },
  get whatsappAppSecret() { return str("WHATSAPP_APP_SECRET"); },
  get whatsappApiVersion() { return str("WHATSAPP_API_VERSION", "v21.0"); },
  get whatsappApiBase() { return str("WHATSAPP_API_BASE", "https://graph.facebook.com"); },

  // Moodle (adapter LMS awal)
  get moodleToken() { return str("MOODLE_WS_TOKEN"); },

  // Pembayaran (webhook gateway; tidak aktif tanpa persetujuan pengelola)
  get paymentWebhookSecret() { return str("PAYMENT_WEBHOOK_SECRET"); },

  // Seed
  get seedAdminEmail() { return str("SEED_ADMIN_EMAIL"); },
  get seedAdminPassword() { return str("SEED_ADMIN_PASSWORD"); },
  get seedAdminName() { return str("SEED_ADMIN_NAME", "Pengelola PasundanEdu"); },
};

export type Env = typeof env;
