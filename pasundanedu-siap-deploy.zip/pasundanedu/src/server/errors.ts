export class AppError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public fields?: Record<string, string>,
  ) {
    super(message);
  }
}

export const badRequest = (message: string, fields?: Record<string, string>) => new AppError(400, "bad_request", message, fields);
export const unauthorized = (message = "Silakan masuk terlebih dahulu.") => new AppError(401, "unauthorized", message);
export const forbidden = (message = "Anda tidak memiliki akses untuk tindakan ini.") => new AppError(403, "forbidden", message);
export const notFound = (message = "Data tidak ditemukan.") => new AppError(404, "not_found", message);
export const conflict = (message: string, code = "conflict") => new AppError(409, code, message);
export const unprocessable = (message: string, fields?: Record<string, string>) => new AppError(422, "validation_error", message, fields);
export const tooMany = (message: string, retryAfterSec?: number) => {
  const e = new AppError(429, "rate_limited", message);
  (e as AppError & { retryAfterSec?: number }).retryAfterSec = retryAfterSec;
  return e;
};

/** Kode galat PostgreSQL untuk pelanggaran unique. */
export function isUniqueViolation(e: unknown, constraintHint?: string): boolean {
  const err = e as { code?: string; constraint?: string; message?: string };
  if (err?.code !== "23505") return false;
  if (!constraintHint) return true;
  return (err.constraint ?? err.message ?? "").includes(constraintHint);
}
