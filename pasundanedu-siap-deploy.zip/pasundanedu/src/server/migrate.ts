import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import type { Db } from "./db";
import { env } from "./env";

/**
 * Runner migrasi SQL berurutan.
 * - Setiap berkas db/migrations/NNN_nama.sql dijalankan sekali dalam satu transaksi.
 * - Checksum disimpan; jika berkas yang sudah diterapkan berubah, runner berhenti dengan galat
 *   (perubahan skema harus lewat migrasi baru).
 * - Aman dijalankan ulang dan aman terhadap runner paralel (advisory lock).
 */
export async function runMigrations(db: Db, dir = env.migrationsDir): Promise<string[]> {
  const abs = path.resolve(/*turbopackIgnore: true*/ process.cwd(), dir);
  const files = fs.readdirSync(abs).filter((f) => /^\d+_.+\.sql$/.test(f)).sort();
  await db.exec(`create table if not exists schema_migrations (
    version text primary key,
    checksum text not null,
    applied_at timestamptz not null default now()
  )`);

  const applied: string[] = [];
  for (const file of files) {
    const sql = fs.readFileSync(path.join(abs, file), "utf8");
    const checksum = createHash("sha256").update(sql).digest("hex");
    const version = file.replace(/\.sql$/, "");
    await db.tx(async (q) => {
      await q.query("select pg_advisory_xact_lock(7272741)");
      const { rows } = await q.query<{ checksum: string }>("select checksum from schema_migrations where version = $1", [version]);
      if (rows[0]) {
        if (rows[0].checksum !== checksum) {
          throw new Error(`Migrasi ${version} sudah diterapkan tetapi isinya berubah. Buat migrasi baru, jangan ubah yang lama.`);
        }
        return;
      }
      await q.exec(sql);
      await q.query("insert into schema_migrations (version, checksum) values ($1, $2)", [version, checksum]);
      applied.push(version);
    });
  }
  return applied;
}
