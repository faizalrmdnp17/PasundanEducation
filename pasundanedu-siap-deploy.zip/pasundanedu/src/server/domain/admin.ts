import { query, tx } from "../db";
import { audit } from "../audit";
import { conflict, forbidden, notFound, isUniqueViolation, unprocessable } from "../errors";
import { notify } from "../notify";
import { escapeLike } from "./services";
import { revokeAllSessions } from "../auth/session";
import { paymentsEnabled } from "./settings";
import { jobStats } from "../jobs";
import { whatsappConfigStatus } from "../integrations/whatsapp";
import { emailProviderLabel } from "../integrations/email";
import type { Actor } from "../auth/types";
import type { Role } from "@/lib/constants";
import type { z } from "zod";
import type { announcementSchema, integrationUpsertSchema, userAdminSchema, whatsappTemplateSchema } from "@/lib/validation";

/* ------------------------------- Laporan ------------------------------- */

export async function getReports() {
  const [byStatus, popular, avg, upcoming, daily, lib, topRes, users, pendingRoles, integ, jobs, payOn, failedMsgs, unassigned, feedback] = await Promise.all([
    query<{ status: string; n: number }>("select status, count(*)::int as n from service_requests group by status"),
    query<{ name: string; n: number }>(
      `select s.name, count(*)::int as n from service_requests r join services s on s.id = r.service_id
       where r.created_at > now() - interval '90 days' group by s.name order by n desc, s.name limit 6`),
    query<{ hours: number | null; n: number }>(
      `select round((avg(extract(epoch from (completed_at - created_at)) / 3600))::numeric, 1)::float as hours, count(*)::int as n
       from service_requests where status = 'completed' and completed_at is not null`),
    query<{ id: string; request_id: string; request_number: string; service_name: string; starts_at: Date; student_name: string; staff_name: string }>(
      `select a.id, a.request_id, r.request_number, s.name as service_name, a.starts_at, st.full_name as student_name, sf.full_name as staff_name
       from appointments a join service_requests r on r.id = a.request_id join services s on s.id = r.service_id
       join profiles st on st.id = a.student_id join profiles sf on sf.id = a.staff_id
       where a.status = 'booked' and a.starts_at > now() order by a.starts_at limit 8`),
    query<{ d: string; n: number }>(
      `select to_char((created_at at time zone 'Asia/Jakarta')::date, 'YYYY-MM-DD') as d, count(*)::int as n
       from service_requests where created_at > now() - interval '14 days' group by 1 order by 1`),
    query<{ opens: number; borrows: number; favs: number; users: number }>(
      `select (select count(*)::int from resource_access_logs where action = 'open' and created_at > now() - interval '30 days') as opens,
              (select count(*)::int from service_requests r join services s on s.id = r.service_id where s.slug = 'peminjaman-buku-referensi' and r.created_at > now() - interval '30 days') as borrows,
              (select count(*)::int from resource_favorites) as favs,
              (select count(distinct user_id)::int from resource_access_logs where created_at > now() - interval '30 days') as users`),
    query<{ title: string; n: number }>(
      `select r.title, count(*)::int as n from resource_access_logs l join learning_resources r on r.id = l.resource_id
       where l.created_at > now() - interval '30 days' group by r.title order by n desc, r.title limit 5`),
    query<{ code: string; n: number }>(
      `select r.code, count(*)::int as n from user_roles ur join roles r on r.id = ur.role_id join profiles p on p.id = ur.user_id where p.status = 'active' group by r.code`),
    query<{ n: number }>("select count(*)::int as n from role_requests where status = 'pending'"),
    query<{ id: string; name: string; kind: string; status: string; is_active: boolean; last_checked_at: Date | null; last_error: string | null }>(
      "select id, name, kind, status, is_active, last_checked_at, last_error from external_integrations order by name"),
    jobStats(),
    paymentsEnabled(),
    query<{ id: string; channel: string; template: string; status: string; last_error: string | null; updated_at: Date }>(
      `select id, channel, template, status, last_error, updated_at from notification_jobs where status in ('failed','dead') order by updated_at desc limit 8`),
    query<{ n: number }>("select count(*)::int as n from service_requests where assignee_id is null and status not in ('completed','rejected','cancelled')"),
    query<{ avg: number | null; n: number }>("select round(avg(rating)::numeric, 2)::float as avg, count(*)::int as n from service_feedback"),
  ]);

  let payments: { paid_total: number; paid_count: number; awaiting: number; pending: number } | null = null;
  if (payOn) {
    const p = await query<{ paid_total: number; paid_count: number; awaiting: number; pending: number }>(
      `select coalesce(sum(amount_idr) filter (where status = 'paid'), 0)::int as paid_total,
              (count(*) filter (where status = 'paid'))::int as paid_count,
              (count(*) filter (where status = 'awaiting_verification'))::int as awaiting,
              (count(*) filter (where status = 'pending'))::int as pending from payments`);
    payments = p.rows[0]!;
  }
  return {
    byStatus: Object.fromEntries(byStatus.rows.map((r) => [r.status, r.n])) as Record<string, number>,
    popular: popular.rows,
    avgCompletionHours: avg.rows[0]!.hours,
    completedCount: avg.rows[0]!.n,
    upcoming: upcoming.rows,
    daily: daily.rows,
    library: { ...lib.rows[0]!, top: topRes.rows },
    usersByRole: Object.fromEntries(users.rows.map((r) => [r.code, r.n])) as Record<string, number>,
    pendingRoleRequests: pendingRoles.rows[0]!.n,
    integrations: integ.rows,
    notificationJobs: jobs,
    failedMessages: failedMsgs.rows,
    unassigned: unassigned.rows[0]!.n,
    feedback: feedback.rows[0]!,
    paymentsEnabled: payOn,
    payments,
  };
}

/* ------------------------------- Pengguna ------------------------------- */

export async function listUsers(opts: { q?: string; role?: string; status?: string; page?: number; size?: number }) {
  const page = Math.max(1, opts.page ?? 1);
  const size = Math.min(100, opts.size ?? 20);
  const params: unknown[] = [];
  const where: string[] = [];
  if (opts.q?.trim()) {
    params.push(`%${escapeLike(opts.q.trim())}%`);
    where.push(`(p.full_name ilike $${params.length} or p.email ilike $${params.length} or p.npm ilike $${params.length} or p.nidn ilike $${params.length})`);
  }
  if (opts.status) { params.push(opts.status); where.push(`p.status = $${params.length}`); }
  if (opts.role) { params.push(opts.role); where.push(`exists (select 1 from user_roles ur join roles r on r.id = ur.role_id where ur.user_id = p.id and r.code = $${params.length})`); }
  const w = where.length ? `where ${where.join(" and ")}` : "";
  const total = (await query<{ n: number }>(`select count(*)::int as n from profiles p ${w}`, params)).rows[0]!.n;
  const items = (await query<{
    id: string; email: string; full_name: string; account_type: string; npm: string | null; nidn: string | null; status: string;
    email_verified: boolean; whatsapp_number: string | null; whatsapp_verified: boolean; identity_verified: boolean; roles: Role[]; created_at: Date;
  }>(
    `select p.id, p.email, p.full_name, p.account_type, p.npm, p.nidn, p.status, (p.email_verified_at is not null) as email_verified,
            p.whatsapp_number, (p.whatsapp_verified_at is not null) as whatsapp_verified, (p.identity_verified_at is not null) as identity_verified, p.created_at,
            coalesce((select array_agg(r.code order by r.id) from user_roles ur join roles r on r.id = ur.role_id where ur.user_id = p.id), '{}') as roles
     from profiles p ${w} order by p.created_at desc limit ${size} offset ${(page - 1) * size}`, params,
  )).rows;
  return { items, total, page, size, totalPages: Math.max(1, Math.ceil(total / size)) };
}

export async function listStaff() {
  return (await query<{ id: string; full_name: string; roles: Role[] }>(
    `select p.id, p.full_name, array_agg(r.code order by r.id) as roles from profiles p
     join user_roles ur on ur.user_id = p.id join roles r on r.id = ur.role_id
     where p.status = 'active' and r.code in ('dosen','petugas') group by p.id, p.full_name order by p.full_name`,
  )).rows;
}

/** Perubahan akun oleh admin. Pengguna tidak dapat menaikkan perannya sendiri; admin tidak dapat mengubah perannya/ statusnya sendiri. */
export async function updateUserAdmin(actor: Actor, userId: string, patch: z.infer<typeof userAdminSchema>, ip?: string) {
  if (userId === actor.id && (patch.roles || patch.status)) throw forbidden("Anda tidak dapat mengubah peran atau status akun Anda sendiri.");
  return tx(async (q) => {
    const u = (await q.query<{ id: string; full_name: string }>("select id, full_name from profiles where id = $1 for update", [userId])).rows[0];
    if (!u) throw notFound("Pengguna tidak ditemukan.");
    if (patch.status) {
      await q.query("update profiles set status = $2, updated_at = now() where id = $1", [userId, patch.status]);
      if (patch.status === "suspended") await q.query("update sessions set revoked_at = now() where user_id = $1 and revoked_at is null", [userId]);
    }
    if (patch.whatsapp_verified !== undefined) {
      if (patch.whatsapp_verified) {
        const has = await q.query("select 1 from profiles where id = $1 and whatsapp_number is not null", [userId]);
        if (!has.rowCount) throw unprocessable("Pengguna belum mengisi nomor WhatsApp.");
      }
      await q.query("update profiles set whatsapp_verified_at = case when $2 then coalesce(whatsapp_verified_at, now()) else null end where id = $1", [userId, patch.whatsapp_verified]);
    }
    if (patch.identity_verified !== undefined) {
      await q.query("update profiles set identity_verified_at = case when $2 then coalesce(identity_verified_at, now()) else null end where id = $1", [userId, patch.identity_verified]);
    }
    if (patch.roles) {
      if (!patch.roles.length) throw unprocessable("Minimal satu peran.");
      await q.query("delete from user_roles where user_id = $1", [userId]);
      for (const code of patch.roles) {
        await q.query(`insert into user_roles (user_id, role_id, granted_by) select $1, id, $3 from roles where code = $2`, [userId, code, actor.id]);
      }
      const primary = (["admin", "petugas", "dosen", "mahasiswa"] as const).find((r) => patch.roles!.includes(r))!;
      await q.query("update profiles set account_type = $2, status = case when status = 'pending_approval' then 'active' else status end, updated_at = now() where id = $1", [userId, primary]);
      // Hak akses berubah: sesi aktif dipaksa keluar agar peran terbaru berlaku.
      await q.query("update sessions set revoked_at = now() where user_id = $1 and revoked_at is null", [userId]);
    }
    await audit(q, { actor, action: "user.update", entityType: "profile", entityId: userId, meta: patch as Record<string, unknown>, ip });
  });
}

/* ----------------------------- Persetujuan peran ----------------------------- */

export async function listRoleRequests(status = "pending") {
  return (await query<{
    id: string; user_id: string; full_name: string; email: string; nidn: string | null; requested_role: string; evidence_note: string | null; status: string; created_at: Date; whatsapp_number: string | null;
  }>(
    `select rr.id, rr.user_id, p.full_name, p.email, p.nidn, rr.requested_role, rr.evidence_note, rr.status, rr.created_at, p.whatsapp_number
     from role_requests rr join profiles p on p.id = rr.user_id where rr.status = $1 order by rr.created_at`, [status],
  )).rows;
}

export async function decideRoleRequest(actor: Actor, id: string, decision: "approve" | "reject", note: string | undefined, ip?: string) {
  return tx(async (q) => {
    const rr = (await q.query<{ id: string; user_id: string; requested_role: Role; status: string }>("select id, user_id, requested_role, status from role_requests where id = $1 for update", [id])).rows[0];
    if (!rr) throw notFound("Permohonan tidak ditemukan.");
    if (rr.status !== "pending") throw conflict("Permohonan sudah diputuskan.");
    if (rr.user_id === actor.id) throw forbidden("Anda tidak dapat memutuskan permohonan Anda sendiri.");
    await q.query("update role_requests set status = $2, decided_by = $3, decided_at = now(), decision_note = $4 where id = $1", [id, decision === "approve" ? "approved" : "rejected", actor.id, note ?? null]);
    if (decision === "approve") {
      await q.query(`insert into user_roles (user_id, role_id, granted_by) select $1, id, $3 from roles where code = $2 on conflict do nothing`, [rr.user_id, rr.requested_role, actor.id]);
      await q.query("update profiles set status = 'active', identity_verified_at = now(), account_type = $2, updated_at = now() where id = $1", [rr.user_id, rr.requested_role]);
      await notify(q, { userId: rr.user_id, type: "role_approved", title: "Akun Anda disetujui", body: `Peran ${rr.requested_role} telah diaktifkan. Masuk kembali untuk memuat akses terbaru.`, link: "/" });
    } else {
      await q.query("update profiles set status = 'suspended', updated_at = now() where id = $1", [rr.user_id]);
      await q.query("update sessions set revoked_at = now() where user_id = $1 and revoked_at is null", [rr.user_id]);
    }
    await audit(q, { actor, action: `role_request.${decision}`, entityType: "role_request", entityId: id, meta: { user_id: rr.user_id, role: rr.requested_role }, ip });
  });
}

/* ------------------------------ Pengumuman ------------------------------ */

export async function upsertAnnouncement(actor: Actor, input: z.infer<typeof announcementSchema>, id?: string, ip?: string) {
  return tx(async (q) => {
    let aid = id;
    if (id) {
      const r = await q.query("update announcements set title=$2, body=$3, category=$4, event_date=$5, is_published=$6, updated_at=now() where id=$1", [id, input.title, input.body ?? null, input.category, input.event_date ?? null, input.is_published]);
      if (!r.rowCount) throw notFound("Pengumuman tidak ditemukan.");
    } else {
      aid = (await q.query<{ id: string }>("insert into announcements (title, body, category, event_date, is_published, created_by) values ($1,$2,$3,$4,$5,$6) returning id", [input.title, input.body ?? null, input.category, input.event_date ?? null, input.is_published, actor.id])).rows[0]!.id;
    }
    await audit(q, { actor, action: id ? "announcement.update" : "announcement.create", entityType: "announcement", entityId: aid, ip });
    return aid!;
  });
}

export async function deleteAnnouncement(actor: Actor, id: string, ip?: string) {
  const r = await query("delete from announcements where id = $1", [id]);
  if (!r.rowCount) throw notFound("Pengumuman tidak ditemukan.");
  await audit(null, { actor, action: "announcement.delete", entityType: "announcement", entityId: id, ip });
}

/* -------------------------------- Integrasi -------------------------------- */

export async function listIntegrations() {
  return (await query<{
    id: string; code: string; name: string; kind: string; connection_type: string; base_url: string | null; auth_method: string; is_active: boolean;
    status: string; instructions: string | null; last_checked_at: Date | null; last_error: string | null;
  }>("select id, code, name, kind, connection_type, base_url, auth_method, is_active, status, instructions, last_checked_at, last_error from external_integrations order by name")).rows;
}

export async function listIntegrationEvents(limit = 30) {
  return (await query<{ id: string; integration_name: string | null; level: string; message: string; created_at: Date }>(
    `select e.id, i.name as integration_name, e.level, e.message, e.created_at from integration_events e left join external_integrations i on i.id = e.integration_id
     order by e.created_at desc limit $1`, [limit],
  )).rows;
}

export async function upsertIntegration(actor: Actor, input: z.infer<typeof integrationUpsertSchema>, id?: string, ip?: string) {
  try {
    return await tx(async (q) => {
      // Tautan biasa tidak boleh diklaim sebagai integrasi API: status mengikuti jenis koneksi.
      const status = input.connection_type === "link" ? "link_only" : "not_connected";
      let iid = id;
      if (id) {
        const r = await q.query(
          `update external_integrations set code=$2, name=$3, kind=$4, connection_type=$5, base_url=$6, auth_method=$7, is_active=$8, instructions=$9,
                  status = case when connection_type <> $5 then $10 else status end, updated_at=now() where id=$1`,
          [id, input.code, input.name, input.kind, input.connection_type, input.base_url ?? null, input.auth_method, input.is_active, input.instructions ?? null, status]);
        if (!r.rowCount) throw notFound("Integrasi tidak ditemukan.");
      } else {
        iid = (await q.query<{ id: string }>(
          `insert into external_integrations (code, name, kind, connection_type, base_url, auth_method, is_active, instructions, status)
           values ($1,$2,$3,$4,$5,$6,$7,$8,$9) returning id`,
          [input.code, input.name, input.kind, input.connection_type, input.base_url ?? null, input.auth_method, input.is_active, input.instructions ?? null, status])).rows[0]!.id;
      }
      await audit(q, { actor, action: id ? "integration.update" : "integration.create", entityType: "external_integration", entityId: iid, meta: { code: input.code }, ip });
      return iid!;
    });
  } catch (e) {
    if (isUniqueViolation(e)) throw conflict("Kode integrasi sudah dipakai.");
    throw e;
  }
}

/** Integrasi aktif bertipe tautan, ditampilkan sebagai "Platform belajar" di aplikasi. */
export async function listActiveLinks() {
  return (await query<{ id: string; name: string; kind: string; base_url: string; instructions: string | null }>(
    "select id, name, kind, base_url, instructions from external_integrations where is_active and base_url is not null and connection_type = 'link' order by name")).rows;
}

/* ------------------------------ WhatsApp admin ------------------------------ */

export async function getWhatsappAdmin() {
  const [templates, logs, jobs, webhooks] = await Promise.all([
    query<{ id: string; name: string; purpose: string; language: string; body_preview: string; variables: string[]; status: string; is_active: boolean }>(
      "select id, name, purpose, language, body_preview, variables, status, is_active from whatsapp_templates order by purpose"),
    query<{ id: string; channel: string; provider: string; recipient: string; template: string; status: string; error: string | null; created_at: Date }>(
      `select id, channel, provider, recipient, template, status, error, created_at from integration_message_logs order by created_at desc limit 40`),
    jobStats(),
    query<{ id: string; event_type: string | null; signature_valid: boolean; processed_at: Date | null; created_at: Date }>(
      "select id, event_type, signature_valid, processed_at, created_at from webhook_events where provider = 'whatsapp' order by created_at desc limit 15"),
  ]);
  return { config: whatsappConfigStatus(), email: emailProviderLabel(), templates: templates.rows, logs: logs.rows, jobs, webhooks: webhooks.rows };
}

export async function updateWhatsappTemplate(actor: Actor, id: string, input: z.infer<typeof whatsappTemplateSchema>, ip?: string) {
  try {
    await tx(async (q) => {
      // Template hanya boleh aktif bila disetujui Meta.
      if (input.is_active && input.status !== "approved") throw unprocessable("Template hanya dapat diaktifkan setelah berstatus 'approved' di WhatsApp Business Manager.");
      const r = await q.query("update whatsapp_templates set name=$2, language=$3, status=$4, is_active=$5, updated_at=now() where id=$1", [id, input.name, input.language, input.status, input.is_active]);
      if (!r.rowCount) throw notFound("Template tidak ditemukan.");
      await audit(q, { actor, action: "whatsapp_template.update", entityType: "whatsapp_template", entityId: id, meta: { status: input.status, active: input.is_active }, ip });
    });
  } catch (e) {
    if (isUniqueViolation(e)) throw conflict("Nama template sudah dipakai.");
    throw e;
  }
}

export async function requeueFailedJobs(actor: Actor, ip?: string) {
  const r = await query("update notification_jobs set status = 'pending', attempts = 0, next_attempt_at = now(), updated_at = now() where status in ('failed','dead')");
  await audit(null, { actor, action: "jobs.requeue", meta: { count: r.rowCount }, ip });
  return r.rowCount;
}

/* --------------------------------- Audit --------------------------------- */

export async function listAuditLogs(opts: { q?: string; action?: string; page?: number; size?: number }) {
  const page = Math.max(1, opts.page ?? 1);
  const size = Math.min(100, opts.size ?? 30);
  const params: unknown[] = [];
  const where: string[] = [];
  if (opts.action) { params.push(`${escapeLike(opts.action)}%`); where.push(`a.action like $${params.length}`); }
  if (opts.q?.trim()) { params.push(`%${escapeLike(opts.q.trim())}%`); where.push(`(p.full_name ilike $${params.length} or a.entity_id ilike $${params.length} or a.action ilike $${params.length})`); }
  const w = where.length ? `where ${where.join(" and ")}` : "";
  const from = "from audit_logs a left join profiles p on p.id = a.actor_id";
  const total = (await query<{ n: number }>(`select count(*)::int as n ${from} ${w}`, params)).rows[0]!.n;
  const items = (await query<{ id: string; action: string; actor_name: string | null; actor_role: string | null; entity_type: string | null; entity_id: string | null; meta: Record<string, unknown>; ip: string | null; created_at: Date }>(
    `select a.id, a.action, p.full_name as actor_name, a.actor_role, a.entity_type, a.entity_id, a.meta, a.ip, a.created_at ${from} ${w}
     order by a.created_at desc limit ${size} offset ${(page - 1) * size}`, params)).rows;
  return { items, total, page, size, totalPages: Math.max(1, Math.ceil(total / size)) };
}

export { revokeAllSessions };
