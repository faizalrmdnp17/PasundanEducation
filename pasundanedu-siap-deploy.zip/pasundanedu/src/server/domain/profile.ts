import { one, tx } from "../db";
import { audit } from "../audit";
import { conflict, isUniqueViolation, unprocessable } from "../errors";
import type { SessionUser } from "../auth/types";

export type Preferences = { email_enabled: boolean; whatsapp_enabled: boolean; reminders_enabled: boolean };

export async function getPreferences(userId: string): Promise<Preferences & { whatsapp_consent: boolean }> {
  const r = await one<Preferences & { whatsapp_consent: boolean | null }>(
    `select coalesce(np.email_enabled, true) as email_enabled, coalesce(np.whatsapp_enabled, false) as whatsapp_enabled,
            coalesce(np.reminders_enabled, true) as reminders_enabled,
            (select granted from consents c where c.user_id = $1 and c.consent_type = 'whatsapp' order by c.created_at desc limit 1) as whatsapp_consent
     from (select $1::uuid as id) u left join notification_preferences np on np.user_id = u.id`, [userId],
  );
  return { ...r!, whatsapp_consent: r?.whatsapp_consent === true };
}

type ProfilePatch = { full_name?: string; study_program?: string; cohort_year?: number; phone?: string; whatsapp_number?: string };

export async function updateProfile(user: SessionUser, patch: ProfilePatch, ip?: string | null) {
  try {
    await tx(async (q) => {
      const cur = (await q.query<{ whatsapp_number: string | null }>("select whatsapp_number from profiles where id = $1 for update", [user.id])).rows[0]!;
      const waChanged = patch.whatsapp_number !== undefined && patch.whatsapp_number !== cur.whatsapp_number;
      await q.query(
        `update profiles set full_name = coalesce($2, full_name), study_program = coalesce($3, study_program), cohort_year = coalesce($4, cohort_year),
                phone = coalesce($5, phone), whatsapp_number = case when $6 then $7 else whatsapp_number end,
                whatsapp_verified_at = case when $6 then null else whatsapp_verified_at end, updated_at = now() where id = $1`,
        [user.id, patch.full_name ?? null, patch.study_program ?? null, patch.cohort_year ?? null, patch.phone ?? null, waChanged, patch.whatsapp_number ?? null],
      );
      if (waChanged) {
        // Nomor baru: nonaktifkan WhatsApp sampai pengguna menyetujui ulang untuk nomor tersebut.
        await q.query("update notification_preferences set whatsapp_enabled = false, updated_at = now() where user_id = $1", [user.id]);
        await q.query("insert into consents (user_id, consent_type, version, granted, ip) values ($1,'whatsapp','1.0',false,$2)", [user.id, ip ?? null]);
      }
      await audit(q, { actor: user, action: "profile.update", entityType: "profile", entityId: user.id, meta: { whatsapp_changed: waChanged }, ip });
    });
  } catch (e) {
    if (isUniqueViolation(e)) throw conflict("Data sudah dipakai akun lain.");
    throw e;
  }
}

export async function updatePreferences(user: SessionUser, p: Preferences, ip?: string | null) {
  await tx(async (q) => {
    if (p.whatsapp_enabled) {
      const row = (await q.query<{ whatsapp_number: string | null }>("select whatsapp_number from profiles where id = $1", [user.id])).rows[0]!;
      if (!row.whatsapp_number) throw unprocessable("Isi nomor WhatsApp di profil terlebih dahulu.", { whatsapp_enabled: "Nomor WhatsApp belum diisi." });
    }
    const prev = (await q.query<{ whatsapp_enabled: boolean; email_enabled: boolean }>("select whatsapp_enabled, email_enabled from notification_preferences where user_id = $1", [user.id])).rows[0];
    await q.query(
      `insert into notification_preferences (user_id, email_enabled, whatsapp_enabled, reminders_enabled) values ($1,$2,$3,$4)
       on conflict (user_id) do update set email_enabled = $2, whatsapp_enabled = $3, reminders_enabled = $4, updated_at = now()`,
      [user.id, p.email_enabled, p.whatsapp_enabled, p.reminders_enabled],
    );
    // Persetujuan dicatat sebagai riwayat (append-only) setiap kali berubah.
    if ((prev?.whatsapp_enabled ?? false) !== p.whatsapp_enabled) {
      await q.query("insert into consents (user_id, consent_type, version, granted, ip) values ($1,'whatsapp','1.0',$2,$3)", [user.id, p.whatsapp_enabled, ip ?? null]);
    }
    if ((prev?.email_enabled ?? true) !== p.email_enabled) {
      await q.query("insert into consents (user_id, consent_type, version, granted, ip) values ($1,'email','1.0',$2,$3)", [user.id, p.email_enabled, ip ?? null]);
    }
    await audit(q, { actor: user, action: "preferences.update", entityType: "profile", entityId: user.id, meta: { ...p }, ip });
  });
}
