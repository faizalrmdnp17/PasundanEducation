import { query } from "../db";
import { notFound } from "../errors";

export type NotificationView = { id: string; type: string; title: string; body: string | null; link: string | null; read_at: Date | null; created_at: Date };

export async function listNotifications(userId: string, opts: { unreadOnly?: boolean; page?: number; size?: number } = {}) {
  const page = Math.max(1, opts.page ?? 1);
  const size = Math.min(100, opts.size ?? 20);
  const w = opts.unreadOnly ? "and read_at is null" : "";
  const total = (await query<{ n: number }>(`select count(*)::int as n from notifications where user_id = $1 ${w}`, [userId])).rows[0]!.n;
  const items = (await query<NotificationView>(
    `select id, type, title, body, link, read_at, created_at from notifications where user_id = $1 ${w} order by created_at desc limit ${size} offset ${(page - 1) * size}`, [userId],
  )).rows;
  return { items, total, page, size, totalPages: Math.max(1, Math.ceil(total / size)) };
}

export async function unreadCount(userId: string): Promise<number> {
  return (await query<{ n: number }>("select count(*)::int as n from notifications where user_id = $1 and read_at is null", [userId])).rows[0]!.n;
}

export async function markRead(userId: string, id: string) {
  const r = await query("update notifications set read_at = coalesce(read_at, now()) where id = $1 and user_id = $2", [id, userId]);
  if (!r.rowCount) throw notFound("Notifikasi tidak ditemukan.");
}

export async function markAllRead(userId: string) {
  await query("update notifications set read_at = now() where user_id = $1 and read_at is null", [userId]);
}

export async function listAnnouncements(opts: { includeUnpublished?: boolean; limit?: number } = {}) {
  return (await query<{ id: string; title: string; body: string | null; category: string; event_date: string | null; is_published: boolean }>(
    `select id, title, body, category, to_char(event_date, 'YYYY-MM-DD') as event_date, is_published from announcements
     ${opts.includeUnpublished ? "" : "where is_published"} order by event_date desc nulls last, created_at desc limit $1`, [opts.limit ?? 50],
  )).rows;
}
