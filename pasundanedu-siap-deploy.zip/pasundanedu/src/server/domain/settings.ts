import { query, tx } from "../db";
import type { Queryable } from "../db";
import { audit } from "../audit";
import type { Actor } from "../auth/types";

export type Settings = {
  payments_enabled: boolean;
  institution_name: string;
  institution_verified: boolean;
  bank_account_info: string;
};

export async function getSettings(q?: Queryable): Promise<Settings> {
  const r = q ? await q.query<{ key: string; value: unknown }>("select key, value from system_settings") : await query<{ key: string; value: unknown }>("select key, value from system_settings");
  const m = Object.fromEntries(r.rows.map((x) => [x.key, x.value])) as Record<string, unknown>;
  return {
    payments_enabled: m.payments_enabled === true,
    institution_name: typeof m.institution_name === "string" ? m.institution_name : "",
    institution_verified: m.institution_verified === true,
    bank_account_info: typeof m.bank_account_info === "string" ? m.bank_account_info : "",
  };
}

export async function paymentsEnabled(q?: Queryable): Promise<boolean> {
  return (await getSettings(q)).payments_enabled;
}

export async function updateSettings(actor: Actor, patch: Partial<Settings>, ip?: string) {
  await tx(async (q) => {
    for (const [k, v] of Object.entries(patch)) {
      if (v === undefined) continue;
      await q.query(
        `insert into system_settings (key, value, updated_by, updated_at) values ($1,$2::jsonb,$3,now())
         on conflict (key) do update set value = excluded.value, updated_by = excluded.updated_by, updated_at = now()`,
        [k, JSON.stringify(v), actor.id],
      );
    }
    await audit(q, { actor, action: "settings.update", entityType: "system_settings", meta: patch as Record<string, unknown>, ip });
  });
  return getSettings();
}
