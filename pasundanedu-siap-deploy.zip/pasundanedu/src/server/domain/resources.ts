import { one, query, tx } from "../db";
import { audit } from "../audit";
import { conflict, isUniqueViolation, notFound } from "../errors";
import { LIBRARY_TABS } from "@/lib/constants";
import { escapeLike } from "./services";
import type { Actor } from "../auth/types";
import type { z } from "zod";
import type { resourceUpsertSchema } from "@/lib/validation";

export type ResourceView = {
  id: string; kind: string; title: string; authors: string | null; publisher: string | null; year: number | null; description: string | null;
  access_type: "link" | "borrow"; external_url: string | null; duration_minutes: number | null; license_note: string | null;
  category_code: string | null; category_name: string | null; is_published: boolean; favorite: boolean;
};

export async function listResources(opts: {
  userId?: string | null; q?: string; tab?: string; kind?: string; year?: number; sort?: "title" | "year" | "newest";
  onlyFavorites?: boolean; includeUnpublished?: boolean; page?: number; size?: number;
}) {
  const page = Math.max(1, opts.page ?? 1);
  const size = Math.min(100, opts.size ?? 20);
  const params: unknown[] = [opts.userId ?? null];
  const where: string[] = [];
  if (!opts.includeUnpublished) where.push("r.is_published");
  if (opts.tab) {
    const t = LIBRARY_TABS.find((x) => x.key === opts.tab);
    if (t) { params.push([...t.kinds]); where.push(`r.kind = any($${params.length}::text[])`); }
  }
  if (opts.kind) { params.push(opts.kind); where.push(`r.kind = $${params.length}`); }
  if (opts.year) { params.push(opts.year); where.push(`r.year = $${params.length}`); }
  if (opts.q?.trim()) {
    params.push(`%${escapeLike(opts.q.trim())}%`);
    const n = params.length;
    where.push(`(r.title ilike $${n} or r.authors ilike $${n} or c.name ilike $${n} or r.year::text = trim(both '%' from $${n}))`);
  }
  if (opts.onlyFavorites) where.push("f.user_id is not null");
  const w = where.length ? `where ${where.join(" and ")}` : "";
  const from = `from learning_resources r left join resource_categories c on c.id = r.category_id left join resource_favorites f on f.resource_id = r.id and f.user_id = $1::uuid`;
  const order = { title: "r.title", year: "r.year desc nulls last, r.title", newest: "r.created_at desc" }[opts.sort ?? "newest"];
  const total = (await query<{ n: number }>(`select count(*)::int as n ${from} ${w}`, params)).rows[0]!.n;
  const items = (await query<ResourceView>(
    `select r.id, r.kind, r.title, r.authors, r.publisher, r.year, r.description, r.access_type, r.external_url, r.duration_minutes, r.license_note,
            c.code as category_code, c.name as category_name, r.is_published, (f.user_id is not null) as favorite
     ${from} ${w} order by ${order} limit ${size} offset ${(page - 1) * size}`, params,
  )).rows;
  return { items, total, page, size, totalPages: Math.max(1, Math.ceil(total / size)) };
}

export async function setFavorite(userId: string, resourceId: string, on: boolean) {
  const exists = await one("select 1 as x from learning_resources where id = $1 and is_published", [resourceId]);
  if (!exists) throw notFound("Sumber belajar tidak ditemukan.");
  if (on) await query("insert into resource_favorites (user_id, resource_id) values ($1,$2) on conflict do nothing", [userId, resourceId]);
  else await query("delete from resource_favorites where user_id = $1 and resource_id = $2", [userId, resourceId]);
  return { favorite: on };
}

/** Membuka sumber berbasis tautan: dicatat ke riwayat akses lalu mengembalikan URL tujuan. */
export async function openResource(userId: string, resourceId: string) {
  const r = await one<{ id: string; access_type: string; external_url: string | null; title: string }>(
    "select id, access_type, external_url, title from learning_resources where id = $1 and is_published", [resourceId],
  );
  if (!r) throw notFound("Sumber belajar tidak ditemukan.");
  if (r.access_type !== "link" || !r.external_url) throw conflict("Sumber ini dipinjam melalui pengajuan, bukan tautan langsung.", "not_a_link");
  await query("insert into resource_access_logs (user_id, resource_id, action) values ($1,$2,'open')", [userId, resourceId]);
  return { url: r.external_url, title: r.title };
}

export async function recentAccess(userId: string, limit = 10) {
  return (await query<{ resource_id: string; title: string; kind: string; last_at: Date }>(
    `select l.resource_id, r.title, r.kind, max(l.created_at) as last_at from resource_access_logs l join learning_resources r on r.id = l.resource_id
     where l.user_id = $1 group by l.resource_id, r.title, r.kind order by max(l.created_at) desc limit $2`, [userId, limit],
  )).rows;
}

export async function upsertResource(actor: Actor, input: z.infer<typeof resourceUpsertSchema>, id?: string, ip?: string) {
  try {
    return await tx(async (q) => {
      const vals = [
        input.category_id ?? null, input.kind, input.title, input.authors ?? null, input.publisher ?? null, input.year ?? null, input.description ?? null,
        input.access_type, input.external_url ?? null, input.duration_minutes ?? null, input.license_note ?? null, input.is_published,
      ];
      if (input.access_type === "link" && !input.external_url) throw conflict("Sumber bertipe tautan wajib memiliki URL.");
      let rid = id;
      if (id) {
        const r = await q.query(
          `update learning_resources set category_id=$2, kind=$3, title=$4, authors=$5, publisher=$6, year=$7, description=$8, access_type=$9,
                  external_url=$10, duration_minutes=$11, license_note=$12, is_published=$13, updated_at=now() where id=$1`, [id, ...vals]);
        if (!r.rowCount) throw notFound("Sumber belajar tidak ditemukan.");
      } else {
        rid = (await q.query<{ id: string }>(
          `insert into learning_resources (category_id, kind, title, authors, publisher, year, description, access_type, external_url, duration_minutes, license_note, is_published, created_by)
           values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) returning id`, [...vals, actor.id])).rows[0]!.id;
      }
      await audit(q, { actor, action: id ? "resource.update" : "resource.create", entityType: "learning_resource", entityId: rid, meta: { title: input.title }, ip });
      return rid!;
    });
  } catch (e) {
    if (isUniqueViolation(e)) throw conflict("Data sudah ada.");
    throw e;
  }
}

export async function listResourceCategories() {
  return (await query<{ id: string; code: string; name: string }>("select id, code, name from resource_categories order by sort_order")).rows;
}
