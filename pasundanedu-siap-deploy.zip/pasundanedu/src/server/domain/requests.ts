import { createHash } from "node:crypto";
import { dbq, one, query, tx } from "../db";
import type { Queryable } from "../db";
import { audit } from "../audit";
import { badRequest, conflict, forbidden, isUniqueViolation, notFound, unprocessable } from "../errors";
import { rateLimit } from "../rate-limit";
import { notify } from "../notify";
import { hasRole, type Actor, type SessionUser } from "../auth/types";
import { bookSlot, cancelAppointmentsForRequest, getAppointmentForRequest } from "./appointments";
import { paymentsEnabled } from "./settings";
import { escapeLike } from "./services";
import {
  canTransition, REQUEST_STATUSES, STATUS_LABEL, STATUS_TRANSITIONS, STUDENT_CANCELLABLE, TERMINAL_STATUSES, type RequestStatus,
} from "@/lib/constants";
import { formatDateTime } from "@/lib/format";
import { fileStore, newStorageKey, signedDownloadPath, validateUpload } from "../storage";
import { waLink } from "@/lib/phone";
import type { Role } from "@/lib/constants";

/* ------------------------------------------------------------------ */
/* Hak akses                                                           */
/* ------------------------------------------------------------------ */

type ReqAccessRow = { id: string; student_id: string; assignee_id: string | null; service_id: string; status: RequestStatus };

/** Pengelola kasus: admin; penanggung jawab; atau staf yang ditugaskan pada layanan bila kasus belum punya penanggung jawab. */
async function canManage(q: Queryable, actor: Actor, r: ReqAccessRow): Promise<boolean> {
  if (hasRole(actor, "admin")) return true;
  if (!hasRole(actor, "dosen", "petugas")) return false;
  if (r.assignee_id === actor.id) return true;
  if (r.assignee_id) return false;
  const a = await q.query("select 1 from service_assignments where service_id = $1 and staff_id = $2", [r.service_id, actor.id]);
  return a.rowCount > 0;
}

async function loadAccess(q: Queryable, actor: Actor, id: string, lock = false): Promise<{ r: ReqAccessRow & { request_number: string; payment_status: string; price_idr: number }; manage: boolean; owner: boolean }> {
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw notFound("Pengajuan tidak ditemukan.");
  const r = (await q.query<ReqAccessRow & { request_number: string; payment_status: string; price_idr: number }>(
    `select id, student_id, assignee_id, service_id, status, request_number, payment_status, price_idr from service_requests where id = $1 ${lock ? "for update" : ""}`, [id],
  )).rows[0];
  const owner = !!r && r.student_id === actor.id;
  const manage = !!r && (await canManage(q, actor, r));
  // Pengguna lain mendapat 404 (bukan 403) agar keberadaan pengajuan tidak bocor.
  if (!r || (!owner && !manage)) throw notFound("Pengajuan tidak ditemukan.");
  return { r, manage, owner };
}

const link = (manage: boolean, id: string) => (manage ? `/pengajuan/${id}` : `/riwayat/${id}`);

/* ------------------------------------------------------------------ */
/* Pembuatan pengajuan                                                  */
/* ------------------------------------------------------------------ */

export type CreateRequestInput = {
  service_id: string; slot_id?: string; student_note?: string; details?: Record<string, string | number | boolean>; resource_id?: string;
};

async function pickAssignee(q: Queryable, serviceId: string): Promise<string | null> {
  const r = await q.query<{ staff_id: string }>(
    `select sa.staff_id from service_assignments sa
     join profiles p on p.id = sa.staff_id and p.status = 'active'
     left join service_requests r on r.assignee_id = sa.staff_id and r.status not in ('completed','rejected','cancelled')
     where sa.service_id = $1 group by sa.staff_id order by count(r.id), sa.staff_id limit 1`,
    [serviceId],
  );
  return r.rows[0]?.staff_id ?? null;
}

export async function createServiceRequest(
  user: SessionUser, input: CreateRequestInput, idemKey: string | null, meta: { ip?: string | null },
): Promise<{ id: string; request_number: string; duplicate: boolean }> {
  if (!user.roles.includes("mahasiswa")) throw forbidden("Hanya akun mahasiswa yang dapat mengajukan layanan.");
  await rateLimit(`req:${user.id}`, { limit: 30, windowSec: 3600 });
  const key = idemKey ? createHash("sha256").update(idemKey).digest("hex").slice(0, 40) : null;

  const existingByKey = async () =>
    key ? one<{ id: string; request_number: string }>("select id, request_number from service_requests where student_id = $1 and idempotency_key = $2", [user.id, key]) : null;

  const replay = await existingByKey();
  if (replay) return { ...replay, duplicate: true };

  try {
    return await tx(async (q) => {
      const svc = (await q.query<{
        id: string; name: string; price_idr: number; requires_appointment: boolean; requires_documents: boolean; is_active: boolean;
      }>("select id, name, price_idr, requires_appointment, requires_documents, is_active from services where id = $1", [input.service_id])).rows[0];
      if (!svc || !svc.is_active) throw notFound("Layanan tidak tersedia.");
      if (svc.requires_appointment && !input.slot_id) throw unprocessable("Pilih jadwal konsultasi.", { slot_id: "Pilih salah satu jadwal." });
      if (!svc.requires_appointment && input.slot_id) throw unprocessable("Layanan ini tidak memakai jadwal.", { slot_id: "Layanan ini tidak memakai jadwal." });

      // Tanpa kunci idempotensi dari klien: tolak duplikat identik dalam 30 detik (klik ganda / jaringan terputus).
      if (!key) {
        const dup = (await q.query<{ id: string; request_number: string }>(
          `select id, request_number from service_requests
           where student_id = $1 and service_id = $2 and coalesce(student_note,'') = $3 and created_at > now() - interval '30 seconds'
             and status not in ('cancelled','rejected') order by created_at desc limit 1`,
          [user.id, svc.id, input.student_note ?? ""],
        )).rows[0];
        if (dup) return { ...dup, duplicate: true };
      }

      const payOn = await paymentsEnabled(q);
      const price = payOn ? svc.price_idr : 0;
      const seq = (await q.query<{ n: number }>("select nextval('request_number_seq')::int as n")).rows[0]!.n;
      const year = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta", year: "numeric" }).format(new Date());
      const number = `PE-${year}-${String(seq).padStart(5, "0")}`;

      const assignee = input.slot_id ? null : await pickAssignee(q, svc.id);
      const details: Record<string, unknown> = { ...(input.details ?? {}) };
      if (input.resource_id) {
        const res = (await q.query<{ title: string }>("select title from learning_resources where id = $1 and is_published", [input.resource_id])).rows[0];
        if (!res) throw notFound("Sumber belajar tidak ditemukan.");
        details.resource_id = input.resource_id;
        details.resource_title = res.title;
      }

      const ins = await q.query<{ id: string }>(
        `insert into service_requests (request_number, student_id, service_id, assignee_id, status, payment_status, price_idr, student_note, details, idempotency_key)
         values ($1,$2,$3,$4,'submitted',$5,$6,$7,$8::jsonb,$9) returning id`,
        [number, user.id, svc.id, assignee, price > 0 ? "pending" : "not_required", price, input.student_note ?? null, JSON.stringify(details), key],
      );
      const id = ins.rows[0]!.id;

      let scheduleText = "Belum ditentukan";
      let staffId = assignee;
      if (input.slot_id) {
        const b = await bookSlot(q, { slotId: input.slot_id, requestId: id, studentId: user.id, serviceId: svc.id });
        staffId = b.staffId;
        scheduleText = formatDateTime(b.startsAt);
        await q.query("update service_requests set assignee_id = $2 where id = $1", [id, b.staffId]);
      }
      await q.query(`insert into request_status_history (request_id, from_status, to_status, changed_by, note) values ($1,null,'submitted',$2,'Pengajuan dibuat')`, [id, user.id]);

      await notify(q, { userId: user.id, type: "request_created", title: "Pengajuan terkirim", body: `${svc.name} · ${number}. Menunggu konfirmasi.`, link: `/riwayat/${id}` });
      if (staffId) {
        await notify(q, {
          userId: staffId, type: "request_new", title: `Pengajuan baru ${number}`, body: `${svc.name} · ${scheduleText}`, link: `/pengajuan/${id}`,
          template: "request_new_staff", vars: { nomor_pengajuan: number, layanan: svc.name, jadwal: scheduleText }, dedupe: `new:${id}`,
        });
      } else {
        const admins = await q.query<{ user_id: string }>("select ur.user_id from user_roles ur join roles r on r.id = ur.role_id where r.code = 'admin'");
        for (const a of admins.rows) {
          await notify(q, { userId: a.user_id, type: "request_unassigned", title: `Pengajuan ${number} belum memiliki penanggung jawab`, body: svc.name, link: `/pengajuan/${id}` });
        }
      }
      await audit(q, { actor: user, action: "request.create", entityType: "service_request", entityId: id, meta: { number, service: svc.name }, ip: meta.ip });
      return { id, request_number: number, duplicate: false };
    });
  } catch (e) {
    // Dua permintaan serentak dengan kunci sama: yang kalah mengambil hasil pemenang.
    if (key && isUniqueViolation(e, "service_requests_idem_uq")) {
      const r = await existingByKey();
      if (r) return { ...r, duplicate: true };
    }
    throw e;
  }
}

/* ------------------------------------------------------------------ */
/* Daftar & detail                                                      */
/* ------------------------------------------------------------------ */

export type RequestListItem = {
  id: string; request_number: string; status: RequestStatus; payment_status: string; price_idr: number; created_at: Date; updated_at: Date;
  service_id: string; service_name: string; service_icon: string; student_name: string; student_npm: string | null; assignee_name: string | null;
  appointment_at: Date | null;
};

export async function listRequests(
  actor: Actor,
  opts: { as: "student" | "staff"; status?: string; q?: string; page?: number; size?: number; unassigned?: boolean },
) {
  const page = Math.max(1, opts.page ?? 1);
  const size = Math.min(100, opts.size ?? 20);
  // Parameter hanya ditambahkan bila dipakai: PostgreSQL menolak parameter yang tidak direferensikan.
  const params: unknown[] = [];
  const where: string[] = [];
  if (opts.as === "student") {
    params.push(actor.id);
    where.push("r.student_id = $1");
  } else if (!hasRole(actor, "admin")) {
    if (!hasRole(actor, "dosen", "petugas")) throw forbidden();
    params.push(actor.id);
    where.push(`(r.assignee_id = $1 or (r.assignee_id is null and exists (select 1 from service_assignments sa where sa.service_id = r.service_id and sa.staff_id = $1)))`);
  }
  if (opts.status) {
    const list = opts.status.split(",").filter((s) => (REQUEST_STATUSES as readonly string[]).includes(s));
    if (list.length) { params.push(list); where.push(`r.status = any($${params.length}::text[])`); }
  }
  if (opts.unassigned) where.push("r.assignee_id is null");
  if (opts.q?.trim()) {
    params.push(`%${escapeLike(opts.q.trim())}%`);
    const n = params.length;
    where.push(`(r.request_number ilike $${n} or s.name ilike $${n} or st.full_name ilike $${n} or st.npm ilike $${n})`);
  }
  const w = where.length ? `where ${where.join(" and ")}` : "";
  const from = `from service_requests r join services s on s.id = r.service_id join profiles st on st.id = r.student_id left join profiles asg on asg.id = r.assignee_id`;
  const total = (await query<{ n: number }>(`select count(*)::int as n ${from} ${w}`, params)).rows[0]!.n;
  const rows = (await query<RequestListItem>(
    `select r.id, r.request_number, r.status, r.payment_status, r.price_idr, r.created_at, r.updated_at, s.id as service_id, s.name as service_name,
            s.icon as service_icon, st.full_name as student_name, st.npm as student_npm, asg.full_name as assignee_name,
            (select a.starts_at from appointments a where a.request_id = r.id and a.status = 'booked' limit 1) as appointment_at
     ${from} ${w} order by r.created_at desc limit ${size} offset ${(page - 1) * size}`,
    params,
  )).rows;
  return { items: rows, total, page, size, totalPages: Math.max(1, Math.ceil(total / size)) };
}

export type RequestDetail = Awaited<ReturnType<typeof getRequestDetail>>;

export async function getRequestDetail(actor: Actor, id: string) {
  const { r: acc, manage, owner } = await loadAccess(dbq, actor, id);
  const staffView = manage && !owner;

  const req = (await query<{
    id: string; request_number: string; status: RequestStatus; payment_status: string; price_idr: number; student_note: string | null;
    details: Record<string, unknown>; created_at: Date; updated_at: Date; completed_at: Date | null; assignee_id: string | null;
    service_id: string; service_name: string; service_slug: string; requires_documents: boolean; requires_appointment: boolean; cancellation_policy: string;
    student_id: string; student_name: string; student_npm: string | null; student_prodi: string | null; student_year: number | null;
    assignee_name: string | null; assignee_wa: string | null; assignee_wa_verified: boolean;
  }>(
    `select r.id, r.request_number, r.status, r.payment_status, r.price_idr, r.student_note, r.details, r.created_at, r.updated_at, r.completed_at,
            r.assignee_id, s.id as service_id, s.name as service_name, s.slug as service_slug, s.requires_documents, s.requires_appointment, s.cancellation_policy,
            st.id as student_id, st.full_name as student_name, st.npm as student_npm, st.study_program as student_prodi, st.cohort_year as student_year,
            asg.full_name as assignee_name, asg.whatsapp_number as assignee_wa, (asg.whatsapp_verified_at is not null) as assignee_wa_verified
     from service_requests r join services s on s.id = r.service_id join profiles st on st.id = r.student_id left join profiles asg on asg.id = r.assignee_id
     where r.id = $1`, [id],
  )).rows[0]!;

  const [history, messages, documents, appointment, payment, feedback] = await Promise.all([
    query<{ id: string; from_status: string | null; to_status: string; note: string | null; created_at: Date; by_name: string | null }>(
      `select h.id, h.from_status, h.to_status, h.note, h.created_at, p.full_name as by_name
       from request_status_history h left join profiles p on p.id = h.changed_by where h.request_id = $1 order by h.created_at, h.id`, [id]),
    query<{ id: string; body: string; visibility: string; created_at: Date; author_id: string; author_name: string; author_staff: boolean }>(
      `select m.id, m.body, m.visibility, m.created_at, m.author_id, p.full_name as author_name, (m.author_id <> $2) as author_staff
       from request_messages m join profiles p on p.id = m.author_id
       where m.request_id = $1 ${staffView ? "" : "and m.visibility = 'student'"} order by m.created_at`, [id, req.student_id]),
    query<{ id: string; kind: string; original_name: string; mime_type: string; size_bytes: number; verification_status: string; verification_note: string | null; created_at: Date; uploader_name: string }>(
      `select d.id, d.kind, d.original_name, d.mime_type, d.size_bytes, d.verification_status, d.verification_note, d.created_at, p.full_name as uploader_name
       from request_documents d join profiles p on p.id = d.uploaded_by where d.request_id = $1 order by d.created_at`, [id]),
    getAppointmentForRequest(id),
    one<{ id: string; amount_idr: number; status: string; provider: string; paid_at: Date | null; proof_document_id: string | null; created_at: Date }>(
      `select id, amount_idr, status, provider, paid_at, proof_document_id, created_at from payments where request_id = $1 order by created_at desc limit 1`, [id]),
    one<{ rating: number; comment: string | null; created_at: Date }>("select rating, comment, created_at from service_feedback where request_id = $1", [id]),
  ]);

  const status = req.status;
  const next = staffView ? STATUS_TRANSITIONS[status] : [];
  const abilities = {
    manage: staffView,
    owner,
    nextStatuses: staffView ? next.filter((s) => !(req.price_idr > 0 && !["paid", "waived"].includes(req.payment_status) && ["in_progress", "completed"].includes(s))) : [],
    canCancel: owner && STUDENT_CANCELLABLE.includes(status),
    canFeedback: owner && status === "completed" && !feedback,
    canUpload: !TERMINAL_STATUSES.includes(status) || (manage && status === "completed"),
    canPay: owner && req.price_idr > 0 && ["pending"].includes(req.payment_status) && !TERMINAL_STATUSES.includes(status),
    canVerifyPayment: staffView && hasRole(actor, "admin", "petugas"),
  };
  const downloads: Record<string, string> = {};
  for (const d of documents.rows) downloads[d.id] = signedDownloadPath(d.id, actor.id);

  return {
    request: req,
    history: history.rows,
    messages: messages.rows,
    documents: documents.rows.map((d) => ({ ...d, url: downloads[d.id]! })),
    appointment,
    payment,
    feedback,
    abilities,
    // Tombol WhatsApp hanya untuk nomor kerja penanggung jawab yang sudah diverifikasi pengelola.
    contact: owner && req.assignee_wa && req.assignee_wa_verified
      ? { name: req.assignee_name!, wa: waLink(req.assignee_wa, `Halo, saya ${actor.fullName ?? "mahasiswa"}. Terkait pengajuan ${req.request_number} (${req.service_name}) di PasundanEdu.`) }
      : null,
    viewAs: owner ? ("student" as const) : ("staff" as const),
    id: acc.id,
  };
}

/* ------------------------------------------------------------------ */
/* Perubahan status                                                     */
/* ------------------------------------------------------------------ */

export async function changeStatus(actor: Actor, id: string, to: RequestStatus, note: string | undefined, meta: { ip?: string | null }) {
  return tx(async (q) => {
    const { r, manage, owner } = await loadAccess(q, actor, id, true);
    if (!manage) throw forbidden("Anda tidak berwenang mengubah status pengajuan ini.");
    if (owner) throw forbidden("Anda tidak dapat memproses pengajuan Anda sendiri.");
    const from = r.status;
    if (from === to) throw conflict("Pengajuan sudah berstatus tersebut.");
    if (!canTransition(from, to)) {
      throw conflict(`Perubahan status dari "${STATUS_LABEL[from]}" ke "${STATUS_LABEL[to]}" tidak diizinkan.`, "invalid_transition");
    }
    if (["rejected", "awaiting_information"].includes(to) && !note) {
      throw unprocessable("Catatan wajib diisi agar mahasiswa tahu alasannya.", { note: "Catatan wajib diisi." });
    }
    if (to === "awaiting_payment" && r.price_idr <= 0) throw conflict("Layanan ini tidak berbayar.", "no_payment_required");
    if (["in_progress", "completed"].includes(to) && r.price_idr > 0 && !["paid", "waived"].includes(r.payment_status)) {
      throw conflict("Pembayaran belum lunas atau belum diverifikasi.", "payment_required");
    }
    await q.query(
      `update service_requests set status = $2, updated_at = now(), completed_at = case when $2 = 'completed' then now() else completed_at end,
              assignee_id = coalesce(assignee_id, $3) where id = $1`,
      [id, to, actor.id],
    );
    if (to === "cancelled" || to === "rejected") await cancelAppointmentsForRequest(q, id);
    if (to === "completed") await q.query("update appointments set status = 'completed', updated_at = now() where request_id = $1 and status = 'booked'", [id]);
    const refundNote = (to === "cancelled" || to === "rejected") && r.payment_status === "paid" ? " Pembayaran sudah lunas: pengembalian dana diproses petugas sesuai kebijakan." : "";
    const hist = await q.query<{ id: string }>(
      `insert into request_status_history (request_id, from_status, to_status, changed_by, note) values ($1,$2,$3,$4,$5) returning id`,
      [id, from, to, actor.id, ((note ?? "") + refundNote).trim() || null],
    );
    const svc = (await q.query<{ name: string }>("select s.name from services s join service_requests r on r.service_id = s.id where r.id = $1", [id])).rows[0]!;
    await notify(q, {
      userId: r.student_id, type: "status_changed", title: `Status pengajuan: ${STATUS_LABEL[to]}`,
      body: `${svc.name} · ${r.request_number}${note ? ` — ${note}` : ""}`, link: `/riwayat/${id}`,
      template: "request_status_student",
      vars: { nomor_pengajuan: r.request_number, layanan: svc.name, status: STATUS_LABEL[to], catatan: note ?? "" },
      dedupe: `status:${hist.rows[0]!.id}`,
    });
    await audit(q, { actor, action: "request.status", entityType: "service_request", entityId: id, meta: { from, to }, ip: meta.ip });
    return { id, from, to };
  });
}

export async function cancelByStudent(user: SessionUser, id: string, reason: string | undefined, meta: { ip?: string | null }) {
  return tx(async (q) => {
    const { r, owner } = await loadAccess(q, user, id, true);
    if (!owner) throw forbidden();
    if (!STUDENT_CANCELLABLE.includes(r.status)) throw conflict("Pengajuan tidak dapat dibatalkan pada status ini. Hubungi petugas.", "not_cancellable");
    const appt = (await q.query<{ starts_at: Date }>("select starts_at from appointments where request_id = $1 and status = 'booked'", [id])).rows[0];
    if (appt && new Date(appt.starts_at).getTime() < Date.now() + 2 * 3600_000) {
      throw conflict("Jadwal dimulai kurang dari 2 jam lagi. Hubungi dosen/petugas untuk membatalkan.", "too_late_to_cancel");
    }
    await q.query("update service_requests set status = 'cancelled', updated_at = now() where id = $1", [id]);
    await cancelAppointmentsForRequest(q, id);
    const refundNote = r.payment_status === "paid" ? " Pembayaran sudah lunas: ajukan pengembalian dana ke petugas sesuai kebijakan." : "";
    await q.query(
      `insert into request_status_history (request_id, from_status, to_status, changed_by, note) values ($1,$2,'cancelled',$3,$4)`,
      [id, r.status, user.id, (reason ?? "Dibatalkan oleh mahasiswa") + refundNote],
    );
    if (r.assignee_id) {
      await notify(q, { userId: r.assignee_id, type: "request_cancelled", title: `Pengajuan ${r.request_number} dibatalkan mahasiswa`, body: reason, link: `/pengajuan/${id}` });
    }
    await audit(q, { actor: user, action: "request.cancel", entityType: "service_request", entityId: id, ip: meta.ip });
    return { id };
  });
}

export async function rescheduleAppointment(actor: Actor, id: string, newSlotId: string, note: string | undefined, meta: { ip?: string | null }) {
  return tx(async (q) => {
    const { r, manage, owner } = await loadAccess(q, actor, id, true);
    if (!manage || owner) throw forbidden();
    if (TERMINAL_STATUSES.includes(r.status)) throw conflict("Pengajuan sudah selesai/ditutup.");
    await cancelAppointmentsForRequest(q, id);
    const b = await bookSlot(q, { slotId: newSlotId, requestId: id, studentId: r.student_id, serviceId: r.service_id });
    await q.query("update service_requests set assignee_id = $2, updated_at = now() where id = $1", [id, b.staffId]);
    await q.query(
      `insert into request_status_history (request_id, from_status, to_status, changed_by, note) values ($1,$2,$2,$3,$4)`,
      [id, r.status, actor.id, `Jadwal diubah ke ${formatDateTime(b.startsAt)}${note ? ` — ${note}` : ""}`],
    );
    await notify(q, { userId: r.student_id, type: "rescheduled", title: "Jadwal diubah", body: `${r.request_number} · ${formatDateTime(b.startsAt)}`, link: `/riwayat/${id}` });
    await audit(q, { actor, action: "request.reschedule", entityType: "service_request", entityId: id, ip: meta.ip });
    return { id, starts_at: b.startsAt };
  });
}

/* ------------------------------------------------------------------ */
/* Pesan, dokumen, umpan balik                                          */
/* ------------------------------------------------------------------ */

export async function addMessage(actor: Actor, id: string, body: string, visibility: "student" | "internal", meta: { ip?: string | null }) {
  await rateLimit(`msg:${actor.id}`, { limit: 60, windowSec: 600 });
  return tx(async (q) => {
    const { r, manage, owner } = await loadAccess(q, actor, id, false);
    if (visibility === "internal" && (!manage || owner)) throw forbidden("Catatan internal hanya untuk staf.");
    const ins = await q.query<{ id: string }>(
      "insert into request_messages (request_id, author_id, body, visibility) values ($1,$2,$3,$4) returning id", [id, actor.id, body, visibility],
    );
    await q.query("update service_requests set updated_at = now() where id = $1", [id]);
    if (visibility === "student") {
      if (owner && r.assignee_id) {
        await notify(q, { userId: r.assignee_id, type: "message", title: `Pesan baru · ${r.request_number}`, body: body.slice(0, 140), link: `/pengajuan/${id}` });
      } else if (!owner) {
        await notify(q, { userId: r.student_id, type: "message", title: `Pesan dari petugas · ${r.request_number}`, body: body.slice(0, 140), link: `/riwayat/${id}` });
      }
    }
    await audit(q, { actor, action: "request.message", entityType: "service_request", entityId: id, meta: { visibility }, ip: meta.ip });
    return ins.rows[0]!.id;
  });
}

export async function addDocument(actor: Actor, id: string, file: { name: string; data: Buffer }, kind: string, meta: { ip?: string | null }) {
  const v = validateUpload(file.name, file.data);
  if (!["lampiran", "naskah", "bukti_pembayaran", "hasil"].includes(kind)) throw badRequest("Jenis dokumen tidak valid.");
  await rateLimit(`upload:${actor.id}`, { limit: 30, windowSec: 3600 });
  const key = newStorageKey();
  let stored = false;
  try {
    const docId = await tx(async (q) => {
      const { r, manage, owner } = await loadAccess(q, actor, id, false);
      if (kind === "hasil" && !manage) throw forbidden("Hanya staf yang dapat mengunggah hasil.");
      if (kind === "bukti_pembayaran" && !owner) throw forbidden("Bukti pembayaran diunggah oleh mahasiswa.");
      if (TERMINAL_STATUSES.includes(r.status) && !(manage && kind === "hasil")) throw conflict("Pengajuan sudah ditutup; dokumen tidak dapat ditambahkan.");
      const count = (await q.query<{ n: number }>("select count(*)::int as n from request_documents where request_id = $1", [id])).rows[0]!.n;
      if (count >= 15) throw unprocessable("Maksimal 15 dokumen per pengajuan.");
      await fileStore.put(key, file.data);
      stored = true;
      const ins = await q.query<{ id: string }>(
        `insert into request_documents (request_id, uploaded_by, kind, original_name, storage_key, mime_type, size_bytes, sha256)
         values ($1,$2,$3,$4,$5,$6,$7,$8) returning id`,
        [id, actor.id, kind, v.safeName, key, v.mime, file.data.length, v.sha256],
      );
      await q.query("update service_requests set updated_at = now() where id = $1", [id]);
      const other = owner ? r.assignee_id : r.student_id;
      if (other) await notify(q, { userId: other, type: "document", title: `Dokumen baru · ${r.request_number}`, body: v.safeName, link: link(!owner, id) });
      await audit(q, { actor, action: "document.upload", entityType: "service_request", entityId: id, meta: { kind, bytes: file.data.length, sha256: v.sha256 }, ip: meta.ip });
      return ins.rows[0]!.id;
    });
    return docId;
  } catch (e) {
    if (stored) await fileStore.remove(key).catch(() => {});
    throw e;
  }
}

/** Mengambil berkas untuk diunduh setelah memeriksa ulang hak akses (selain tanda tangan URL). */
export async function getDocumentForDownload(actor: Actor, docId: string) {
  if (!/^[0-9a-f-]{36}$/i.test(docId)) throw notFound("Berkas tidak ditemukan.");
  const d = await one<{ id: string; request_id: string; original_name: string; mime_type: string; storage_key: string }>(
    "select id, request_id, original_name, mime_type, storage_key from request_documents where id = $1", [docId],
  );
  if (!d) throw notFound("Berkas tidak ditemukan.");
  await loadAccess(dbq, actor, d.request_id);
  const data = await fileStore.get(d.storage_key).catch(() => { throw notFound("Berkas tidak ditemukan."); });
  await audit(null, { actor, action: "document.download", entityType: "request_document", entityId: docId });
  return { ...d, data };
}

export async function verifyDocument(actor: Actor, docId: string, status: "verified" | "rejected", note: string | undefined, meta: { ip?: string | null }) {
  return tx(async (q) => {
    const d = (await q.query<{ request_id: string; original_name: string }>("select request_id, original_name from request_documents where id = $1 for update", [docId])).rows[0];
    if (!d) throw notFound("Berkas tidak ditemukan.");
    const { r, manage, owner } = await loadAccess(q, actor, d.request_id);
    if (!manage || owner) throw forbidden();
    if (status === "rejected" && !note) throw unprocessable("Catatan wajib diisi untuk dokumen yang ditolak.", { note: "Catatan wajib diisi." });
    await q.query(
      "update request_documents set verification_status = $2, verified_by = $3, verified_at = now(), verification_note = $4 where id = $1",
      [docId, status, actor.id, note ?? null],
    );
    await notify(q, {
      userId: r.student_id, type: "document_verified", title: status === "verified" ? "Dokumen terverifikasi" : "Dokumen perlu diperbaiki",
      body: `${d.original_name}${note ? ` — ${note}` : ""}`, link: `/riwayat/${r.id}`,
    });
    await audit(q, { actor, action: `document.${status}`, entityType: "request_document", entityId: docId, ip: meta.ip });
  });
}

export async function submitFeedback(user: SessionUser, id: string, rating: number, comment: string | undefined) {
  return tx(async (q) => {
    const { r, owner } = await loadAccess(q, user, id, false);
    if (!owner) throw forbidden();
    if (r.status !== "completed") throw conflict("Umpan balik hanya dapat diberikan setelah layanan selesai.");
    try {
      await q.query("insert into service_feedback (request_id, student_id, rating, comment) values ($1,$2,$3,$4)", [id, user.id, rating, comment ?? null]);
    } catch (e) {
      if (isUniqueViolation(e)) throw conflict("Anda sudah memberikan umpan balik untuk pengajuan ini.");
      throw e;
    }
  });
}

export const _internal = { loadAccess, canManage };
export type { Role };
