import { createHmac, timingSafeEqual } from "node:crypto";
import { env } from "../env";
import { query, tx } from "../db";
import type { Queryable } from "../db";
import { audit } from "../audit";
import { badRequest, conflict, forbidden, isUniqueViolation, notFound } from "../errors";
import { notify } from "../notify";
import { paymentsEnabled } from "./settings";
import { addDocument } from "./requests";
import { hasRole, type Actor, type SessionUser } from "../auth/types";
import { formatRupiah } from "@/lib/format";
import { PAYMENT_STATUS_LABEL } from "@/lib/constants";

/**
 * Pembayaran. Status pembayaran (payments / service_requests.payment_status) terpisah dari status layanan.
 * Saat ini tersedia: transfer manual dengan verifikasi petugas, serta endpoint webhook generik bertanda tangan
 * HMAC untuk payment gateway. Adapter gateway tertentu (Midtrans/Xendit/dll.) BELUM diimplementasikan.
 * Pembayaran nonaktif secara bawaan dan hanya berlaku setelah pengelola mengaktifkannya.
 */

export async function startPayment(user: SessionUser, requestId: string, idemKey: string | null, ip?: string | null) {
  return tx(async (q) => {
    if (!(await paymentsEnabled(q))) throw conflict("Pembayaran belum diaktifkan oleh pengelola.", "payments_disabled");
    const r = (await q.query<{ id: string; student_id: string; price_idr: number; payment_status: string; status: string; request_number: string }>(
      "select id, student_id, price_idr, payment_status, status, request_number from service_requests where id = $1 for update", [requestId],
    )).rows[0];
    if (!r || r.student_id !== user.id) throw notFound("Pengajuan tidak ditemukan.");
    if (r.price_idr <= 0) throw conflict("Layanan ini gratis.", "free_service");
    if (["cancelled", "rejected", "completed"].includes(r.status)) throw conflict("Pengajuan sudah ditutup.");
    // Idempoten: bila sudah ada pembayaran berjalan, kembalikan yang sama.
    const active = (await q.query<{ id: string; status: string }>(
      "select id, status from payments where request_id = $1 and status in ('pending','awaiting_verification','paid')", [requestId],
    )).rows[0];
    if (active) return { id: active.id, status: active.status, amount_idr: r.price_idr, duplicate: true };
    try {
      const p = await q.query<{ id: string }>(
        `insert into payments (request_id, amount_idr, provider, status, idempotency_key) values ($1,$2,'manual_transfer','pending',$3) returning id`,
        [requestId, r.price_idr, idemKey],
      );
      await q.query("update service_requests set payment_status = 'pending', updated_at = now() where id = $1", [requestId]);
      await q.query(
        `insert into payment_events (payment_id, provider, event_type, payload) values ($1,'manual_transfer','created',$2::jsonb)`,
        [p.rows[0]!.id, JSON.stringify({ amount_idr: r.price_idr })],
      );
      await audit(q, { actor: user, action: "payment.start", entityType: "payment", entityId: p.rows[0]!.id, meta: { amount_idr: r.price_idr }, ip });
      return { id: p.rows[0]!.id, status: "pending", amount_idr: r.price_idr, duplicate: false };
    } catch (e) {
      if (isUniqueViolation(e)) throw conflict("Pembayaran untuk pengajuan ini sudah dibuat.");
      throw e;
    }
  });
}

export async function submitPaymentProof(user: SessionUser, requestId: string, file: { name: string; data: Buffer }, ip?: string | null) {
  const pay = (await query<{ id: string; status: string }>(
    "select id, status from payments where request_id = $1 and status in ('pending','awaiting_verification') order by created_at desc limit 1", [requestId],
  )).rows[0];
  if (!pay) throw conflict("Mulai pembayaran terlebih dahulu.", "no_payment");
  const docId = await addDocument(user, requestId, file, "bukti_pembayaran", { ip });
  await tx(async (q) => {
    await q.query("update payments set status = 'awaiting_verification', proof_document_id = $2, updated_at = now() where id = $1", [pay.id, docId]);
    await q.query("update service_requests set payment_status = 'awaiting_verification', updated_at = now() where id = $1", [requestId]);
    await q.query(`insert into payment_events (payment_id, provider, event_type, payload) values ($1,'manual_transfer','proof_uploaded',$2::jsonb)`, [pay.id, JSON.stringify({ document_id: docId })]);
    // Beri tahu petugas/admin penanggung jawab.
    const r = (await q.query<{ assignee_id: string | null; request_number: string }>("select assignee_id, request_number from service_requests where id = $1", [requestId])).rows[0]!;
    const targets = r.assignee_id ? [r.assignee_id] : (await q.query<{ user_id: string }>("select ur.user_id from user_roles ur join roles ro on ro.id = ur.role_id where ro.code in ('admin','petugas')")).rows.map((x) => x.user_id);
    for (const t of targets) await notify(q, { userId: t, type: "payment_proof", title: `Bukti pembayaran ${r.request_number}`, body: "Menunggu verifikasi", link: `/pengajuan/${requestId}` });
  });
  return { id: pay.id };
}

async function settle(q: Queryable, payId: string, eventProvider: string, newStatus: "paid" | "failed" | "expired" | "refunded", actorId: string | null) {
  const p = (await q.query<{ id: string; request_id: string; status: string; amount_idr: number }>("select id, request_id, status, amount_idr from payments where id = $1 for update", [payId])).rows[0];
  if (!p) throw notFound("Pembayaran tidak ditemukan.");
  if (p.status === newStatus) return p; // idempoten
  const legal: Record<string, string[]> = {
    paid: ["pending", "awaiting_verification"], failed: ["pending", "awaiting_verification"], expired: ["pending"], refunded: ["paid"],
  };
  if (!legal[newStatus]!.includes(p.status)) throw conflict(`Pembayaran berstatus "${p.status}" tidak dapat diubah menjadi "${newStatus}".`, "invalid_payment_transition");
  await q.query(
    `update payments set status = $2, updated_at = now(), paid_at = case when $2 = 'paid' then now() else paid_at end, verified_by = coalesce($3, verified_by) where id = $1`,
    [payId, newStatus, actorId],
  );
  const reqStatus = { paid: "paid", failed: "pending", expired: "pending", refunded: "refunded" }[newStatus];
  await q.query("update service_requests set payment_status = $2, updated_at = now() where id = $1", [p.request_id, reqStatus]);
  const rq = (await q.query<{ student_id: string; status: string; request_number: string }>("select student_id, status, request_number from service_requests where id = $1", [p.request_id])).rows[0]!;
  if (newStatus === "paid" && rq.status === "awaiting_payment") {
    await q.query("update service_requests set status = 'confirmed' where id = $1", [p.request_id]);
    await q.query(`insert into request_status_history (request_id, from_status, to_status, changed_by, note) values ($1,'awaiting_payment','confirmed',$2,'Pembayaran lunas')`, [p.request_id, actorId]);
  }
  await q.query(`insert into payment_events (payment_id, provider, event_type, payload) values ($1,$2,$3,$4::jsonb)`, [payId, eventProvider, `status.${newStatus}`, JSON.stringify({ by: actorId })]);
  await notify(q, {
    userId: rq.student_id, type: "payment", title: `Pembayaran ${rq.request_number}: ${PAYMENT_STATUS_LABEL[reqStatus] ?? reqStatus}`,
    body: formatRupiah(p.amount_idr), link: `/riwayat/${p.request_id}`, template: "payment_update",
    vars: { nomor_pengajuan: rq.request_number, status: PAYMENT_STATUS_LABEL[reqStatus] ?? reqStatus }, dedupe: `pay:${payId}:${newStatus}`,
  });
  return p;
}

/** Verifikasi manual bukti transfer oleh petugas/admin. */
export async function verifyPayment(actor: Actor, requestId: string, decision: "approve" | "reject", ip?: string | null) {
  if (!hasRole(actor, "petugas", "admin")) throw forbidden("Hanya petugas administrasi atau admin yang dapat memverifikasi pembayaran.");
  return tx(async (q) => {
    const r = (await q.query<{ student_id: string }>("select student_id from service_requests where id = $1", [requestId])).rows[0];
    if (!r) throw notFound("Pengajuan tidak ditemukan.");
    if (r.student_id === actor.id) throw forbidden("Anda tidak dapat memverifikasi pembayaran Anda sendiri.");
    const p = (await q.query<{ id: string; status: string }>("select id, status from payments where request_id = $1 and status = 'awaiting_verification' order by created_at desc limit 1", [requestId])).rows[0];
    if (!p) throw conflict("Tidak ada pembayaran yang menunggu verifikasi.", "nothing_to_verify");
    await settle(q, p.id, "manual_transfer", decision === "approve" ? "paid" : "failed", actor.id);
    await audit(q, { actor, action: `payment.${decision}`, entityType: "payment", entityId: p.id, ip });
    return { id: p.id };
  });
}

export async function refundPayment(actor: Actor, requestId: string, ip?: string | null) {
  if (!hasRole(actor, "petugas", "admin")) throw forbidden();
  return tx(async (q) => {
    const p = (await q.query<{ id: string }>("select id from payments where request_id = $1 and status = 'paid' limit 1", [requestId])).rows[0];
    if (!p) throw conflict("Tidak ada pembayaran lunas untuk dikembalikan.");
    await settle(q, p.id, "manual_transfer", "refunded", actor.id);
    await audit(q, { actor, action: "payment.refund", entityType: "payment", entityId: p.id, ip });
    return { id: p.id };
  });
}

/* ------------------------- Webhook gateway generik ------------------------- */

export function verifyPaymentSignature(rawBody: string, header: string | null, secret = env.paymentWebhookSecret): boolean {
  if (!secret || !header) return false;
  const given = header.startsWith("sha256=") ? header.slice(7) : header;
  const expected = createHmac("sha256", secret).update(rawBody, "utf8").digest("hex");
  const a = Buffer.from(given, "utf8");
  const b = Buffer.from(expected, "utf8");
  return a.length === b.length && timingSafeEqual(a, b);
}

type PaymentWebhook = { event_id?: string; type?: string; reference?: string; amount?: number };

/**
 * Payload yang diharapkan: { event_id, type: "payment.paid"|"payment.failed"|"payment.expired", reference, amount }.
 * `reference` = ID pembayaran PasundanEdu (payments.id). Tanda tangan WAJIB sudah diverifikasi oleh pemanggil.
 */
export async function processPaymentWebhook(payload: PaymentWebhook): Promise<{ duplicate: boolean }> {
  const { event_id, type, reference, amount } = payload;
  if (!event_id || !type || !reference || !/^[0-9a-f-]{36}$/i.test(reference)) throw badRequest("Payload webhook tidak lengkap.");
  const map: Record<string, "paid" | "failed" | "expired"> = { "payment.paid": "paid", "payment.failed": "failed", "payment.expired": "expired" };
  const target = map[type];
  if (!target) throw badRequest("Jenis event tidak dikenal.");
  return tx(async (q) => {
    const ev = await q.query(
      `insert into webhook_events (provider, event_id, event_type, signature_valid, payload) values ('payment',$1,$2,true,$3::jsonb) on conflict (provider, event_id) do nothing`,
      [event_id, type, JSON.stringify(payload)],
    );
    if (!ev.rowCount) return { duplicate: true };
    const p = (await q.query<{ amount_idr: number }>("select amount_idr from payments where id = $1", [reference])).rows[0];
    if (!p) throw notFound("Pembayaran tidak ditemukan.");
    if (target === "paid" && amount !== p.amount_idr) throw conflict("Nominal tidak sesuai dengan tagihan.", "amount_mismatch");
    await q.query(`insert into payment_events (payment_id, provider, provider_event_id, event_type, payload) values ($1,'gateway',$2,$3,$4::jsonb)`, [reference, event_id, type, JSON.stringify(payload)]);
    await settle(q, reference, "gateway", target, null);
    await q.query("update webhook_events set processed_at = now() where provider = 'payment' and event_id = $1", [event_id]);
    return { duplicate: false };
  });
}

export async function listPayments(opts: { status?: string; page?: number; size?: number }) {
  const page = opts.page ?? 1;
  const size = opts.size ?? 20;
  const params: unknown[] = [];
  let where = "";
  if (opts.status) { params.push(opts.status); where = "where p.status = $1"; }
  const total = (await query<{ n: number }>(`select count(*)::int as n from payments p ${where}`, params)).rows[0]!.n;
  const rows = (await query<{
    id: string; request_id: string; request_number: string; amount_idr: number; status: string; provider: string; created_at: Date; paid_at: Date | null; student_name: string; service_name: string;
  }>(
    `select p.id, p.request_id, r.request_number, p.amount_idr, p.status, p.provider, p.created_at, p.paid_at, st.full_name as student_name, s.name as service_name
     from payments p join service_requests r on r.id = p.request_id join profiles st on st.id = r.student_id join services s on s.id = r.service_id
     ${where} order by p.created_at desc limit ${size} offset ${(page - 1) * size}`, params,
  )).rows;
  return { items: rows, total, page, size, totalPages: Math.max(1, Math.ceil(total / size)) };
}
