import { one, query, tx } from "../db";
import { audit } from "../audit";
import { notFound, conflict, isUniqueViolation } from "../errors";
import type { Actor } from "../auth/types";
import type { z } from "zod";
import type { serviceUpsertSchema } from "@/lib/validation";

export type ServiceView = {
  id: string; slug: string; name: string; description: string; icon: string;
  price_idr: number; duration_minutes: number | null; requirements: string[]; estimated_process: string | null;
  capacity: number | null; requires_appointment: boolean; requires_documents: boolean; cancellation_policy: string;
  is_active: boolean; category_id: string; category_code: string; category_name: string; category_icon: string;
  staff: Array<{ id: string; name: string }>;
};

const SELECT = `
  select s.id, s.slug, s.name, s.description, s.icon, s.price_idr, s.duration_minutes, s.requirements, s.estimated_process,
         s.capacity, s.requires_appointment, s.requires_documents, s.cancellation_policy, s.is_active, s.category_id,
         c.code as category_code, c.name as category_name, c.icon as category_icon,
         coalesce((select json_agg(json_build_object('id', p.id, 'name', p.full_name) order by p.full_name)
                   from service_assignments sa join profiles p on p.id = sa.staff_id and p.status = 'active'
                   where sa.service_id = s.id), '[]'::json) as staff
  from services s join service_categories c on c.id = s.category_id`;

export const escapeLike = (s: string) => s.replace(/[\\%_]/g, (m) => "\\" + m);

export async function listCategories() {
  return (await query<{ id: string; code: string; name: string; icon: string }>(
    "select id, code, name, icon from service_categories where is_active order by sort_order, name",
  )).rows;
}

export async function listServices(opts: { q?: string; category?: string; includeInactive?: boolean; page?: number; size?: number } = {}) {
  const page = opts.page ?? 1;
  const size = opts.size ?? 50;
  const where: string[] = [];
  const params: unknown[] = [];
  if (!opts.includeInactive) where.push("s.is_active and c.is_active");
  if (opts.category) { params.push(opts.category); where.push(`c.code = $${params.length}`); }
  if (opts.q?.trim()) {
    params.push(`%${escapeLike(opts.q.trim())}%`);
    where.push(`(s.name ilike $${params.length} or s.description ilike $${params.length})`);
  }
  const w = where.length ? `where ${where.join(" and ")}` : "";
  const total = (await query<{ n: number }>(`select count(*)::int as n from services s join service_categories c on c.id = s.category_id ${w}`, params)).rows[0]!.n;
  const rows = (await query<ServiceView>(`${SELECT} ${w} order by c.sort_order, s.name limit ${size} offset ${(page - 1) * size}`, params)).rows;
  return { items: rows, total, page, size };
}

export async function getService(idOrSlug: string, includeInactive = false): Promise<ServiceView> {
  const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(idOrSlug);
  const s = await one<ServiceView>(`${SELECT} where ${isUuid ? "s.id" : "s.slug"} = $1 ${includeInactive ? "" : "and s.is_active"}`, [idOrSlug]);
  if (!s) throw notFound("Layanan tidak ditemukan.");
  return s;
}

function slugify(name: string) {
  return name.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "layanan";
}

export async function upsertService(actor: Actor, input: z.infer<typeof serviceUpsertSchema>, id?: string, ip?: string) {
  try {
    return await tx(async (q) => {
      const cat = await q.query("select 1 from service_categories where id = $1", [input.category_id]);
      if (!cat.rowCount) throw notFound("Kategori tidak ditemukan.");
      if (input.staff_ids.length) {
        const ok = await q.query(
          `select count(*)::int as n from profiles p join user_roles ur on ur.user_id = p.id join roles r on r.id = ur.role_id
           where p.id = any($1::uuid[]) and p.status = 'active' and r.code in ('dosen','petugas')`,
          [input.staff_ids],
        );
        if (ok.rows[0]!.n < new Set(input.staff_ids).size) throw conflict("Penanggung jawab harus akun dosen/petugas yang aktif.");
      }
      const vals = [
        input.category_id, input.name, input.description, input.icon, input.price_idr, input.duration_minutes ?? null,
        JSON.stringify(input.requirements), input.estimated_process ?? null, input.capacity ?? null,
        input.requires_appointment, input.requires_documents, input.cancellation_policy, input.is_active,
      ];
      let sid = id;
      if (id) {
        const r = await q.query(
          `update services set category_id=$2, name=$3, description=$4, icon=$5, price_idr=$6, duration_minutes=$7, requirements=$8::jsonb,
                  estimated_process=$9, capacity=$10, requires_appointment=$11, requires_documents=$12, cancellation_policy=$13,
                  is_active=$14, updated_at=now() where id=$1`,
          [id, ...vals],
        );
        if (!r.rowCount) throw notFound("Layanan tidak ditemukan.");
      } else {
        const base = slugify(input.name);
        const exists = await q.query("select 1 from services where slug = $1", [base]);
        const slug = exists.rowCount ? `${base}-${Math.random().toString(36).slice(2, 6)}` : base;
        const r = await q.query<{ id: string }>(
          `insert into services (slug, category_id, name, description, icon, price_idr, duration_minutes, requirements, estimated_process,
                                 capacity, requires_appointment, requires_documents, cancellation_policy, is_active, created_by)
           values ($14,$1,$2,$3,$4,$5,$6,$7::jsonb,$8,$9,$10,$11,$12,$13,$15) returning id`,
          [...vals, slug, actor.id],
        );
        sid = r.rows[0]!.id;
      }
      await q.query("delete from service_assignments where service_id = $1", [sid]);
      for (const staff of new Set(input.staff_ids)) {
        await q.query("insert into service_assignments (service_id, staff_id) values ($1,$2)", [sid, staff]);
      }
      await audit(q, { actor, action: id ? "service.update" : "service.create", entityType: "service", entityId: sid, meta: { name: input.name, price_idr: input.price_idr, is_active: input.is_active }, ip });
      return sid!;
    });
  } catch (e) {
    if (isUniqueViolation(e)) throw conflict("Layanan dengan nama serupa sudah ada.");
    throw e;
  }
}
