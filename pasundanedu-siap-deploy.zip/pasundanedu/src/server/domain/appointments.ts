import { one, query, tx } from "../db";
import type { Queryable } from "../db";
import { audit } from "../audit";
import { conflict, forbidden, notFound, unprocessable } from "../errors";
import { fromJakarta } from "@/lib/format";
import { hasRole, type Actor } from "../auth/types";

export type SlotView = {
  id: string; staff_id: string; staff_name: string; service_id: string | null; starts_at: Date; ends_at: Date;
  mode: "online" | "offline"; location: string | null; capacity: number; booked: number; status: string;
};

/** Slot yang masih bisa dipesan untuk layanan tertentu (hanya milik staf yang ditugaskan, di masa depan, belum penuh). */
export async function listAvailability(opts: { serviceId: string; days?: number; limit?: number }): Promise<SlotView[]> {
  const days = Math.min(60, opts.days ?? 30);
  const { rows } = await query<SlotView>(
    `select sl.id, sl.staff_id, p.full_name as staff_name, sl.service_id, sl.starts_at, sl.ends_at, sl.mode, sl.location, sl.capacity, sl.status,
            (select count(*)::int from appointments a where a.slot_id = sl.id and a.status = 'booked') as booked
     from availability_slots sl
     join profiles p on p.id = sl.staff_id and p.status = 'active'
     where sl.status = 'open'
       and sl.starts_at > now() + interval '1 hour' and sl.starts_at < now() + make_interval(days => $2::int)
       and (sl.service_id is null or sl.service_id = $1)
       and exists (select 1 from service_assignments sa where sa.service_id = $1 and sa.staff_id = sl.staff_id)
       and (select count(*) from appointments a where a.slot_id = sl.id and a.status = 'booked') < sl.capacity
     order by sl.starts_at limit $3`,
    [opts.serviceId, days, opts.limit ?? 200],
  );
  return rows;
}

export async function listStaffSlots(staffId: string, fromNow = true): Promise<SlotView[]> {
  const { rows } = await query<SlotView>(
    `select sl.id, sl.staff_id, p.full_name as staff_name, sl.service_id, sl.starts_at, sl.ends_at, sl.mode, sl.location, sl.capacity, sl.status,
            (select count(*)::int from appointments a where a.slot_id = sl.id and a.status = 'booked') as booked
     from availability_slots sl join profiles p on p.id = sl.staff_id
     where sl.staff_id = $1 ${fromNow ? "and sl.ends_at > now()" : ""} order by sl.starts_at limit 200`,
    [staffId],
  );
  return rows;
}

type SlotInput = { date: string; start: string; end: string; mode: "online" | "offline"; location?: string; service_id?: string; capacity?: number };

export async function createSlot(actor: Actor, input: SlotInput, ip?: string) {
  if (!hasRole(actor, "dosen", "petugas", "admin")) throw forbidden();
  const starts = fromJakarta(input.date, input.start);
  const ends = fromJakarta(input.date, input.end);
  if (Number.isNaN(starts.getTime()) || Number.isNaN(ends.getTime())) throw unprocessable("Tanggal atau jam tidak valid.");
  if (ends <= starts) throw unprocessable("Jam selesai harus setelah jam mulai.", { end: "Jam selesai harus setelah jam mulai." });
  if (ends.getTime() - starts.getTime() > 8 * 3600_000) throw unprocessable("Durasi slot maksimal 8 jam.", { end: "Maksimal 8 jam." });
  if (starts.getTime() < Date.now() + 3600_000) throw unprocessable("Slot harus dibuat minimal 1 jam dari sekarang.", { date: "Pilih waktu yang lebih akhir." });
  return tx(async (q) => {
    if (input.service_id) {
      const a = await q.query("select 1 from service_assignments where service_id = $1 and staff_id = $2", [input.service_id, actor.id]);
      if (!a.rowCount) throw forbidden("Anda tidak ditugaskan pada layanan tersebut.");
    }
    // Hindari tumpang tindih dengan slot staf yang sama.
    const overlap = await q.query(
      `select 1 from availability_slots where staff_id = $1 and status = 'open' and starts_at < $3 and ends_at > $2`,
      [actor.id, starts.toISOString(), ends.toISOString()],
    );
    if (overlap.rowCount) throw conflict("Slot bertumpuk dengan jadwal lain milik Anda.", "slot_overlap");
    const r = await q.query<{ id: string }>(
      `insert into availability_slots (staff_id, service_id, starts_at, ends_at, mode, location, capacity)
       values ($1,$2,$3,$4,$5,$6,$7) returning id`,
      [actor.id, input.service_id ?? null, starts.toISOString(), ends.toISOString(), input.mode, input.location ?? null, input.capacity ?? 1],
    );
    await audit(q, { actor, action: "slot.create", entityType: "availability_slot", entityId: r.rows[0]!.id, ip });
    return r.rows[0]!.id;
  });
}

export async function closeSlot(actor: Actor, slotId: string, ip?: string) {
  await tx(async (q) => {
    const s = (await q.query<{ staff_id: string }>("select staff_id from availability_slots where id = $1 for update", [slotId])).rows[0];
    if (!s) throw notFound("Slot tidak ditemukan.");
    if (s.staff_id !== actor.id && !hasRole(actor, "admin")) throw forbidden();
    const booked = await q.query("select 1 from appointments where slot_id = $1 and status = 'booked'", [slotId]);
    if (booked.rowCount) throw conflict("Slot sudah dipesan. Jadwalkan ulang atau batalkan pengajuannya terlebih dahulu.", "slot_booked");
    await q.query("update availability_slots set status = 'closed' where id = $1", [slotId]);
    await audit(q, { actor, action: "slot.close", entityType: "availability_slot", entityId: slotId, ip });
  });
}

/**
 * Memesan slot untuk sebuah pengajuan di dalam transaksi pemanggil.
 * Baris slot dikunci; trigger database menolak pemesanan melebihi kapasitas (kode 23P01).
 */
export async function bookSlot(
  q: Queryable,
  p: { slotId: string; requestId: string; studentId: string; serviceId: string },
) {
  const slot = (await q.query<{ id: string; staff_id: string; service_id: string | null; starts_at: Date; ends_at: Date; status: string }>(
    "select id, staff_id, service_id, starts_at, ends_at, status from availability_slots where id = $1 for update", [p.slotId],
  )).rows[0];
  if (!slot || slot.status !== "open") throw conflict("Jadwal tidak tersedia lagi. Pilih jadwal lain.", "slot_unavailable");
  if (new Date(slot.starts_at).getTime() < Date.now() + 3600_000) throw conflict("Jadwal ini sudah terlalu dekat. Pilih jadwal lain.", "slot_too_soon");
  if (slot.service_id && slot.service_id !== p.serviceId) throw unprocessable("Jadwal ini tidak berlaku untuk layanan yang dipilih.");
  const assigned = await q.query("select 1 from service_assignments where service_id = $1 and staff_id = $2", [p.serviceId, slot.staff_id]);
  if (!assigned.rowCount) throw unprocessable("Jadwal ini tidak berlaku untuk layanan yang dipilih.");
  const clash = await q.query(
    `select 1 from appointments where student_id = $1 and status = 'booked' and starts_at < $3 and ends_at > $2`,
    [p.studentId, new Date(slot.starts_at).toISOString(), new Date(slot.ends_at).toISOString()],
  );
  if (clash.rowCount) throw conflict("Anda sudah memiliki jadwal lain pada waktu yang sama.", "student_clash");
  try {
    await q.query(
      `insert into appointments (request_id, slot_id, student_id, staff_id, starts_at, ends_at) values ($1,$2,$3,$4,$5,$6)`,
      [p.requestId, slot.id, p.studentId, slot.staff_id, new Date(slot.starts_at).toISOString(), new Date(slot.ends_at).toISOString()],
    );
  } catch (e) {
    const err = e as { code?: string; message?: string };
    if (err.code === "23P01" || /slot_full/.test(err.message ?? "")) throw conflict("Jadwal sudah terisi. Pilih jadwal lain.", "slot_full");
    throw e;
  }
  return { staffId: slot.staff_id, startsAt: new Date(slot.starts_at), endsAt: new Date(slot.ends_at) };
}

export async function cancelAppointmentsForRequest(q: Queryable, requestId: string) {
  await q.query("update appointments set status = 'cancelled', updated_at = now() where request_id = $1 and status = 'booked'", [requestId]);
}

export async function listMyAppointments(userId: string, role: "student" | "staff") {
  const col = role === "student" ? "a.student_id" : "a.staff_id";
  const { rows } = await query<{
    id: string; request_id: string; request_number: string; service_name: string; starts_at: Date; ends_at: Date; status: string;
    mode: string; location: string | null; other_name: string;
  }>(
    `select a.id, a.request_id, r.request_number, s.name as service_name, a.starts_at, a.ends_at, a.status, sl.mode, sl.location,
            case when $2 = 'student' then st.full_name else sd.full_name end as other_name
     from appointments a
     join service_requests r on r.id = a.request_id join services s on s.id = r.service_id
     join availability_slots sl on sl.id = a.slot_id
     join profiles st on st.id = a.staff_id join profiles sd on sd.id = a.student_id
     where ${col} = $1 and a.status in ('booked','completed','no_show') and a.ends_at > now() - interval '30 days'
     order by a.starts_at`,
    [userId, role],
  );
  return rows;
}

export async function getAppointmentForRequest(requestId: string) {
  return one<{ id: string; slot_id: string; starts_at: Date; ends_at: Date; status: string; mode: string; location: string | null; staff_id: string }>(
    `select a.id, a.slot_id, a.starts_at, a.ends_at, a.status, sl.mode, sl.location, a.staff_id
     from appointments a join availability_slots sl on sl.id = a.slot_id
     where a.request_id = $1 order by (a.status = 'booked') desc, a.created_at desc limit 1`,
    [requestId],
  );
}
