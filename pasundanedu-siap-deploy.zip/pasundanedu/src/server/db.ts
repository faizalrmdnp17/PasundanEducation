import { env } from "./env";
import { runMigrations } from "./migrate";

export type Row = Record<string, any>;
export type QueryResult<T extends Row = Row> = { rows: T[]; rowCount: number };

export interface Queryable {
  query<T extends Row = Row>(text: string, params?: unknown[]): Promise<QueryResult<T>>;
  /** Menjalankan beberapa pernyataan SQL tanpa parameter (migrasi). */
  exec(sql: string): Promise<void>;
}

export interface Db extends Queryable {
  readonly kind: "pg" | "pglite";
  /** Menjalankan fungsi di dalam satu transaksi. Rollback otomatis bila terjadi error. */
  tx<T>(fn: (q: Queryable) => Promise<T>): Promise<T>;
  close(): Promise<void>;
}

const g = globalThis as unknown as { __pe_db?: Promise<Db> };

async function createPg(): Promise<Db> {
  const pg = await import("pg");
  // int8 (count, bigint) dikembalikan sebagai number agar mudah dipakai.
  pg.types.setTypeParser(20, (v: string) => Number.parseInt(v, 10));
  const pool = new pg.Pool({
    connectionString: env.databaseUrl,
    max: 10,
    ssl: env.databaseSsl === "off" ? undefined : { rejectUnauthorized: env.databaseSsl === "verify", ...(env.databaseSslCa ? { ca: env.databaseSslCa.replace(/\\n/g, "\n") } : {}) },
  });
  const wrap = (c: { query: (t: string, p?: unknown[]) => Promise<any> }): Queryable => ({
    async query(text, params) {
      const r = await c.query(text, params as unknown[]);
      return { rows: r.rows, rowCount: r.rowCount ?? r.rows.length };
    },
    async exec(sql) { await c.query(sql); },
  });
  return {
    kind: "pg",
    ...wrap(pool),
    async tx(fn) {
      const client = await pool.connect();
      try {
        await client.query("BEGIN");
        const out = await fn(wrap(client));
        await client.query("COMMIT");
        return out;
      } catch (e) {
        await client.query("ROLLBACK").catch(() => {});
        throw e;
      } finally {
        client.release();
      }
    },
    close: () => pool.end(),
  };
}

async function createPglite(): Promise<Db> {
  const { PGlite } = await import("@electric-sql/pglite");
  const dir = env.pgliteDir;
  if (env.isProd && !env.isTest) {
    console.warn("[db] PERINGATAN: DATABASE_URL kosong, memakai PGlite (basis data tertanam, satu proses, tersimpan di berkas lokal). Untuk produksi gunakan PostgreSQL dan atur DATABASE_URL.");
  }
  if (!dir.startsWith("memory://")) {
    const fs = await import("node:fs");
    fs.mkdirSync(dir, { recursive: true });
  }
  const lite = new PGlite(dir);
  await lite.waitReady;
  const wrap = (c: { query: Function; exec: Function }): Queryable => ({
    async query(text, params) {
      const r = await c.query(text, params as unknown[]);
      // PGlite melaporkan affectedRows = 0 untuk SELECT; samakan perilaku dengan node-postgres (rowCount = jumlah baris).
      return { rows: r.rows, rowCount: Math.max(r.rows.length, r.affectedRows ?? 0) };
    },
    async exec(sql) { await c.exec(sql); },
  });
  return {
    kind: "pglite",
    ...wrap(lite),
    tx: (fn) => lite.transaction((t) => fn(wrap(t as any))),
    close: () => lite.close(),
  };
}

/** Singleton koneksi basis data (aman terhadap hot reload Next.js). */
export function getDb(): Promise<Db> {
  if (!g.__pe_db) {
    g.__pe_db = (async () => {
      const db = env.databaseUrl ? await createPg() : await createPglite();
      if (env.autoMigrate) await runMigrations(db);
      return db;
    })().catch((e) => {
      g.__pe_db = undefined;
      throw e;
    });
  }
  return g.__pe_db;
}

export async function closeDb() {
  if (!g.__pe_db) return;
  const db = await g.__pe_db;
  g.__pe_db = undefined;
  await db.close();
}

/** Kueri tunggal di luar transaksi. */
export async function query<T extends Row = Row>(text: string, params?: unknown[]) {
  return (await getDb()).query<T>(text, params);
}
export async function one<T extends Row = Row>(text: string, params?: unknown[]): Promise<T | null> {
  return (await query<T>(text, params)).rows[0] ?? null;
}
export async function tx<T>(fn: (q: Queryable) => Promise<T>): Promise<T> {
  return (await getDb()).tx(fn);
}

/** Antarmuka Queryable di luar transaksi (untuk fungsi yang menerima Queryable tetapi dipanggil tanpa transaksi). */
export const dbq: Queryable = {
  query: (text, params) => query(text, params),
  exec: async (sql) => (await getDb()).exec(sql),
};

/** Helper untuk kueri di dalam transaksi. */
export async function oneOf<T extends Row = Row>(q: Queryable, text: string, params?: unknown[]): Promise<T | null> {
  return (await q.query<T>(text, params)).rows[0] ?? null;
}
