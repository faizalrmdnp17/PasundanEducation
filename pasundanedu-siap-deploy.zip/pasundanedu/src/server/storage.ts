import { createHmac, randomUUID, timingSafeEqual, createHash } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { env } from "./env";
import { badRequest, unprocessable } from "./errors";

/**
 * Penyimpanan berkas privat (adapter sistem berkas lokal).
 * - Berkas disimpan di luar direktori publik; tidak pernah dilayani langsung.
 * - Unduhan lewat URL bertanda tangan berumur pendek DAN pemeriksaan hak akses ulang di rute unduh.
 * - Untuk Supabase Storage/S3, implementasikan antarmuka FileStore yang sama (lihat docs/DEPLOYMENT.md).
 */
export interface FileStore {
  put(key: string, data: Buffer): Promise<void>;
  get(key: string): Promise<Buffer>;
  remove(key: string): Promise<void>;
}

class LocalStore implements FileStore {
  private resolve(key: string) {
    const root = path.resolve(/*turbopackIgnore: true*/ process.cwd(), env.uploadDir);
    const full = path.resolve(root, key);
    if (!full.startsWith(root + path.sep)) throw new Error("Kunci berkas tidak valid");
    return full;
  }
  async put(key: string, data: Buffer) {
    const p = this.resolve(key);
    await fs.mkdir(path.dirname(p), { recursive: true });
    await fs.writeFile(p, data, { mode: 0o600 });
  }
  get(key: string) {
    return fs.readFile(this.resolve(key));
  }
  async remove(key: string) {
    await fs.rm(this.resolve(key), { force: true });
  }
}

export const fileStore: FileStore = new LocalStore();

const SIGNATURES: Array<{ mime: string; ext: string[]; test: (b: Buffer) => boolean }> = [
  { mime: "application/pdf", ext: [".pdf"], test: (b) => b.subarray(0, 5).toString("latin1") === "%PDF-" },
  { mime: "image/png", ext: [".png"], test: (b) => b.length > 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { mime: "image/jpeg", ext: [".jpg", ".jpeg"], test: (b) => b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  {
    mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ext: [".docx"],
    // DOCX adalah arsip ZIP; periksa tanda tangan ZIP dan keberadaan entri word/ di direktori pusat.
    test: (b) => b.length > 4 && b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04 && b.includes(Buffer.from("word/")),
  },
];

export type ValidatedUpload = { mime: string; safeName: string; sha256: string };

/** Validasi berkas unggahan: ukuran, ekstensi, dan isi sebenarnya (magic bytes), bukan sekadar header dari klien. */
export function validateUpload(name: string, data: Buffer): ValidatedUpload {
  if (!data.length) throw badRequest("Berkas kosong.");
  if (data.length > env.maxUploadBytes) {
    throw unprocessable(`Ukuran berkas maksimal ${Math.round(env.maxUploadBytes / 1024 / 1024)} MB.`, { file: "Berkas terlalu besar." });
  }
  const ext = path.extname(name).toLowerCase();
  const sig = SIGNATURES.find((s) => s.test(data));
  if (!sig || !sig.ext.includes(ext)) {
    throw unprocessable("Jenis berkas tidak diizinkan. Gunakan PDF, PNG, JPG, atau DOCX.", { file: "Jenis berkas tidak diizinkan atau isinya tidak sesuai ekstensi." });
  }
  const base = path.basename(name, ext).normalize("NFKD").replace(/[^\w.\- ]+/g, "").trim().replace(/\s+/g, "-").slice(0, 80) || "berkas";
  return { mime: sig.mime, safeName: base + ext, sha256: createHash("sha256").update(data).digest("hex") };
}

export function newStorageKey(): string {
  const d = new Date();
  return `${d.getUTCFullYear()}/${String(d.getUTCMonth() + 1).padStart(2, "0")}/${randomUUID()}`;
}

/* ---------- URL bertanda tangan ---------- */

function sign(docId: string, userId: string, exp: number): string {
  return createHmac("sha256", env.appSecret).update(`${docId}.${userId}.${exp}`).digest("base64url");
}

/** URL unduh berumur pendek yang terikat pada satu pengguna dan satu dokumen. */
export function signedDownloadPath(docId: string, userId: string, ttlSec = env.signedUrlTtlSeconds): string {
  const exp = Math.floor(Date.now() / 1000) + ttlSec;
  return `/api/files/${docId}?exp=${exp}&sig=${sign(docId, userId, exp)}`;
}

export function verifyDownloadSignature(docId: string, userId: string, exp: string | null, sig: string | null): boolean {
  if (!exp || !sig) return false;
  const e = Number(exp);
  if (!Number.isFinite(e) || e < Math.floor(Date.now() / 1000)) return false;
  const expected = Buffer.from(sign(docId, userId, e));
  const given = Buffer.from(sig);
  return expected.length === given.length && timingSafeEqual(expected, given);
}
