/**
 * Uji end-to-end lewat HTTP terhadap server yang SEDANG BERJALAN (next dev / next start).
 * Tidak memakai browser dan tidak mengirim pesan WhatsApp/email sungguhan.
 *
 * Prasyarat:
 *  - Server berjalan dan basis data berisi seed demo (`npm run db:setup`).
 *  - Variabel rahasia webhook di sini HARUS sama dengan yang dipakai server:
 *      WHATSAPP_APP_SECRET, WHATSAPP_VERIFY_TOKEN, PAYMENT_WEBHOOK_SECRET, CRON_SECRET
 *    Bagian yang membutuhkan rahasia yang tidak diisi akan DILEWATI dan dilaporkan, bukan dianggap lulus.
 *
 * Pakai:  E2E_BASE_URL=http://localhost:3000 npm run test:e2e
 */
import { createHmac } from "node:crypto";

const BASE = (process.env.E2E_BASE_URL ?? "http://localhost:3000").replace(/\/$/, "");
const DEMO_PW = process.env.E2E_DEMO_PASSWORD ?? "DemoPasundan2026";
const WA_SECRET = process.env.WHATSAPP_APP_SECRET ?? "";
const WA_VERIFY = process.env.WHATSAPP_VERIFY_TOKEN ?? "";
const PAY_SECRET = process.env.PAYMENT_WEBHOOK_SECRET ?? "";
const CRON_SECRET = process.env.CRON_SECRET ?? "";

type Res = { status: number; json: any; text: string; headers: Headers };

class Client {
  jar = new Map<string, string>();
  async req(method: string, path: string, o: { body?: unknown; form?: FormData; headers?: Record<string, string>; raw?: string } = {}): Promise<Res> {
    const headers: Record<string, string> = { ...(o.headers ?? {}) };
    if (this.jar.size) headers.cookie = [...this.jar].map(([k, v]) => `${k}=${v}`).join("; ");
    let body: BodyInit | undefined;
    if (o.form) body = o.form;
    else if (o.raw !== undefined) body = o.raw;
    else if (o.body !== undefined) { headers["content-type"] = "application/json"; body = JSON.stringify(o.body); }
    const res = await fetch(BASE + path, { method, headers, body, redirect: "manual" });
    for (const c of res.headers.getSetCookie?.() ?? []) {
      const [pair, ...attrs] = c.split(";");
      const [k, ...v] = pair!.split("=");
      const expired = attrs.some((a) => /^\s*max-age=0/i.test(a)) || attrs.some((a) => /^\s*expires=.*1970/i.test(a));
      if (expired || !v.join("=")) this.jar.delete(k!.trim());
      else this.jar.set(k!.trim(), v.join("="));
    }
    const text = await res.text();
    let json: any = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* bukan JSON */ }
    return { status: res.status, json, text, headers: res.headers };
  }
  get = (p: string, h?: Record<string, string>) => this.req("GET", p, { headers: h });
  post = (p: string, body?: unknown, h?: Record<string, string>) => this.req("POST", p, { body, headers: h });
  patch = (p: string, body?: unknown) => this.req("PATCH", p, { body });
}

let pass = 0, fail = 0, skipped = 0;
const failures: string[] = [];
async function t(name: string, fn: () => Promise<void>) {
  try { await fn(); pass++; console.log(`  ok    ${name}`); }
  catch (e) { fail++; failures.push(name); console.log(`  GAGAL ${name}\n        ${(e as Error).message}`); }
}
function skip(name: string, why: string) { skipped++; console.log(`  lewat ${name} (${why})`); }
function eq<T>(a: T, b: T, msg = "") { if (a !== b) throw new Error(`${msg} diharapkan ${JSON.stringify(b)}, dapat ${JSON.stringify(a)}`); }
function ok(c: unknown, msg: string) { if (!c) throw new Error(msg); }
const hmacHex = (secret: string, body: string) => createHmac("sha256", secret).update(body, "utf8").digest("hex");

async function login(email: string) {
  const c = new Client();
  const r = await c.post("/api/auth/login", { email, password: DEMO_PW });
  if (r.status !== 200) throw new Error(`login ${email} gagal: ${r.status} ${r.text.slice(0, 120)}`);
  return c;
}

const stamp = Date.now().toString().slice(-9);
const PDF = Buffer.from("%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n");

async function main() {
  console.log(`E2E terhadap ${BASE}\n`);

  console.log("Dasar dan keamanan HTTP");
  await t("GET /api/health menyatakan database aktif", async () => {
    const r = await new Client().get("/api/health"); eq(r.status, 200, "status"); eq(r.json?.database, "up", "database");
  });
  await t("header keamanan terpasang dan tidak membocorkan X-Powered-By", async () => {
    const r = await new Client().get("/masuk");
    for (const h of ["content-security-policy", "x-frame-options", "x-content-type-options", "referrer-policy"]) ok(r.headers.get(h), `header ${h} tidak ada`);
    ok(!r.headers.get("x-powered-by"), "X-Powered-By bocor");
  });
  await t("halaman berautentikasi mengalihkan ke /masuk dengan ?next=", async () => {
    const r = await new Client().get("/layanan");
    eq(r.status, 307, "status"); ok(/\/masuk\?next=%2Flayanan/.test(r.headers.get("location") ?? ""), `location: ${r.headers.get("location")}`);
  });
  await t("API tanpa sesi → 401", async () => {
    const c = new Client();
    eq((await c.get("/api/auth/me")).status, 401, "me"); eq((await c.get("/api/service-requests")).status, 401, "requests");
  });
  await t("CSRF: permintaan ubah-data dari asal asing ditolak 403", async () => {
    const r = await new Client().post("/api/auth/login", { email: "a@example.test", password: "x" }, { origin: "https://evil.example" });
    eq(r.status, 403, "status");
  });

  console.log("\nRegistrasi dan login");
  const email = `e2e${stamp}@example.test`;
  const pw = "SandiUji2026ok";
  const reg = { full_name: "Uji E2E", email, password: pw, account_type: "mahasiswa", npm: `9${stamp}`, whatsapp_number: `0812${stamp.slice(-8)}`, accept_terms: true, consent_whatsapp: true, consent_email: true };
  const me = new Client();
  let registerRes: any = null;
  await t("registrasi mahasiswa berhasil dan langsung memegang sesi", async () => {
    const r = await me.post("/api/auth/register", reg); eq(r.status, 200, `status ${r.text.slice(0, 150)}`); eq(r.json?.status, "active", "status akun");
    registerRes = r.json;
    const m = await me.get("/api/auth/me"); eq(m.status, 200, "me"); eq(m.json?.user?.email, email, "email");
    ok(!("password" in (m.json?.user ?? {})) && !("sessionId" in (m.json?.user ?? {})), "respons /me membocorkan field internal");
  });
  await t("pelaporan email jujur: pesan registrasi tidak mengklaim terkirim bila email tidak bisa dikirim", async () => {
    const h = (await new Client().get("/api/health")).json?.email;
    ok(h === "ready" || h === "not_configured", `health.email tidak dikenal: ${h}`);
    eq(typeof registerRes?.email_sent, "boolean", "email_sent");
    eq(registerRes.email_sent, h === "ready", "email_sent harus sejalan dengan kesiapan email");
    if (!registerRes.email_sent) ok(!/dikirim ke email Anda/.test(registerRes.message) && /belum dapat dikirim/.test(registerRes.message), `pesan menyesatkan: ${registerRes.message}`);
    const rs = await me.post("/api/auth/resend-verification");
    eq(rs.status, h === "ready" ? 200 : 503, `kirim ulang: ${rs.text.slice(0, 120)}`);
  });
  await t("cookie sesi HttpOnly + SameSite=Lax", async () => {
    const c = new Client(); const r = await c.post("/api/auth/login", { email: "mahasiswa@example.test", password: DEMO_PW });
    const sc = (r.headers.getSetCookie?.() ?? []).join(" | "); ok(/httponly/i.test(sc) && /samesite=lax/i.test(sc), sc);
  });
  await t("registrasi: email ganda → 409, kata sandi lemah → 422 dengan galat per kolom", async () => {
    eq((await new Client().post("/api/auth/register", reg)).status, 409, "ganda");
    const w = await new Client().post("/api/auth/register", { ...reg, email: `lemah${stamp}@example.test`, password: "abc" });
    eq(w.status, 422, "lemah"); ok(w.json?.error?.fields?.password, "tidak ada fields.password");
  });
  await t("registrasi tanpa persetujuan syarat → 422", async () => {
    const r = await new Client().post("/api/auth/register", { ...reg, email: `tos${stamp}@example.test`, accept_terms: false }); eq(r.status, 422);
  });
  await t("login salah memberi pesan sama untuk email tak dikenal dan kata sandi keliru", async () => {
    const a = await new Client().post("/api/auth/login", { email: "mahasiswa@example.test", password: "SalahSalah1" });
    const b = await new Client().post("/api/auth/login", { email: `tidakada${stamp}@example.test`, password: "SalahSalah1" });
    eq(a.status, 401); eq(b.status, 401); eq(a.json?.error?.message, b.json?.error?.message, "pesan");
  });
  await t("pembatasan laju login: beberapa gagal beruntun → 429", async () => {
    const e = `laju${stamp}@example.test`; const codes: number[] = [];
    for (let i = 0; i < 8; i++) codes.push((await new Client().post("/api/auth/login", { email: e, password: "SalahSalah1" })).status);
    ok(codes.includes(429), `tidak ada 429: ${codes}`); ok(codes.slice(0, 4).every((c) => c === 401), `awal harus 401: ${codes}`);
  });
  await t("akun belum terverifikasi tidak bisa membuat pengajuan (403)", async () => {
    const svc = (await me.get("/api/services")).json.items.find((s: any) => !s.requires_appointment);
    const r = await me.post("/api/service-requests", { service_id: svc.id }); eq(r.status, 403, r.text.slice(0, 120));
  });

  console.log("\nPengajuan, idempotensi, dan RBAC");
  const mhs = await login("mahasiswa@example.test");
  const mhs2 = await login("mahasiswa2@example.test");
  const petugas = await login("petugas@example.test");
  const dosen = await login("dosen@example.test");
  let reqId = "";
  let svcSurat: any;
  await t("mahasiswa membuat pengajuan; kunci idempotensi yang sama tidak menggandakan", async () => {
    const svcs = (await mhs.get("/api/services")).json;
    svcSurat = svcs.items.find((s: any) => s.slug === "surat-keterangan-mahasiswa"); ok(svcSurat, "layanan surat tidak ada di seed");
    const key = `e2e-${stamp}`;
    const a = await mhs.post("/api/service-requests", { service_id: svcSurat.id, student_note: "uji e2e" }, { "idempotency-key": key });
    eq(a.status, 201, a.text.slice(0, 150)); reqId = a.json.id; ok(/^PE-\d{4}-\d{5}$/.test(a.json.request_number), "format nomor");
    const b = await mhs.post("/api/service-requests", { service_id: svcSurat.id, student_note: "uji e2e" }, { "idempotency-key": key });
    eq(b.status, 200, "ulang"); eq(b.json.id, reqId, "id sama"); eq(b.json.duplicate, true, "duplicate");
  });
  await t("validasi: service_id kosong → 422", async () => { eq((await mhs.post("/api/service-requests", {})).status, 422); });
  await t("harga dikunci server: pembayaran nonaktif → pengajuan tanpa biaya", async () => {
    const d = (await mhs.get(`/api/service-requests/${reqId}`)).json; eq(d.request.price_idr, 0, "harga"); eq(d.request.payment_status, "not_required", "status bayar");
  });
  await t("mahasiswa lain tidak dapat melihat pengajuan (404, bukan 403)", async () => { eq((await mhs2.get(`/api/service-requests/${reqId}`)).status, 404); });
  await t("mahasiswa tidak dapat mengubah status, membuka antrean staf, atau API admin", async () => {
    eq((await mhs.patch(`/api/service-requests/${reqId}/status`, { status: "under_review" })).status, 403, "status");
    eq((await mhs.get("/api/service-requests?scope=staff")).status, 403, "antrean staf");
    eq((await mhs.get("/api/admin/reports")).status, 403, "admin");
  });
  await t("dosen yang tidak menangani layanan tidak dapat melihat pengajuan (404)", async () => { eq((await dosen.get(`/api/service-requests/${reqId}`)).status, 404); });
  await t("petugas penanggung jawab memproses; transisi tidak sah ditolak", async () => {
    eq((await petugas.get(`/api/service-requests/${reqId}`)).status, 200, "lihat");
    const bad = await petugas.patch(`/api/service-requests/${reqId}/status`, { status: "completed" }); ok([409, 422].includes(bad.status), `transisi tak sah → ${bad.status}`);
    const good = await petugas.patch(`/api/service-requests/${reqId}/status`, { status: "under_review", note: "uji" }); eq(good.status, 200, good.text.slice(0, 120));
  });
  await t("catatan internal tidak terlihat mahasiswa dan tidak bisa dibuat mahasiswa", async () => {
    eq((await petugas.post(`/api/service-requests/${reqId}/messages`, { body: "RAHASIA-INTERNAL", visibility: "internal" })).status, 201, "buat");
    eq((await mhs.post(`/api/service-requests/${reqId}/messages`, { body: "halo", visibility: "internal" })).status, 403, "mahasiswa buat internal");
    const d = (await mhs.get(`/api/service-requests/${reqId}`)).json; ok(!JSON.stringify(d).includes("RAHASIA-INTERNAL"), "catatan internal bocor");
  });
  await t("pemilik tidak dapat memproses pengajuannya sendiri lewat API staf", async () => {
    eq((await mhs.patch(`/api/service-requests/${reqId}/status`, { status: "confirmed" })).status, 403);
  });

  console.log("\nDokumen privat");
  await t("unggahan: berkas teks berkedok .pdf ditolak (cek magic bytes)", async () => {
    const f = new FormData(); f.set("file", new Blob(["ini bukan pdf"]), "palsu.pdf");
    const r = await mhs.req("POST", `/api/service-requests/${reqId}/documents`, { form: f }); eq(r.status, 422, r.text.slice(0, 150));
  });
  let docUrl = "";
  await t("unggahan PDF valid diterima; unduhan lewat URL bertanda tangan", async () => {
    const f = new FormData(); f.set("file", new Blob([PDF], { type: "application/pdf" }), "surat uji.pdf"); f.set("kind", "lampiran");
    const up = await mhs.req("POST", `/api/service-requests/${reqId}/documents`, { form: f }); eq(up.status, 201, up.text.slice(0, 150));
    const d = (await mhs.get(`/api/service-requests/${reqId}`)).json; docUrl = d.documents[0].url; ok(docUrl.startsWith("/api/files/"), docUrl);
    const dl = await mhs.get(docUrl); eq(dl.status, 200, "unduh"); eq(dl.headers.get("content-type"), "application/pdf", "mime");
    ok(/attachment/.test(dl.headers.get("content-disposition") ?? ""), "harus attachment"); eq(dl.headers.get("x-content-type-options"), "nosniff", "nosniff");
  });
  await t("URL unduhan dirusak atau dipakai orang lain → ditolak", async () => {
    eq((await mhs.get(docUrl.replace(/sig=.{4}/, "sig=AAAA"))).status, 403, "tanda tangan rusak");
    const other = await mhs2.get(docUrl); ok([403, 404].includes(other.status), `pengguna lain → ${other.status}`);
    eq((await new Client().get(docUrl)).status, 401, "tanpa sesi");
  });

  console.log("\nWebhook, cron, dan persetujuan WhatsApp");
  if (!WA_SECRET || !WA_VERIFY) skip("webhook WhatsApp", "WHATSAPP_APP_SECRET/WHATSAPP_VERIFY_TOKEN tidak diisi");
  else {
    await t("GET webhook: token benar → challenge; token salah → 403", async () => {
      const good = await new Client().get(`/api/integrations/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=${encodeURIComponent(WA_VERIFY)}&hub.challenge=12345`);
      eq(good.status, 200); eq(good.text, "12345", "challenge");
      eq((await new Client().get("/api/integrations/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=salah&hub.challenge=1")).status, 403);
    });
    await t("POST webhook tanpa/dengan tanda tangan salah → 401, payload tidak diproses", async () => {
      const body = JSON.stringify({ entry: [] });
      eq((await new Client().req("POST", "/api/integrations/whatsapp/webhook", { raw: body })).status, 401, "tanpa");
      eq((await new Client().req("POST", "/api/integrations/whatsapp/webhook", { raw: body, headers: { "x-hub-signature-256": "sha256=" + "0".repeat(64) } })).status, 401, "salah");
    });
    await t("POST webhook bertanda tangan benar diproses; event ganda dideduplikasi", async () => {
      const body = JSON.stringify({ entry: [{ changes: [{ value: { statuses: [{ id: `wamid.e2e${stamp}`, status: "delivered" }] } }] }] });
      const h = { "x-hub-signature-256": "sha256=" + hmacHex(WA_SECRET, body) };
      const a = await new Client().req("POST", "/api/integrations/whatsapp/webhook", { raw: body, headers: h }); eq(a.status, 200); eq(a.json.processed, 1, "diproses");
      const b = await new Client().req("POST", "/api/integrations/whatsapp/webhook", { raw: body, headers: h }); eq(b.json.duplicates, 1, "duplikat");
    });
    await t("balasan STOP dari penerima mencabut persetujuan WhatsApp", async () => {
      const before = (await me.get("/api/me/preferences")).json;
      const from = reg.whatsapp_number.replace(/^0/, "62");
      const body = JSON.stringify({ entry: [{ changes: [{ value: { messages: [{ id: `wamid.stop${stamp}`, from, type: "text", text: { body: "STOP" } }] } }] }] });
      const r = await new Client().req("POST", "/api/integrations/whatsapp/webhook", { raw: body, headers: { "x-hub-signature-256": "sha256=" + hmacHex(WA_SECRET, body) } }); eq(r.status, 200, r.text.slice(0, 120));
      const after = (await me.get("/api/me/preferences")).json;
      eq(after.whatsapp_enabled, false, "whatsapp_enabled"); eq(after.whatsapp_consent, false, "consent"); eq(before.whatsapp_enabled, true, "sebelum STOP, pengguna harus sudah berlangganan");
    });
  }
  if (!PAY_SECRET) skip("webhook pembayaran", "PAYMENT_WEBHOOK_SECRET tidak diisi");
  else await t("webhook pembayaran: tanda tangan salah → 401; benar tetapi pembayaran nonaktif → 409", async () => {
    const body = JSON.stringify({ event_id: `evt-${stamp}`, type: "payment.paid", reference: "00000000-0000-0000-0000-000000000000", amount: 1000 });
    eq((await new Client().req("POST", "/api/integrations/payments/webhook", { raw: body, headers: { "x-signature": "salah" } })).status, 401, "salah");
    eq((await new Client().req("POST", "/api/integrations/payments/webhook", { raw: body })).status, 401, "tanpa");
    eq((await new Client().req("POST", "/api/integrations/payments/webhook", { raw: body, headers: { "x-signature": hmacHex(PAY_SECRET, body) } })).status, 409, "nonaktif");
  });
  if (!CRON_SECRET) skip("endpoint cron", "CRON_SECRET tidak diisi");
  else await t("cron: tanpa/salah bearer → 401; benar → 200", async () => {
    eq((await new Client().post("/api/cron/process-jobs")).status, 401, "tanpa");
    eq((await new Client().post("/api/cron/process-jobs", undefined, { authorization: "Bearer salah" })).status, 401, "salah");
    const r = await new Client().post("/api/cron/process-jobs", undefined, { authorization: `Bearer ${CRON_SECRET}` }); eq(r.status, 200, r.text.slice(0, 120)); ok(r.json?.ok, "ok");
  });

  console.log("\nSesi");
  await t("logout mencabut sesi di server (token lama tidak berlaku lagi)", async () => {
    const c = await login("mahasiswa2@example.test"); const tok = new Map(c.jar);
    eq((await c.post("/api/auth/logout")).status, 200); eq((await c.get("/api/auth/me")).status, 401, "setelah logout");
    const replay = new Client(); replay.jar = tok; eq((await replay.get("/api/auth/me")).status, 401, "token lama");
  });
  await t("admin dapat membuka laporan; respons tidak memuat rahasia", async () => {
    const a = await login("admin@example.test"); const r = await a.get("/api/admin/reports"); eq(r.status, 200);
    const w = await a.get("/api/admin/whatsapp"); eq(w.status, 200);
    ok(!/access_token|app_secret|whatsapp_token/i.test(JSON.stringify(w.json).replace(/"(tokenSet|appSecretSet|verifyTokenSet)"/g, "")), "rahasia terlihat");
    const raw = JSON.stringify(w.json); if (WA_SECRET) ok(!raw.includes(WA_SECRET), "app secret bocor ke respons admin"); if (WA_VERIFY) ok(!raw.includes(WA_VERIFY), "verify token bocor");
  });

  console.log(`\nHasil: ${pass} lulus, ${fail} gagal, ${skipped} dilewati`);
  if (failures.length) console.log("Gagal:\n - " + failures.join("\n - "));
  if (skipped) console.log("Catatan: bagian yang dilewati TIDAK teruji pada eksekusi ini.");
  process.exit(fail ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(2); });
