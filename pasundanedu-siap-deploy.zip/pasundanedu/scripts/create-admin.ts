import "./load-env";
import { closeDb, getDb } from "../src/server/db";
import { createAdmin } from "../src/server/seed";
import { passwordSchema } from "../src/lib/validation";

// Pemakaian: npm run admin:create -- email@kampus.ac.id "Nama Lengkap"   (kata sandi dibaca dari ADMIN_PASSWORD)
const [email, name] = process.argv.slice(2);
const password = process.env.ADMIN_PASSWORD ?? "";
if (!email || !name || !password) {
  console.error('Pemakaian: ADMIN_PASSWORD="..." npm run admin:create -- email@domain "Nama Lengkap"');
  process.exit(1);
}
const parsed = passwordSchema.safeParse(password);
if (!parsed.success) {
  console.error("Kata sandi tidak memenuhi syarat:", parsed.error.issues.map((i) => i.message).join(" "));
  process.exit(1);
}
const db = await getDb();
await createAdmin(db, email, password, name);
console.log(`Admin dibuat/diperbarui: ${email}`);
await closeDb();
