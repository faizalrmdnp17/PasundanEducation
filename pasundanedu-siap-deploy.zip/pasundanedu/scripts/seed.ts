import "./load-env";
import { closeDb, getDb } from "../src/server/db";
import { env } from "../src/server/env";
import { createAdmin, DEMO_PASSWORD, DEMO_USERS, seedCatalog, seedDemo } from "../src/server/seed";

const wantDemo = process.argv.includes("--demo");
const db = await getDb();

await db.tx((q) => seedCatalog(q));
console.log("✔ Seed katalog selesai (kategori, layanan, template WhatsApp, integrasi, pengaturan awal).");

if (wantDemo) {
  // Dua pagar: (1) NODE_ENV=production, (2) database sudah berisi pengguna selain akun contoh (@example.test), tanda data nyata.
  const real = (await db.query<{ n: number }>("select count(*)::int as n from profiles where email not like '%@example.test'")).rows[0]!.n;
  if ((env.isProd || real > 0) && process.env.ALLOW_DEMO_SEED !== "true") {
    console.error(env.isProd
      ? "✖ Seed demo ditolak pada produksi. Set ALLOW_DEMO_SEED=true bila benar-benar disengaja."
      : `✖ Seed demo ditolak: database sudah berisi ${real} pengguna bukan-contoh (kemungkinan data nyata). Set ALLOW_DEMO_SEED=true bila benar-benar disengaja.`);
    process.exitCode = 1;
  } else {
    await seedDemo(db);
    console.log("✔ Seed demo selesai (data fiktif @example.test). Kata sandi seluruh akun demo:", DEMO_PASSWORD);
    for (const u of DEMO_USERS) console.log(`   - ${u.role.padEnd(9)} ${u.email}`);
  }
}

if (env.seedAdminEmail && env.seedAdminPassword) {
  await createAdmin(db, env.seedAdminEmail, env.seedAdminPassword, env.seedAdminName);
  console.log(`✔ Akun admin awal dibuat/diperbarui: ${env.seedAdminEmail}`);
}
await closeDb();
