# alur pesan, proses, dan notifikasi lewat antarmuka
# Uji UI dengan Playwright (Python). Jalankan terhadap server yang berjalan.
#   E2E_BASE_URL (default http://localhost:3000), UI_OUT (folder tangkapan layar, default ./.ui-out)
# Prasyarat: pip install playwright && playwright install chromium; basis data berisi seed demo.
import os
os.makedirs(os.environ.get('UI_OUT','./.ui-out'),exist_ok=True)
import asyncio, re
from playwright.async_api import async_playwright, expect
OUT=os.environ.get("UI_OUT","./.ui-out")
BASE=os.environ.get("E2E_BASE_URL","http://localhost:3000"); PW="DemoPasundan2026"
async def login(b, email, mobile=False):
    ctx=await b.new_context(viewport={"width":390 if mobile else 1280,"height":780 if mobile else 820}, is_mobile=mobile)
    pg=await ctx.new_page()
    errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.goto(BASE+"/masuk", wait_until="networkidle")
    await pg.fill('input[name=email]', email); await pg.fill('input[name=password]', PW)
    await pg.click('button[type=submit]'); await pg.wait_for_url(lambda u:"/masuk" not in u, timeout=15000)
    return ctx,pg,errs
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/opt/pw-browsers/chromium")
        ctx,pg,errs=await login(b,"mahasiswa@example.test")
        # 1. buka layanan berjadwal
        await pg.goto(BASE+"/layanan/bimbingan-skripsi", wait_until="networkidle")
        await pg.screenshot(path=f"{OUT}/flow-1-layanan-detail.png", full_page=True)
        slots=pg.locator('input[name=slot]'); n=await slots.count(); print("slot tersedia:", n)
        assert n>0
        btn=pg.get_by_role("button", name="Kirim pengajuan")
        assert await btn.is_disabled(), "tombol harus nonaktif sebelum slot dipilih"
        await slots.first.check()
        await pg.get_by_label("Topik atau keperluan (opsional)").fill("Bab 3 metode penelitian")
        await pg.get_by_label("Catatan untuk penanggung jawab (opsional)").fill("Mohon arahan pemilihan sampel.")
        await btn.click()
        await pg.wait_for_url(re.compile(r"/riwayat/[0-9a-f-]{36}"), timeout=15000)
        rid=pg.url.split("/riwayat/")[1].split("?")[0]; print("pengajuan dibuat:", rid)
        await pg.wait_for_load_state("networkidle")
        assert await pg.get_by_text("terkirim").first.is_visible()
        txt=await pg.inner_text("main")
        assignee="dosen@example.test" if "Dr. Dosen Demo" in txt else "dosen2@example.test"
        print("penanggung jawab:", assignee)
        await pg.screenshot(path=f"{OUT}/flow-2-detail-mhs.png", full_page=True)
        # 2. dosen memproses
        dctx,dpg,derrs=await login(b,assignee)
        await dpg.goto(BASE+"/pengajuan?k=baru", wait_until="networkidle")
        await dpg.screenshot(path=f"{OUT}/flow-3-antrean-dosen.png", full_page=True)
        await dpg.goto(f"{BASE}/pengajuan/{rid}", wait_until="networkidle")
        await dpg.select_option("select >> nth=0", "under_review") if False else None
        sel=dpg.locator("select").filter(has=dpg.locator("option[value=under_review]")).first
        await sel.select_option("under_review")
        await dpg.get_by_label(re.compile("Catatan untuk mahasiswa")).fill("Berkas diterima, kita bahas saat jadwal.")
        await dpg.get_by_role("button", name="Simpan status").click()
        await dpg.wait_for_selector("text=Status diperbarui", timeout=10000)
        await dpg.wait_for_load_state("networkidle")
        await dpg.get_by_label("Tulis pesan").fill("Mohon siapkan draf Bab 3 sebelum bertemu.")
        await dpg.get_by_role("button", name="Kirim pesan").click()
        await dpg.locator("section[aria-labelledby=pesan] li", has_text="Mohon siapkan draf Bab 3").wait_for(timeout=10000)
        await dpg.screenshot(path=f"{OUT}/flow-4-detail-dosen.png", full_page=True)
        # 3. mahasiswa melihat dampak
        await pg.goto(f"{BASE}/riwayat/{rid}", wait_until="networkidle")
        body=await pg.inner_text("main")
        for needle in ("Ditinjau","Berkas diterima","Mohon siapkan draf Bab 3"):
            assert needle in body, needle+" tidak tampil di sisi mahasiswa"
        await pg.screenshot(path=f"{OUT}/flow-5-detail-mhs-after.png", full_page=True)
        await pg.goto(BASE+"/notifikasi", wait_until="networkidle")
        nb=await pg.inner_text("main"); print("notifikasi:", [l for l in nb.split("\n") if l.strip()][:6])
        assert "Pengajuan terkirim" in nb
        # 4. catatan internal tidak bocor
        await dpg.get_by_label("Tulis pesan").fill("INTERNAL-RAHASIA")
        await dpg.locator("select").filter(has=dpg.locator("option[value=internal]")).first.select_option("internal")
        await dpg.get_by_role("button", name="Kirim pesan").click()
        await dpg.locator("section[aria-labelledby=pesan] li", has_text="INTERNAL-RAHASIA").wait_for(timeout=10000)
        await pg.goto(f"{BASE}/riwayat/{rid}", wait_until="networkidle")
        assert "INTERNAL-RAHASIA" not in await pg.inner_text("body"), "catatan internal bocor ke mahasiswa!"
        print("catatan internal tidak terlihat mahasiswa: OK")
        # 5. mahasiswa lain tidak bisa membuka
        c2,p2,_=await login(b,"mahasiswa2@example.test")
        r=await p2.goto(f"{BASE}/riwayat/{rid}", wait_until="networkidle"); print("mahasiswa lain ->", r.status)
        assert r.status==404
        # 6. mahasiswa tidak boleh buka halaman staf / admin
        r=await pg.goto(BASE+"/admin", wait_until="networkidle"); print("mahasiswa -> /admin:", r.status); assert r.status==404
        r=await pg.goto(f"{BASE}/pengajuan/{rid}", wait_until="networkidle"); print("mahasiswa -> /pengajuan/id:", r.status); assert r.status==404
        print("JS errors:", errs, derrs)
        await b.close()
asyncio.run(main())
