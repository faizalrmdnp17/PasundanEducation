# audit overflow horizontal di 390px
# Uji UI dengan Playwright (Python). Jalankan terhadap server yang berjalan.
#   E2E_BASE_URL (default http://localhost:3000), UI_OUT (folder tangkapan layar, default ./.ui-out)
# Prasyarat: pip install playwright && playwright install chromium; basis data berisi seed demo.
import os
os.makedirs(os.environ.get('UI_OUT','./.ui-out'),exist_ok=True)
import asyncio, sys
from playwright.async_api import async_playwright
BASE=os.environ.get("E2E_BASE_URL","http://localhost:3000"); PW="DemoPasundan2026"
W=390
JS="""(W)=>{const out=[];const de=document.documentElement;
 const over=de.scrollWidth-de.clientWidth;
 for(const el of document.querySelectorAll('body *')){const r=el.getBoundingClientRect(); if(r.width>0&&r.right>W+1){const cs=getComputedStyle(el); if(cs.position==='fixed')continue; out.push({tag:el.tagName.toLowerCase(),cls:(el.className&&el.className.toString()||'').slice(0,70),right:Math.round(r.right),w:Math.round(r.width)});}}
 out.sort((a,b)=>b.right-a.right); return {over, sw:de.scrollWidth, top:out.slice(0,4)};}"""
PLAN={
 "mahasiswa@example.test":["/","/layanan","/layanan/bimbingan-skripsi","/pustaka","/favorit","/riwayat","/jadwal","/notifikasi","/info","/akun"],
 "dosen@example.test":["/dosen","/pengajuan","/pengajuan?k=semua","/jadwal"],
 "petugas@example.test":["/petugas"],
 "admin@example.test":["/admin","/admin/pengguna","/admin/layanan","/admin/pustaka","/admin/pengumuman","/admin/pembayaran","/admin/whatsapp","/admin/integrasi","/admin/audit","/admin/pengaturan"],
}
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/opt/pw-browsers/chromium")
        bad=0
        # halaman publik/auth tanpa login
        ctx=await b.new_context(viewport={"width":W,"height":780},is_mobile=True); pg=await ctx.new_page()
        for path in ["/masuk","/daftar","/lupa-sandi","/faq","/privasi","/syarat"]:
            await pg.goto(BASE+path,wait_until="networkidle"); r=await pg.evaluate(JS,W)
            flag="OVERFLOW" if r["over"]>0 else "ok"; bad+= r["over"]>0
            print(f"{flag:9} {path:32} scrollW={r['sw']}", r["top"][:2] if r["over"]>0 else "")
        await ctx.close()
        for email,paths in PLAN.items():
            ctx=await b.new_context(viewport={"width":W,"height":780},is_mobile=True); pg=await ctx.new_page()
            await pg.goto(BASE+"/masuk"); await pg.fill('input[name=email]',email); await pg.fill('input[name=password]',PW)
            await pg.click('button[type=submit]'); await pg.wait_for_url(lambda u:"/masuk" not in u)
            for path in paths:
                await pg.goto(BASE+path,wait_until="networkidle"); r=await pg.evaluate(JS,W)
                flag="OVERFLOW" if r["over"]>0 else "ok"; bad+= r["over"]>0
                print(f"{flag:9} {path:32} scrollW={r['sw']}", r["top"][:3] if r["over"]>0 else "")
            await ctx.close()
        print("halaman dengan overflow:",bad); await b.close()
asyncio.run(main())
