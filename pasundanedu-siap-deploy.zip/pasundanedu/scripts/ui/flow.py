# login per peran + tangkapan layar halaman utama
# Pemakaian: python3 flow.py <email-akun-demo> <tag> nama=/jalur [nama=/jalur ...]
#   contoh: python3 flow.py mahasiswa@example.test m beranda=/ layanan=/layanan riwayat=/riwayat
# Uji UI dengan Playwright (Python). Jalankan terhadap server yang berjalan.
#   E2E_BASE_URL (default http://localhost:3000), UI_OUT (folder tangkapan layar, default ./.ui-out)
# Prasyarat: pip install playwright && playwright install chromium; basis data berisi seed demo.
import os
os.makedirs(os.environ.get('UI_OUT','./.ui-out'),exist_ok=True)
import sys, asyncio, json
from playwright.async_api import async_playwright
OUT=os.environ.get("UI_OUT","./.ui-out")
BASE=os.environ.get("E2E_BASE_URL","http://localhost:3000")
PW="DemoPasundan2026"
async def login(ctx, email):
    pg=await ctx.new_page()
    await pg.goto(BASE+"/masuk", wait_until="networkidle")
    await pg.fill('input[name=email]', email)
    await pg.fill('input[name=password]', PW)
    await pg.click('button[type=submit]')
    await pg.wait_for_url(lambda u: "/masuk" not in u, timeout=15000)
    return pg
async def main(who, paths, tag):
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/opt/pw-browsers/chromium")
        for label,vw,vh,mobile in (("d",1280,820,False),("m",390,780,True)):
            ctx=await b.new_context(viewport={"width":vw,"height":vh},is_mobile=mobile)
            pg=await login(ctx, who)
            print(label, "landed", pg.url)
            for name,path in paths:
                errs=[]
                pg.on("pageerror", lambda e: errs.append(str(e)))
                pg.on("console", lambda m: errs.append(m.text) if m.type=="error" else None)
                r=await pg.goto(BASE+path, wait_until="networkidle")
                await pg.screenshot(path=f"{OUT}/{tag}-{name}-{label}.png", full_page=True)
                print(label, name, r.status if r else None, pg.url.replace(BASE,""), ("ERR:"+"; ".join(errs[:2])) if errs else "")
            await ctx.close()
        await b.close()
who=sys.argv[1]; tag=sys.argv[2]
paths=[a.split("=",1) for a in sys.argv[3:]]
asyncio.run(main(who, paths, tag))
