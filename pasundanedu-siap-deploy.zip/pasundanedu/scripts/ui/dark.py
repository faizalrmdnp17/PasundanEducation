# tangkapan layar mode gelap
# Uji UI dengan Playwright (Python). Jalankan terhadap server yang berjalan.
#   E2E_BASE_URL (default http://localhost:3000), UI_OUT (folder tangkapan layar, default ./.ui-out)
# Prasyarat: pip install playwright && playwright install chromium; basis data berisi seed demo.
import os
os.makedirs(os.environ.get('UI_OUT','./.ui-out'),exist_ok=True)
import asyncio
from playwright.async_api import async_playwright
OUT=os.environ.get("UI_OUT","./.ui-out"); BASE=os.environ.get("E2E_BASE_URL","http://localhost:3000")
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/opt/pw-browsers/chromium")
        ctx=await b.new_context(viewport={"width":390,"height":844},is_mobile=True,color_scheme="dark"); pg=await ctx.new_page()
        await pg.goto(BASE+"/masuk",wait_until="networkidle"); await pg.screenshot(path=f"{OUT}/dark-masuk.png")
        await pg.goto(BASE+"/daftar",wait_until="networkidle"); await pg.screenshot(path=f"{OUT}/dark-daftar.png")
        await pg.goto(BASE+"/masuk",wait_until="networkidle")
        await pg.fill('input[name=email]',"mahasiswa@example.test"); await pg.fill('input[name=password]',"DemoPasundan2026")
        await pg.click('button[type=submit]'); await pg.wait_for_url(lambda u:"/masuk" not in u)
        for n,path in (("beranda","/"),("pustaka","/pustaka"),("layanan-detail","/layanan/bimbingan-skripsi")):
            await pg.goto(BASE+path,wait_until="networkidle"); await pg.screenshot(path=f"{OUT}/dark-{n}.png")
        await b.close()
asyncio.run(main())
