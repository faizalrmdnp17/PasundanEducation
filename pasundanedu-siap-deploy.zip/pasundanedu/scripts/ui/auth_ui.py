# registrasi, verifikasi, reset sandi, open-redirect (butuh `npm run dev`; token dibaca dari log email simulasi di DEV_LOG)
# Uji UI dengan Playwright (Python). Jalankan terhadap server yang berjalan.
#   E2E_BASE_URL (default http://localhost:3000), UI_OUT (folder tangkapan layar, default ./.ui-out)
# Prasyarat: pip install playwright && playwright install chromium; basis data berisi seed demo.
import os
os.makedirs(os.environ.get('UI_OUT','./.ui-out'),exist_ok=True)
import asyncio, re, time
from playwright.async_api import async_playwright
SP=os.environ.get("UI_OUT","./.ui-out")
BASE=os.environ.get("E2E_BASE_URL","http://localhost:3000")
stamp=str(int(time.time()))
EMAIL=f"uji{stamp}@example.test"; PW1="AwalSandi2026"; PW2="BaruSandi2026x"
def token_from_log(kind, email, timeout=25):
    end=time.time()+timeout
    while time.time()<end:
        txt=open(os.environ.get("DEV_LOG","dev.log"),errors="ignore").read()
        blocks=re.split(r"\[email:simulasi\] ", txt)
        for blk in reversed(blocks):
            if f"kepada={email}" in blk and kind in blk:
                m=re.search(r"token=([A-Za-z0-9_\-]+)", blk)
                if m: return m.group(1)
        time.sleep(1)
    raise AssertionError(f"email {kind} untuk {email} tidak muncul di log")
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/opt/pw-browsers/chromium")
        ctx=await b.new_context(viewport={"width":1280,"height":900}); pg=await ctx.new_page()
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
        # 1. validasi: tanpa menyetujui syarat
        await pg.goto(BASE+"/daftar",wait_until="networkidle")
        await pg.fill('input[name=full_name]',"Uji Otomatis"); await pg.fill('input[name=email]',EMAIL)
        await pg.fill('input[name=npm]',"2026"+stamp[-6:]); await pg.fill('input[name=password]',PW1)
        await pg.get_by_role("button",name="Daftar",exact=True).click()
        await pg.get_by_text("Anda harus menyetujui").wait_for(timeout=8000); print("validasi syarat: OK")
        # 2. daftar benar
        await pg.get_by_label(re.compile("Saya menyetujui")).check()
        await pg.get_by_role("button",name="Daftar",exact=True).click()
        await pg.wait_for_url(re.compile(r"/\?baru=1"),timeout=15000)
        assert await pg.get_by_text("Akun Anda sudah dibuat").is_visible()
        assert await pg.get_by_text("Email Anda belum diverifikasi").first.is_visible(); print("daftar mahasiswa -> beranda + banner verifikasi: OK")
        # 3. belum terverifikasi: tombol kirim pengajuan nonaktif
        await pg.goto(BASE+"/layanan/surat-keterangan-mahasiswa",wait_until="networkidle")
        assert await pg.get_by_role("button",name="Kirim pengajuan").is_disabled(); print("pengajuan diblokir sebelum verifikasi: OK")
        # 4. verifikasi email
        tok=token_from_log("Verifikasi", EMAIL) if False else token_from_log("verifikasi", EMAIL)
        await pg.goto(f"{BASE}/verifikasi?token={tok}",wait_until="networkidle")
        await pg.get_by_text("sudah terverifikasi").wait_for(timeout=8000); print("verifikasi email: OK")
        await pg.goto(f"{BASE}/verifikasi?token={tok}",wait_until="networkidle")
        await pg.locator("div.alert-bad[role=alert]").wait_for(timeout=8000); print("token verifikasi tidak bisa dipakai ulang: OK")
        # 5. keluar
        await pg.goto(BASE+"/akun",wait_until="networkidle")
        await pg.get_by_role("button",name="Keluar").first.click(); await pg.wait_for_url(re.compile(r"/masuk"),timeout=10000)
        r=await pg.goto(BASE+"/layanan"); assert "/masuk" in pg.url; print("setelah keluar /layanan -> /masuk:", pg.url.replace(BASE,""))
        # 6. login salah
        await pg.goto(BASE+"/masuk",wait_until="networkidle")
        await pg.fill('input[name=email]',EMAIL); await pg.fill('input[name=password]',"SalahSalah123")
        await pg.get_by_role("button",name="Masuk",exact=True).click()
        err=pg.locator("div.alert-bad[role=alert]"); await err.wait_for(timeout=8000); print("login salah ->", (await err.inner_text()).strip()); assert "/masuk" in pg.url
        # 7. lupa sandi + atur ulang
        await pg.goto(BASE+"/lupa-sandi",wait_until="networkidle"); await pg.fill('input[type=email]',EMAIL)
        await pg.get_by_role("button",name="Kirim tautan atur ulang").click(); await pg.get_by_text("Jika email terdaftar").wait_for(timeout=8000)
        rt=token_from_log("atur ulang", EMAIL) if False else None
        txt=open(os.environ.get("DEV_LOG","dev.log"),errors="ignore").read()
        def reset_tok():
            end=time.time()+25
            while time.time()<end:
                t=open(os.environ.get("DEV_LOG","dev.log"),errors="ignore").read()
                for blk in reversed(re.split(r"\[email:simulasi\] ",t)):
                    if f"kepada={EMAIL}" in blk and "atur-ulang-sandi" in blk:
                        m=re.search(r"atur-ulang-sandi\?token=([A-Za-z0-9_\-]+)",blk)
                        if m: return m.group(1)
                time.sleep(1)
            raise AssertionError("email reset tidak muncul")
        rt=reset_tok()
        await pg.goto(f"{BASE}/atur-ulang-sandi?token={rt}",wait_until="networkidle"); await pg.fill('input[name=password]',PW2)
        await pg.get_by_role("button",name="Simpan kata sandi baru").click(); await pg.wait_for_url(re.compile(r"/masuk\?diatur=1"),timeout=10000)
        assert await pg.get_by_text("Kata sandi diperbarui").is_visible(); print("atur ulang kata sandi -> notice di /masuk: OK")
        await pg.goto(f"{BASE}/atur-ulang-sandi?token={rt}",wait_until="networkidle"); await pg.fill('input[name=password]',"LainLagi2026x")
        await pg.get_by_role("button",name="Simpan kata sandi baru").click(); await pg.locator("div.alert-bad[role=alert]").wait_for(timeout=8000); assert "kedaluwarsa" in await pg.locator("div.alert-bad[role=alert]").inner_text(); print("token reset sekali pakai: OK")
        # 8. login sandi lama gagal, baru berhasil, dan anti open redirect
        await pg.goto(BASE+"/masuk?next=//evil.example.com",wait_until="networkidle")
        await pg.fill('input[name=email]',EMAIL); await pg.fill('input[name=password]',PW1); await pg.get_by_role("button",name="Masuk",exact=True).click()
        await pg.locator("div.alert-bad[role=alert]").wait_for(timeout=8000); print("sandi lama ditolak: OK")
        await pg.fill('input[name=password]',PW2); await pg.get_by_role("button",name="Masuk",exact=True).click()
        await pg.wait_for_url(lambda u: "/masuk" not in u, timeout=15000)
        assert pg.url.startswith(BASE) and "evil" not in pg.url; print("login sandi baru + open-redirect diblokir ->", pg.url.replace(BASE,""))
        # 9. dosen: menunggu persetujuan
        c2=await b.new_context(viewport={"width":1280,"height":900}); p2=await c2.new_page()
        await p2.goto(BASE+"/daftar",wait_until="networkidle")
        await p2.get_by_text("Dosen",exact=True).click()
        await p2.fill('input[name=full_name]',"Dosen Uji"); await p2.fill('input[name=email]',f"dosen{stamp}@example.test")
        await p2.fill('input[name=nidn]',"04"+stamp[-8:]); await p2.fill('input[name=password]',PW1)
        await p2.get_by_label(re.compile("Saya menyetujui")).check(); await p2.get_by_role("button",name="Daftar",exact=True).click()
        await p2.wait_for_url(re.compile(r"/menunggu-persetujuan"),timeout=15000); print("daftar dosen -> menunggu persetujuan: OK")
        await p2.goto(BASE+"/dosen",wait_until="networkidle"); assert "/menunggu-persetujuan" in p2.url; print("dosen belum disetujui tidak bisa buka /dosen: OK")
        await p2.goto(BASE+"/admin",wait_until="networkidle"); assert "/menunggu-persetujuan" in p2.url
        print("JS errors:",errs); await b.close()
asyncio.run(main())
