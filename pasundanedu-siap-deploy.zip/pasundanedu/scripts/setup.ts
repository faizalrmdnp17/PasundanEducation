import "./load-env";
import { closeDb, getDb } from "../src/server/db";
import { env } from "../src/server/env";
import { runMigrations } from "../src/server/migrate";
import { seedCatalog, seedDemo } from "../src/server/seed";

/**
 * Persiapan lingkungan pengembangan: migrasi + seed katalog + seed demo (hanya bila belum ada pengguna).
 * Dipanggil otomatis oleh `npm run dev`. Tidak dipakai di produksi.
 */
if (env.isProd) {
  console.error("db:setup hanya untuk pengembangan. Gunakan db:migrate dan db:seed pada produksi.");
  process.exit(1);
}
const db = await getDb();
const applied = await runMigrations(db);
if (applied.length) console.log("Migrasi diterapkan:", applied.join(", "));
await db.tx((q) => seedCatalog(q));
const { rows } = await db.query<{ n: number }>("select count(*)::int as n from profiles");
if (rows[0]!.n === 0 && process.env.SEED_DEMO !== "false") {
  await seedDemo(db);
  console.log("Seed demo dibuat (akun @example.test, kata sandi: DemoPasundan2026).");
}
await closeDb();
