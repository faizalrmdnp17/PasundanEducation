// Memuat .env, .env.local, .env.production dll. dengan aturan yang sama seperti Next.js, agar skrip CLI (migrasi, seed, worker)
// memakai konfigurasi yang sama dengan aplikasi. Variabel yang sudah ada di lingkungan proses tidak ditimpa.
// Impor berkas ini PALING AWAL di setiap skrip. Untuk produksi jalankan dengan NODE_ENV=production.
import { createRequire } from "node:module";

// @next/env adalah modul CommonJS; require lewat createRequire agar bekerja di skrip ESM.
const { loadEnvConfig } = createRequire(import.meta.url)("@next/env") as typeof import("@next/env");
loadEnvConfig(process.cwd(), process.env.NODE_ENV !== "production");
