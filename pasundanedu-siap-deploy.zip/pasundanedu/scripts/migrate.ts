import "./load-env";
import { closeDb, getDb } from "../src/server/db";
import { runMigrations } from "../src/server/migrate";

// Jalankan migrasi secara eksplisit (untuk PostgreSQL produksi: AUTO_MIGRATE tidak aktif secara bawaan).
process.env.AUTO_MIGRATE = "false";
const db = await getDb();
const applied = await runMigrations(db);
console.log(applied.length ? `Migrasi diterapkan: ${applied.join(", ")}` : "Skema sudah mutakhir.");
await closeDb();
