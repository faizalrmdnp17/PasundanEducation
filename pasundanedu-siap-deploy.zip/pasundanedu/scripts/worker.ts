import "./load-env";
import { closeDb } from "../src/server/db";
import { enqueueAppointmentReminders, processDueJobs } from "../src/server/jobs";
import { purgeRateLimits } from "../src/server/rate-limit";

/**
 * Worker antrean notifikasi (proses terpisah). Jalankan: npm run worker
 * Untuk deployment serverless, gunakan POST /api/cron/process-jobs dari penjadwal eksternal.
 */
const intervalSec = Number(process.env.WORKER_INTERVAL_SEC ?? 30);
let stop = false;
process.on("SIGINT", () => (stop = true));
process.on("SIGTERM", () => (stop = true));

console.log(`Worker aktif (interval ${intervalSec} detik). Ctrl+C untuk berhenti.`);
let tick = 0;
while (!stop) {
  try {
    const reminders = await enqueueAppointmentReminders();
    const r = await processDueJobs({ limit: 50 });
    if (reminders || r.claimed) console.log(new Date().toISOString(), { reminders, ...r });
    if (++tick % 120 === 0) await purgeRateLimits();
  } catch (e) {
    console.error("Worker error:", (e as Error).message);
  }
  await new Promise((res) => setTimeout(res, intervalSec * 1000));
}
await closeDb();
