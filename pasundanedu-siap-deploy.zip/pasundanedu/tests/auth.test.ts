import { beforeAll, describe, expect, it } from "vitest";
import { query } from "@/server/db";
import { register, login, verifyEmail, requestPasswordReset, resetPassword, changePassword, resendVerification } from "@/server/auth/service";
import { userFromToken } from "@/server/auth/session";
import { clearOutbox, emailConfigured, getOutbox } from "@/server/integrations/email";
import { registerSchema } from "@/lib/validation";
import { setupDb, PASSWORD } from "./helpers";

const meta = (ip = "10.0.0.1") => ({ ip, userAgent: "vitest" });
const base = (over: Record<string, unknown> = {}) =>
  registerSchema.parse({
    full_name: "Budi Santoso", email: "budi@example.test", password: PASSWORD, account_type: "mahasiswa", npm: "2025123456",
    accept_terms: true, consent_whatsapp: false, consent_email: true, ...over,
  });

beforeAll(async () => { await setupDb(); });

describe("registrasi", () => {
  it("menyimpan pengguna, peran mahasiswa, persetujuan, dan mengirim email verifikasi", async () => {
    clearOutbox();
    const r = await register(base(), meta("10.0.0.2"));
    expect(r.status).toBe("active");
    const u = await userFromToken(r.sessionToken);
    expect(u?.email).toBe("budi@example.test");
    expect(u?.roles).toEqual(["mahasiswa"]);
    expect(u?.emailVerified).toBe(false);
    const consents = await query("select consent_type, granted from consents where user_id = $1 order by consent_type", [u!.id]);
    expect(consents.rows.map((c) => c.consent_type)).toEqual(["email", "privacy", "terms", "whatsapp"]);
    expect(getOutbox().some((m) => m.to === "budi@example.test" && m.text.includes("/verifikasi?token="))).toBe(true);
  });

  it("melaporkan jujur bila email verifikasi tidak dapat dikirim (SMTP belum diatur), tanpa membatalkan pendaftaran", async () => {
    const prev = { p: process.env.EMAIL_PROVIDER, u: process.env.SMTP_URL };
    process.env.EMAIL_PROVIDER = "smtp";
    delete process.env.SMTP_URL;
    try {
      expect(emailConfigured()).toBe(false);
      const r = await register(base({ email: "tanpa-smtp@example.test", npm: "2025777001" }), meta("10.0.0.77"));
      expect(r.emailSent).toBe(false);
      const u = await userFromToken(r.sessionToken);
      expect(u?.email).toBe("tanpa-smtp@example.test");
      await expect(resendVerification(u!.id, meta("10.0.0.77"))).rejects.toMatchObject({ status: 503, code: "email_unavailable" });
    } finally {
      if (prev.p === undefined) delete process.env.EMAIL_PROVIDER; else process.env.EMAIL_PROVIDER = prev.p;
      if (prev.u === undefined) delete process.env.SMTP_URL; else process.env.SMTP_URL = prev.u;
    }
    expect(emailConfigured()).toBe(true); // provider "log" siap di luar produksi
  });

  it("kata sandi disimpan sebagai hash di tabel terpisah, bukan di profil", async () => {
    const cols = await query("select column_name from information_schema.columns where table_name = 'profiles'");
    expect(cols.rows.map((c) => c.column_name).join(",")).not.toMatch(/password/);
    const h = await query("select password_hash from auth_credentials limit 1");
    expect(h.rows[0]!.password_hash).toMatch(/^scrypt\$/);
    expect(h.rows[0]!.password_hash).not.toContain(PASSWORD);
  });

  it("menolak email duplikat (tanpa membedakan huruf besar/kecil)", async () => {
    await expect(register(base({ email: "BUDI@example.test", npm: "2025999999" }), meta("10.0.0.3"))).rejects.toMatchObject({ code: "email_taken", status: 409 });
  });

  it("menolak NPM duplikat", async () => {
    await expect(register(base({ email: "lain@example.test" }), meta("10.0.0.4"))).rejects.toMatchObject({ status: 422 });
  });

  it("validasi: kata sandi lemah, NPM wajib untuk mahasiswa, persetujuan wajib", () => {
    expect(() => base({ password: "abc" })).toThrow();
    expect(() => base({ password: "password123" })).toThrow();
    expect(() => base({ npm: "" })).toThrow();
    expect(() => base({ accept_terms: false })).toThrow();
    expect(() => base({ password: "budi12345" })).toThrow(); // memuat bagian email
  });

  it("registrasi dosen tidak mendapat peran; masuk antrean persetujuan pengelola", async () => {
    const r = await register(base({ email: "dosen.baru@example.test", account_type: "dosen", npm: "", nidn: "0412999999" }), meta("10.0.0.5"));
    expect(r.status).toBe("pending_approval");
    const u = await userFromToken(r.sessionToken);
    expect(u?.roles).toEqual([]);
    expect(u?.status).toBe("pending_approval");
    const rr = await query("select status from role_requests where user_id = $1", [u!.id]);
    expect(rr.rows[0]!.status).toBe("pending");
  });

  it("tidak ada cara mendaftar sebagai admin", () => {
    expect(() => base({ account_type: "admin" })).toThrow();
  });
});

describe("login & sesi", () => {
  it("berhasil dengan kredensial benar; sesi dapat dibaca; token disimpan sebagai hash", async () => {
    const r = await login("budi@example.test", PASSWORD, meta("10.1.0.1"));
    const u = await userFromToken(r.sessionToken);
    expect(u?.id).toBe(r.userId);
    const rows = await query("select token_hash from sessions where user_id = $1", [r.userId]);
    expect(rows.rows.every((s) => s.token_hash !== r.sessionToken)).toBe(true);
  });

  it("pesan galat seragam untuk email tidak ada dan kata sandi salah", async () => {
    const a = await login("budi@example.test", "SalahTotal123", meta("10.1.0.2")).catch((e) => e);
    const b = await login("tidakada@example.test", "SalahTotal123", meta("10.1.0.3")).catch((e) => e);
    expect(a.status).toBe(401);
    expect(a.message).toBe(b.message);
  });

  it("membatasi percobaan brute force (blokir setelah 5 kegagalan)", async () => {
    const ip = "10.1.0.9";
    for (let i = 0; i < 5; i++) await login("budi@example.test", "salah-salah-1", meta(ip)).catch(() => {});
    // Percobaan berikutnya ditolak 429, bahkan dengan kata sandi benar.
    await expect(login("budi@example.test", PASSWORD, meta(ip))).rejects.toMatchObject({ status: 429 });
  });

  it("akun yang disuspend tidak bisa masuk", async () => {
    await register(base({ email: "susp@example.test", npm: "2025777777" }), meta("10.1.1.1"));
    await query("update profiles set status = 'suspended' where email = 'susp@example.test'");
    await expect(login("susp@example.test", PASSWORD, meta("10.1.1.2"))).rejects.toMatchObject({ status: 403 });
  });

  it("sesi kedaluwarsa atau dicabut ditolak", async () => {
    await register(base({ email: "sesi@example.test", npm: "2025333333" }), meta("10.1.2.0"));
    const r = await login("sesi@example.test", PASSWORD, meta("10.1.2.1"));
    await query("update sessions set revoked_at = now() where user_id = $1", [r.userId]);
    expect(await userFromToken(r.sessionToken)).toBeNull();
  });
});

describe("verifikasi email & reset kata sandi", () => {
  it("token verifikasi sekali pakai", async () => {
    clearOutbox();
    await register(base({ email: "ver@example.test", npm: "2025555555" }), meta("10.2.0.1"));
    const token = getOutbox().find((m) => m.to === "ver@example.test")!.text.match(/token=([\w-]+)/)![1]!;
    expect(await verifyEmail(token)).toBe(true);
    expect(await verifyEmail(token)).toBe(false);
    const p = await query("select email_verified_at from profiles where email = 'ver@example.test'");
    expect(p.rows[0]!.email_verified_at).not.toBeNull();
  });

  it("token verifikasi palsu/kedaluwarsa ditolak", async () => {
    expect(await verifyEmail("x".repeat(43))).toBe(false);
  });

  it("reset: tidak membocorkan email terdaftar, token sekali pakai, sesi lama dicabut", async () => {
    clearOutbox();
    const r = await login("ver@example.test", PASSWORD, meta("10.2.1.1"));
    await requestPasswordReset("tidakada@example.test", meta("10.2.1.2")); // tidak melempar, tidak mengirim
    expect(getOutbox().length).toBe(0);
    await requestPasswordReset("ver@example.test", meta("10.2.1.3"));
    const token = getOutbox()[0]!.text.match(/token=([\w-]+)/)![1]!;
    expect(await resetPassword(token, "PasswordBaru2026", meta())).toBe(true);
    expect(await resetPassword(token, "PasswordLain2026", meta())).toBe(false);
    expect(await userFromToken(r.sessionToken)).toBeNull(); // sesi lama dicabut
    await expect(login("ver@example.test", PASSWORD, meta("10.2.1.4"))).rejects.toMatchObject({ status: 401 });
    await expect(login("ver@example.test", "PasswordBaru2026", meta("10.2.1.5"))).resolves.toBeTruthy();
  });

  it("ganti kata sandi memerlukan kata sandi saat ini", async () => {
    await register(base({ email: "ganti@example.test", npm: "2025444444" }), meta("10.2.2.2"));
    const l = await login("ganti@example.test", PASSWORD, meta("10.2.2.3"));
    const u = (await userFromToken(l.sessionToken))!;
    await expect(changePassword(u, "salah-salah-9", "PasswordBaru2026", meta())).rejects.toMatchObject({ status: 422 });
    await changePassword(u, PASSWORD, "PasswordBaru2026", meta());
    await expect(login("ganti@example.test", "PasswordBaru2026", meta("10.2.2.4"))).resolves.toBeTruthy();
  });
});
