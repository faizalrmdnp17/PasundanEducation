import { afterEach, describe, expect, it } from "vitest";
import { NextRequest } from "next/server";
import { env } from "@/server/env";
import { clientIp } from "@/server/http";

const prev = process.env.DATABASE_SSL;
afterEach(() => { if (prev === undefined) delete process.env.DATABASE_SSL; else process.env.DATABASE_SSL = prev; });

describe("TLS database", () => {
  it("bawaan mati; 'true'/'require' memverifikasi sertifikat; hanya 'no-verify' yang melewati verifikasi", () => {
    delete process.env.DATABASE_SSL;
    expect(env.databaseSsl).toBe("off");
    for (const v of ["true", "1", "require", "verify", "TRUE"]) { process.env.DATABASE_SSL = v; expect(env.databaseSsl).toBe("verify"); }
    process.env.DATABASE_SSL = "no-verify";
    expect(env.databaseSsl).toBe("no-verify");
    process.env.DATABASE_SSL = "false";
    expect(env.databaseSsl).toBe("off");
  });
});

describe("IP klien di belakang proxy", () => {
  const req = (xff: string) => new NextRequest("http://localhost/api/x", { headers: { "x-forwarded-for": xff } });
  it("tidak memercayai entri paling kiri yang dapat dipalsukan klien", () => {
    delete process.env.TRUSTED_PROXY_COUNT;
    expect(clientIp(req("6.6.6.6, 203.0.113.9"))).toBe("203.0.113.9"); // satu proxy: ambil entri terakhir yang ditambahkan proxy
    expect(clientIp(req("203.0.113.9"))).toBe("203.0.113.9");
    process.env.TRUSTED_PROXY_COUNT = "2";
    expect(clientIp(req("6.6.6.6, 198.51.100.7, 10.0.0.2"))).toBe("198.51.100.7");
    delete process.env.TRUSTED_PROXY_COUNT;
  });
});
