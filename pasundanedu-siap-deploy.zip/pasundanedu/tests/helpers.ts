import { getDb } from "@/server/db";
import { seedCatalog } from "@/server/seed";
import { hashPassword } from "@/server/auth/password";
import { toSessionUser } from "@/server/auth/session";
import type { SessionUser } from "@/server/auth/types";
import type { Role } from "@/lib/constants";

export const PASSWORD = "KataSandiUji2026";
let hashCache: string | null = null;

export async function setupDb() {
  const db = await getDb();
  await db.tx((q) => seedCatalog(q));
  // Database bersama (TEST_DATABASE_URL): buang penugasan layanan peninggalan berkas tes lain agar penugasan otomatis hanya memilih staf milik tes ini.
  if (process.env.TEST_DATABASE_URL) await db.query("delete from service_assignments");
  return db;
}

// Awalan unik per proses uji: berkas tes yang berbagi satu database PostgreSQL (TEST_DATABASE_URL) tidak saling bertabrakan.
const RUN = String(Math.floor(Math.random() * 1e6)).padStart(6, "0");
let counter = 0;
export type MakeUser = { role: Role; name?: string; email?: string; verified?: boolean; wa?: string; waVerified?: boolean };

/** Membuat pengguna langsung di database (melewati registrasi) dan mengembalikan objek SessionUser. */
export async function makeUser(o: MakeUser): Promise<SessionUser> {
  const db = await getDb();
  hashCache ??= await hashPassword(PASSWORD);
  const n = ++counter;
  const email = o.email ?? `${o.role}${n}.${RUN}@example.test`;
  const r = await db.query<{ id: string }>(
    `insert into profiles (email, full_name, account_type, npm, nidn, whatsapp_number, whatsapp_verified_at, status, email_verified_at, identity_verified_at)
     values ($1,$2,$3,$4,$5,$6,$7,'active',$8,now()) returning id`,
    [email, o.name ?? `${o.role} ${n}`, o.role, o.role === "mahasiswa" ? `${RUN}${String(n).padStart(4, "0")}` : null, o.role !== "mahasiswa" ? `NID${RUN}${String(n).padStart(4, "0")}` : null,
     o.wa ?? null, o.waVerified ? new Date().toISOString() : null, o.verified === false ? null : new Date().toISOString()],
  );
  const id = r.rows[0]!.id;
  await db.query("insert into auth_credentials (user_id, password_hash) values ($1,$2)", [id, hashCache]);
  await db.query("insert into user_roles (user_id, role_id) select $1, id from roles where code = $2", [id, o.role]);
  await db.query("insert into notification_preferences (user_id) values ($1) on conflict do nothing", [id]);
  return loadUser(id);
}

export async function loadUser(id: string): Promise<SessionUser> {
  const db = await getDb();
  const r = await db.query(
    `select p.id, p.email, p.full_name, p.account_type, p.status, p.email_verified_at, p.npm, p.nidn, p.study_program, p.cohort_year, p.phone,
            p.whatsapp_number, p.whatsapp_verified_at, p.identity_verified_at, '00000000-0000-0000-0000-000000000000' as session_id, now() as last_seen_at,
            coalesce((select array_agg(r.code order by r.id) from user_roles ur join roles r on r.id = ur.role_id where ur.user_id = p.id), '{}') as roles
     from profiles p where p.id = $1`, [id]);
  return toSessionUser(r.rows[0] as never);
}

export async function serviceBySlug(slug: string) {
  const db = await getDb();
  return (await db.query<{ id: string; price_idr: number }>("select id, price_idr from services where slug = $1", [slug])).rows[0]!;
}

export async function assign(serviceSlug: string, staff: SessionUser) {
  const db = await getDb();
  await db.query("insert into service_assignments (service_id, staff_id) select id, $2 from services where slug = $1 on conflict do nothing", [serviceSlug, staff.id]);
}

/** Membuat slot di masa depan langsung ke DB. */
export async function makeSlot(staff: SessionUser, opts: { hoursAhead?: number; capacity?: number; serviceSlug?: string } = {}) {
  const db = await getDb();
  const start = new Date(Date.now() + (opts.hoursAhead ?? 48) * 3600_000);
  start.setMinutes(0, 0, 0);
  const end = new Date(start.getTime() + 3600_000);
  const r = await db.query<{ id: string }>(
    `insert into availability_slots (staff_id, service_id, starts_at, ends_at, capacity)
     values ($1, (select id from services where slug = $2), $3, $4, $5) on conflict (staff_id, starts_at) do update set capacity = excluded.capacity returning id`,
    [staff.id, opts.serviceSlug ?? null, start.toISOString(), end.toISOString(), opts.capacity ?? 1],
  );
  return r.rows[0]!.id;
}

export const png = () => Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(64, 1)]);
export const pdf = () => Buffer.concat([Buffer.from("%PDF-1.4\n"), Buffer.alloc(64, 65)]);
