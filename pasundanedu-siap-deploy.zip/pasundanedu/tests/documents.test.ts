import { beforeAll, describe, expect, it } from "vitest";
import { query } from "@/server/db";
import { addDocument, createServiceRequest, getDocumentForDownload, getRequestDetail, verifyDocument } from "@/server/domain/requests";
import { signedDownloadPath, validateUpload, verifyDownloadSignature } from "@/server/storage";
import { assign, makeUser, pdf, png, serviceBySlug, setupDb } from "./helpers";
import type { SessionUser } from "@/server/auth/types";

const ip = { ip: "127.0.0.1" };
let petugas: SessionUser, owner: SessionUser, stranger: SessionUser, reqId: string;

beforeAll(async () => {
  await setupDb();
  petugas = await makeUser({ role: "petugas" });
  owner = await makeUser({ role: "mahasiswa" });
  stranger = await makeUser({ role: "mahasiswa" });
  await assign("surat-keterangan-mahasiswa", petugas);
  const svc = await serviceBySlug("surat-keterangan-mahasiswa");
  reqId = (await createServiceRequest(owner, { service_id: svc.id }, "doc-1", ip)).id;
});

describe("validasi unggahan", () => {
  it("menerima PDF/PNG/JPG/DOCX yang isinya sesuai", () => {
    expect(validateUpload("surat.pdf", pdf()).mime).toBe("application/pdf");
    expect(validateUpload("foto.PNG", png()).mime).toBe("image/png");
    expect(validateUpload("foto.jpg", Buffer.from([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3, 4])).mime).toBe("image/jpeg");
  });

  it("menolak ekstensi yang tidak cocok dengan isi (mis. exe diganti .pdf), jenis berbahaya, kosong, dan terlalu besar", () => {
    expect(() => validateUpload("virus.pdf", Buffer.from("MZ\x90\x00 exe"))).toThrow();
    expect(() => validateUpload("skrip.html", Buffer.from("<script>alert(1)</script>"))).toThrow();
    expect(() => validateUpload("foto.png", pdf())).toThrow(); // isi PDF, ekstensi PNG
    expect(() => validateUpload("a.pdf", Buffer.alloc(0))).toThrow();
    expect(() => validateUpload("besar.pdf", Buffer.concat([Buffer.from("%PDF-"), Buffer.alloc(6 * 1024 * 1024)]))).toThrow(/maksimal/i);
  });

  it("menormalkan nama berkas (tanpa path traversal)", () => {
    expect(validateUpload("../../etc/passwd.pdf", pdf()).safeName).toBe("passwd.pdf");
    expect(validateUpload("laporan akhir (final)!.pdf", pdf()).safeName).toBe("laporan-akhir-final.pdf");
  });
});

describe("dokumen privat", () => {
  let docId: string;

  it("mahasiswa mengunggah; metadata + hash tersimpan; berkas tidak berada di direktori publik", async () => {
    docId = await addDocument(owner, reqId, { name: "ktm.pdf", data: pdf() }, "lampiran", ip);
    const d = (await query("select storage_key, sha256, size_bytes, mime_type, verification_status from request_documents where id = $1", [docId])).rows[0]!;
    expect(d.sha256).toMatch(/^[0-9a-f]{64}$/);
    expect(d.verification_status).toBe("pending");
    expect(d.storage_key).not.toMatch(/^\/|\.\./);
    const fs = await import("node:fs");
    expect(fs.existsSync("public/" + d.storage_key)).toBe(false);
  });

  it("pemilik dan staf penanggung jawab dapat mengunduh; orang lain 404", async () => {
    expect((await getDocumentForDownload(owner, docId)).data.length).toBeGreaterThan(0);
    expect((await getDocumentForDownload(petugas, docId)).original_name).toBe("ktm.pdf");
    await expect(getDocumentForDownload(stranger, docId)).rejects.toMatchObject({ status: 404 });
    await expect(addDocument(stranger, reqId, { name: "x.pdf", data: pdf() }, "lampiran", ip)).rejects.toMatchObject({ status: 404 });
  });

  it("URL bertanda tangan: terikat pengguna & dokumen, berumur pendek, tidak bisa dipalsukan", () => {
    const p = signedDownloadPath(docId, owner.id, 300);
    const u = new URL(p, "http://x");
    const exp = u.searchParams.get("exp"), sig = u.searchParams.get("sig");
    expect(verifyDownloadSignature(docId, owner.id, exp, sig)).toBe(true);
    expect(verifyDownloadSignature(docId, stranger.id, exp, sig)).toBe(false); // tautan dibagikan ke orang lain
    expect(verifyDownloadSignature("00000000-0000-0000-0000-000000000000", owner.id, exp, sig)).toBe(false);
    expect(verifyDownloadSignature(docId, owner.id, exp, sig + "x")).toBe(false);
    const expired = new URL(signedDownloadPath(docId, owner.id, -10), "http://x");
    expect(verifyDownloadSignature(docId, owner.id, expired.searchParams.get("exp"), expired.searchParams.get("sig"))).toBe(false);
    expect(verifyDownloadSignature(docId, owner.id, null, null)).toBe(false);
  });

  it("tautan unduhan pada detail pengajuan hanya muncul untuk pihak berwenang", async () => {
    const d = await getRequestDetail(owner, reqId);
    expect(d.documents[0]!.url).toContain("/api/files/");
    await expect(getRequestDetail(stranger, reqId)).rejects.toMatchObject({ status: 404 });
  });

  it("verifikasi dokumen hanya oleh staf; penolakan wajib catatan; mahasiswa diberi notifikasi", async () => {
    await expect(verifyDocument(owner, docId, "verified", undefined, ip)).rejects.toMatchObject({ status: 403 });
    await expect(verifyDocument(petugas, docId, "rejected", undefined, ip)).rejects.toMatchObject({ status: 422 });
    await verifyDocument(petugas, docId, "rejected", "Foto buram", ip);
    await verifyDocument(petugas, docId, "verified", undefined, ip);
    expect((await query("select verification_status from request_documents where id = $1", [docId])).rows[0]!.verification_status).toBe("verified");
    expect((await query("select count(*)::int n from notifications where user_id = $1 and type = 'document_verified'", [owner.id])).rows[0]!.n).toBe(2);
  });

  it("mahasiswa tidak dapat mengunggah 'hasil'; bukti pembayaran hanya oleh pemilik; unduhan tercatat di audit", async () => {
    await expect(addDocument(owner, reqId, { name: "h.pdf", data: pdf() }, "hasil", ip)).rejects.toMatchObject({ status: 403 });
    await expect(addDocument(petugas, reqId, { name: "b.pdf", data: pdf() }, "bukti_pembayaran", ip)).rejects.toMatchObject({ status: 403 });
    await addDocument(petugas, reqId, { name: "hasil.pdf", data: pdf() }, "hasil", ip);
    expect((await query("select count(*)::int n from audit_logs where action = 'document.download'")).rows[0]!.n).toBeGreaterThan(0);
  });

  it("batas 15 dokumen: unggahan yang ditolak tidak meninggalkan berkas yatim di penyimpanan", async () => {
    const fs = await import("node:fs");
    const root = ".data/test-uploads";
    const countFiles = () => {
      let n = 0;
      const walk = (d: string) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) e.isDirectory() ? walk(`${d}/${e.name}`) : n++; };
      if (fs.existsSync(root)) walk(root);
      return n;
    };
    const countRows = async () => (await query("select count(*)::int n from request_documents")).rows[0]!.n as number;
    const filesBefore = countFiles(), rowsBefore = await countRows();
    for (let i = 0; i < 16; i++) await addDocument(owner, reqId, { name: `f${i}.pdf`, data: pdf() }, "lampiran", ip).catch(() => {});
    const perRequest = (await query("select count(*)::int n from request_documents where request_id = $1", [reqId])).rows[0]!.n;
    expect(perRequest).toBe(15);
    expect(countFiles() - filesBefore).toBe((await countRows()) - rowsBefore);
  });
});
