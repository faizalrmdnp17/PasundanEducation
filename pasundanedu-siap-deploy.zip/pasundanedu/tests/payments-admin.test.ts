import { createHmac } from "node:crypto";
import { beforeAll, describe, expect, it } from "vitest";
import { query } from "@/server/db";
import { changeStatus, createServiceRequest, getRequestDetail } from "@/server/domain/requests";
import { processPaymentWebhook, refundPayment, startPayment, submitPaymentProof, verifyPayment, verifyPaymentSignature } from "@/server/domain/payments";
import { updateSettings } from "@/server/domain/settings";
import { decideRoleRequest, getReports, listRoleRequests, listUsers, updateUserAdmin, upsertIntegration, updateWhatsappTemplate, getWhatsappAdmin } from "@/server/domain/admin";
import { checkMoodle, unsafeApiUrl } from "@/server/integrations/moodle";
import { listResources, openResource, setFavorite, upsertResource } from "@/server/domain/resources";
import { listServices, upsertService } from "@/server/domain/services";
import { register } from "@/server/auth/service";
import { registerSchema } from "@/lib/validation";
import { assign, makeUser, pdf, serviceBySlug, setupDb, PASSWORD } from "./helpers";
import type { SessionUser } from "@/server/auth/types";

const ip = { ip: "127.0.0.1" };
let admin: SessionUser, petugas: SessionUser, dosen: SessionUser, mhs: SessionUser;

beforeAll(async () => {
  await setupDb();
  [admin, petugas, dosen, mhs] = await Promise.all([makeUser({ role: "admin" }), makeUser({ role: "petugas" }), makeUser({ role: "dosen" }), makeUser({ role: "mahasiswa" })]);
  await assign("cek-kemiripan-naskah", petugas);
});

const paySign = (b: string) => "sha256=" + createHmac("sha256", "pay-secret").update(b).digest("hex");

describe("pembayaran (opsional, nonaktif secara bawaan)", () => {
  let reqId: string, payId: string;

  it("nonaktif secara bawaan: layanan berbayar tidak ditagih dan tidak bisa memulai pembayaran", async () => {
    const svc = await serviceBySlug("cek-kemiripan-naskah");
    const r = await createServiceRequest(mhs, { service_id: svc.id }, "pay-off", ip);
    const row = (await query("select price_idr, payment_status from service_requests where id = $1", [r.id])).rows[0]!;
    expect(row).toMatchObject({ price_idr: 0, payment_status: "not_required" });
    await expect(startPayment(mhs, r.id, null, "x")).rejects.toMatchObject({ code: "payments_disabled" });
  });

  it("hanya admin yang dapat mengaktifkan; harga di-snapshot dari server saat pengajuan", async () => {
    await updateSettings(admin, { payments_enabled: true }, "x");
    const svc = await serviceBySlug("cek-kemiripan-naskah");
    const r = await createServiceRequest(mhs, { service_id: svc.id }, "pay-on", ip);
    reqId = r.id;
    expect((await query("select price_idr, payment_status from service_requests where id = $1", [reqId])).rows[0]!).toMatchObject({ price_idr: 25000, payment_status: "pending" });
    // Mengubah harga layanan setelahnya tidak mengubah tagihan yang sudah dibuat.
    await query("update services set price_idr = 99000 where id = $1", [svc.id]);
    expect((await query("select price_idr from service_requests where id = $1", [reqId])).rows[0]!.price_idr).toBe(25000);
    await query("update services set price_idr = 25000 where id = $1", [svc.id]);
  });

  it("mulai pembayaran idempoten; status layanan dan status pembayaran terpisah", async () => {
    const a = await startPayment(mhs, reqId, "k1", "x");
    const b = await startPayment(mhs, reqId, "k2", "x");
    expect(b).toMatchObject({ id: a.id, duplicate: true });
    payId = a.id;
    expect((await query("select count(*)::int n from payments where request_id = $1", [reqId])).rows[0]!.n).toBe(1);
    const d = await getRequestDetail(mhs, reqId);
    expect(d.request.status).toBe("submitted");
    expect(d.request.payment_status).toBe("pending");
    await expect(startPayment(await makeUser({ role: "mahasiswa" }), reqId, null, "x")).rejects.toMatchObject({ status: 404 });
  });

  it("layanan tidak dapat berjalan/selesai sebelum lunas", async () => {
    await changeStatus(petugas, reqId, "under_review", undefined, ip);
    await changeStatus(petugas, reqId, "awaiting_payment", undefined, ip);
    await expect(changeStatus(petugas, reqId, "in_progress", undefined, ip)).rejects.toMatchObject({ code: "payment_required" });
  });

  it("bukti transfer → menunggu verifikasi → petugas menyetujui → lunas dan layanan terkonfirmasi otomatis", async () => {
    await submitPaymentProof(mhs, reqId, { name: "bukti.pdf", data: pdf() }, "x");
    expect((await query("select status from payments where id = $1", [payId])).rows[0]!.status).toBe("awaiting_verification");
    await expect(verifyPayment(mhs, reqId, "approve", "x")).rejects.toMatchObject({ status: 403 });
    await expect(verifyPayment(dosen, reqId, "approve", "x")).rejects.toMatchObject({ status: 403 });
    await verifyPayment(petugas, reqId, "approve", "x");
    const row = (await query("select status, payment_status from service_requests where id = $1", [reqId])).rows[0]!;
    expect(row).toMatchObject({ status: "confirmed", payment_status: "paid" });
    await changeStatus(petugas, reqId, "in_progress", undefined, ip);
    const ev = await query("select event_type from payment_events where payment_id = $1 order by created_at", [payId]);
    expect(ev.rows.map((e) => e.event_type)).toEqual(["created", "proof_uploaded", "status.paid"]);
  });

  it("pengembalian dana hanya oleh petugas/admin dan hanya untuk pembayaran lunas", async () => {
    await expect(refundPayment(mhs, reqId, "x")).rejects.toMatchObject({ status: 403 });
    await refundPayment(petugas, reqId, "x");
    expect((await query("select payment_status from service_requests where id = $1", [reqId])).rows[0]!.payment_status).toBe("refunded");
    await expect(refundPayment(petugas, reqId, "x")).rejects.toMatchObject({ status: 409 });
  });

  it("tidak ada data kartu di skema (tanpa nomor kartu/CVV)", async () => {
    const cols = await query("select column_name from information_schema.columns where table_name in ('payments','payment_events')");
    expect(cols.rows.map((c) => c.column_name).join(",")).not.toMatch(/card|cvv|pan/i);
  });

  describe("webhook gateway", () => {
    let wReq: string, wPay: string;
    beforeAll(async () => {
      const svc = await serviceBySlug("cek-kemiripan-naskah");
      wReq = (await createServiceRequest(await makeUser({ role: "mahasiswa" }), { service_id: svc.id }, "wh-1", ip)).id;
      const m = (await query("select student_id from service_requests where id = $1", [wReq])).rows[0]!.student_id;
      wPay = (await startPayment({ id: m, roles: ["mahasiswa"] } as never, wReq, null, "x")).id;
    });

    it("tanda tangan HMAC divalidasi", () => {
      const b = '{"x":1}';
      expect(verifyPaymentSignature(b, paySign(b))).toBe(true);
      expect(verifyPaymentSignature(b, paySign(b + "1"))).toBe(false);
      expect(verifyPaymentSignature(b, null)).toBe(false);
      expect(verifyPaymentSignature(b, paySign(b), "")).toBe(false);
    });

    it("menolak nominal yang tidak sesuai; menerima yang sesuai; event duplikat tidak diproses ulang", async () => {
      await expect(processPaymentWebhook({ event_id: "ev1", type: "payment.paid", reference: wPay, amount: 1000 })).rejects.toMatchObject({ code: "amount_mismatch" });
      expect((await query("select status from payments where id = $1", [wPay])).rows[0]!.status).toBe("pending");
      // Event yang gagal diproses tidak boleh "terkunci" sebagai sudah diproses.
      expect((await query("select count(*)::int n from webhook_events where event_id = 'ev1'")).rows[0]!.n).toBe(0);
      expect(await processPaymentWebhook({ event_id: "ev2", type: "payment.paid", reference: wPay, amount: 25000 })).toEqual({ duplicate: false });
      expect(await processPaymentWebhook({ event_id: "ev2", type: "payment.paid", reference: wPay, amount: 25000 })).toEqual({ duplicate: true });
      expect((await query("select status from payments where id = $1", [wPay])).rows[0]!.status).toBe("paid");
      expect((await query("select count(*)::int n from payment_events where payment_id = $1 and event_type = 'status.paid'", [wPay])).rows[0]!.n).toBe(1);
    });

    it("payload tidak lengkap atau referensi tidak dikenal ditolak", async () => {
      await expect(processPaymentWebhook({ type: "payment.paid" })).rejects.toMatchObject({ status: 400 });
      await expect(processPaymentWebhook({ event_id: "e9", type: "payment.paid", reference: "00000000-0000-0000-0000-000000000000", amount: 1 })).rejects.toMatchObject({ status: 404 });
      await expect(processPaymentWebhook({ event_id: "e10", type: "payment.lain", reference: wPay, amount: 1 })).rejects.toMatchObject({ status: 400 });
    });
  });
});

describe("hak akses & kebijakan admin", () => {
  it("pengguna tidak dapat menaikkan perannya sendiri; admin tidak dapat mengubah peran/statusnya sendiri", async () => {
    await expect(updateUserAdmin(admin, admin.id, { roles: ["mahasiswa"] })).rejects.toMatchObject({ status: 403 });
    await expect(updateUserAdmin(admin, admin.id, { status: "suspended" })).rejects.toMatchObject({ status: 403 });
    // Tidak ada jalur API domain bagi mahasiswa untuk mengubah peran: updateUserAdmin tidak melakukan cek peran sendiri,
    // sehingga proteksinya ada di lapisan route (auth: ["admin"]) — diverifikasi pada tes e2e HTTP.
  });

  it("memberikan peran memaksa keluar sesi aktif pengguna dan menyinkronkan account_type", async () => {
    const u = await makeUser({ role: "mahasiswa" });
    await query("insert into sessions (user_id, token_hash, expires_at) values ($1,'h1', now() + interval '1 day')", [u.id]);
    await updateUserAdmin(admin, u.id, { roles: ["mahasiswa", "dosen"] });
    expect((await query("select revoked_at from sessions where user_id = $1", [u.id])).rows[0]!.revoked_at).not.toBeNull();
    expect((await query("select account_type from profiles where id = $1", [u.id])).rows[0]!.account_type).toBe("dosen");
  });

  it("registrasi dosen: tidak ada akses sampai disetujui; setelah disetujui mendapat peran dan terverifikasi", async () => {
    const r = await register(registerSchema.parse({ full_name: "Calon Dosen", email: "calon@example.test", password: PASSWORD, account_type: "dosen", nidn: "0411000999", accept_terms: true }), ip);
    expect(r.status).toBe("pending_approval");
    const pending = (await listRoleRequests("pending")).find((x) => x.email === "calon@example.test")!;
    expect(pending).toBeTruthy();
    await expect(decideRoleRequest(admin, pending.id, "approve", undefined)).resolves.toBeUndefined();
    const u = (await query("select status, account_type, identity_verified_at from profiles where email = 'calon@example.test'")).rows[0]!;
    expect(u).toMatchObject({ status: "active", account_type: "dosen" });
    expect(u.identity_verified_at).not.toBeNull();
    expect((await query("select r.code from user_roles ur join roles r on r.id = ur.role_id join profiles p on p.id = ur.user_id where p.email = 'calon@example.test'")).rows[0]!.code).toBe("dosen");
    await expect(decideRoleRequest(admin, pending.id, "approve", undefined)).rejects.toMatchObject({ status: 409 });
  });

  it("template WhatsApp hanya bisa diaktifkan jika berstatus approved; kredensial tidak pernah dikembalikan oleh API", async () => {
    const t = (await getWhatsappAdmin()).templates[0]!;
    await expect(updateWhatsappTemplate(admin, t.id, { name: t.name, language: "id", status: "draft", is_active: true })).rejects.toMatchObject({ status: 422 });
    await updateWhatsappTemplate(admin, t.id, { name: t.name, language: "id", status: "approved", is_active: true });
    const json = JSON.stringify(await getWhatsappAdmin());
    expect(json).not.toContain("test-token");
    expect(json).not.toContain("wa-app-secret");
    expect(json).not.toContain("wa-verify");
  });

  it("system_settings menolak kunci yang menyiratkan rahasia", async () => {
    await expect(query("insert into system_settings (key, value) values ('whatsapp_access_token', '\"x\"')")).rejects.toThrow();
    await expect(query("insert into system_settings (key, value) values ('db_password', '\"x\"')")).rejects.toThrow();
  });

  it("integrasi: tautan biasa berstatus 'link_only' (bukan API); Moodle tanpa token tidak mengaku terhubung", async () => {
    const id = await upsertIntegration(admin, { code: "kelas-x", name: "Kelas X", kind: "google_classroom", connection_type: "link", base_url: "https://classroom.google.com/c/abc", auth_method: "none", is_active: true } as any);
    expect((await query("select status from external_integrations where id = $1", [id])).rows[0]!.status).toBe("link_only");
    const noToken = await checkMoodle("https://moodle.example.test");
    expect(noToken).toMatchObject({ ok: false, status: "not_connected" });
    expect((await checkMoodle(null)).status).toBe("not_connected");
    process.env.MOODLE_WS_TOKEN = "tok";
    const okFetch = (async () => new Response(JSON.stringify({ sitename: "Moodle Uji", release: "4.4" }), { status: 200 })) as unknown as typeof fetch;
    expect(await checkMoodle("https://moodle.example.test", okFetch)).toMatchObject({ ok: true, status: "connected" });
    const errFetch = (async () => new Response(JSON.stringify({ exception: "moodle_exception", message: "Invalid token" }), { status: 200 })) as unknown as typeof fetch;
    expect(await checkMoodle("https://moodle.example.test", errFetch)).toMatchObject({ ok: false, status: "error" });
    const down = (async () => { throw new Error("ECONNREFUSED"); }) as unknown as typeof fetch;
    expect(await checkMoodle("https://moodle.example.test", down)).toMatchObject({ ok: false, status: "error" });
    process.env.MOODLE_WS_TOKEN = "";
  });

  it("Moodle: di produksi token hanya dikirim ke https dan bukan alamat jaringan internal", async () => {
    const prev = process.env.NODE_ENV;
    (process.env as Record<string, string>).NODE_ENV = "production";
    try {
      expect(unsafeApiUrl("http://lms.kampus.ac.id")).toMatch(/https/);
      for (const h of ["https://localhost", "https://127.0.0.1", "https://10.1.2.3", "https://192.168.0.5", "https://172.20.0.1", "https://169.254.169.254", "https://[::1]", "https://db.internal"])
        expect(unsafeApiUrl(h), h).toMatch(/internal/);
      expect(unsafeApiUrl("https://lms.kampus.ac.id")).toBeNull();
      process.env.MOODLE_WS_TOKEN = "tok";
      let called = false;
      const spy = (async () => { called = true; return new Response("{}"); }) as unknown as typeof fetch;
      expect(await checkMoodle("http://lms.kampus.ac.id", spy)).toMatchObject({ ok: false, status: "error" });
      expect(called).toBe(false); // token tidak pernah dikirim ke URL yang tidak aman
    } finally {
      (process.env as Record<string, string>).NODE_ENV = prev!;
      process.env.MOODLE_WS_TOKEN = "";
    }
  });

  it("laporan dibangun dari data nyata di database (bukan angka statis)", async () => {
    const before = await getReports();
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    await assign("surat-keterangan-mahasiswa", petugas);
    await createServiceRequest(await makeUser({ role: "mahasiswa" }), { service_id: svc.id }, "rep-1", ip);
    const after = await getReports();
    expect(after.byStatus.submitted).toBe((before.byStatus.submitted ?? 0) + 1);
    expect(after.paymentsEnabled).toBe(true);
    expect(after.payments).not.toBeNull();
    expect(after.integrations.length).toBeGreaterThan(0);
    const users = await listUsers({ role: "petugas" });
    expect(users.items.every((u) => u.roles.includes("petugas"))).toBe(true);
  });
});

describe("pustaka, pencarian, dan layanan", () => {
  beforeAll(async () => {
    const cat = (await query<{ id: string }>("select id from resource_categories where code = 'buku'")).rows[0]!.id;
    for (let i = 1; i <= 25; i++) {
      await upsertResource(admin, { category_id: cat, kind: "ebook", title: `Statistik Bisnis Jilid ${String(i).padStart(2, "0")}`, authors: i % 2 ? "Ani Wijaya" : "Budi Hartono", year: 2000 + i, access_type: "link", external_url: `https://example.com/s/${i}`, is_published: i !== 25 } as any);
    }
    await upsertResource(admin, { kind: "journal", title: "Jurnal Pemasaran Digital", authors: "Citra", year: 2024, access_type: "link", external_url: "https://example.com/j", is_published: true } as any);
  });

  it("pencarian berdasarkan judul, penulis, tahun, dan tab/kategori", async () => {
    expect((await listResources({ q: "Statistik Bisnis", size: 100 })).total).toBe(24); // yang tidak dipublikasikan tidak muncul
    expect((await listResources({ q: "Ani Wijaya", size: 100 })).items.every((r) => r.authors === "Ani Wijaya")).toBe(true);
    expect((await listResources({ q: "2010" })).items.map((r) => r.year)).toEqual([2010]);
    expect((await listResources({ tab: "jurnal" })).items.every((r) => r.kind === "journal")).toBe(true);
    expect((await listResources({ tab: "buku", q: "Pemasaran" })).total).toBe(0);
    expect((await listResources({ q: "%_" })).total).toBe(0); // karakter wildcard di-escape
  });

  it("pagination dan pengurutan", async () => {
    const p1 = await listResources({ q: "Statistik Bisnis", size: 10, page: 1, sort: "title" });
    const p3 = await listResources({ q: "Statistik Bisnis", size: 10, page: 3, sort: "title" });
    expect(p1.totalPages).toBe(3);
    expect(p1.items.length).toBe(10);
    expect(p3.items.length).toBe(4);
    expect(p1.items[0]!.title).toBe("Statistik Bisnis Jilid 01");
    const byYear = await listResources({ q: "Statistik Bisnis", size: 3, sort: "year" });
    expect(byYear.items.map((r) => r.year)).toEqual([2024, 2023, 2022]);
  });

  it("favorit per pengguna, filter favorit, dan riwayat akses tautan", async () => {
    const all = await listResources({ q: "Jilid 01", userId: mhs.id });
    const id = all.items[0]!.id;
    expect(all.items[0]!.favorite).toBe(false);
    await setFavorite(mhs.id, id, true);
    await setFavorite(mhs.id, id, true); // idempoten
    expect((await listResources({ userId: mhs.id, onlyFavorites: true })).total).toBe(1);
    expect((await listResources({ userId: dosen.id, onlyFavorites: true })).total).toBe(0);
    await setFavorite(mhs.id, id, false);
    expect((await listResources({ userId: mhs.id, onlyFavorites: true })).total).toBe(0);
    expect((await openResource(mhs.id, id)).url).toBe("https://example.com/s/1");
    expect((await query("select count(*)::int n from resource_access_logs where user_id = $1 and resource_id = $2", [mhs.id, id])).rows[0]!.n).toBe(1);
  });

  it("pencarian layanan + kategori; admin mengelola harga dan penanggung jawab dengan validasi", async () => {
    expect((await listServices({ q: "skripsi" })).items.map((s) => s.slug)).toContain("bimbingan-skripsi");
    expect((await listServices({ category: "karier" })).items.every((s) => s.category_code === "karier")).toBe(true);
    const svc = (await listServices({ q: "Tutor" })).items[0]!;
    await expect(upsertService(admin, { category_id: svc.category_id, name: svc.name, description: svc.description, icon: svc.icon, price_idr: 20000, requirements: [], cancellation_policy: "Ok ok", requires_appointment: true, requires_documents: false, is_active: true, staff_ids: [mhs.id] } as any, svc.id)).rejects.toMatchObject({ status: 409 });
    await upsertService(admin, { category_id: svc.category_id, name: svc.name, description: svc.description, icon: svc.icon, price_idr: 30000, requirements: ["A"], cancellation_policy: "Ok ok", requires_appointment: true, requires_documents: false, is_active: true, staff_ids: [dosen.id] } as any, svc.id);
    const after = (await listServices({ q: "Tutor" })).items[0]!;
    expect(after.price_idr).toBe(30000);
    expect(after.staff.map((s) => s.id)).toEqual([dosen.id]);
    await query("update services set price_idr = 20000 where id = $1", [svc.id]);
  });
});
