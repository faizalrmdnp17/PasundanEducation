import { beforeAll, describe, expect, it } from "vitest";
import { query } from "@/server/db";
import {
  addMessage, cancelByStudent, changeStatus, createServiceRequest, getRequestDetail, listRequests, rescheduleAppointment, submitFeedback,
} from "@/server/domain/requests";
import { createSlot, listAvailability } from "@/server/domain/appointments";
import { assign, makeSlot, makeUser, serviceBySlug, setupDb } from "./helpers";
import type { SessionUser } from "@/server/auth/types";

let dosen: SessionUser, dosen2: SessionUser, petugas: SessionUser, admin: SessionUser, mhs: SessionUser, mhs2: SessionUser;
const ip = { ip: "127.0.0.1" };

beforeAll(async () => {
  await setupDb();
  [dosen, dosen2, petugas, admin, mhs, mhs2] = await Promise.all([
    makeUser({ role: "dosen" }), makeUser({ role: "dosen" }), makeUser({ role: "petugas" }), makeUser({ role: "admin" }),
    makeUser({ role: "mahasiswa" }), makeUser({ role: "mahasiswa" }),
  ]);
  await assign("konsultasi-dosen-wali", dosen);
  await assign("konsultasi-dosen-wali", dosen2);
  await assign("surat-keterangan-mahasiswa", petugas);
});

describe("pembuatan pengajuan", () => {
  it("tersimpan di database dengan nomor unik, riwayat status awal, penugasan, dan notifikasi", async () => {
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    const r = await createServiceRequest(mhs, { service_id: svc.id, student_note: "Untuk beasiswa" }, "key-1", ip);
    expect(r.request_number).toMatch(/^PE-\d{4}-\d{5}$/);
    const row = (await query("select status, assignee_id, student_id, price_idr, payment_status from service_requests where id = $1", [r.id])).rows[0]!;
    expect(row).toMatchObject({ status: "submitted", assignee_id: petugas.id, student_id: mhs.id, payment_status: "not_required" });
    const hist = await query("select from_status, to_status from request_status_history where request_id = $1", [r.id]);
    expect(hist.rows).toEqual([{ from_status: null, to_status: "submitted" }]);
    const notifs = await query("select user_id, type from notifications where link like $1", [`%${r.id}`]);
    expect(notifs.rows.map((n) => n.user_id).sort()).toEqual([mhs.id, petugas.id].sort());
    expect(await query("select 1 from audit_logs where action = 'request.create' and entity_id = $1", [r.id]).then((x) => x.rowCount)).toBe(1);
  });

  it("nomor pengajuan selalu unik, termasuk pada pengajuan serentak", async () => {
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    const results = await Promise.all(Array.from({ length: 8 }, (_, i) => createServiceRequest(mhs2, { service_id: svc.id, student_note: `n${i}` }, `bulk-${i}`, ip)));
    expect(new Set(results.map((r) => r.request_number)).size).toBe(8);
  });

  it("idempoten: kunci yang sama (berurutan maupun serentak) menghasilkan satu pengajuan", async () => {
    const svc = await serviceBySlug("akses-jurnal-ilmiah");
    await assign("akses-jurnal-ilmiah", petugas);
    const before = (await query("select count(*)::int n from service_requests where student_id = $1", [mhs.id])).rows[0]!.n;
    const a = await createServiceRequest(mhs, { service_id: svc.id }, "same-key", ip);
    const b = await createServiceRequest(mhs, { service_id: svc.id }, "same-key", ip);
    expect(b).toMatchObject({ id: a.id, duplicate: true });
    const burst = await Promise.all(Array.from({ length: 5 }, () => createServiceRequest(mhs, { service_id: svc.id }, "burst-key", ip)));
    expect(new Set(burst.map((r) => r.id)).size).toBe(1);
    const after = (await query("select count(*)::int n from service_requests where student_id = $1", [mhs.id])).rows[0]!.n;
    expect(after - before).toBe(2);
  });

  it("tanpa kunci: klik ganda identik dalam 30 detik tidak membuat duplikat", async () => {
    const svc = await serviceBySlug("peminjaman-buku-referensi");
    await assign("peminjaman-buku-referensi", petugas);
    const a = await createServiceRequest(mhs, { service_id: svc.id, student_note: "klik ganda" }, null, ip);
    const b = await createServiceRequest(mhs, { service_id: svc.id, student_note: "klik ganda" }, null, ip);
    expect(b.id).toBe(a.id);
    expect(b.duplicate).toBe(true);
  });

  it("hanya mahasiswa yang dapat mengajukan; layanan nonaktif ditolak; layanan berjadwal wajib memilih slot", async () => {
    const svc = await serviceBySlug("konsultasi-dosen-wali");
    await expect(createServiceRequest(dosen, { service_id: svc.id }, "k-d", ip)).rejects.toMatchObject({ status: 403 });
    await expect(createServiceRequest(mhs, { service_id: svc.id }, "k-noslot", ip)).rejects.toMatchObject({ status: 422 });
    await query("update services set is_active = false where slug = 'cek-kemiripan-naskah'");
    const off = await serviceBySlug("cek-kemiripan-naskah");
    await expect(createServiceRequest(mhs, { service_id: off.id }, "k-off", ip)).rejects.toMatchObject({ status: 404 });
    await query("update services set is_active = true where slug = 'cek-kemiripan-naskah'");
  });

  it("harga di sisi server: biaya tidak ditagih selama pembayaran nonaktif (snapshot 0)", async () => {
    const svc = await serviceBySlug("bimbingan-skripsi");
    expect(svc.price_idr).toBe(50000);
    await assign("bimbingan-skripsi", dosen);
    const slot = await makeSlot(dosen, { hoursAhead: 200 });
    const r = await createServiceRequest(mhs2, { service_id: svc.id, slot_id: slot }, "k-skripsi", ip);
    const row = (await query("select price_idr, payment_status from service_requests where id = $1", [r.id])).rows[0]!;
    expect(row).toMatchObject({ price_idr: 0, payment_status: "not_required" });
  });
});

describe("jadwal konsultasi tanpa bentrok", () => {
  it("dua mahasiswa serentak memesan slot berkapasitas 1: tepat satu yang berhasil", async () => {
    const svc = await serviceBySlug("konsultasi-dosen-wali");
    const slot = await makeSlot(dosen, { hoursAhead: 72 });
    const [a, b] = await Promise.allSettled([
      createServiceRequest(mhs, { service_id: svc.id, slot_id: slot }, "race-a", ip),
      createServiceRequest(mhs2, { service_id: svc.id, slot_id: slot }, "race-b", ip),
    ]);
    const ok = [a, b].filter((x) => x.status === "fulfilled");
    const bad = [a, b].filter((x) => x.status === "rejected") as PromiseRejectedResult[];
    expect(ok.length).toBe(1);
    expect(bad[0]!.reason).toMatchObject({ status: 409 });
    expect((await query("select count(*)::int n from appointments where slot_id = $1 and status = 'booked'", [slot])).rows[0]!.n).toBe(1);
    // Pengajuan yang kalah tidak meninggalkan baris yatim (transaksi dibatalkan).
    expect((await query("select count(*)::int n from service_requests where idempotency_key is not null and student_id in ($1,$2) and request_number is not null", [mhs.id, mhs2.id])).rows[0]!.n).toBeGreaterThan(0);
  });

  it("slot penuh tidak muncul di ketersediaan; kapasitas >1 mengizinkan beberapa peserta", async () => {
    const svc = await serviceBySlug("konsultasi-dosen-wali");
    const slot = await makeSlot(dosen2, { hoursAhead: 96, capacity: 2 });
    const m3 = await makeUser({ role: "mahasiswa" });
    const m4 = await makeUser({ role: "mahasiswa" });
    const m5 = await makeUser({ role: "mahasiswa" });
    await createServiceRequest(m3, { service_id: svc.id, slot_id: slot }, "cap-1", ip);
    expect((await listAvailability({ serviceId: svc.id })).some((s) => s.id === slot)).toBe(true);
    await createServiceRequest(m4, { service_id: svc.id, slot_id: slot }, "cap-2", ip);
    expect((await listAvailability({ serviceId: svc.id })).some((s) => s.id === slot)).toBe(false);
    await expect(createServiceRequest(m5, { service_id: svc.id, slot_id: slot }, "cap-3", ip)).rejects.toMatchObject({ code: "slot_full" });
  });

  it("trigger database menolak pelampauan kapasitas meskipun lewat SQL langsung", async () => {
    const svc = await serviceBySlug("konsultasi-dosen-wali");
    const slot = await makeSlot(dosen, { hoursAhead: 120 });
    const m = await makeUser({ role: "mahasiswa" });
    const r = await createServiceRequest(m, { service_id: svc.id, slot_id: slot }, "trg-1", ip);
    const other = await makeUser({ role: "mahasiswa" });
    const r2 = await query<{ id: string }>("insert into service_requests (request_number, student_id, service_id) values ('PE-X-1', $1, $2) returning id", [other.id, svc.id]);
    await expect(
      query("insert into appointments (request_id, slot_id, student_id, staff_id, starts_at, ends_at) select $1, id, $2, staff_id, starts_at, ends_at from availability_slots where id = $3", [r2.rows[0]!.id, other.id, slot]),
    ).rejects.toThrow(/slot_full/);
    expect(r.id).toBeTruthy();
  });

  it("slot terlalu dekat atau tidak berlaku untuk layanan ditolak; bentrok jadwal mahasiswa sendiri ditolak", async () => {
    const svc = await serviceBySlug("konsultasi-dosen-wali");
    const soon = await makeSlot(dosen, { hoursAhead: 0 });
    const m = await makeUser({ role: "mahasiswa" });
    await expect(createServiceRequest(m, { service_id: svc.id, slot_id: soon }, "soon", ip)).rejects.toMatchObject({ code: "slot_too_soon" });
    const s1 = await makeSlot(dosen, { hoursAhead: 150 });
    const s2 = await makeSlot(dosen2, { hoursAhead: 150 });
    await createServiceRequest(m, { service_id: svc.id, slot_id: s1 }, "clash-1", ip);
    await expect(createServiceRequest(m, { service_id: svc.id, slot_id: s2 }, "clash-2", ip)).rejects.toMatchObject({ code: "student_clash" });
    const wrong = await serviceBySlug("bimbingan-skripsi");
    const slotOtherSvc = await makeSlot(dosen, { hoursAhead: 180, serviceSlug: "konsultasi-metodologi" });
    await expect(createServiceRequest(await makeUser({ role: "mahasiswa" }), { service_id: wrong.id, slot_id: slotOtherSvc }, "wrong-svc", ip)).rejects.toMatchObject({ status: 422 });
  });

  it("staf membuat slot lewat API domain: validasi waktu dan tumpang tindih", async () => {
    const d = new Date(Date.now() + 10 * 86400_000);
    const date = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta" }).format(d);
    const id = await createSlot(dosen2, { date, start: "09:00", end: "10:00", mode: "online" });
    expect(id).toBeTruthy();
    await expect(createSlot(dosen2, { date, start: "09:30", end: "10:30", mode: "online" })).rejects.toMatchObject({ code: "slot_overlap" });
    await expect(createSlot(dosen2, { date, start: "11:00", end: "10:00", mode: "online" })).rejects.toMatchObject({ status: 422 });
    await expect(createSlot(dosen2, { date: "2020-01-01", start: "09:00", end: "10:00", mode: "online" })).rejects.toMatchObject({ status: 422 });
  });
});

describe("status & histori", () => {
  let reqId: string;
  beforeAll(async () => {
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    reqId = (await createServiceRequest(await makeUser({ role: "mahasiswa" }), { service_id: svc.id }, "st-1", ip)).id;
  });

  it("transisi valid tercatat di histori dan memberi notifikasi ke mahasiswa", async () => {
    await changeStatus(petugas, reqId, "under_review", undefined, ip);
    await changeStatus(petugas, reqId, "in_progress", undefined, ip);
    await changeStatus(petugas, reqId, "completed", "Surat siap diambil", ip);
    const h = await query("select from_status, to_status from request_status_history where request_id = $1 order by created_at, id", [reqId]);
    expect(h.rows.map((r) => `${r.from_status ?? "-"}>${r.to_status}`)).toEqual(["->submitted", "submitted>under_review", "under_review>in_progress", "in_progress>completed"]);
    const done = (await query("select status, completed_at from service_requests where id = $1", [reqId])).rows[0]!;
    expect(done.status).toBe("completed");
    expect(done.completed_at).not.toBeNull();
  });

  it("transisi tidak valid ditolak (mis. dari selesai atau melompati tahap)", async () => {
    await expect(changeStatus(petugas, reqId, "under_review", undefined, ip)).rejects.toMatchObject({ code: "invalid_transition" });
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    const fresh = (await createServiceRequest(await makeUser({ role: "mahasiswa" }), { service_id: svc.id }, "st-2", ip)).id;
    await expect(changeStatus(petugas, fresh, "completed", undefined, ip)).rejects.toMatchObject({ code: "invalid_transition" });
    await expect(changeStatus(petugas, fresh, "rejected", undefined, ip)).rejects.toMatchObject({ status: 422 }); // catatan wajib
    await expect(changeStatus(petugas, fresh, "awaiting_payment", "x", ip)).rejects.toMatchObject({ status: 409 }); // layanan gratis
  });

  it("mahasiswa tidak dapat mengubah status lewat jalur staf; staf lain yang tidak ditugaskan ditolak", async () => {
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    const m = await makeUser({ role: "mahasiswa" });
    const r = await createServiceRequest(m, { service_id: svc.id }, "st-3", ip);
    await expect(changeStatus(m, r.id, "completed", undefined, ip)).rejects.toMatchObject({ status: 403 }); // pemilik melihat kasusnya, tapi tanpa hak kelola
    await expect(changeStatus(dosen, r.id, "under_review", undefined, ip)).rejects.toMatchObject({ status: 404 }); // staf yang tidak ditugaskan: keberadaan tidak bocor
    await expect(changeStatus(admin, r.id, "under_review", undefined, ip)).resolves.toMatchObject({ to: "under_review" });
  });

  it("mahasiswa membatalkan sendiri hanya saat status membolehkan; jadwal dilepas", async () => {
    const svc = await serviceBySlug("konsultasi-dosen-wali");
    const m = await makeUser({ role: "mahasiswa" });
    const slot = await makeSlot(dosen, { hoursAhead: 300 });
    const r = await createServiceRequest(m, { service_id: svc.id, slot_id: slot }, "cx-1", ip);
    await cancelByStudent(m, r.id, "Berhalangan", ip);
    expect((await query("select status from service_requests where id = $1", [r.id])).rows[0]!.status).toBe("cancelled");
    expect((await query("select count(*)::int n from appointments where slot_id = $1 and status = 'booked'", [slot])).rows[0]!.n).toBe(0);
    await expect(cancelByStudent(m, r.id, undefined, ip)).rejects.toMatchObject({ code: "not_cancellable" });
    // slot bisa dipesan lagi
    const again = await createServiceRequest(await makeUser({ role: "mahasiswa" }), { service_id: svc.id, slot_id: slot }, "cx-2", ip);
    expect(again.id).toBeTruthy();
  });

  it("penjadwalan ulang oleh dosen memindahkan janji dan memberi tahu mahasiswa", async () => {
    const svc = await serviceBySlug("konsultasi-dosen-wali");
    const m = await makeUser({ role: "mahasiswa" });
    const s1 = await makeSlot(dosen, { hoursAhead: 400 });
    const s2 = await makeSlot(dosen, { hoursAhead: 410 });
    const r = await createServiceRequest(m, { service_id: svc.id, slot_id: s1 }, "rs-1", ip);
    await rescheduleAppointment(dosen, r.id, s2, "Bentrok rapat", ip);
    const a = await query("select slot_id, status from appointments where request_id = $1 order by created_at", [r.id]);
    expect(a.rows.map((x) => `${x.status}`)).toEqual(["cancelled", "booked"]);
    expect(a.rows[1]!.slot_id).toBe(s2);
    expect((await query("select count(*)::int n from notifications where user_id = $1 and type = 'rescheduled'", [m.id])).rows[0]!.n).toBe(1);
  });

  it("umpan balik hanya setelah selesai dan hanya sekali", async () => {
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    const m = await makeUser({ role: "mahasiswa" });
    const r = await createServiceRequest(m, { service_id: svc.id }, "fb-1", ip);
    await expect(submitFeedback(m, r.id, 5, "bagus")).rejects.toMatchObject({ status: 409 });
    await changeStatus(petugas, r.id, "under_review", undefined, ip);
    await changeStatus(petugas, r.id, "in_progress", undefined, ip);
    await changeStatus(petugas, r.id, "completed", undefined, ip);
    await submitFeedback(m, r.id, 5, "bagus");
    await expect(submitFeedback(m, r.id, 4, "lagi")).rejects.toMatchObject({ status: 409 });
  });
});

describe("pembatasan akses data pengguna lain", () => {
  it("mahasiswa tidak dapat melihat/menulis ke pengajuan mahasiswa lain (404, bukan 403)", async () => {
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    const owner = await makeUser({ role: "mahasiswa" });
    const stranger = await makeUser({ role: "mahasiswa" });
    const r = await createServiceRequest(owner, { service_id: svc.id }, "acc-1", ip);
    await expect(getRequestDetail(stranger, r.id)).rejects.toMatchObject({ status: 404 });
    await expect(addMessage(stranger, r.id, "halo", "student", ip)).rejects.toMatchObject({ status: 404 });
    await expect(cancelByStudent(stranger, r.id, undefined, ip)).rejects.toMatchObject({ status: 404 });
    const mine = await listRequests(stranger, { as: "student" });
    expect(mine.items.some((i) => i.id === r.id)).toBe(false);
  });

  it("dosen hanya melihat kasus yang ditugaskan; admin melihat semua; mahasiswa tidak bisa memakai daftar staf", async () => {
    const m = await makeUser({ role: "mahasiswa" });
    const svcW = await serviceBySlug("konsultasi-dosen-wali");
    const slot = await makeSlot(dosen2, { hoursAhead: 500 });
    const r = await createServiceRequest(m, { service_id: svcW.id, slot_id: slot }, "vis-1", ip);
    const dosen1List = await listRequests(dosen, { as: "staff", size: 100 });
    const dosen2List = await listRequests(dosen2, { as: "staff", size: 100 });
    const adminList = await listRequests(admin, { as: "staff", size: 100 });
    expect(dosen2List.items.some((i) => i.id === r.id)).toBe(true);
    expect(dosen1List.items.some((i) => i.id === r.id)).toBe(false);
    expect(adminList.items.some((i) => i.id === r.id)).toBe(true);
    await expect(listRequests(m, { as: "staff" })).rejects.toMatchObject({ status: 403 });
    await expect(getRequestDetail(dosen, r.id)).rejects.toMatchObject({ status: 404 });
  });

  it("catatan internal tidak terlihat oleh mahasiswa; mahasiswa tidak dapat membuat catatan internal", async () => {
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    const m = await makeUser({ role: "mahasiswa" });
    const r = await createServiceRequest(m, { service_id: svc.id }, "int-1", ip);
    await addMessage(petugas, r.id, "Catatan rahasia staf", "internal", ip);
    await addMessage(petugas, r.id, "Balasan untuk mahasiswa", "student", ip);
    await expect(addMessage(m, r.id, "coba internal", "internal", ip)).rejects.toMatchObject({ status: 403 });
    const asStudent = await getRequestDetail(m, r.id);
    const asStaff = await getRequestDetail(petugas, r.id);
    expect(asStudent.messages.map((x) => x.body)).toEqual(["Balasan untuk mahasiswa"]);
    expect(asStaff.messages.length).toBe(2);
    expect(asStudent.abilities.nextStatuses).toEqual([]);
    expect(asStaff.abilities.nextStatuses.length).toBeGreaterThan(0);
  });

  it("pencarian dan pagination daftar pengajuan", async () => {
    const m = await makeUser({ role: "mahasiswa", name: "Zulkifli Unik" });
    const svc = await serviceBySlug("surat-keterangan-mahasiswa");
    for (let i = 0; i < 5; i++) await createServiceRequest(m, { service_id: svc.id, student_note: `p${i}` }, `pg-${i}`, ip);
    const p1 = await listRequests(admin, { as: "staff", q: "Zulkifli", size: 2, page: 1 });
    const p3 = await listRequests(admin, { as: "staff", q: "Zulkifli", size: 2, page: 3 });
    expect(p1.total).toBe(5);
    expect(p1.items.length).toBe(2);
    expect(p1.totalPages).toBe(3);
    expect(p3.items.length).toBe(1);
    expect((await listRequests(admin, { as: "staff", q: "%" })).total).toBe(0); // wildcard di-escape
    const byStatus = await listRequests(admin, { as: "staff", status: "completed", size: 100 });
    expect(byStatus.items.every((i) => i.status === "completed")).toBe(true);
  });
});
