import { createHmac } from "node:crypto";
import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { query } from "@/server/db";
import { processDueJobs, enqueueAppointmentReminders } from "@/server/jobs";
import { notify } from "@/server/notify";
import { dbq } from "@/server/db";
import { sendWhatsappTemplate, verifyWebhookChallenge, verifyWebhookSignature, processWhatsappWebhook, sanitizeParam } from "@/server/integrations/whatsapp";
import { clearOutbox, getOutbox } from "@/server/integrations/email";
import { createServiceRequest } from "@/server/domain/requests";
import { updatePreferences } from "@/server/domain/profile";
import { assign, loadUser, makeSlot, makeUser, serviceBySlug, setupDb } from "./helpers";
import type { SessionUser } from "@/server/auth/types";

const ip = { ip: "127.0.0.1" };
const SECRET = "wa-app-secret";
const sign = (body: string) => "sha256=" + createHmac("sha256", SECRET).update(body).digest("hex");

let dosen: SessionUser, mhs: SessionUser;

async function approveTemplates(on = true) {
  await query("update whatsapp_templates set status = $1, is_active = $2", [on ? "approved" : "draft", on]);
}
const okFetch = (id = "wamid.TEST1") =>
  vi.fn(async () => new Response(JSON.stringify({ messages: [{ id }] }), { status: 200, headers: { "Content-Type": "application/json" } })) as unknown as typeof fetch;

beforeAll(async () => {
  await setupDb();
  dosen = await makeUser({ role: "dosen", wa: "628111222333", waVerified: true });
  mhs = await makeUser({ role: "mahasiswa", wa: "628999888777" });
  await assign("konsultasi-dosen-wali", dosen);
  await updatePreferences(dosen, { email_enabled: true, whatsapp_enabled: true, reminders_enabled: true });
  dosen = await loadUser(dosen.id);
});
beforeEach(async () => {
  await query("delete from notification_jobs");
  await query("delete from integration_message_logs");
  clearOutbox();
});

let slotCounter = 0;
async function newRequest(key: string) {
  const svc = await serviceBySlug("konsultasi-dosen-wali");
  const slot = await makeSlot(dosen, { hoursAhead: 24 * 20 + ++slotCounter * 2 });
  const m = await makeUser({ role: "mahasiswa" });
  return createServiceRequest(m, { service_id: svc.id, slot_id: slot }, key, ip);
}

describe("antrean notifikasi", () => {
  it("pengajuan baru mengantrekan email + WhatsApp ke dosen sesuai preferensi dan persetujuan", async () => {
    await newRequest("n-1");
    const jobs = await query("select channel, template, payload from notification_jobs where user_id = $1 order by channel", [dosen.id]);
    expect(jobs.rows.map((j) => j.channel)).toEqual(["email", "whatsapp"]);
    expect(jobs.rows[0]!.payload).toMatchObject({ nomor_pengajuan: expect.stringMatching(/^PE-/), layanan: "Konsultasi Dosen Wali" });
    expect(jobs.rows[0]!.payload.link).toMatch(/\/pengajuan\//); // tautan dashboard (bukan data akademik di pesan)
  });

  it("WhatsApp tidak diantrekan bila persetujuan dicabut, nomor belum diverifikasi, atau preferensi mati", async () => {
    const d2 = await makeUser({ role: "dosen", wa: "628555000111", waVerified: false });
    await assign("konsultasi-dosen-wali", d2);
    await updatePreferences(d2, { email_enabled: true, whatsapp_enabled: true, reminders_enabled: true });
    const slot = await makeSlot(d2, { hoursAhead: 24 * 30 + 3 });
    const svc = await serviceBySlug("konsultasi-dosen-wali");
    await createServiceRequest(await makeUser({ role: "mahasiswa" }), { service_id: svc.id, slot_id: slot }, "n-2", ip);
    const j = await query("select channel from notification_jobs where user_id = $1", [d2.id]);
    expect(j.rows.map((x) => x.channel)).toEqual(["email"]); // nomor staf belum diverifikasi pengelola

    await updatePreferences(dosen, { email_enabled: true, whatsapp_enabled: false, reminders_enabled: true });
    await newRequest("n-3");
    expect((await query("select count(*)::int n from notification_jobs where user_id = $1 and channel = 'whatsapp'", [dosen.id])).rows[0]!.n).toBe(0);
    await updatePreferences(dosen, { email_enabled: true, whatsapp_enabled: true, reminders_enabled: true });
  });

  it("email: terkirim (simulasi di provider log) dan tercatat di log", async () => {
    await newRequest("n-4");
    const r = await processDueJobs({ limit: 50 });
    expect(r.sent).toBeGreaterThanOrEqual(1);
    const mail = getOutbox().find((m) => m.to === dosen.email);
    expect(mail?.subject).toMatch(/Pengajuan baru PE-/);
    const log = (await query("select status, provider from integration_message_logs where channel = 'email' and recipient = $1", [dosen.email])).rows[0]!;
    expect(log).toMatchObject({ status: "sent", provider: "log" });
  });

  it("WhatsApp: tanpa template yang disetujui → dilewati (skipped), bukan gagal", async () => {
    await approveTemplates(false);
    await newRequest("n-5");
    const f = okFetch();
    await processDueJobs({ limit: 50, fetchImpl: f });
    expect(f).not.toHaveBeenCalled();
    const j = (await query("select status, last_error from notification_jobs where channel = 'whatsapp' and user_id = $1", [dosen.id])).rows[0]!;
    expect(j).toMatchObject({ status: "skipped", last_error: "template_not_approved" });
  });

  it("WhatsApp: mengirim template yang disetujui dengan parameter berurutan, token di header, dan menyimpan ID pesan", async () => {
    await approveTemplates(true);
    await newRequest("n-6");
    const f = okFetch("wamid.ABC");
    await processDueJobs({ limit: 50, fetchImpl: f });
    expect(f).toHaveBeenCalledTimes(1);
    const [url, init] = (f as unknown as ReturnType<typeof vi.fn>).mock.calls[0] as [string, RequestInit];
    expect(url).toBe("https://graph.facebook.com/v21.0/123456/messages");
    expect((init.headers as Record<string, string>).Authorization).toBe("Bearer test-token");
    const body = JSON.parse(init.body as string);
    expect(body).toMatchObject({ messaging_product: "whatsapp", to: "628111222333", type: "template", template: { name: "pe_pengajuan_baru_staf", language: { code: "id" } } });
    const params = body.template.components[0].parameters.map((p: { text: string }) => p.text);
    expect(params[0]).toBe(dosen.fullName);
    expect(params[1]).toMatch(/^PE-/);
    expect(params[2]).toBe("Konsultasi Dosen Wali");
    const log = (await query("select status, provider_message_id from integration_message_logs where channel = 'whatsapp'")).rows[0]!;
    expect(log).toMatchObject({ status: "sent", provider_message_id: "wamid.ABC" });
  });

  it("kegagalan sementara di-retry dengan backoff; setelah batas percobaan menjadi 'dead'; galat permanen tidak di-retry", async () => {
    await approveTemplates(true);
    await newRequest("n-7");
    const fail503 = vi.fn(async () => new Response(JSON.stringify({ error: { message: "Service unavailable" } }), { status: 503 })) as unknown as typeof fetch;
    const r1 = await processDueJobs({ limit: 50, fetchImpl: fail503 });
    expect(r1.retried).toBe(1);
    let j = (await query("select status, attempts, last_error, next_attempt_at > now() as later from notification_jobs where channel = 'whatsapp'")).rows[0]!;
    expect(j).toMatchObject({ status: "failed", attempts: 1, later: true });
    expect(j.last_error).toContain("503");
    // Belum jatuh tempo → tidak diproses ulang.
    expect((await processDueJobs({ limit: 50, fetchImpl: fail503 })).claimed).toBe(0);
    // Paksa jatuh tempo berulang sampai habis.
    for (let i = 0; i < 6; i++) {
      await query("update notification_jobs set next_attempt_at = now() where channel = 'whatsapp' and status = 'failed'");
      await processDueJobs({ limit: 50, fetchImpl: fail503 });
    }
    j = (await query("select status, attempts from notification_jobs where channel = 'whatsapp'")).rows[0]! as never;
    expect(j).toMatchObject({ status: "dead", attempts: 5 });
    expect((await query("select count(*)::int n from integration_message_logs where channel = 'whatsapp' and status = 'failed'")).rows[0]!.n).toBe(5);

    await query("delete from notification_jobs");
    await newRequest("n-8");
    const bad400 = vi.fn(async () => new Response(JSON.stringify({ error: { message: "Invalid parameter" } }), { status: 400 })) as unknown as typeof fetch;
    const r2 = await processDueJobs({ limit: 50, fetchImpl: bad400 });
    expect(r2.dead).toBe(1);
    expect((await query("select attempts from notification_jobs where channel = 'whatsapp'")).rows[0]!.attempts).toBe(1);
  });

  it("pekerja serentak tidak mengirim pesan yang sama dua kali (SKIP LOCKED + status processing)", async () => {
    await approveTemplates(true);
    await newRequest("n-9");
    const f = okFetch("wamid.ONCE");
    await Promise.all([processDueJobs({ limit: 50, fetchImpl: f }), processDueJobs({ limit: 50, fetchImpl: f })]);
    expect(f).toHaveBeenCalledTimes(1);
  });

  it("persetujuan dicabut setelah antre → pesan dilewati saat pengiriman", async () => {
    await approveTemplates(true);
    await newRequest("n-10");
    await updatePreferences(dosen, { email_enabled: true, whatsapp_enabled: false, reminders_enabled: true });
    const f = okFetch();
    await processDueJobs({ limit: 50, fetchImpl: f });
    expect(f).not.toHaveBeenCalled();
    expect((await query("select last_error from notification_jobs where channel = 'whatsapp' and user_id = $1", [dosen.id])).rows[0]!.last_error).toBe("consent_revoked");
    await updatePreferences(dosen, { email_enabled: true, whatsapp_enabled: true, reminders_enabled: true });
  });

  it("deduplikasi: kunci yang sama tidak membuat pekerjaan ganda", async () => {
    await notify(dbq, { userId: dosen.id, type: "t", title: "x", template: "request_new_staff", vars: { nomor_pengajuan: "PE-1", layanan: "L", jadwal: "J" }, dedupe: "dup-1" });
    await notify(dbq, { userId: dosen.id, type: "t", title: "x", template: "request_new_staff", vars: { nomor_pengajuan: "PE-1", layanan: "L", jadwal: "J" }, dedupe: "dup-1" });
    expect((await query("select count(*)::int n from notification_jobs where dedupe_key like 'dup-1:%'")).rows[0]!.n).toBe(2); // 1 email + 1 whatsapp
  });

  it("pengingat jadwal: hanya janji ≤24 jam, sekali saja (idempoten)", async () => {
    const svc = await serviceBySlug("konsultasi-dosen-wali");
    const near = await makeSlot(dosen, { hoursAhead: 12 });
    const m = await makeUser({ role: "mahasiswa" });
    await createServiceRequest(m, { service_id: svc.id, slot_id: near }, "rem-1", ip);
    await query("delete from notification_jobs");
    const a = await enqueueAppointmentReminders();
    const b = await enqueueAppointmentReminders();
    expect(a).toBeGreaterThanOrEqual(1);
    expect(b).toBe(0);
    const j = await query("select template from notification_jobs where template = 'appointment_reminder'");
    expect(j.rowCount).toBeGreaterThanOrEqual(1);
  });
});

describe("webhook WhatsApp", () => {
  it("verifikasi langganan: token benar → challenge; salah → null", () => {
    expect(verifyWebhookChallenge(new URLSearchParams({ "hub.mode": "subscribe", "hub.verify_token": "wa-verify", "hub.challenge": "12345" }))).toBe("12345");
    expect(verifyWebhookChallenge(new URLSearchParams({ "hub.mode": "subscribe", "hub.verify_token": "salah", "hub.challenge": "12345" }))).toBeNull();
    expect(verifyWebhookChallenge(new URLSearchParams({ "hub.mode": "subscribe", "hub.challenge": "12345" }))).toBeNull();
  });

  it("tanda tangan: valid diterima; salah, hilang, atau badan diubah ditolak", () => {
    const body = JSON.stringify({ a: 1 });
    expect(verifyWebhookSignature(body, sign(body))).toBe(true);
    expect(verifyWebhookSignature(body + " ", sign(body))).toBe(false);
    expect(verifyWebhookSignature(body, "sha256=" + "0".repeat(64))).toBe(false);
    expect(verifyWebhookSignature(body, null)).toBe(false);
    expect(verifyWebhookSignature(body, "md5=abc")).toBe(false);
    expect(verifyWebhookSignature(body, sign(body), "")).toBe(false); // secret belum diatur → selalu tolak
  });

  async function seedLog(id: string) {
    await query(`insert into integration_message_logs (channel, provider, recipient, template, status, provider_message_id) values ('whatsapp','whatsapp_cloud_api','628111222333','x','sent',$1)`, [id]);
  }
  const statusPayload = (id: string, status: string) => ({ entry: [{ changes: [{ value: { statuses: [{ id, status, recipient_id: "628111222333" }] } }] }] });

  it("status pengiriman memperbarui log; urutan mundur diabaikan; event duplikat tidak diproses dua kali", async () => {
    await seedLog("wamid.S1");
    const r1 = await processWhatsappWebhook(statusPayload("wamid.S1", "delivered"), true);
    expect(r1).toEqual({ processed: 1, duplicates: 0 });
    const dup = await processWhatsappWebhook(statusPayload("wamid.S1", "delivered"), true);
    expect(dup).toEqual({ processed: 0, duplicates: 1 });
    await processWhatsappWebhook(statusPayload("wamid.S1", "read"), true);
    await processWhatsappWebhook(statusPayload("wamid.S1", "sent"), true); // datang terlambat
    expect((await query("select status from integration_message_logs where provider_message_id = 'wamid.S1'")).rows[0]!.status).toBe("read");
    expect((await query("select count(*)::int n from webhook_events where event_id like 'status:wamid.S1:%'")).rows[0]!.n).toBe(3);
  });

  it("status gagal menyimpan alasan galat", async () => {
    await seedLog("wamid.F1");
    await processWhatsappWebhook({ entry: [{ changes: [{ value: { statuses: [{ id: "wamid.F1", status: "failed", errors: [{ message: "Nomor tidak terdaftar WhatsApp" }] }] } }] }] }, true);
    expect((await query("select status, error from integration_message_logs where provider_message_id = 'wamid.F1'")).rows[0]!).toMatchObject({ status: "failed", error: "Nomor tidak terdaftar WhatsApp" });
  });

  it("balasan 'STOP' mencabut persetujuan notifikasi WhatsApp pengguna", async () => {
    const u = await makeUser({ role: "mahasiswa", wa: "628777666555" });
    await updatePreferences(u, { email_enabled: true, whatsapp_enabled: true, reminders_enabled: true });
    await processWhatsappWebhook({ entry: [{ changes: [{ value: { messages: [{ id: "wamid.IN1", from: "628777666555", type: "text", text: { body: " STOP " } }] } }] }] }, true);
    expect((await query("select whatsapp_enabled from notification_preferences where user_id = $1", [u.id])).rows[0]!.whatsapp_enabled).toBe(false);
    const c = await query("select granted from consents where user_id = $1 and consent_type = 'whatsapp' order by created_at desc limit 1", [u.id]);
    expect(c.rows[0]!.granted).toBe(false);
  });

  it("parameter template dibersihkan dari baris baru (aturan Cloud API)", () => {
    expect(sanitizeParam("a\nb\t c   d")).toBe("a b c d");
    expect(sanitizeParam("")).toBe("-");
  });

  it("tanpa token/ID nomor, pengiriman ditolak sebagai 'belum dikonfigurasi' (bukan dianggap sukses)", async () => {
    const saved = process.env.WHATSAPP_ACCESS_TOKEN;
    process.env.WHATSAPP_ACCESS_TOKEN = "";
    await expect(sendWhatsappTemplate({ to: "628111", templateName: "t", language: "id", params: [] })).rejects.toMatchObject({ notConfigured: true });
    process.env.WHATSAPP_ACCESS_TOKEN = saved;
  });
});
